




$('#select-all').click(function(event) {   
    if(this.checked) {
        // Iterate each checkbox
        $(':checkbox').each(function() {
            this.checked = true;                        
        });
    }else{
      $(':checkbox').each(function() {
            this.checked = false;                        
        });
    }
});





$('#subject').change(function(){
  /*alert('its works');*/
    $.ajax({
        url: myUrl+"Exam_Controller/get_all_chapter_by_id",
        data: { id: $("#subject").val() },
        dataType:"html",
        type: "post",
        success: function(data){
        $('#result').empty().append(data);
        }
    });
});

$('#question').change(function(){
  /*alert('its works');*/
    $.ajax({
        url: myUrl+"Question_Controller/get_all_chapter",
        data: { id: $("#question").val() },
        dataType:"html",
        type: "post",
        success: function(data){
        $('#result').empty().append(data);
        }
    });
});



	
$(document).ready(function(){
    $('#dobPicker').datepicker({
      startView: 2,
      todayBtn: "linked",
      keyboardNavigation: false,
      forceParse: false,
      autoclose: true,
      format: "dd-mm-yyyy"
  });   
});


 var numberOnly = function(selector){
    $(selector).bind('keypress', function (e) {
        if (e.keyCode == '9' || e.keyCode == '16') { return;}
        var code;
        if (e.keyCode) code = e.keyCode;
        else if (e.which) code = e.which;
        if (e.which == 46) return false;
        if (code == 8 || code == 46) return true;
        if (code < 48 || code > 57) return false;
    });
    
    $(selector).bind("paste", function (e) {
        e.preventDefault();
    });
    $(selector).bind('mouseenter', function (e) {
        var val = $(this).val();
        if (val != '0') {
            val = val.replace(/[^0-9]+/g, "");
            $(this).val(val);
        }
    });
}

numberOnly('.quantity');
//numberOnly('#quantity');
// numberOnly('input[type=text]');
    

 
function PreviewImage() {
    var oFReader = new FileReader();
    oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);

    oFReader.onload = function (oFREvent) {
        document.getElementById("uploadPreview").src = oFREvent.target.result;
    };
};

 
function phonenumber(inputtxt)  
{ 
 var input = document.getElementById(inputtxt);
  var phoneno =/^(011|015|016|017|018|019)\d{8}$/;  
  if(input.value.match(phoneno))  
        {  
      return true;  
        }  
      else  
        {  
    alert('Please insert valid mobile number');  
        return false;  
        }  
}
