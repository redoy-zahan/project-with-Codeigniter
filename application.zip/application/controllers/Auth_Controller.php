<?php 
/**
* User authentication check here:
*/
class Auth_Controller extends Admin_Controller
{
	
	public function __construct()
	{
		parent::__construct();

	}

//Load login view: 
#if session exist the user can't land in this login view:	
	public function index(){
		if ($this->session->userdata('logged_in')==true) {
			//var_dump($this->session->userdata('userType'));
			//die();
			if ($this->session->userdata('userType')==1)
			{
			$url = base_url('Welcome');
			parent::Fredirect($url);
			}else{
			$url = base_url('Stud_Controller');
			parent::Fredirect($url);
			}
		}else{
  		$this->load->view('user/login');
  		}
	
	}

#checking user acces and if user valid give access user to login:
#create session
	public function loginUser(){
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$this->load->model('User_Model');
		$row = $this->User_Model->userLogin($email, $password);
		//var_dump($row);
		//exit();
		if ($row > 0) {
			//var_dump($email);
			//exit();
			$user =$this->User_Model->userData($email);
			//var_dump($user);
			//exit();
			foreach ($user as $row)
				{
				       $id       = $row->id;
				       $userType = $row->user_type;
				}
							
				$this->session->set_userdata('logged_in', true);
				$this->session->set_userdata('id', $id);
				$this->session->set_userdata('userType', $userType);

			if ($userType==1) {
				$url =base_url('Welcome');
				header("Location:$url");
			}else {
				$url =base_url('Stud_Controller');
				header("Location:$url");
			}
			
		}else{
			$msg['msg']="Sorry your email or password is incorrect!";
			$this->load->view('user/login', $msg);
		}
		
	}

#logout function used for destroy session:
	public function logout(){
		$this->load->library('session');
		$this->session->unset_userdata('id');
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('userName');
		$this->session->unset_userdata('userType');
		unset($_SESSION);
    	session_destroy();
    	
		$url=base_url("/");
		parent::Fredirect($url);
	}

}