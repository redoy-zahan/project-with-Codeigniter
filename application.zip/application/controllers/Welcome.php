<?php

class Welcome extends Admin_Controller {

	public function __construct(){
		parent::__construct();
		parent::checkUser();
	}

	public function index() {
	#load middle view:
		$this->load->model('Admin_Model');
		$allUser['allUsers'] = $this->Admin_Model->get_all_user();
		$this->middle = 'admin/index';
	    #pass paramitter:
	    $this->data =$allUser;
	    $this->layout();
    }

    function deleteUser (){

		 $id = base64_decode($this->uri->segment('3'));
		 /*var_dump($id);
		 exit();*/

		 $this->load->model('Admin_Model');
		 $delate = $this->Admin_Model->userDelate($id);
		
		if($delate==true)
		 {
		 	$this->session->set_flashdata('msg', 'Delate Successful');
		 	$this->session->set_flashdata('alert', 'success');
		 	$url = base_url('Welcome/index');
			 return redirect($url);
		 }
    }



#end class bracket:
}
