<?php

class Home extends Student_Controller {

	public function __construct(){
		parent::__construct();
		//parent::checkUser();
	}

	public function index() {
	#load middle view:
		$this->middle = 'user/home';
	    #pass paramitter:
	    $this->layout();
    }

    public function donate()
    {
    	$this->middle = 'user/donate' ;
    	$this->layout();
    }

    public function need()
    {
    	$this->middle = 'user/need' ;
    	$this->layout();
    }

    public function contact()
    {
    	$this->middle = 'user/contact' ;
    	$this->layout();
    }

#end class bracket:
}
