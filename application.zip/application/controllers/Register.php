<?php
class Register extends Student_Controller
{
	public function index(){
		return $this->load->view('user/register');

	}

	public function registerUser(){

		if (isset($_POST['register'])) {

			/*var_dump($_POST);
			exit();*/
			
			$data = array(
				'user_type' => 2,
				'name' => $this->input->post('name') ,
				'email' => $this->input->post('email') ,
				'gender' => $this->input->post('gender') ,
				'blood_group' => $this->input->post('blood_group') ,
				'phone' => $this->input->post('phone') ,
				'dob' => $this->input->post('dob') ,
				'weight' => $this->input->post('weight') ,
				'country' => $this->input->post('country') 

			 );

			/*var_dump($data);
			exit();
*/
			$this->load->model('User_Model');
			$insert = $this->User_Model->registerData($data);
			if ($insert==true) {
				$this->session->set_flashdata('message', 'Registration Successful');
				$this->load->view('user/login');
			}

		}

	}


}

?>