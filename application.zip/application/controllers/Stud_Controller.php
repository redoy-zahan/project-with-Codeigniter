<?php
/**

*/

class Stud_Controller extends Student_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Stud_Model');

	}

	public function index(){
		$id = $this->session->userdata('id');

		$user['user'] = $this->Stud_Model->userInfo($id);
		//print_r($user);
		//exit();
		$this->middle = 'user/user';
	    #pass paramitter:
	    $this->data = $user;
	    $this->layout();
	
	}


	public function show_info(){

		
		
		 $id = base64_decode($this->uri->segment('3'));
		 //var_dump($id);
		 //exit();
		$showData['user_info'] = $this->Stud_Model->show_user_info($id);
		$this->middle = 'user/show';
	    $this->data =$showData;
	    $this->layout();
	
	}

	function updateInfo(){

		if ($this->input->post('update')==1) {
			/*var_dump($this->input->post());
			exit();*/
			$id = $this->input->post('user_id');
			$data = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'gender' => $this->input->post('gender'),
				'dob' => $this->input->post('dob'),
				'phone' => $this->input->post('phone'),
				'country' => $this->input->post('country')
				
			);

			//var_dump($data);

			 $update = $this->Stud_Model->update_info($id,$data);
			 //exit();

			  if($update==true)
			  {	
			  	$this->session->set_flashdata('alert', 'success');
			  	$this->session->set_flashdata('msg', 'update Successful');
			  	//$this->load->view('user/user');
			  	$url = base_url('Stud_Controller/index');
			  	return redirect($url);
	

			  }
			  else
			  {
			  	$this->session->set_flashdata('alert', 'alert');
			  	$this->session->set_flashdata('msg', 'update Failed');
			  	$url = base_url('Stud_controller/show_info/').$id;
			  	return redirect($url);


			  }

			
		}




	}






}

	
	
	