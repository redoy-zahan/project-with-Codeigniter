<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-06 05:10:07 --> Config Class Initialized
INFO - 2018-04-06 05:10:07 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:10:08 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:10:08 --> Utf8 Class Initialized
INFO - 2018-04-06 05:10:08 --> URI Class Initialized
DEBUG - 2018-04-06 05:10:08 --> No URI present. Default controller set.
INFO - 2018-04-06 05:10:08 --> Router Class Initialized
INFO - 2018-04-06 05:10:08 --> Output Class Initialized
INFO - 2018-04-06 05:10:08 --> Security Class Initialized
DEBUG - 2018-04-06 05:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:10:08 --> Input Class Initialized
INFO - 2018-04-06 05:10:08 --> Language Class Initialized
INFO - 2018-04-06 05:10:08 --> Loader Class Initialized
INFO - 2018-04-06 05:10:08 --> Helper loaded: url_helper
INFO - 2018-04-06 05:10:09 --> Helper loaded: file_helper
INFO - 2018-04-06 05:10:09 --> Helper loaded: date_helper
INFO - 2018-04-06 05:10:09 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:10:09 --> Controller Class Initialized
INFO - 2018-04-06 05:10:09 --> Config Class Initialized
INFO - 2018-04-06 05:10:09 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:10:09 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:10:09 --> Utf8 Class Initialized
INFO - 2018-04-06 05:10:09 --> URI Class Initialized
INFO - 2018-04-06 05:10:09 --> Router Class Initialized
INFO - 2018-04-06 05:10:09 --> Output Class Initialized
INFO - 2018-04-06 05:10:09 --> Security Class Initialized
DEBUG - 2018-04-06 05:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:10:09 --> Input Class Initialized
INFO - 2018-04-06 05:10:10 --> Language Class Initialized
INFO - 2018-04-06 05:10:10 --> Loader Class Initialized
INFO - 2018-04-06 05:10:10 --> Helper loaded: url_helper
INFO - 2018-04-06 05:10:10 --> Helper loaded: file_helper
INFO - 2018-04-06 05:10:10 --> Helper loaded: date_helper
INFO - 2018-04-06 05:10:10 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:10:10 --> Controller Class Initialized
INFO - 2018-04-06 05:10:10 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-06 05:10:10 --> Final output sent to browser
DEBUG - 2018-04-06 05:10:10 --> Total execution time: 0.5537
INFO - 2018-04-06 05:10:22 --> Config Class Initialized
INFO - 2018-04-06 05:10:22 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:10:22 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:10:23 --> Utf8 Class Initialized
INFO - 2018-04-06 05:10:23 --> URI Class Initialized
INFO - 2018-04-06 05:10:23 --> Router Class Initialized
INFO - 2018-04-06 05:10:23 --> Output Class Initialized
INFO - 2018-04-06 05:10:23 --> Security Class Initialized
DEBUG - 2018-04-06 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:10:23 --> Input Class Initialized
INFO - 2018-04-06 05:10:23 --> Language Class Initialized
INFO - 2018-04-06 05:10:23 --> Loader Class Initialized
INFO - 2018-04-06 05:10:23 --> Helper loaded: url_helper
INFO - 2018-04-06 05:10:23 --> Helper loaded: file_helper
INFO - 2018-04-06 05:10:23 --> Helper loaded: date_helper
INFO - 2018-04-06 05:10:23 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:10:23 --> Controller Class Initialized
INFO - 2018-04-06 05:10:23 --> Model Class Initialized
ERROR - 2018-04-06 05:10:23 --> Severity: Notice --> Undefined property: stdClass::$user_name G:\xampp\htdocs\codeigniter\application\controllers\Auth_Controller.php 50
INFO - 2018-04-06 05:10:24 --> Final output sent to browser
DEBUG - 2018-04-06 05:10:24 --> Total execution time: 1.0852
INFO - 2018-04-06 05:10:24 --> Config Class Initialized
INFO - 2018-04-06 05:10:24 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:10:24 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:10:24 --> Utf8 Class Initialized
INFO - 2018-04-06 05:10:24 --> URI Class Initialized
INFO - 2018-04-06 05:10:24 --> Router Class Initialized
INFO - 2018-04-06 05:10:24 --> Output Class Initialized
INFO - 2018-04-06 05:10:24 --> Security Class Initialized
DEBUG - 2018-04-06 05:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:10:24 --> Input Class Initialized
INFO - 2018-04-06 05:10:24 --> Language Class Initialized
INFO - 2018-04-06 05:10:24 --> Loader Class Initialized
INFO - 2018-04-06 05:10:24 --> Helper loaded: url_helper
INFO - 2018-04-06 05:10:24 --> Helper loaded: file_helper
INFO - 2018-04-06 05:10:24 --> Helper loaded: date_helper
INFO - 2018-04-06 05:10:24 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:10:24 --> Controller Class Initialized
INFO - 2018-04-06 05:10:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-06 05:10:24 --> Final output sent to browser
DEBUG - 2018-04-06 05:10:24 --> Total execution time: 0.3493
INFO - 2018-04-06 05:12:38 --> Config Class Initialized
INFO - 2018-04-06 05:12:38 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:12:38 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:12:38 --> Utf8 Class Initialized
INFO - 2018-04-06 05:12:38 --> URI Class Initialized
DEBUG - 2018-04-06 05:12:38 --> No URI present. Default controller set.
INFO - 2018-04-06 05:12:38 --> Router Class Initialized
INFO - 2018-04-06 05:12:38 --> Output Class Initialized
INFO - 2018-04-06 05:12:38 --> Security Class Initialized
DEBUG - 2018-04-06 05:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:12:38 --> Input Class Initialized
INFO - 2018-04-06 05:12:38 --> Language Class Initialized
INFO - 2018-04-06 05:12:38 --> Loader Class Initialized
INFO - 2018-04-06 05:12:38 --> Helper loaded: url_helper
INFO - 2018-04-06 05:12:38 --> Helper loaded: file_helper
INFO - 2018-04-06 05:12:38 --> Helper loaded: date_helper
INFO - 2018-04-06 05:12:38 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:12:38 --> Controller Class Initialized
INFO - 2018-04-06 05:12:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:12:38 --> Final output sent to browser
DEBUG - 2018-04-06 05:12:38 --> Total execution time: 0.3097
INFO - 2018-04-06 05:12:38 --> Config Class Initialized
INFO - 2018-04-06 05:12:38 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:12:38 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:12:38 --> Utf8 Class Initialized
INFO - 2018-04-06 05:12:38 --> URI Class Initialized
INFO - 2018-04-06 05:12:38 --> Router Class Initialized
INFO - 2018-04-06 05:12:38 --> Output Class Initialized
INFO - 2018-04-06 05:12:38 --> Security Class Initialized
DEBUG - 2018-04-06 05:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:12:38 --> Input Class Initialized
INFO - 2018-04-06 05:12:38 --> Language Class Initialized
ERROR - 2018-04-06 05:12:38 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-06 05:12:38 --> Config Class Initialized
INFO - 2018-04-06 05:12:38 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:12:38 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:12:38 --> Utf8 Class Initialized
INFO - 2018-04-06 05:12:38 --> URI Class Initialized
INFO - 2018-04-06 05:12:38 --> Router Class Initialized
INFO - 2018-04-06 05:12:38 --> Output Class Initialized
INFO - 2018-04-06 05:12:38 --> Security Class Initialized
DEBUG - 2018-04-06 05:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:12:38 --> Input Class Initialized
INFO - 2018-04-06 05:12:38 --> Language Class Initialized
ERROR - 2018-04-06 05:12:38 --> 404 Page Not Found: Downloadpng/index
INFO - 2018-04-06 05:13:05 --> Config Class Initialized
INFO - 2018-04-06 05:13:05 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:13:05 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:13:05 --> Utf8 Class Initialized
INFO - 2018-04-06 05:13:05 --> URI Class Initialized
DEBUG - 2018-04-06 05:13:05 --> No URI present. Default controller set.
INFO - 2018-04-06 05:13:05 --> Router Class Initialized
INFO - 2018-04-06 05:13:05 --> Output Class Initialized
INFO - 2018-04-06 05:13:05 --> Security Class Initialized
DEBUG - 2018-04-06 05:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:13:05 --> Input Class Initialized
INFO - 2018-04-06 05:13:05 --> Language Class Initialized
INFO - 2018-04-06 05:13:05 --> Loader Class Initialized
INFO - 2018-04-06 05:13:05 --> Helper loaded: url_helper
INFO - 2018-04-06 05:13:05 --> Helper loaded: file_helper
INFO - 2018-04-06 05:13:05 --> Helper loaded: date_helper
INFO - 2018-04-06 05:13:05 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:13:05 --> Controller Class Initialized
INFO - 2018-04-06 05:13:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:13:05 --> Final output sent to browser
DEBUG - 2018-04-06 05:13:05 --> Total execution time: 0.2497
INFO - 2018-04-06 05:13:05 --> Config Class Initialized
INFO - 2018-04-06 05:13:05 --> Config Class Initialized
INFO - 2018-04-06 05:13:05 --> Hooks Class Initialized
INFO - 2018-04-06 05:13:05 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:13:05 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:13:05 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:13:05 --> Utf8 Class Initialized
INFO - 2018-04-06 05:13:05 --> Utf8 Class Initialized
INFO - 2018-04-06 05:13:05 --> URI Class Initialized
INFO - 2018-04-06 05:13:05 --> URI Class Initialized
INFO - 2018-04-06 05:13:05 --> Router Class Initialized
INFO - 2018-04-06 05:13:05 --> Router Class Initialized
INFO - 2018-04-06 05:13:05 --> Output Class Initialized
INFO - 2018-04-06 05:13:05 --> Output Class Initialized
INFO - 2018-04-06 05:13:05 --> Security Class Initialized
INFO - 2018-04-06 05:13:05 --> Security Class Initialized
DEBUG - 2018-04-06 05:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:13:05 --> Input Class Initialized
INFO - 2018-04-06 05:13:05 --> Input Class Initialized
INFO - 2018-04-06 05:13:05 --> Language Class Initialized
INFO - 2018-04-06 05:13:05 --> Language Class Initialized
ERROR - 2018-04-06 05:13:05 --> 404 Page Not Found: Css/bootstrap.min.css
ERROR - 2018-04-06 05:13:05 --> 404 Page Not Found: Downloadpng/index
INFO - 2018-04-06 05:13:41 --> Config Class Initialized
INFO - 2018-04-06 05:13:41 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:13:41 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:13:41 --> Utf8 Class Initialized
INFO - 2018-04-06 05:13:41 --> URI Class Initialized
INFO - 2018-04-06 05:13:41 --> Router Class Initialized
INFO - 2018-04-06 05:13:41 --> Output Class Initialized
INFO - 2018-04-06 05:13:41 --> Security Class Initialized
DEBUG - 2018-04-06 05:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:13:41 --> Input Class Initialized
INFO - 2018-04-06 05:13:41 --> Language Class Initialized
ERROR - 2018-04-06 05:13:41 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-06 05:13:52 --> Config Class Initialized
INFO - 2018-04-06 05:13:52 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:13:52 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:13:52 --> Utf8 Class Initialized
INFO - 2018-04-06 05:13:52 --> URI Class Initialized
DEBUG - 2018-04-06 05:13:52 --> No URI present. Default controller set.
INFO - 2018-04-06 05:13:52 --> Router Class Initialized
INFO - 2018-04-06 05:13:52 --> Output Class Initialized
INFO - 2018-04-06 05:13:52 --> Security Class Initialized
DEBUG - 2018-04-06 05:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:13:52 --> Input Class Initialized
INFO - 2018-04-06 05:13:52 --> Language Class Initialized
INFO - 2018-04-06 05:13:52 --> Loader Class Initialized
INFO - 2018-04-06 05:13:52 --> Helper loaded: url_helper
INFO - 2018-04-06 05:13:52 --> Helper loaded: file_helper
INFO - 2018-04-06 05:13:52 --> Helper loaded: date_helper
INFO - 2018-04-06 05:13:52 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:13:52 --> Controller Class Initialized
INFO - 2018-04-06 05:13:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:13:52 --> Final output sent to browser
DEBUG - 2018-04-06 05:13:52 --> Total execution time: 0.3407
INFO - 2018-04-06 05:14:03 --> Config Class Initialized
INFO - 2018-04-06 05:14:03 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:14:03 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:14:03 --> Utf8 Class Initialized
INFO - 2018-04-06 05:14:03 --> URI Class Initialized
INFO - 2018-04-06 05:14:03 --> Router Class Initialized
INFO - 2018-04-06 05:14:03 --> Output Class Initialized
INFO - 2018-04-06 05:14:03 --> Security Class Initialized
DEBUG - 2018-04-06 05:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:14:03 --> Input Class Initialized
INFO - 2018-04-06 05:14:03 --> Language Class Initialized
ERROR - 2018-04-06 05:14:03 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-06 05:32:15 --> Config Class Initialized
INFO - 2018-04-06 05:32:15 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:32:15 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:32:15 --> Utf8 Class Initialized
INFO - 2018-04-06 05:32:15 --> URI Class Initialized
DEBUG - 2018-04-06 05:32:15 --> No URI present. Default controller set.
INFO - 2018-04-06 05:32:15 --> Router Class Initialized
INFO - 2018-04-06 05:32:15 --> Output Class Initialized
INFO - 2018-04-06 05:32:15 --> Security Class Initialized
DEBUG - 2018-04-06 05:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:32:15 --> Input Class Initialized
INFO - 2018-04-06 05:32:15 --> Language Class Initialized
INFO - 2018-04-06 05:32:15 --> Loader Class Initialized
INFO - 2018-04-06 05:32:15 --> Helper loaded: url_helper
INFO - 2018-04-06 05:32:15 --> Helper loaded: file_helper
INFO - 2018-04-06 05:32:15 --> Helper loaded: date_helper
INFO - 2018-04-06 05:32:15 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:32:15 --> Controller Class Initialized
INFO - 2018-04-06 05:32:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-06 05:32:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:32:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-06 05:32:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-06 05:32:15 --> Final output sent to browser
DEBUG - 2018-04-06 05:32:15 --> Total execution time: 0.4198
INFO - 2018-04-06 05:32:15 --> Config Class Initialized
INFO - 2018-04-06 05:32:15 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:32:15 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:32:15 --> Utf8 Class Initialized
INFO - 2018-04-06 05:32:15 --> URI Class Initialized
INFO - 2018-04-06 05:32:15 --> Router Class Initialized
INFO - 2018-04-06 05:32:15 --> Config Class Initialized
INFO - 2018-04-06 05:32:15 --> Hooks Class Initialized
INFO - 2018-04-06 05:32:15 --> Output Class Initialized
INFO - 2018-04-06 05:32:15 --> Security Class Initialized
DEBUG - 2018-04-06 05:32:15 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:32:15 --> Utf8 Class Initialized
DEBUG - 2018-04-06 05:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:32:15 --> Input Class Initialized
INFO - 2018-04-06 05:32:15 --> URI Class Initialized
INFO - 2018-04-06 05:32:15 --> Language Class Initialized
INFO - 2018-04-06 05:32:15 --> Router Class Initialized
ERROR - 2018-04-06 05:32:15 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-06 05:32:15 --> Output Class Initialized
INFO - 2018-04-06 05:32:15 --> Config Class Initialized
INFO - 2018-04-06 05:32:15 --> Hooks Class Initialized
INFO - 2018-04-06 05:32:15 --> Security Class Initialized
DEBUG - 2018-04-06 05:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:32:15 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:32:16 --> Utf8 Class Initialized
INFO - 2018-04-06 05:32:16 --> Input Class Initialized
INFO - 2018-04-06 05:32:16 --> URI Class Initialized
INFO - 2018-04-06 05:32:16 --> Router Class Initialized
INFO - 2018-04-06 05:32:16 --> Output Class Initialized
INFO - 2018-04-06 05:32:16 --> Security Class Initialized
DEBUG - 2018-04-06 05:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:32:16 --> Input Class Initialized
INFO - 2018-04-06 05:32:16 --> Language Class Initialized
INFO - 2018-04-06 05:32:16 --> Language Class Initialized
ERROR - 2018-04-06 05:32:16 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-06 05:32:16 --> 404 Page Not Found: Downloadpng/index
INFO - 2018-04-06 05:32:16 --> Config Class Initialized
INFO - 2018-04-06 05:32:16 --> Config Class Initialized
INFO - 2018-04-06 05:32:16 --> Hooks Class Initialized
INFO - 2018-04-06 05:32:16 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:32:16 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:32:16 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:32:16 --> Utf8 Class Initialized
INFO - 2018-04-06 05:32:16 --> Utf8 Class Initialized
INFO - 2018-04-06 05:32:16 --> URI Class Initialized
INFO - 2018-04-06 05:32:16 --> URI Class Initialized
INFO - 2018-04-06 05:32:16 --> Router Class Initialized
INFO - 2018-04-06 05:32:16 --> Router Class Initialized
INFO - 2018-04-06 05:32:16 --> Output Class Initialized
INFO - 2018-04-06 05:32:16 --> Output Class Initialized
INFO - 2018-04-06 05:32:16 --> Security Class Initialized
INFO - 2018-04-06 05:32:16 --> Security Class Initialized
DEBUG - 2018-04-06 05:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:32:16 --> Input Class Initialized
INFO - 2018-04-06 05:32:16 --> Input Class Initialized
INFO - 2018-04-06 05:32:16 --> Language Class Initialized
INFO - 2018-04-06 05:32:16 --> Language Class Initialized
ERROR - 2018-04-06 05:32:16 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-06 05:32:16 --> 404 Page Not Found: Assets/js
INFO - 2018-04-06 05:32:29 --> Config Class Initialized
INFO - 2018-04-06 05:32:29 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:32:29 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:32:29 --> Config Class Initialized
INFO - 2018-04-06 05:32:29 --> Config Class Initialized
INFO - 2018-04-06 05:32:29 --> Hooks Class Initialized
INFO - 2018-04-06 05:32:29 --> Hooks Class Initialized
INFO - 2018-04-06 05:32:29 --> Utf8 Class Initialized
INFO - 2018-04-06 05:32:29 --> URI Class Initialized
DEBUG - 2018-04-06 05:32:29 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:32:29 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:32:29 --> Utf8 Class Initialized
INFO - 2018-04-06 05:32:29 --> Utf8 Class Initialized
INFO - 2018-04-06 05:32:29 --> Router Class Initialized
INFO - 2018-04-06 05:32:29 --> URI Class Initialized
INFO - 2018-04-06 05:32:29 --> URI Class Initialized
INFO - 2018-04-06 05:32:29 --> Output Class Initialized
INFO - 2018-04-06 05:32:29 --> Security Class Initialized
INFO - 2018-04-06 05:32:29 --> Router Class Initialized
INFO - 2018-04-06 05:32:29 --> Router Class Initialized
DEBUG - 2018-04-06 05:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:32:29 --> Output Class Initialized
INFO - 2018-04-06 05:32:29 --> Output Class Initialized
INFO - 2018-04-06 05:32:30 --> Input Class Initialized
INFO - 2018-04-06 05:32:30 --> Security Class Initialized
INFO - 2018-04-06 05:32:30 --> Security Class Initialized
INFO - 2018-04-06 05:32:30 --> Language Class Initialized
DEBUG - 2018-04-06 05:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:32:30 --> Input Class Initialized
INFO - 2018-04-06 05:32:30 --> Input Class Initialized
ERROR - 2018-04-06 05:32:30 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-06 05:32:30 --> Language Class Initialized
INFO - 2018-04-06 05:32:30 --> Language Class Initialized
ERROR - 2018-04-06 05:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-06 05:32:30 --> 404 Page Not Found: Assets/js
INFO - 2018-04-06 05:32:30 --> Config Class Initialized
INFO - 2018-04-06 05:32:30 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:32:30 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:32:30 --> Utf8 Class Initialized
INFO - 2018-04-06 05:32:30 --> URI Class Initialized
INFO - 2018-04-06 05:32:30 --> Router Class Initialized
INFO - 2018-04-06 05:32:30 --> Output Class Initialized
INFO - 2018-04-06 05:32:30 --> Security Class Initialized
DEBUG - 2018-04-06 05:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:32:30 --> Input Class Initialized
INFO - 2018-04-06 05:32:30 --> Language Class Initialized
ERROR - 2018-04-06 05:32:30 --> 404 Page Not Found: Assets/css
INFO - 2018-04-06 05:33:04 --> Config Class Initialized
INFO - 2018-04-06 05:33:04 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:33:04 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:33:04 --> Utf8 Class Initialized
INFO - 2018-04-06 05:33:04 --> URI Class Initialized
DEBUG - 2018-04-06 05:33:04 --> No URI present. Default controller set.
INFO - 2018-04-06 05:33:04 --> Router Class Initialized
INFO - 2018-04-06 05:33:05 --> Output Class Initialized
INFO - 2018-04-06 05:33:05 --> Security Class Initialized
DEBUG - 2018-04-06 05:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:33:05 --> Input Class Initialized
INFO - 2018-04-06 05:33:05 --> Language Class Initialized
INFO - 2018-04-06 05:33:05 --> Loader Class Initialized
INFO - 2018-04-06 05:33:05 --> Helper loaded: url_helper
INFO - 2018-04-06 05:33:05 --> Helper loaded: file_helper
INFO - 2018-04-06 05:33:05 --> Helper loaded: date_helper
INFO - 2018-04-06 05:33:05 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:33:05 --> Controller Class Initialized
INFO - 2018-04-06 05:33:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-06 05:33:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:33:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-06 05:33:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-06 05:33:05 --> Final output sent to browser
DEBUG - 2018-04-06 05:33:05 --> Total execution time: 0.4619
INFO - 2018-04-06 05:33:05 --> Config Class Initialized
INFO - 2018-04-06 05:33:05 --> Config Class Initialized
INFO - 2018-04-06 05:33:05 --> Hooks Class Initialized
INFO - 2018-04-06 05:33:05 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:33:05 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:33:05 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:33:05 --> Utf8 Class Initialized
INFO - 2018-04-06 05:33:05 --> Utf8 Class Initialized
INFO - 2018-04-06 05:33:05 --> URI Class Initialized
INFO - 2018-04-06 05:33:05 --> URI Class Initialized
INFO - 2018-04-06 05:33:05 --> Router Class Initialized
INFO - 2018-04-06 05:33:05 --> Router Class Initialized
INFO - 2018-04-06 05:33:05 --> Config Class Initialized
INFO - 2018-04-06 05:33:05 --> Hooks Class Initialized
INFO - 2018-04-06 05:33:05 --> Output Class Initialized
INFO - 2018-04-06 05:33:05 --> Output Class Initialized
INFO - 2018-04-06 05:33:05 --> Security Class Initialized
INFO - 2018-04-06 05:33:05 --> Security Class Initialized
DEBUG - 2018-04-06 05:33:05 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:33:05 --> Utf8 Class Initialized
DEBUG - 2018-04-06 05:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:33:05 --> Input Class Initialized
INFO - 2018-04-06 05:33:05 --> Input Class Initialized
INFO - 2018-04-06 05:33:05 --> URI Class Initialized
INFO - 2018-04-06 05:33:05 --> Language Class Initialized
INFO - 2018-04-06 05:33:05 --> Language Class Initialized
INFO - 2018-04-06 05:33:05 --> Router Class Initialized
ERROR - 2018-04-06 05:33:05 --> 404 Page Not Found: Downloadpng/index
ERROR - 2018-04-06 05:33:05 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-06 05:33:05 --> Output Class Initialized
INFO - 2018-04-06 05:33:05 --> Security Class Initialized
DEBUG - 2018-04-06 05:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:33:05 --> Input Class Initialized
INFO - 2018-04-06 05:33:05 --> Language Class Initialized
ERROR - 2018-04-06 05:33:05 --> 404 Page Not Found: Assets/css
INFO - 2018-04-06 05:33:05 --> Config Class Initialized
INFO - 2018-04-06 05:33:05 --> Config Class Initialized
INFO - 2018-04-06 05:33:05 --> Hooks Class Initialized
INFO - 2018-04-06 05:33:05 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:33:05 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:33:05 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:33:05 --> Utf8 Class Initialized
INFO - 2018-04-06 05:33:05 --> Utf8 Class Initialized
INFO - 2018-04-06 05:33:05 --> URI Class Initialized
INFO - 2018-04-06 05:33:05 --> URI Class Initialized
INFO - 2018-04-06 05:33:05 --> Router Class Initialized
INFO - 2018-04-06 05:33:05 --> Router Class Initialized
INFO - 2018-04-06 05:33:05 --> Output Class Initialized
INFO - 2018-04-06 05:33:05 --> Output Class Initialized
INFO - 2018-04-06 05:33:05 --> Security Class Initialized
INFO - 2018-04-06 05:33:05 --> Security Class Initialized
DEBUG - 2018-04-06 05:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:33:06 --> Input Class Initialized
INFO - 2018-04-06 05:33:06 --> Input Class Initialized
INFO - 2018-04-06 05:33:06 --> Language Class Initialized
INFO - 2018-04-06 05:33:06 --> Language Class Initialized
ERROR - 2018-04-06 05:33:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-06 05:33:06 --> 404 Page Not Found: Assets/js
INFO - 2018-04-06 05:33:55 --> Config Class Initialized
INFO - 2018-04-06 05:33:55 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:33:55 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:33:55 --> Utf8 Class Initialized
INFO - 2018-04-06 05:33:55 --> URI Class Initialized
DEBUG - 2018-04-06 05:33:55 --> No URI present. Default controller set.
INFO - 2018-04-06 05:33:55 --> Router Class Initialized
INFO - 2018-04-06 05:33:55 --> Output Class Initialized
INFO - 2018-04-06 05:33:55 --> Security Class Initialized
DEBUG - 2018-04-06 05:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:33:55 --> Input Class Initialized
INFO - 2018-04-06 05:33:55 --> Language Class Initialized
INFO - 2018-04-06 05:33:55 --> Loader Class Initialized
INFO - 2018-04-06 05:33:55 --> Helper loaded: url_helper
INFO - 2018-04-06 05:33:55 --> Helper loaded: file_helper
INFO - 2018-04-06 05:33:55 --> Helper loaded: date_helper
INFO - 2018-04-06 05:33:55 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:33:55 --> Controller Class Initialized
INFO - 2018-04-06 05:33:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-06 05:33:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:33:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-06 05:33:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-06 05:33:55 --> Final output sent to browser
DEBUG - 2018-04-06 05:33:55 --> Total execution time: 0.3360
INFO - 2018-04-06 05:33:55 --> Config Class Initialized
INFO - 2018-04-06 05:33:55 --> Config Class Initialized
INFO - 2018-04-06 05:33:55 --> Hooks Class Initialized
INFO - 2018-04-06 05:33:55 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:33:55 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:33:55 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:33:55 --> Utf8 Class Initialized
INFO - 2018-04-06 05:33:55 --> Utf8 Class Initialized
INFO - 2018-04-06 05:33:55 --> Config Class Initialized
INFO - 2018-04-06 05:33:55 --> Hooks Class Initialized
INFO - 2018-04-06 05:33:55 --> URI Class Initialized
INFO - 2018-04-06 05:33:55 --> URI Class Initialized
INFO - 2018-04-06 05:33:55 --> Router Class Initialized
INFO - 2018-04-06 05:33:55 --> Router Class Initialized
DEBUG - 2018-04-06 05:33:55 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:33:55 --> Utf8 Class Initialized
INFO - 2018-04-06 05:33:55 --> Output Class Initialized
INFO - 2018-04-06 05:33:55 --> Output Class Initialized
INFO - 2018-04-06 05:33:55 --> URI Class Initialized
INFO - 2018-04-06 05:33:55 --> Security Class Initialized
INFO - 2018-04-06 05:33:55 --> Security Class Initialized
DEBUG - 2018-04-06 05:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:33:55 --> Router Class Initialized
DEBUG - 2018-04-06 05:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:33:55 --> Input Class Initialized
INFO - 2018-04-06 05:33:55 --> Input Class Initialized
INFO - 2018-04-06 05:33:55 --> Output Class Initialized
INFO - 2018-04-06 05:33:55 --> Language Class Initialized
INFO - 2018-04-06 05:33:55 --> Security Class Initialized
INFO - 2018-04-06 05:33:55 --> Language Class Initialized
DEBUG - 2018-04-06 05:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-06 05:33:55 --> 404 Page Not Found: Css/bootstrap.min.css
ERROR - 2018-04-06 05:33:55 --> 404 Page Not Found: Downloadpng/index
INFO - 2018-04-06 05:33:55 --> Input Class Initialized
INFO - 2018-04-06 05:33:55 --> Language Class Initialized
ERROR - 2018-04-06 05:33:56 --> 404 Page Not Found: Assets/css
INFO - 2018-04-06 05:33:56 --> Config Class Initialized
INFO - 2018-04-06 05:33:56 --> Config Class Initialized
INFO - 2018-04-06 05:33:56 --> Hooks Class Initialized
INFO - 2018-04-06 05:33:56 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:33:56 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:33:56 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:33:56 --> Utf8 Class Initialized
INFO - 2018-04-06 05:33:56 --> Utf8 Class Initialized
INFO - 2018-04-06 05:33:56 --> URI Class Initialized
INFO - 2018-04-06 05:33:56 --> URI Class Initialized
INFO - 2018-04-06 05:33:56 --> Router Class Initialized
INFO - 2018-04-06 05:33:56 --> Router Class Initialized
INFO - 2018-04-06 05:33:56 --> Output Class Initialized
INFO - 2018-04-06 05:33:56 --> Output Class Initialized
INFO - 2018-04-06 05:33:56 --> Security Class Initialized
INFO - 2018-04-06 05:33:56 --> Security Class Initialized
DEBUG - 2018-04-06 05:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:33:56 --> Input Class Initialized
INFO - 2018-04-06 05:33:56 --> Input Class Initialized
INFO - 2018-04-06 05:33:56 --> Language Class Initialized
INFO - 2018-04-06 05:33:56 --> Language Class Initialized
ERROR - 2018-04-06 05:33:56 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-06 05:33:56 --> 404 Page Not Found: Assets/js
INFO - 2018-04-06 05:34:02 --> Config Class Initialized
INFO - 2018-04-06 05:34:02 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:34:02 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:34:02 --> Utf8 Class Initialized
INFO - 2018-04-06 05:34:02 --> URI Class Initialized
INFO - 2018-04-06 05:34:02 --> Router Class Initialized
INFO - 2018-04-06 05:34:02 --> Output Class Initialized
INFO - 2018-04-06 05:34:02 --> Security Class Initialized
DEBUG - 2018-04-06 05:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:34:02 --> Input Class Initialized
INFO - 2018-04-06 05:34:02 --> Language Class Initialized
INFO - 2018-04-06 05:34:02 --> Loader Class Initialized
INFO - 2018-04-06 05:34:02 --> Helper loaded: url_helper
INFO - 2018-04-06 05:34:02 --> Helper loaded: file_helper
INFO - 2018-04-06 05:34:02 --> Helper loaded: date_helper
INFO - 2018-04-06 05:34:02 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:34:03 --> Controller Class Initialized
DEBUG - 2018-04-06 05:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-06 05:34:03 --> Config Class Initialized
INFO - 2018-04-06 05:34:03 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:34:03 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:34:03 --> Utf8 Class Initialized
INFO - 2018-04-06 05:34:03 --> URI Class Initialized
INFO - 2018-04-06 05:34:03 --> Router Class Initialized
INFO - 2018-04-06 05:34:03 --> Output Class Initialized
INFO - 2018-04-06 05:34:03 --> Security Class Initialized
DEBUG - 2018-04-06 05:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:34:03 --> Input Class Initialized
INFO - 2018-04-06 05:34:03 --> Language Class Initialized
INFO - 2018-04-06 05:34:03 --> Loader Class Initialized
INFO - 2018-04-06 05:34:03 --> Helper loaded: url_helper
INFO - 2018-04-06 05:34:03 --> Helper loaded: file_helper
INFO - 2018-04-06 05:34:03 --> Helper loaded: date_helper
INFO - 2018-04-06 05:34:03 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:34:03 --> Controller Class Initialized
INFO - 2018-04-06 05:34:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-06 05:34:03 --> Final output sent to browser
DEBUG - 2018-04-06 05:34:03 --> Total execution time: 0.2586
INFO - 2018-04-06 05:34:03 --> Config Class Initialized
INFO - 2018-04-06 05:34:03 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:34:03 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:34:03 --> Utf8 Class Initialized
INFO - 2018-04-06 05:34:03 --> URI Class Initialized
INFO - 2018-04-06 05:34:03 --> Router Class Initialized
INFO - 2018-04-06 05:34:03 --> Output Class Initialized
INFO - 2018-04-06 05:34:03 --> Security Class Initialized
DEBUG - 2018-04-06 05:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:34:03 --> Input Class Initialized
INFO - 2018-04-06 05:34:03 --> Language Class Initialized
ERROR - 2018-04-06 05:34:03 --> 404 Page Not Found: Assets/css
INFO - 2018-04-06 05:35:12 --> Config Class Initialized
INFO - 2018-04-06 05:35:12 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:35:12 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:35:12 --> Utf8 Class Initialized
INFO - 2018-04-06 05:35:12 --> URI Class Initialized
INFO - 2018-04-06 05:35:12 --> Router Class Initialized
INFO - 2018-04-06 05:35:12 --> Output Class Initialized
INFO - 2018-04-06 05:35:12 --> Security Class Initialized
DEBUG - 2018-04-06 05:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:35:12 --> Input Class Initialized
INFO - 2018-04-06 05:35:12 --> Language Class Initialized
INFO - 2018-04-06 05:35:12 --> Loader Class Initialized
INFO - 2018-04-06 05:35:12 --> Helper loaded: url_helper
INFO - 2018-04-06 05:35:12 --> Helper loaded: file_helper
INFO - 2018-04-06 05:35:12 --> Helper loaded: date_helper
INFO - 2018-04-06 05:35:12 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:35:12 --> Controller Class Initialized
INFO - 2018-04-06 05:35:12 --> Model Class Initialized
INFO - 2018-04-06 05:37:39 --> Config Class Initialized
INFO - 2018-04-06 05:37:39 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:37:39 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:37:39 --> Utf8 Class Initialized
INFO - 2018-04-06 05:37:39 --> URI Class Initialized
INFO - 2018-04-06 05:37:39 --> Router Class Initialized
INFO - 2018-04-06 05:37:39 --> Output Class Initialized
INFO - 2018-04-06 05:37:39 --> Security Class Initialized
DEBUG - 2018-04-06 05:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:37:39 --> Input Class Initialized
INFO - 2018-04-06 05:37:39 --> Language Class Initialized
INFO - 2018-04-06 05:37:39 --> Loader Class Initialized
INFO - 2018-04-06 05:37:39 --> Helper loaded: url_helper
INFO - 2018-04-06 05:37:39 --> Helper loaded: file_helper
INFO - 2018-04-06 05:37:39 --> Helper loaded: date_helper
INFO - 2018-04-06 05:37:39 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:37:39 --> Controller Class Initialized
INFO - 2018-04-06 05:37:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-06 05:37:39 --> Final output sent to browser
DEBUG - 2018-04-06 05:37:39 --> Total execution time: 0.2654
INFO - 2018-04-06 05:37:53 --> Config Class Initialized
INFO - 2018-04-06 05:37:53 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:37:53 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:37:53 --> Utf8 Class Initialized
INFO - 2018-04-06 05:37:53 --> URI Class Initialized
INFO - 2018-04-06 05:37:54 --> Router Class Initialized
INFO - 2018-04-06 05:37:54 --> Output Class Initialized
INFO - 2018-04-06 05:37:54 --> Security Class Initialized
DEBUG - 2018-04-06 05:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:37:54 --> Input Class Initialized
INFO - 2018-04-06 05:37:54 --> Language Class Initialized
INFO - 2018-04-06 05:37:54 --> Loader Class Initialized
INFO - 2018-04-06 05:37:54 --> Helper loaded: url_helper
INFO - 2018-04-06 05:37:54 --> Helper loaded: file_helper
INFO - 2018-04-06 05:37:54 --> Helper loaded: date_helper
INFO - 2018-04-06 05:37:54 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:37:54 --> Controller Class Initialized
INFO - 2018-04-06 05:37:54 --> Model Class Initialized
ERROR - 2018-04-06 05:37:54 --> Severity: Notice --> Undefined property: stdClass::$user_name G:\xampp\htdocs\codeigniter\application\controllers\Auth_Controller.php 50
INFO - 2018-04-06 05:37:54 --> Final output sent to browser
DEBUG - 2018-04-06 05:37:54 --> Total execution time: 0.2705
INFO - 2018-04-06 05:37:54 --> Config Class Initialized
INFO - 2018-04-06 05:37:54 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:37:54 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:37:54 --> Utf8 Class Initialized
INFO - 2018-04-06 05:37:54 --> URI Class Initialized
INFO - 2018-04-06 05:37:54 --> Router Class Initialized
INFO - 2018-04-06 05:37:54 --> Output Class Initialized
INFO - 2018-04-06 05:37:54 --> Security Class Initialized
DEBUG - 2018-04-06 05:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:37:54 --> Input Class Initialized
INFO - 2018-04-06 05:37:54 --> Language Class Initialized
INFO - 2018-04-06 05:37:54 --> Loader Class Initialized
INFO - 2018-04-06 05:37:54 --> Helper loaded: url_helper
INFO - 2018-04-06 05:37:54 --> Helper loaded: file_helper
INFO - 2018-04-06 05:37:54 --> Helper loaded: date_helper
INFO - 2018-04-06 05:37:54 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:37:54 --> Controller Class Initialized
INFO - 2018-04-06 05:37:54 --> Model Class Initialized
INFO - 2018-04-06 05:37:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 05:37:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/dashboard.php
INFO - 2018-04-06 05:37:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 05:37:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 05:37:54 --> Final output sent to browser
DEBUG - 2018-04-06 05:37:54 --> Total execution time: 0.6383
INFO - 2018-04-06 05:38:32 --> Config Class Initialized
INFO - 2018-04-06 05:38:32 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:38:32 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:38:32 --> Utf8 Class Initialized
INFO - 2018-04-06 05:38:32 --> URI Class Initialized
INFO - 2018-04-06 05:38:32 --> Router Class Initialized
INFO - 2018-04-06 05:38:32 --> Output Class Initialized
INFO - 2018-04-06 05:38:32 --> Security Class Initialized
DEBUG - 2018-04-06 05:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:38:32 --> Input Class Initialized
INFO - 2018-04-06 05:38:32 --> Language Class Initialized
INFO - 2018-04-06 05:38:32 --> Loader Class Initialized
INFO - 2018-04-06 05:38:32 --> Helper loaded: url_helper
INFO - 2018-04-06 05:38:32 --> Helper loaded: file_helper
INFO - 2018-04-06 05:38:32 --> Helper loaded: date_helper
INFO - 2018-04-06 05:38:32 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:38:32 --> Controller Class Initialized
INFO - 2018-04-06 05:38:32 --> Config Class Initialized
INFO - 2018-04-06 05:38:32 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:38:32 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:38:32 --> Utf8 Class Initialized
INFO - 2018-04-06 05:38:32 --> URI Class Initialized
INFO - 2018-04-06 05:38:32 --> Router Class Initialized
INFO - 2018-04-06 05:38:32 --> Output Class Initialized
INFO - 2018-04-06 05:38:32 --> Security Class Initialized
DEBUG - 2018-04-06 05:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:38:32 --> Input Class Initialized
INFO - 2018-04-06 05:38:32 --> Language Class Initialized
INFO - 2018-04-06 05:38:32 --> Loader Class Initialized
INFO - 2018-04-06 05:38:32 --> Helper loaded: url_helper
INFO - 2018-04-06 05:38:32 --> Helper loaded: file_helper
INFO - 2018-04-06 05:38:32 --> Helper loaded: date_helper
INFO - 2018-04-06 05:38:32 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:38:32 --> Controller Class Initialized
INFO - 2018-04-06 05:38:32 --> Model Class Initialized
INFO - 2018-04-06 05:38:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 05:38:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/dashboard.php
INFO - 2018-04-06 05:38:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 05:38:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 05:38:32 --> Final output sent to browser
DEBUG - 2018-04-06 05:38:32 --> Total execution time: 0.2933
INFO - 2018-04-06 05:39:47 --> Config Class Initialized
INFO - 2018-04-06 05:39:47 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:39:47 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:39:47 --> Utf8 Class Initialized
INFO - 2018-04-06 05:39:47 --> URI Class Initialized
INFO - 2018-04-06 05:39:47 --> Router Class Initialized
INFO - 2018-04-06 05:39:47 --> Output Class Initialized
INFO - 2018-04-06 05:39:47 --> Security Class Initialized
DEBUG - 2018-04-06 05:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:39:47 --> Input Class Initialized
INFO - 2018-04-06 05:39:47 --> Language Class Initialized
INFO - 2018-04-06 05:39:47 --> Loader Class Initialized
INFO - 2018-04-06 05:39:47 --> Helper loaded: url_helper
INFO - 2018-04-06 05:39:47 --> Helper loaded: file_helper
INFO - 2018-04-06 05:39:47 --> Helper loaded: date_helper
INFO - 2018-04-06 05:39:47 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:39:47 --> Controller Class Initialized
INFO - 2018-04-06 05:39:47 --> Config Class Initialized
INFO - 2018-04-06 05:39:47 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:39:47 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:39:47 --> Utf8 Class Initialized
INFO - 2018-04-06 05:39:47 --> URI Class Initialized
INFO - 2018-04-06 05:39:47 --> Router Class Initialized
INFO - 2018-04-06 05:39:47 --> Output Class Initialized
INFO - 2018-04-06 05:39:47 --> Security Class Initialized
DEBUG - 2018-04-06 05:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:39:47 --> Input Class Initialized
INFO - 2018-04-06 05:39:47 --> Language Class Initialized
INFO - 2018-04-06 05:39:47 --> Loader Class Initialized
INFO - 2018-04-06 05:39:47 --> Helper loaded: url_helper
INFO - 2018-04-06 05:39:47 --> Helper loaded: file_helper
INFO - 2018-04-06 05:39:47 --> Helper loaded: date_helper
INFO - 2018-04-06 05:39:47 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:39:47 --> Controller Class Initialized
INFO - 2018-04-06 05:39:47 --> Model Class Initialized
INFO - 2018-04-06 05:39:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 05:39:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/dashboard.php
INFO - 2018-04-06 05:39:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 05:39:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 05:39:47 --> Final output sent to browser
DEBUG - 2018-04-06 05:39:47 --> Total execution time: 0.2910
INFO - 2018-04-06 05:48:55 --> Config Class Initialized
INFO - 2018-04-06 05:48:55 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:48:55 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:48:55 --> Utf8 Class Initialized
INFO - 2018-04-06 05:48:55 --> URI Class Initialized
INFO - 2018-04-06 05:48:55 --> Router Class Initialized
INFO - 2018-04-06 05:48:55 --> Output Class Initialized
INFO - 2018-04-06 05:48:55 --> Security Class Initialized
DEBUG - 2018-04-06 05:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:48:55 --> Input Class Initialized
INFO - 2018-04-06 05:48:55 --> Language Class Initialized
INFO - 2018-04-06 05:48:55 --> Loader Class Initialized
INFO - 2018-04-06 05:48:55 --> Helper loaded: url_helper
INFO - 2018-04-06 05:48:55 --> Helper loaded: file_helper
INFO - 2018-04-06 05:48:55 --> Helper loaded: date_helper
INFO - 2018-04-06 05:48:55 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:48:55 --> Controller Class Initialized
INFO - 2018-04-06 05:48:55 --> Model Class Initialized
INFO - 2018-04-06 05:48:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 05:48:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:48:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 05:48:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 05:48:56 --> Final output sent to browser
DEBUG - 2018-04-06 05:48:56 --> Total execution time: 0.3851
INFO - 2018-04-06 05:48:56 --> Config Class Initialized
INFO - 2018-04-06 05:48:56 --> Config Class Initialized
INFO - 2018-04-06 05:48:56 --> Hooks Class Initialized
INFO - 2018-04-06 05:48:56 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:48:56 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:48:56 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:48:56 --> Utf8 Class Initialized
INFO - 2018-04-06 05:48:56 --> Utf8 Class Initialized
INFO - 2018-04-06 05:48:56 --> URI Class Initialized
INFO - 2018-04-06 05:48:56 --> URI Class Initialized
INFO - 2018-04-06 05:48:56 --> Router Class Initialized
INFO - 2018-04-06 05:48:56 --> Router Class Initialized
INFO - 2018-04-06 05:48:56 --> Output Class Initialized
INFO - 2018-04-06 05:48:56 --> Output Class Initialized
INFO - 2018-04-06 05:48:56 --> Security Class Initialized
INFO - 2018-04-06 05:48:56 --> Security Class Initialized
DEBUG - 2018-04-06 05:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:48:56 --> Input Class Initialized
INFO - 2018-04-06 05:48:56 --> Input Class Initialized
INFO - 2018-04-06 05:48:56 --> Language Class Initialized
INFO - 2018-04-06 05:48:56 --> Language Class Initialized
ERROR - 2018-04-06 05:48:56 --> 404 Page Not Found: Stud_Controller/download.png
ERROR - 2018-04-06 05:48:56 --> 404 Page Not Found: Stud_Controller/css
INFO - 2018-04-06 05:51:25 --> Config Class Initialized
INFO - 2018-04-06 05:51:25 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:51:25 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:51:25 --> Utf8 Class Initialized
INFO - 2018-04-06 05:51:25 --> URI Class Initialized
INFO - 2018-04-06 05:51:25 --> Router Class Initialized
INFO - 2018-04-06 05:51:25 --> Output Class Initialized
INFO - 2018-04-06 05:51:25 --> Security Class Initialized
DEBUG - 2018-04-06 05:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:51:25 --> Input Class Initialized
INFO - 2018-04-06 05:51:25 --> Language Class Initialized
INFO - 2018-04-06 05:51:25 --> Loader Class Initialized
INFO - 2018-04-06 05:51:25 --> Helper loaded: url_helper
INFO - 2018-04-06 05:51:25 --> Helper loaded: file_helper
INFO - 2018-04-06 05:51:25 --> Helper loaded: date_helper
INFO - 2018-04-06 05:51:25 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:51:25 --> Controller Class Initialized
INFO - 2018-04-06 05:51:25 --> Model Class Initialized
INFO - 2018-04-06 05:51:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 05:51:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:51:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 05:51:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 05:51:25 --> Final output sent to browser
DEBUG - 2018-04-06 05:51:25 --> Total execution time: 0.3307
INFO - 2018-04-06 05:51:25 --> Config Class Initialized
INFO - 2018-04-06 05:51:25 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:51:25 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:51:25 --> Utf8 Class Initialized
INFO - 2018-04-06 05:51:25 --> URI Class Initialized
INFO - 2018-04-06 05:51:25 --> Router Class Initialized
INFO - 2018-04-06 05:51:25 --> Output Class Initialized
INFO - 2018-04-06 05:51:25 --> Security Class Initialized
DEBUG - 2018-04-06 05:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:51:25 --> Input Class Initialized
INFO - 2018-04-06 05:51:25 --> Language Class Initialized
ERROR - 2018-04-06 05:51:25 --> 404 Page Not Found: Stud_Controller/download.png
INFO - 2018-04-06 05:51:28 --> Config Class Initialized
INFO - 2018-04-06 05:51:28 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:51:28 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:51:28 --> Utf8 Class Initialized
INFO - 2018-04-06 05:51:28 --> URI Class Initialized
INFO - 2018-04-06 05:51:28 --> Router Class Initialized
INFO - 2018-04-06 05:51:28 --> Output Class Initialized
INFO - 2018-04-06 05:51:28 --> Security Class Initialized
DEBUG - 2018-04-06 05:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:51:28 --> Input Class Initialized
INFO - 2018-04-06 05:51:28 --> Language Class Initialized
INFO - 2018-04-06 05:51:28 --> Loader Class Initialized
INFO - 2018-04-06 05:51:28 --> Helper loaded: url_helper
INFO - 2018-04-06 05:51:28 --> Helper loaded: file_helper
INFO - 2018-04-06 05:51:28 --> Helper loaded: date_helper
INFO - 2018-04-06 05:51:28 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:51:28 --> Controller Class Initialized
INFO - 2018-04-06 05:51:28 --> Model Class Initialized
INFO - 2018-04-06 05:51:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 05:51:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:51:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 05:51:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 05:51:28 --> Final output sent to browser
DEBUG - 2018-04-06 05:51:28 --> Total execution time: 0.5740
INFO - 2018-04-06 05:51:28 --> Config Class Initialized
INFO - 2018-04-06 05:51:28 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:51:28 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:51:28 --> Utf8 Class Initialized
INFO - 2018-04-06 05:51:28 --> URI Class Initialized
INFO - 2018-04-06 05:51:28 --> Router Class Initialized
INFO - 2018-04-06 05:51:28 --> Output Class Initialized
INFO - 2018-04-06 05:51:28 --> Security Class Initialized
DEBUG - 2018-04-06 05:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:51:28 --> Input Class Initialized
INFO - 2018-04-06 05:51:28 --> Language Class Initialized
ERROR - 2018-04-06 05:51:28 --> 404 Page Not Found: Stud_Controller/download.png
INFO - 2018-04-06 05:51:38 --> Config Class Initialized
INFO - 2018-04-06 05:51:38 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:51:38 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:51:38 --> Utf8 Class Initialized
INFO - 2018-04-06 05:51:38 --> URI Class Initialized
INFO - 2018-04-06 05:51:38 --> Router Class Initialized
INFO - 2018-04-06 05:51:38 --> Output Class Initialized
INFO - 2018-04-06 05:51:38 --> Security Class Initialized
DEBUG - 2018-04-06 05:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:51:38 --> Input Class Initialized
INFO - 2018-04-06 05:51:38 --> Language Class Initialized
ERROR - 2018-04-06 05:51:38 --> 404 Page Not Found: Assets/css
INFO - 2018-04-06 05:52:17 --> Config Class Initialized
INFO - 2018-04-06 05:52:17 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:52:17 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:52:17 --> Utf8 Class Initialized
INFO - 2018-04-06 05:52:17 --> URI Class Initialized
INFO - 2018-04-06 05:52:17 --> Router Class Initialized
INFO - 2018-04-06 05:52:17 --> Output Class Initialized
INFO - 2018-04-06 05:52:17 --> Security Class Initialized
DEBUG - 2018-04-06 05:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:52:17 --> Input Class Initialized
INFO - 2018-04-06 05:52:17 --> Language Class Initialized
INFO - 2018-04-06 05:52:17 --> Loader Class Initialized
INFO - 2018-04-06 05:52:17 --> Helper loaded: url_helper
INFO - 2018-04-06 05:52:17 --> Helper loaded: file_helper
INFO - 2018-04-06 05:52:17 --> Helper loaded: date_helper
INFO - 2018-04-06 05:52:17 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:52:17 --> Controller Class Initialized
INFO - 2018-04-06 05:52:17 --> Model Class Initialized
INFO - 2018-04-06 05:52:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 05:52:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:52:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 05:52:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 05:52:17 --> Final output sent to browser
DEBUG - 2018-04-06 05:52:17 --> Total execution time: 0.5619
INFO - 2018-04-06 05:52:17 --> Config Class Initialized
INFO - 2018-04-06 05:52:18 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:52:18 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:52:18 --> Utf8 Class Initialized
INFO - 2018-04-06 05:52:18 --> URI Class Initialized
INFO - 2018-04-06 05:52:18 --> Router Class Initialized
INFO - 2018-04-06 05:52:18 --> Output Class Initialized
INFO - 2018-04-06 05:52:18 --> Security Class Initialized
INFO - 2018-04-06 05:52:18 --> Config Class Initialized
INFO - 2018-04-06 05:52:18 --> Config Class Initialized
INFO - 2018-04-06 05:52:18 --> Hooks Class Initialized
INFO - 2018-04-06 05:52:18 --> Hooks Class Initialized
INFO - 2018-04-06 05:52:18 --> Config Class Initialized
DEBUG - 2018-04-06 05:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:52:18 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:52:18 --> Utf8 Class Initialized
INFO - 2018-04-06 05:52:18 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:52:18 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:52:18 --> Input Class Initialized
INFO - 2018-04-06 05:52:18 --> Utf8 Class Initialized
INFO - 2018-04-06 05:52:18 --> URI Class Initialized
DEBUG - 2018-04-06 05:52:18 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:52:18 --> Language Class Initialized
INFO - 2018-04-06 05:52:18 --> Utf8 Class Initialized
INFO - 2018-04-06 05:52:18 --> URI Class Initialized
ERROR - 2018-04-06 05:52:18 --> 404 Page Not Found: Stud_Controller/download.png
INFO - 2018-04-06 05:52:18 --> Router Class Initialized
INFO - 2018-04-06 05:52:18 --> URI Class Initialized
INFO - 2018-04-06 05:52:18 --> Router Class Initialized
INFO - 2018-04-06 05:52:18 --> Output Class Initialized
INFO - 2018-04-06 05:52:18 --> Router Class Initialized
INFO - 2018-04-06 05:52:18 --> Output Class Initialized
INFO - 2018-04-06 05:52:18 --> Security Class Initialized
INFO - 2018-04-06 05:52:18 --> Security Class Initialized
INFO - 2018-04-06 05:52:18 --> Output Class Initialized
DEBUG - 2018-04-06 05:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:52:18 --> Input Class Initialized
DEBUG - 2018-04-06 05:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:52:18 --> Input Class Initialized
INFO - 2018-04-06 05:52:18 --> Language Class Initialized
INFO - 2018-04-06 05:52:18 --> Security Class Initialized
INFO - 2018-04-06 05:52:18 --> Language Class Initialized
DEBUG - 2018-04-06 05:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-04-06 05:52:18 --> 404 Page Not Found: Assets/js
INFO - 2018-04-06 05:52:18 --> Input Class Initialized
ERROR - 2018-04-06 05:52:18 --> 404 Page Not Found: Assets/js
INFO - 2018-04-06 05:52:18 --> Language Class Initialized
ERROR - 2018-04-06 05:52:18 --> 404 Page Not Found: Assets/css
INFO - 2018-04-06 05:52:54 --> Config Class Initialized
INFO - 2018-04-06 05:52:54 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:52:54 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:52:54 --> Utf8 Class Initialized
INFO - 2018-04-06 05:52:54 --> URI Class Initialized
INFO - 2018-04-06 05:52:54 --> Router Class Initialized
INFO - 2018-04-06 05:52:54 --> Output Class Initialized
INFO - 2018-04-06 05:52:54 --> Security Class Initialized
DEBUG - 2018-04-06 05:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:52:54 --> Input Class Initialized
INFO - 2018-04-06 05:52:54 --> Language Class Initialized
INFO - 2018-04-06 05:52:54 --> Loader Class Initialized
INFO - 2018-04-06 05:52:54 --> Helper loaded: url_helper
INFO - 2018-04-06 05:52:54 --> Helper loaded: file_helper
INFO - 2018-04-06 05:52:54 --> Helper loaded: date_helper
INFO - 2018-04-06 05:52:54 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:52:54 --> Controller Class Initialized
INFO - 2018-04-06 05:52:54 --> Model Class Initialized
INFO - 2018-04-06 05:52:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 05:52:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:52:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 05:52:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 05:52:55 --> Final output sent to browser
DEBUG - 2018-04-06 05:52:55 --> Total execution time: 0.3340
INFO - 2018-04-06 05:52:55 --> Config Class Initialized
INFO - 2018-04-06 05:52:55 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:52:55 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:52:55 --> Utf8 Class Initialized
INFO - 2018-04-06 05:52:55 --> URI Class Initialized
INFO - 2018-04-06 05:52:55 --> Router Class Initialized
INFO - 2018-04-06 05:52:55 --> Output Class Initialized
INFO - 2018-04-06 05:52:55 --> Security Class Initialized
INFO - 2018-04-06 05:52:55 --> Config Class Initialized
INFO - 2018-04-06 05:52:55 --> Config Class Initialized
INFO - 2018-04-06 05:52:55 --> Config Class Initialized
INFO - 2018-04-06 05:52:55 --> Hooks Class Initialized
INFO - 2018-04-06 05:52:55 --> Hooks Class Initialized
INFO - 2018-04-06 05:52:55 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:52:55 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:52:55 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:52:55 --> Input Class Initialized
DEBUG - 2018-04-06 05:52:55 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:52:55 --> Utf8 Class Initialized
INFO - 2018-04-06 05:52:55 --> Utf8 Class Initialized
INFO - 2018-04-06 05:52:55 --> URI Class Initialized
INFO - 2018-04-06 05:52:55 --> Utf8 Class Initialized
INFO - 2018-04-06 05:52:55 --> Language Class Initialized
INFO - 2018-04-06 05:52:55 --> URI Class Initialized
INFO - 2018-04-06 05:52:55 --> URI Class Initialized
INFO - 2018-04-06 05:52:55 --> Router Class Initialized
INFO - 2018-04-06 05:52:55 --> Router Class Initialized
ERROR - 2018-04-06 05:52:55 --> 404 Page Not Found: Stud_Controller/download.png
INFO - 2018-04-06 05:52:55 --> Router Class Initialized
INFO - 2018-04-06 05:52:55 --> Output Class Initialized
INFO - 2018-04-06 05:52:55 --> Output Class Initialized
INFO - 2018-04-06 05:52:55 --> Security Class Initialized
INFO - 2018-04-06 05:52:55 --> Security Class Initialized
INFO - 2018-04-06 05:52:55 --> Output Class Initialized
DEBUG - 2018-04-06 05:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:52:55 --> Security Class Initialized
INFO - 2018-04-06 05:52:55 --> Input Class Initialized
INFO - 2018-04-06 05:52:55 --> Input Class Initialized
DEBUG - 2018-04-06 05:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:52:55 --> Input Class Initialized
INFO - 2018-04-06 05:52:55 --> Language Class Initialized
INFO - 2018-04-06 05:52:55 --> Language Class Initialized
INFO - 2018-04-06 05:52:55 --> Language Class Initialized
ERROR - 2018-04-06 05:52:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-06 05:52:55 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-06 05:52:55 --> 404 Page Not Found: Assets/js
INFO - 2018-04-06 05:53:59 --> Config Class Initialized
INFO - 2018-04-06 05:53:59 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:53:59 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:53:59 --> Utf8 Class Initialized
INFO - 2018-04-06 05:53:59 --> URI Class Initialized
INFO - 2018-04-06 05:53:59 --> Router Class Initialized
INFO - 2018-04-06 05:53:59 --> Output Class Initialized
INFO - 2018-04-06 05:53:59 --> Security Class Initialized
DEBUG - 2018-04-06 05:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:53:59 --> Input Class Initialized
INFO - 2018-04-06 05:53:59 --> Language Class Initialized
INFO - 2018-04-06 05:53:59 --> Loader Class Initialized
INFO - 2018-04-06 05:53:59 --> Helper loaded: url_helper
INFO - 2018-04-06 05:53:59 --> Helper loaded: file_helper
INFO - 2018-04-06 05:53:59 --> Helper loaded: date_helper
INFO - 2018-04-06 05:53:59 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:53:59 --> Controller Class Initialized
INFO - 2018-04-06 05:53:59 --> Model Class Initialized
INFO - 2018-04-06 05:53:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 05:53:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:53:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 05:53:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 05:53:59 --> Final output sent to browser
DEBUG - 2018-04-06 05:53:59 --> Total execution time: 0.5140
INFO - 2018-04-06 05:54:00 --> Config Class Initialized
INFO - 2018-04-06 05:54:00 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:54:00 --> Utf8 Class Initialized
INFO - 2018-04-06 05:54:00 --> URI Class Initialized
INFO - 2018-04-06 05:54:00 --> Router Class Initialized
INFO - 2018-04-06 05:54:00 --> Config Class Initialized
INFO - 2018-04-06 05:54:00 --> Config Class Initialized
INFO - 2018-04-06 05:54:00 --> Hooks Class Initialized
INFO - 2018-04-06 05:54:00 --> Hooks Class Initialized
INFO - 2018-04-06 05:54:00 --> Output Class Initialized
INFO - 2018-04-06 05:54:00 --> Config Class Initialized
INFO - 2018-04-06 05:54:00 --> Hooks Class Initialized
INFO - 2018-04-06 05:54:00 --> Security Class Initialized
DEBUG - 2018-04-06 05:54:00 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:54:00 --> Utf8 Class Initialized
INFO - 2018-04-06 05:54:00 --> Utf8 Class Initialized
DEBUG - 2018-04-06 05:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:54:00 --> Utf8 Class Initialized
INFO - 2018-04-06 05:54:00 --> URI Class Initialized
INFO - 2018-04-06 05:54:00 --> Input Class Initialized
INFO - 2018-04-06 05:54:00 --> URI Class Initialized
INFO - 2018-04-06 05:54:00 --> URI Class Initialized
INFO - 2018-04-06 05:54:00 --> Router Class Initialized
INFO - 2018-04-06 05:54:00 --> Router Class Initialized
INFO - 2018-04-06 05:54:00 --> Language Class Initialized
INFO - 2018-04-06 05:54:00 --> Router Class Initialized
INFO - 2018-04-06 05:54:00 --> Output Class Initialized
INFO - 2018-04-06 05:54:00 --> Output Class Initialized
ERROR - 2018-04-06 05:54:00 --> 404 Page Not Found: Stud_Controller/download.png
INFO - 2018-04-06 05:54:00 --> Security Class Initialized
INFO - 2018-04-06 05:54:00 --> Security Class Initialized
INFO - 2018-04-06 05:54:00 --> Output Class Initialized
DEBUG - 2018-04-06 05:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:54:00 --> Security Class Initialized
INFO - 2018-04-06 05:54:00 --> Input Class Initialized
INFO - 2018-04-06 05:54:00 --> Input Class Initialized
DEBUG - 2018-04-06 05:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:54:00 --> Input Class Initialized
INFO - 2018-04-06 05:54:00 --> Language Class Initialized
INFO - 2018-04-06 05:54:00 --> Language Class Initialized
INFO - 2018-04-06 05:54:00 --> Language Class Initialized
ERROR - 2018-04-06 05:54:00 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-06 05:54:00 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-06 05:54:00 --> 404 Page Not Found: Assets/css
INFO - 2018-04-06 05:59:16 --> Config Class Initialized
INFO - 2018-04-06 05:59:16 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:59:16 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:59:16 --> Utf8 Class Initialized
INFO - 2018-04-06 05:59:16 --> URI Class Initialized
INFO - 2018-04-06 05:59:16 --> Router Class Initialized
INFO - 2018-04-06 05:59:16 --> Output Class Initialized
INFO - 2018-04-06 05:59:16 --> Security Class Initialized
DEBUG - 2018-04-06 05:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:59:16 --> Input Class Initialized
INFO - 2018-04-06 05:59:16 --> Language Class Initialized
INFO - 2018-04-06 05:59:16 --> Loader Class Initialized
INFO - 2018-04-06 05:59:16 --> Helper loaded: url_helper
INFO - 2018-04-06 05:59:16 --> Helper loaded: file_helper
INFO - 2018-04-06 05:59:16 --> Helper loaded: date_helper
INFO - 2018-04-06 05:59:16 --> Database Driver Class Initialized
DEBUG - 2018-04-06 05:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 05:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 05:59:16 --> Controller Class Initialized
INFO - 2018-04-06 05:59:16 --> Model Class Initialized
INFO - 2018-04-06 05:59:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 05:59:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 05:59:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 05:59:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 05:59:16 --> Final output sent to browser
DEBUG - 2018-04-06 05:59:16 --> Total execution time: 0.3439
INFO - 2018-04-06 05:59:16 --> Config Class Initialized
INFO - 2018-04-06 05:59:16 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:59:16 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:59:16 --> Utf8 Class Initialized
INFO - 2018-04-06 05:59:16 --> URI Class Initialized
INFO - 2018-04-06 05:59:16 --> Router Class Initialized
INFO - 2018-04-06 05:59:16 --> Output Class Initialized
INFO - 2018-04-06 05:59:16 --> Security Class Initialized
DEBUG - 2018-04-06 05:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:59:17 --> Input Class Initialized
INFO - 2018-04-06 05:59:17 --> Language Class Initialized
ERROR - 2018-04-06 05:59:17 --> 404 Page Not Found: Assets/img
INFO - 2018-04-06 05:59:37 --> Config Class Initialized
INFO - 2018-04-06 05:59:37 --> Config Class Initialized
INFO - 2018-04-06 05:59:37 --> Config Class Initialized
INFO - 2018-04-06 05:59:37 --> Hooks Class Initialized
INFO - 2018-04-06 05:59:37 --> Hooks Class Initialized
INFO - 2018-04-06 05:59:37 --> Hooks Class Initialized
DEBUG - 2018-04-06 05:59:37 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:59:37 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 05:59:37 --> UTF-8 Support Enabled
INFO - 2018-04-06 05:59:37 --> Utf8 Class Initialized
INFO - 2018-04-06 05:59:37 --> Utf8 Class Initialized
INFO - 2018-04-06 05:59:37 --> Utf8 Class Initialized
INFO - 2018-04-06 05:59:37 --> URI Class Initialized
INFO - 2018-04-06 05:59:37 --> URI Class Initialized
INFO - 2018-04-06 05:59:37 --> URI Class Initialized
INFO - 2018-04-06 05:59:37 --> Router Class Initialized
INFO - 2018-04-06 05:59:37 --> Router Class Initialized
INFO - 2018-04-06 05:59:37 --> Router Class Initialized
INFO - 2018-04-06 05:59:37 --> Output Class Initialized
INFO - 2018-04-06 05:59:37 --> Output Class Initialized
INFO - 2018-04-06 05:59:37 --> Output Class Initialized
INFO - 2018-04-06 05:59:37 --> Security Class Initialized
INFO - 2018-04-06 05:59:37 --> Security Class Initialized
INFO - 2018-04-06 05:59:37 --> Security Class Initialized
DEBUG - 2018-04-06 05:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 05:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:59:37 --> Input Class Initialized
INFO - 2018-04-06 05:59:37 --> Input Class Initialized
DEBUG - 2018-04-06 05:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 05:59:37 --> Language Class Initialized
INFO - 2018-04-06 05:59:37 --> Input Class Initialized
INFO - 2018-04-06 05:59:37 --> Language Class Initialized
ERROR - 2018-04-06 05:59:37 --> 404 Page Not Found: Assets/js
INFO - 2018-04-06 05:59:37 --> Language Class Initialized
ERROR - 2018-04-06 05:59:37 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-06 05:59:37 --> 404 Page Not Found: Assets/js
INFO - 2018-04-06 06:00:02 --> Config Class Initialized
INFO - 2018-04-06 06:00:02 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:00:02 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:00:02 --> Utf8 Class Initialized
INFO - 2018-04-06 06:00:02 --> URI Class Initialized
INFO - 2018-04-06 06:00:02 --> Router Class Initialized
INFO - 2018-04-06 06:00:02 --> Output Class Initialized
INFO - 2018-04-06 06:00:02 --> Security Class Initialized
DEBUG - 2018-04-06 06:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:00:02 --> Input Class Initialized
INFO - 2018-04-06 06:00:02 --> Language Class Initialized
INFO - 2018-04-06 06:00:02 --> Loader Class Initialized
INFO - 2018-04-06 06:00:02 --> Helper loaded: url_helper
INFO - 2018-04-06 06:00:02 --> Helper loaded: file_helper
INFO - 2018-04-06 06:00:02 --> Helper loaded: date_helper
INFO - 2018-04-06 06:00:02 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:00:02 --> Controller Class Initialized
INFO - 2018-04-06 06:00:02 --> Model Class Initialized
INFO - 2018-04-06 06:00:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:00:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:00:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:00:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:00:02 --> Final output sent to browser
DEBUG - 2018-04-06 06:00:02 --> Total execution time: 0.4103
INFO - 2018-04-06 06:00:11 --> Config Class Initialized
INFO - 2018-04-06 06:00:11 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:00:11 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:00:11 --> Utf8 Class Initialized
INFO - 2018-04-06 06:00:11 --> URI Class Initialized
INFO - 2018-04-06 06:00:11 --> Router Class Initialized
INFO - 2018-04-06 06:00:11 --> Output Class Initialized
INFO - 2018-04-06 06:00:11 --> Security Class Initialized
DEBUG - 2018-04-06 06:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:00:11 --> Input Class Initialized
INFO - 2018-04-06 06:00:11 --> Language Class Initialized
ERROR - 2018-04-06 06:00:11 --> 404 Page Not Found: Assets/img
INFO - 2018-04-06 06:02:00 --> Config Class Initialized
INFO - 2018-04-06 06:02:00 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:02:00 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:02:00 --> Utf8 Class Initialized
INFO - 2018-04-06 06:02:00 --> URI Class Initialized
INFO - 2018-04-06 06:02:00 --> Router Class Initialized
INFO - 2018-04-06 06:02:00 --> Output Class Initialized
INFO - 2018-04-06 06:02:00 --> Security Class Initialized
DEBUG - 2018-04-06 06:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:02:00 --> Input Class Initialized
INFO - 2018-04-06 06:02:00 --> Language Class Initialized
INFO - 2018-04-06 06:02:00 --> Loader Class Initialized
INFO - 2018-04-06 06:02:00 --> Helper loaded: url_helper
INFO - 2018-04-06 06:02:00 --> Helper loaded: file_helper
INFO - 2018-04-06 06:02:00 --> Helper loaded: date_helper
INFO - 2018-04-06 06:02:00 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:02:00 --> Controller Class Initialized
INFO - 2018-04-06 06:02:00 --> Model Class Initialized
INFO - 2018-04-06 06:02:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:02:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:02:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:02:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:02:01 --> Final output sent to browser
DEBUG - 2018-04-06 06:02:01 --> Total execution time: 0.3444
INFO - 2018-04-06 06:02:01 --> Config Class Initialized
INFO - 2018-04-06 06:02:01 --> Config Class Initialized
INFO - 2018-04-06 06:02:01 --> Config Class Initialized
INFO - 2018-04-06 06:02:01 --> Hooks Class Initialized
INFO - 2018-04-06 06:02:01 --> Hooks Class Initialized
INFO - 2018-04-06 06:02:01 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:02:01 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 06:02:01 --> UTF-8 Support Enabled
DEBUG - 2018-04-06 06:02:01 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:02:01 --> Utf8 Class Initialized
INFO - 2018-04-06 06:02:01 --> Utf8 Class Initialized
INFO - 2018-04-06 06:02:01 --> Utf8 Class Initialized
INFO - 2018-04-06 06:02:01 --> URI Class Initialized
INFO - 2018-04-06 06:02:01 --> URI Class Initialized
INFO - 2018-04-06 06:02:01 --> URI Class Initialized
INFO - 2018-04-06 06:02:01 --> Router Class Initialized
INFO - 2018-04-06 06:02:01 --> Router Class Initialized
INFO - 2018-04-06 06:02:01 --> Router Class Initialized
INFO - 2018-04-06 06:02:01 --> Output Class Initialized
INFO - 2018-04-06 06:02:01 --> Output Class Initialized
INFO - 2018-04-06 06:02:01 --> Output Class Initialized
INFO - 2018-04-06 06:02:01 --> Security Class Initialized
INFO - 2018-04-06 06:02:01 --> Security Class Initialized
INFO - 2018-04-06 06:02:01 --> Security Class Initialized
DEBUG - 2018-04-06 06:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 06:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-06 06:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:02:01 --> Input Class Initialized
INFO - 2018-04-06 06:02:01 --> Input Class Initialized
INFO - 2018-04-06 06:02:01 --> Input Class Initialized
INFO - 2018-04-06 06:02:01 --> Language Class Initialized
INFO - 2018-04-06 06:02:01 --> Language Class Initialized
INFO - 2018-04-06 06:02:01 --> Language Class Initialized
ERROR - 2018-04-06 06:02:01 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-06 06:02:01 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-06 06:02:01 --> 404 Page Not Found: Assets/js
INFO - 2018-04-06 06:04:23 --> Config Class Initialized
INFO - 2018-04-06 06:04:23 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:04:23 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:04:23 --> Utf8 Class Initialized
INFO - 2018-04-06 06:04:23 --> URI Class Initialized
INFO - 2018-04-06 06:04:23 --> Router Class Initialized
INFO - 2018-04-06 06:04:23 --> Output Class Initialized
INFO - 2018-04-06 06:04:23 --> Security Class Initialized
DEBUG - 2018-04-06 06:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:04:23 --> Input Class Initialized
INFO - 2018-04-06 06:04:23 --> Language Class Initialized
INFO - 2018-04-06 06:04:23 --> Loader Class Initialized
INFO - 2018-04-06 06:04:23 --> Helper loaded: url_helper
INFO - 2018-04-06 06:04:23 --> Helper loaded: file_helper
INFO - 2018-04-06 06:04:24 --> Helper loaded: date_helper
INFO - 2018-04-06 06:04:24 --> Database Driver Class Initialized
INFO - 2018-04-06 06:04:24 --> Config Class Initialized
INFO - 2018-04-06 06:04:24 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-04-06 06:04:24 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:04:24 --> Controller Class Initialized
INFO - 2018-04-06 06:04:24 --> Utf8 Class Initialized
INFO - 2018-04-06 06:04:24 --> Model Class Initialized
INFO - 2018-04-06 06:04:24 --> URI Class Initialized
INFO - 2018-04-06 06:04:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:04:24 --> Router Class Initialized
INFO - 2018-04-06 06:04:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:04:24 --> Output Class Initialized
INFO - 2018-04-06 06:04:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:04:24 --> Security Class Initialized
INFO - 2018-04-06 06:04:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
DEBUG - 2018-04-06 06:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:04:24 --> Input Class Initialized
INFO - 2018-04-06 06:04:24 --> Final output sent to browser
DEBUG - 2018-04-06 06:04:24 --> Total execution time: 0.3387
INFO - 2018-04-06 06:04:24 --> Language Class Initialized
INFO - 2018-04-06 06:04:24 --> Loader Class Initialized
INFO - 2018-04-06 06:04:24 --> Helper loaded: url_helper
INFO - 2018-04-06 06:04:24 --> Helper loaded: file_helper
INFO - 2018-04-06 06:04:24 --> Helper loaded: date_helper
INFO - 2018-04-06 06:04:24 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:04:24 --> Controller Class Initialized
INFO - 2018-04-06 06:04:24 --> Model Class Initialized
INFO - 2018-04-06 06:04:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:04:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:04:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:04:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:04:24 --> Final output sent to browser
DEBUG - 2018-04-06 06:04:24 --> Total execution time: 0.3290
INFO - 2018-04-06 06:04:24 --> Config Class Initialized
INFO - 2018-04-06 06:04:24 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:04:24 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:04:24 --> Utf8 Class Initialized
INFO - 2018-04-06 06:04:24 --> URI Class Initialized
INFO - 2018-04-06 06:04:24 --> Router Class Initialized
INFO - 2018-04-06 06:04:24 --> Output Class Initialized
INFO - 2018-04-06 06:04:24 --> Security Class Initialized
DEBUG - 2018-04-06 06:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:04:24 --> Input Class Initialized
INFO - 2018-04-06 06:04:24 --> Language Class Initialized
ERROR - 2018-04-06 06:04:24 --> 404 Page Not Found: Assets/img
INFO - 2018-04-06 06:04:28 --> Config Class Initialized
INFO - 2018-04-06 06:04:28 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:04:28 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:04:28 --> Utf8 Class Initialized
INFO - 2018-04-06 06:04:28 --> URI Class Initialized
INFO - 2018-04-06 06:04:28 --> Router Class Initialized
INFO - 2018-04-06 06:04:28 --> Output Class Initialized
INFO - 2018-04-06 06:04:28 --> Security Class Initialized
DEBUG - 2018-04-06 06:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:04:28 --> Input Class Initialized
INFO - 2018-04-06 06:04:28 --> Language Class Initialized
INFO - 2018-04-06 06:04:28 --> Loader Class Initialized
INFO - 2018-04-06 06:04:28 --> Helper loaded: url_helper
INFO - 2018-04-06 06:04:28 --> Helper loaded: file_helper
INFO - 2018-04-06 06:04:28 --> Helper loaded: date_helper
INFO - 2018-04-06 06:04:28 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:04:28 --> Controller Class Initialized
INFO - 2018-04-06 06:04:28 --> Model Class Initialized
INFO - 2018-04-06 06:04:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:04:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:04:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:04:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:04:29 --> Final output sent to browser
DEBUG - 2018-04-06 06:04:29 --> Total execution time: 0.4252
INFO - 2018-04-06 06:04:31 --> Config Class Initialized
INFO - 2018-04-06 06:04:31 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:04:31 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:04:31 --> Utf8 Class Initialized
INFO - 2018-04-06 06:04:31 --> URI Class Initialized
INFO - 2018-04-06 06:04:31 --> Router Class Initialized
INFO - 2018-04-06 06:04:31 --> Output Class Initialized
INFO - 2018-04-06 06:04:31 --> Security Class Initialized
DEBUG - 2018-04-06 06:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:04:32 --> Input Class Initialized
INFO - 2018-04-06 06:04:32 --> Language Class Initialized
ERROR - 2018-04-06 06:04:32 --> 404 Page Not Found: Assets/css
INFO - 2018-04-06 06:05:26 --> Config Class Initialized
INFO - 2018-04-06 06:05:26 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:05:26 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:05:26 --> Utf8 Class Initialized
INFO - 2018-04-06 06:05:28 --> Config Class Initialized
INFO - 2018-04-06 06:05:28 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:05:28 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:05:28 --> Utf8 Class Initialized
INFO - 2018-04-06 06:05:28 --> URI Class Initialized
INFO - 2018-04-06 06:05:28 --> Router Class Initialized
INFO - 2018-04-06 06:05:28 --> Output Class Initialized
INFO - 2018-04-06 06:05:28 --> Security Class Initialized
DEBUG - 2018-04-06 06:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:05:28 --> Input Class Initialized
INFO - 2018-04-06 06:05:28 --> Language Class Initialized
INFO - 2018-04-06 06:05:28 --> Loader Class Initialized
INFO - 2018-04-06 06:05:28 --> Helper loaded: url_helper
INFO - 2018-04-06 06:05:28 --> Helper loaded: file_helper
INFO - 2018-04-06 06:05:28 --> Helper loaded: date_helper
INFO - 2018-04-06 06:05:28 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:05:28 --> Controller Class Initialized
INFO - 2018-04-06 06:05:28 --> Model Class Initialized
INFO - 2018-04-06 06:05:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:05:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:05:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:05:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:05:28 --> Final output sent to browser
DEBUG - 2018-04-06 06:05:28 --> Total execution time: 0.4301
INFO - 2018-04-06 06:16:24 --> Config Class Initialized
INFO - 2018-04-06 06:16:24 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:16:24 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:16:24 --> Utf8 Class Initialized
INFO - 2018-04-06 06:16:24 --> URI Class Initialized
INFO - 2018-04-06 06:16:24 --> Router Class Initialized
INFO - 2018-04-06 06:16:24 --> Output Class Initialized
INFO - 2018-04-06 06:16:24 --> Security Class Initialized
DEBUG - 2018-04-06 06:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:16:24 --> Input Class Initialized
INFO - 2018-04-06 06:16:24 --> Language Class Initialized
ERROR - 2018-04-06 06:16:24 --> Severity: error --> Exception: syntax error, unexpected 'exit' (T_EXIT) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 21
INFO - 2018-04-06 06:16:43 --> Config Class Initialized
INFO - 2018-04-06 06:16:43 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:16:43 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:16:43 --> Utf8 Class Initialized
INFO - 2018-04-06 06:16:43 --> URI Class Initialized
INFO - 2018-04-06 06:16:43 --> Router Class Initialized
INFO - 2018-04-06 06:16:43 --> Output Class Initialized
INFO - 2018-04-06 06:16:43 --> Security Class Initialized
DEBUG - 2018-04-06 06:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:16:43 --> Input Class Initialized
INFO - 2018-04-06 06:16:43 --> Language Class Initialized
INFO - 2018-04-06 06:16:43 --> Loader Class Initialized
INFO - 2018-04-06 06:16:43 --> Helper loaded: url_helper
INFO - 2018-04-06 06:16:43 --> Helper loaded: file_helper
INFO - 2018-04-06 06:16:43 --> Helper loaded: date_helper
INFO - 2018-04-06 06:16:43 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:16:43 --> Controller Class Initialized
INFO - 2018-04-06 06:16:43 --> Model Class Initialized
INFO - 2018-04-06 06:17:21 --> Config Class Initialized
INFO - 2018-04-06 06:17:21 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:17:21 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:17:21 --> Utf8 Class Initialized
INFO - 2018-04-06 06:17:21 --> URI Class Initialized
INFO - 2018-04-06 06:17:21 --> Router Class Initialized
INFO - 2018-04-06 06:17:21 --> Output Class Initialized
INFO - 2018-04-06 06:17:21 --> Security Class Initialized
DEBUG - 2018-04-06 06:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:17:21 --> Input Class Initialized
INFO - 2018-04-06 06:17:21 --> Language Class Initialized
INFO - 2018-04-06 06:17:21 --> Loader Class Initialized
INFO - 2018-04-06 06:17:21 --> Helper loaded: url_helper
INFO - 2018-04-06 06:17:21 --> Helper loaded: file_helper
INFO - 2018-04-06 06:17:21 --> Helper loaded: date_helper
INFO - 2018-04-06 06:17:21 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:17:21 --> Controller Class Initialized
INFO - 2018-04-06 06:17:21 --> Model Class Initialized
INFO - 2018-04-06 06:17:35 --> Config Class Initialized
INFO - 2018-04-06 06:17:35 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:17:35 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:17:35 --> Utf8 Class Initialized
INFO - 2018-04-06 06:17:35 --> URI Class Initialized
INFO - 2018-04-06 06:17:35 --> Router Class Initialized
INFO - 2018-04-06 06:17:35 --> Output Class Initialized
INFO - 2018-04-06 06:17:35 --> Security Class Initialized
DEBUG - 2018-04-06 06:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:17:36 --> Input Class Initialized
INFO - 2018-04-06 06:17:36 --> Language Class Initialized
INFO - 2018-04-06 06:17:36 --> Loader Class Initialized
INFO - 2018-04-06 06:17:36 --> Helper loaded: url_helper
INFO - 2018-04-06 06:17:36 --> Helper loaded: file_helper
INFO - 2018-04-06 06:17:36 --> Helper loaded: date_helper
INFO - 2018-04-06 06:17:36 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:17:36 --> Controller Class Initialized
INFO - 2018-04-06 06:17:36 --> Model Class Initialized
INFO - 2018-04-06 06:17:50 --> Config Class Initialized
INFO - 2018-04-06 06:17:50 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:17:50 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:17:50 --> Utf8 Class Initialized
INFO - 2018-04-06 06:17:50 --> URI Class Initialized
INFO - 2018-04-06 06:17:50 --> Router Class Initialized
INFO - 2018-04-06 06:17:50 --> Output Class Initialized
INFO - 2018-04-06 06:17:50 --> Security Class Initialized
DEBUG - 2018-04-06 06:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:17:50 --> Input Class Initialized
INFO - 2018-04-06 06:17:50 --> Language Class Initialized
INFO - 2018-04-06 06:17:50 --> Loader Class Initialized
INFO - 2018-04-06 06:17:50 --> Helper loaded: url_helper
INFO - 2018-04-06 06:17:50 --> Helper loaded: file_helper
INFO - 2018-04-06 06:17:50 --> Helper loaded: date_helper
INFO - 2018-04-06 06:17:51 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:17:51 --> Controller Class Initialized
INFO - 2018-04-06 06:17:51 --> Model Class Initialized
INFO - 2018-04-06 06:18:31 --> Config Class Initialized
INFO - 2018-04-06 06:18:31 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:18:32 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:18:32 --> Utf8 Class Initialized
INFO - 2018-04-06 06:18:32 --> URI Class Initialized
INFO - 2018-04-06 06:18:32 --> Router Class Initialized
INFO - 2018-04-06 06:18:32 --> Output Class Initialized
INFO - 2018-04-06 06:18:32 --> Security Class Initialized
DEBUG - 2018-04-06 06:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:18:32 --> Input Class Initialized
INFO - 2018-04-06 06:18:32 --> Language Class Initialized
INFO - 2018-04-06 06:18:32 --> Loader Class Initialized
INFO - 2018-04-06 06:18:32 --> Helper loaded: url_helper
INFO - 2018-04-06 06:18:32 --> Helper loaded: file_helper
INFO - 2018-04-06 06:18:32 --> Helper loaded: date_helper
INFO - 2018-04-06 06:18:32 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:18:32 --> Controller Class Initialized
INFO - 2018-04-06 06:18:32 --> Model Class Initialized
INFO - 2018-04-06 06:20:01 --> Config Class Initialized
INFO - 2018-04-06 06:20:01 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:20:01 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:20:01 --> Utf8 Class Initialized
INFO - 2018-04-06 06:20:01 --> URI Class Initialized
INFO - 2018-04-06 06:20:01 --> Router Class Initialized
INFO - 2018-04-06 06:20:01 --> Output Class Initialized
INFO - 2018-04-06 06:20:01 --> Security Class Initialized
DEBUG - 2018-04-06 06:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:20:01 --> Input Class Initialized
INFO - 2018-04-06 06:20:01 --> Language Class Initialized
INFO - 2018-04-06 06:20:01 --> Loader Class Initialized
INFO - 2018-04-06 06:20:01 --> Helper loaded: url_helper
INFO - 2018-04-06 06:20:01 --> Helper loaded: file_helper
INFO - 2018-04-06 06:20:01 --> Helper loaded: date_helper
INFO - 2018-04-06 06:20:01 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:20:01 --> Controller Class Initialized
INFO - 2018-04-06 06:20:01 --> Model Class Initialized
INFO - 2018-04-06 06:23:49 --> Config Class Initialized
INFO - 2018-04-06 06:23:49 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:23:49 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:23:49 --> Utf8 Class Initialized
INFO - 2018-04-06 06:23:49 --> URI Class Initialized
INFO - 2018-04-06 06:23:49 --> Router Class Initialized
INFO - 2018-04-06 06:23:49 --> Output Class Initialized
INFO - 2018-04-06 06:23:49 --> Security Class Initialized
DEBUG - 2018-04-06 06:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:23:49 --> Input Class Initialized
INFO - 2018-04-06 06:23:49 --> Language Class Initialized
INFO - 2018-04-06 06:23:49 --> Loader Class Initialized
INFO - 2018-04-06 06:23:49 --> Helper loaded: url_helper
INFO - 2018-04-06 06:23:49 --> Helper loaded: file_helper
INFO - 2018-04-06 06:23:49 --> Helper loaded: date_helper
INFO - 2018-04-06 06:23:49 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:23:49 --> Controller Class Initialized
INFO - 2018-04-06 06:23:49 --> Model Class Initialized
INFO - 2018-04-06 06:23:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:23:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:23:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:23:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:23:49 --> Final output sent to browser
DEBUG - 2018-04-06 06:23:49 --> Total execution time: 0.4878
INFO - 2018-04-06 06:24:11 --> Config Class Initialized
INFO - 2018-04-06 06:24:11 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:24:11 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:24:11 --> Utf8 Class Initialized
INFO - 2018-04-06 06:24:11 --> URI Class Initialized
INFO - 2018-04-06 06:24:11 --> Router Class Initialized
INFO - 2018-04-06 06:24:11 --> Output Class Initialized
INFO - 2018-04-06 06:24:11 --> Security Class Initialized
DEBUG - 2018-04-06 06:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:24:11 --> Input Class Initialized
INFO - 2018-04-06 06:24:11 --> Language Class Initialized
INFO - 2018-04-06 06:24:11 --> Loader Class Initialized
INFO - 2018-04-06 06:24:11 --> Helper loaded: url_helper
INFO - 2018-04-06 06:24:11 --> Helper loaded: file_helper
INFO - 2018-04-06 06:24:11 --> Helper loaded: date_helper
INFO - 2018-04-06 06:24:11 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:24:11 --> Controller Class Initialized
INFO - 2018-04-06 06:24:11 --> Model Class Initialized
INFO - 2018-04-06 06:24:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-06 06:24:11 --> Severity: Notice --> Trying to get property of non-object G:\xampp\htdocs\codeigniter\application\views\user\user.php 12
INFO - 2018-04-06 06:24:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:24:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:24:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:24:11 --> Final output sent to browser
DEBUG - 2018-04-06 06:24:11 --> Total execution time: 0.4553
INFO - 2018-04-06 06:24:27 --> Config Class Initialized
INFO - 2018-04-06 06:24:27 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:24:27 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:24:27 --> Utf8 Class Initialized
INFO - 2018-04-06 06:24:27 --> URI Class Initialized
INFO - 2018-04-06 06:24:27 --> Router Class Initialized
INFO - 2018-04-06 06:24:27 --> Output Class Initialized
INFO - 2018-04-06 06:24:27 --> Security Class Initialized
DEBUG - 2018-04-06 06:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:24:27 --> Input Class Initialized
INFO - 2018-04-06 06:24:27 --> Language Class Initialized
INFO - 2018-04-06 06:24:27 --> Loader Class Initialized
INFO - 2018-04-06 06:24:27 --> Helper loaded: url_helper
INFO - 2018-04-06 06:24:27 --> Helper loaded: file_helper
INFO - 2018-04-06 06:24:27 --> Helper loaded: date_helper
INFO - 2018-04-06 06:24:27 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:24:27 --> Controller Class Initialized
INFO - 2018-04-06 06:24:27 --> Model Class Initialized
INFO - 2018-04-06 06:24:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-06 06:24:27 --> Severity: Notice --> Undefined index: name G:\xampp\htdocs\codeigniter\application\views\user\user.php 12
INFO - 2018-04-06 06:24:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:24:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:24:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:24:27 --> Final output sent to browser
DEBUG - 2018-04-06 06:24:27 --> Total execution time: 0.5324
INFO - 2018-04-06 06:25:52 --> Config Class Initialized
INFO - 2018-04-06 06:25:52 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:25:52 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:25:52 --> Utf8 Class Initialized
INFO - 2018-04-06 06:25:52 --> URI Class Initialized
INFO - 2018-04-06 06:25:52 --> Router Class Initialized
INFO - 2018-04-06 06:25:52 --> Output Class Initialized
INFO - 2018-04-06 06:25:52 --> Security Class Initialized
DEBUG - 2018-04-06 06:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:25:52 --> Input Class Initialized
INFO - 2018-04-06 06:25:52 --> Language Class Initialized
INFO - 2018-04-06 06:25:52 --> Loader Class Initialized
INFO - 2018-04-06 06:25:52 --> Helper loaded: url_helper
INFO - 2018-04-06 06:25:52 --> Helper loaded: file_helper
INFO - 2018-04-06 06:25:52 --> Helper loaded: date_helper
INFO - 2018-04-06 06:25:52 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:25:53 --> Controller Class Initialized
INFO - 2018-04-06 06:25:53 --> Model Class Initialized
INFO - 2018-04-06 06:25:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-06 06:25:53 --> Severity: Notice --> Undefined variable: name G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
ERROR - 2018-04-06 06:25:53 --> Severity: Warning --> Invalid argument supplied for foreach() G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
INFO - 2018-04-06 06:25:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:25:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:25:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:25:53 --> Final output sent to browser
DEBUG - 2018-04-06 06:25:53 --> Total execution time: 0.3960
INFO - 2018-04-06 06:26:07 --> Config Class Initialized
INFO - 2018-04-06 06:26:07 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:26:07 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:26:07 --> Utf8 Class Initialized
INFO - 2018-04-06 06:26:07 --> URI Class Initialized
INFO - 2018-04-06 06:26:07 --> Router Class Initialized
INFO - 2018-04-06 06:26:07 --> Output Class Initialized
INFO - 2018-04-06 06:26:07 --> Security Class Initialized
DEBUG - 2018-04-06 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:26:07 --> Input Class Initialized
INFO - 2018-04-06 06:26:07 --> Language Class Initialized
INFO - 2018-04-06 06:26:07 --> Loader Class Initialized
INFO - 2018-04-06 06:26:07 --> Helper loaded: url_helper
INFO - 2018-04-06 06:26:07 --> Helper loaded: file_helper
INFO - 2018-04-06 06:26:07 --> Helper loaded: date_helper
INFO - 2018-04-06 06:26:07 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:26:07 --> Controller Class Initialized
INFO - 2018-04-06 06:26:07 --> Model Class Initialized
INFO - 2018-04-06 06:26:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-06 06:26:07 --> Severity: Notice --> Undefined variable: name G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
ERROR - 2018-04-06 06:26:07 --> Severity: Warning --> Invalid argument supplied for foreach() G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
INFO - 2018-04-06 06:26:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:26:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:26:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:26:07 --> Final output sent to browser
DEBUG - 2018-04-06 06:26:07 --> Total execution time: 0.4161
INFO - 2018-04-06 06:26:07 --> Config Class Initialized
INFO - 2018-04-06 06:26:07 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:26:07 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:26:07 --> Utf8 Class Initialized
INFO - 2018-04-06 06:26:07 --> URI Class Initialized
INFO - 2018-04-06 06:26:07 --> Router Class Initialized
INFO - 2018-04-06 06:26:07 --> Output Class Initialized
INFO - 2018-04-06 06:26:07 --> Security Class Initialized
DEBUG - 2018-04-06 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:26:07 --> Input Class Initialized
INFO - 2018-04-06 06:26:07 --> Language Class Initialized
ERROR - 2018-04-06 06:26:07 --> 404 Page Not Found: Assets/g
INFO - 2018-04-06 06:26:29 --> Config Class Initialized
INFO - 2018-04-06 06:26:29 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:26:29 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:26:29 --> Utf8 Class Initialized
INFO - 2018-04-06 06:26:29 --> URI Class Initialized
INFO - 2018-04-06 06:26:29 --> Router Class Initialized
INFO - 2018-04-06 06:26:29 --> Output Class Initialized
INFO - 2018-04-06 06:26:29 --> Security Class Initialized
DEBUG - 2018-04-06 06:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:26:29 --> Input Class Initialized
INFO - 2018-04-06 06:26:29 --> Language Class Initialized
INFO - 2018-04-06 06:26:29 --> Loader Class Initialized
INFO - 2018-04-06 06:26:29 --> Helper loaded: url_helper
INFO - 2018-04-06 06:26:29 --> Helper loaded: file_helper
INFO - 2018-04-06 06:26:29 --> Helper loaded: date_helper
INFO - 2018-04-06 06:26:29 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:26:29 --> Controller Class Initialized
INFO - 2018-04-06 06:26:29 --> Model Class Initialized
INFO - 2018-04-06 06:26:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-06 06:26:29 --> Severity: Notice --> Undefined variable: name G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
ERROR - 2018-04-06 06:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
INFO - 2018-04-06 06:26:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:26:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:26:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:26:29 --> Final output sent to browser
DEBUG - 2018-04-06 06:26:29 --> Total execution time: 0.3962
INFO - 2018-04-06 06:26:29 --> Config Class Initialized
INFO - 2018-04-06 06:26:29 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:26:29 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:26:29 --> Utf8 Class Initialized
INFO - 2018-04-06 06:26:29 --> URI Class Initialized
INFO - 2018-04-06 06:26:29 --> Router Class Initialized
INFO - 2018-04-06 06:26:30 --> Output Class Initialized
INFO - 2018-04-06 06:26:30 --> Security Class Initialized
DEBUG - 2018-04-06 06:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:26:30 --> Input Class Initialized
INFO - 2018-04-06 06:26:30 --> Language Class Initialized
ERROR - 2018-04-06 06:26:30 --> 404 Page Not Found: Assets/g
INFO - 2018-04-06 06:26:33 --> Config Class Initialized
INFO - 2018-04-06 06:26:33 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:26:33 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:26:33 --> Utf8 Class Initialized
INFO - 2018-04-06 06:26:33 --> URI Class Initialized
INFO - 2018-04-06 06:26:33 --> Router Class Initialized
INFO - 2018-04-06 06:26:33 --> Output Class Initialized
INFO - 2018-04-06 06:26:33 --> Security Class Initialized
DEBUG - 2018-04-06 06:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:26:33 --> Input Class Initialized
INFO - 2018-04-06 06:26:33 --> Language Class Initialized
INFO - 2018-04-06 06:26:33 --> Loader Class Initialized
INFO - 2018-04-06 06:26:33 --> Helper loaded: url_helper
INFO - 2018-04-06 06:26:33 --> Helper loaded: file_helper
INFO - 2018-04-06 06:26:33 --> Helper loaded: date_helper
INFO - 2018-04-06 06:26:33 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:26:33 --> Controller Class Initialized
INFO - 2018-04-06 06:26:33 --> Model Class Initialized
INFO - 2018-04-06 06:26:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-06 06:26:33 --> Severity: Notice --> Undefined variable: name G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
ERROR - 2018-04-06 06:26:33 --> Severity: Warning --> Invalid argument supplied for foreach() G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
INFO - 2018-04-06 06:26:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:26:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:26:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:26:33 --> Final output sent to browser
DEBUG - 2018-04-06 06:26:33 --> Total execution time: 0.3769
INFO - 2018-04-06 06:26:33 --> Config Class Initialized
INFO - 2018-04-06 06:26:33 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:26:33 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:26:33 --> Utf8 Class Initialized
INFO - 2018-04-06 06:26:33 --> URI Class Initialized
INFO - 2018-04-06 06:26:33 --> Router Class Initialized
INFO - 2018-04-06 06:26:33 --> Output Class Initialized
INFO - 2018-04-06 06:26:34 --> Security Class Initialized
DEBUG - 2018-04-06 06:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:26:34 --> Input Class Initialized
INFO - 2018-04-06 06:26:34 --> Language Class Initialized
ERROR - 2018-04-06 06:26:34 --> 404 Page Not Found: Assets/g
INFO - 2018-04-06 06:27:05 --> Config Class Initialized
INFO - 2018-04-06 06:27:05 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:27:05 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:27:05 --> Utf8 Class Initialized
INFO - 2018-04-06 06:27:05 --> URI Class Initialized
INFO - 2018-04-06 06:27:06 --> Router Class Initialized
INFO - 2018-04-06 06:27:06 --> Output Class Initialized
INFO - 2018-04-06 06:27:06 --> Security Class Initialized
DEBUG - 2018-04-06 06:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:27:06 --> Input Class Initialized
INFO - 2018-04-06 06:27:06 --> Language Class Initialized
INFO - 2018-04-06 06:27:06 --> Loader Class Initialized
INFO - 2018-04-06 06:27:06 --> Helper loaded: url_helper
INFO - 2018-04-06 06:27:06 --> Helper loaded: file_helper
INFO - 2018-04-06 06:27:06 --> Helper loaded: date_helper
INFO - 2018-04-06 06:27:06 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:27:06 --> Controller Class Initialized
INFO - 2018-04-06 06:27:06 --> Model Class Initialized
INFO - 2018-04-06 06:27:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:27:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:27:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:27:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:27:06 --> Final output sent to browser
DEBUG - 2018-04-06 06:27:06 --> Total execution time: 0.5449
INFO - 2018-04-06 06:27:06 --> Config Class Initialized
INFO - 2018-04-06 06:27:06 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:27:06 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:27:06 --> Utf8 Class Initialized
INFO - 2018-04-06 06:27:06 --> URI Class Initialized
INFO - 2018-04-06 06:27:06 --> Router Class Initialized
INFO - 2018-04-06 06:27:06 --> Output Class Initialized
INFO - 2018-04-06 06:27:06 --> Security Class Initialized
DEBUG - 2018-04-06 06:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:27:06 --> Input Class Initialized
INFO - 2018-04-06 06:27:06 --> Language Class Initialized
ERROR - 2018-04-06 06:27:06 --> 404 Page Not Found: Assets/g
INFO - 2018-04-06 06:29:51 --> Config Class Initialized
INFO - 2018-04-06 06:29:51 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:29:51 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:29:51 --> Utf8 Class Initialized
INFO - 2018-04-06 06:29:51 --> URI Class Initialized
INFO - 2018-04-06 06:29:51 --> Router Class Initialized
INFO - 2018-04-06 06:29:51 --> Output Class Initialized
INFO - 2018-04-06 06:29:51 --> Security Class Initialized
DEBUG - 2018-04-06 06:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:29:51 --> Input Class Initialized
INFO - 2018-04-06 06:29:51 --> Language Class Initialized
INFO - 2018-04-06 06:29:51 --> Loader Class Initialized
INFO - 2018-04-06 06:29:51 --> Helper loaded: url_helper
INFO - 2018-04-06 06:29:51 --> Helper loaded: file_helper
INFO - 2018-04-06 06:29:52 --> Helper loaded: date_helper
INFO - 2018-04-06 06:29:52 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:29:52 --> Controller Class Initialized
INFO - 2018-04-06 06:29:52 --> Model Class Initialized
INFO - 2018-04-06 06:29:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-06 06:29:52 --> Severity: error --> Exception: syntax error, unexpected '<' G:\xampp\htdocs\codeigniter\application\views\user\user.php 37
INFO - 2018-04-06 06:30:36 --> Config Class Initialized
INFO - 2018-04-06 06:30:36 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:30:36 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:30:36 --> Utf8 Class Initialized
INFO - 2018-04-06 06:30:36 --> URI Class Initialized
INFO - 2018-04-06 06:30:36 --> Router Class Initialized
INFO - 2018-04-06 06:30:36 --> Output Class Initialized
INFO - 2018-04-06 06:30:36 --> Security Class Initialized
DEBUG - 2018-04-06 06:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:30:36 --> Input Class Initialized
INFO - 2018-04-06 06:30:36 --> Language Class Initialized
INFO - 2018-04-06 06:30:36 --> Loader Class Initialized
INFO - 2018-04-06 06:30:36 --> Helper loaded: url_helper
INFO - 2018-04-06 06:30:36 --> Helper loaded: file_helper
INFO - 2018-04-06 06:30:36 --> Helper loaded: date_helper
INFO - 2018-04-06 06:30:36 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:30:36 --> Controller Class Initialized
INFO - 2018-04-06 06:30:36 --> Model Class Initialized
INFO - 2018-04-06 06:30:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-06 06:30:36 --> Severity: Notice --> Undefined property: stdClass::$address G:\xampp\htdocs\codeigniter\application\views\user\user.php 48
INFO - 2018-04-06 06:30:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:30:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:30:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:30:36 --> Final output sent to browser
DEBUG - 2018-04-06 06:30:36 --> Total execution time: 0.3793
INFO - 2018-04-06 06:30:36 --> Config Class Initialized
INFO - 2018-04-06 06:30:36 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:30:36 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:30:36 --> Utf8 Class Initialized
INFO - 2018-04-06 06:30:36 --> URI Class Initialized
INFO - 2018-04-06 06:30:36 --> Router Class Initialized
INFO - 2018-04-06 06:30:37 --> Output Class Initialized
INFO - 2018-04-06 06:30:37 --> Security Class Initialized
DEBUG - 2018-04-06 06:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:30:37 --> Input Class Initialized
INFO - 2018-04-06 06:30:37 --> Language Class Initialized
ERROR - 2018-04-06 06:30:37 --> 404 Page Not Found: Assets/g
INFO - 2018-04-06 06:31:17 --> Config Class Initialized
INFO - 2018-04-06 06:31:17 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:31:17 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:31:17 --> Utf8 Class Initialized
INFO - 2018-04-06 06:31:17 --> URI Class Initialized
INFO - 2018-04-06 06:31:17 --> Router Class Initialized
INFO - 2018-04-06 06:31:17 --> Output Class Initialized
INFO - 2018-04-06 06:31:17 --> Security Class Initialized
DEBUG - 2018-04-06 06:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:31:17 --> Input Class Initialized
INFO - 2018-04-06 06:31:17 --> Language Class Initialized
INFO - 2018-04-06 06:31:17 --> Loader Class Initialized
INFO - 2018-04-06 06:31:17 --> Helper loaded: url_helper
INFO - 2018-04-06 06:31:18 --> Helper loaded: file_helper
INFO - 2018-04-06 06:31:18 --> Helper loaded: date_helper
INFO - 2018-04-06 06:31:18 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:31:18 --> Controller Class Initialized
INFO - 2018-04-06 06:31:18 --> Model Class Initialized
INFO - 2018-04-06 06:31:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:31:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:31:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:31:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:31:18 --> Final output sent to browser
DEBUG - 2018-04-06 06:31:18 --> Total execution time: 0.3682
INFO - 2018-04-06 06:31:18 --> Config Class Initialized
INFO - 2018-04-06 06:31:18 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:31:18 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:31:18 --> Utf8 Class Initialized
INFO - 2018-04-06 06:31:18 --> URI Class Initialized
INFO - 2018-04-06 06:31:18 --> Router Class Initialized
INFO - 2018-04-06 06:31:18 --> Output Class Initialized
INFO - 2018-04-06 06:31:18 --> Security Class Initialized
DEBUG - 2018-04-06 06:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:31:18 --> Input Class Initialized
INFO - 2018-04-06 06:31:18 --> Language Class Initialized
ERROR - 2018-04-06 06:31:18 --> 404 Page Not Found: Assets/g
INFO - 2018-04-06 06:31:54 --> Config Class Initialized
INFO - 2018-04-06 06:31:54 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:31:54 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:31:54 --> Utf8 Class Initialized
INFO - 2018-04-06 06:31:54 --> URI Class Initialized
INFO - 2018-04-06 06:31:54 --> Router Class Initialized
INFO - 2018-04-06 06:31:54 --> Output Class Initialized
INFO - 2018-04-06 06:31:54 --> Security Class Initialized
DEBUG - 2018-04-06 06:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:31:54 --> Input Class Initialized
INFO - 2018-04-06 06:31:54 --> Language Class Initialized
INFO - 2018-04-06 06:31:54 --> Loader Class Initialized
INFO - 2018-04-06 06:31:54 --> Helper loaded: url_helper
INFO - 2018-04-06 06:31:54 --> Helper loaded: file_helper
INFO - 2018-04-06 06:31:54 --> Helper loaded: date_helper
INFO - 2018-04-06 06:31:54 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:31:54 --> Controller Class Initialized
INFO - 2018-04-06 06:31:54 --> Model Class Initialized
INFO - 2018-04-06 06:31:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:31:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:31:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:31:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:31:54 --> Final output sent to browser
DEBUG - 2018-04-06 06:31:55 --> Total execution time: 0.3598
INFO - 2018-04-06 06:38:34 --> Config Class Initialized
INFO - 2018-04-06 06:38:34 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:38:34 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:38:34 --> Utf8 Class Initialized
INFO - 2018-04-06 06:38:34 --> URI Class Initialized
INFO - 2018-04-06 06:38:34 --> Router Class Initialized
INFO - 2018-04-06 06:38:34 --> Output Class Initialized
INFO - 2018-04-06 06:38:34 --> Security Class Initialized
DEBUG - 2018-04-06 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:38:35 --> Input Class Initialized
INFO - 2018-04-06 06:38:35 --> Language Class Initialized
INFO - 2018-04-06 06:38:35 --> Loader Class Initialized
INFO - 2018-04-06 06:38:35 --> Helper loaded: url_helper
INFO - 2018-04-06 06:38:35 --> Helper loaded: file_helper
INFO - 2018-04-06 06:38:35 --> Helper loaded: date_helper
INFO - 2018-04-06 06:38:35 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:38:35 --> Controller Class Initialized
INFO - 2018-04-06 06:38:35 --> Model Class Initialized
INFO - 2018-04-06 06:38:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:38:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:38:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:38:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:38:35 --> Final output sent to browser
DEBUG - 2018-04-06 06:38:35 --> Total execution time: 0.4101
INFO - 2018-04-06 06:38:37 --> Config Class Initialized
INFO - 2018-04-06 06:38:37 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:38:37 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:38:37 --> Utf8 Class Initialized
INFO - 2018-04-06 06:38:37 --> URI Class Initialized
INFO - 2018-04-06 06:38:37 --> Router Class Initialized
INFO - 2018-04-06 06:38:37 --> Output Class Initialized
INFO - 2018-04-06 06:38:37 --> Security Class Initialized
DEBUG - 2018-04-06 06:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:38:37 --> Input Class Initialized
INFO - 2018-04-06 06:38:37 --> Language Class Initialized
INFO - 2018-04-06 06:38:37 --> Loader Class Initialized
INFO - 2018-04-06 06:38:37 --> Helper loaded: url_helper
INFO - 2018-04-06 06:38:37 --> Helper loaded: file_helper
INFO - 2018-04-06 06:38:37 --> Helper loaded: date_helper
INFO - 2018-04-06 06:38:37 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:38:37 --> Controller Class Initialized
INFO - 2018-04-06 06:38:37 --> Model Class Initialized
ERROR - 2018-04-06 06:38:37 --> Severity: error --> Exception: Call to undefined method Stud_Model::updateInfo() G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 35
INFO - 2018-04-06 06:42:34 --> Config Class Initialized
INFO - 2018-04-06 06:42:34 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:42:34 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:42:34 --> Utf8 Class Initialized
INFO - 2018-04-06 06:42:34 --> URI Class Initialized
INFO - 2018-04-06 06:42:34 --> Router Class Initialized
INFO - 2018-04-06 06:42:34 --> Output Class Initialized
INFO - 2018-04-06 06:42:34 --> Security Class Initialized
DEBUG - 2018-04-06 06:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:42:34 --> Input Class Initialized
INFO - 2018-04-06 06:42:35 --> Language Class Initialized
INFO - 2018-04-06 06:42:35 --> Loader Class Initialized
INFO - 2018-04-06 06:42:35 --> Helper loaded: url_helper
INFO - 2018-04-06 06:42:35 --> Helper loaded: file_helper
INFO - 2018-04-06 06:42:35 --> Helper loaded: date_helper
INFO - 2018-04-06 06:42:35 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:42:35 --> Controller Class Initialized
INFO - 2018-04-06 06:42:35 --> Model Class Initialized
INFO - 2018-04-06 06:42:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:42:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:42:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:42:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:42:35 --> Final output sent to browser
DEBUG - 2018-04-06 06:42:35 --> Total execution time: 0.3778
INFO - 2018-04-06 06:42:37 --> Config Class Initialized
INFO - 2018-04-06 06:42:37 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:42:37 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:42:37 --> Utf8 Class Initialized
INFO - 2018-04-06 06:43:35 --> Config Class Initialized
INFO - 2018-04-06 06:43:35 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:43:35 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:43:35 --> Utf8 Class Initialized
INFO - 2018-04-06 06:43:35 --> URI Class Initialized
INFO - 2018-04-06 06:43:35 --> Router Class Initialized
INFO - 2018-04-06 06:43:35 --> Output Class Initialized
INFO - 2018-04-06 06:43:35 --> Security Class Initialized
DEBUG - 2018-04-06 06:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:43:35 --> Input Class Initialized
INFO - 2018-04-06 06:43:35 --> Language Class Initialized
ERROR - 2018-04-06 06:43:35 --> Severity: error --> Exception: syntax error, unexpected '$assign_data' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 36
INFO - 2018-04-06 06:44:07 --> Config Class Initialized
INFO - 2018-04-06 06:44:07 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:44:07 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:44:07 --> Utf8 Class Initialized
INFO - 2018-04-06 06:44:07 --> URI Class Initialized
INFO - 2018-04-06 06:44:07 --> Router Class Initialized
INFO - 2018-04-06 06:44:07 --> Output Class Initialized
INFO - 2018-04-06 06:44:07 --> Security Class Initialized
DEBUG - 2018-04-06 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:44:07 --> Input Class Initialized
INFO - 2018-04-06 06:44:07 --> Language Class Initialized
ERROR - 2018-04-06 06:44:07 --> Severity: error --> Exception: syntax error, unexpected '$assign_data' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 36
INFO - 2018-04-06 06:44:58 --> Config Class Initialized
INFO - 2018-04-06 06:44:58 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:44:58 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:44:58 --> Utf8 Class Initialized
INFO - 2018-04-06 06:44:58 --> URI Class Initialized
INFO - 2018-04-06 06:44:58 --> Router Class Initialized
INFO - 2018-04-06 06:44:58 --> Output Class Initialized
INFO - 2018-04-06 06:44:58 --> Security Class Initialized
DEBUG - 2018-04-06 06:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:44:58 --> Input Class Initialized
INFO - 2018-04-06 06:44:58 --> Language Class Initialized
INFO - 2018-04-06 06:44:58 --> Loader Class Initialized
INFO - 2018-04-06 06:44:58 --> Helper loaded: url_helper
INFO - 2018-04-06 06:44:58 --> Helper loaded: file_helper
INFO - 2018-04-06 06:44:58 --> Helper loaded: date_helper
INFO - 2018-04-06 06:44:58 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:44:58 --> Controller Class Initialized
INFO - 2018-04-06 06:44:58 --> Model Class Initialized
INFO - 2018-04-06 06:44:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:44:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:44:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:44:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:44:58 --> Final output sent to browser
DEBUG - 2018-04-06 06:44:58 --> Total execution time: 0.6293
INFO - 2018-04-06 06:45:00 --> Config Class Initialized
INFO - 2018-04-06 06:45:00 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:45:00 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:45:00 --> Utf8 Class Initialized
INFO - 2018-04-06 06:47:21 --> Config Class Initialized
INFO - 2018-04-06 06:47:21 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:47:21 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:47:21 --> Utf8 Class Initialized
INFO - 2018-04-06 06:47:23 --> Config Class Initialized
INFO - 2018-04-06 06:47:23 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:47:23 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:47:23 --> Utf8 Class Initialized
INFO - 2018-04-06 06:47:23 --> URI Class Initialized
INFO - 2018-04-06 06:47:23 --> Router Class Initialized
INFO - 2018-04-06 06:47:23 --> Output Class Initialized
INFO - 2018-04-06 06:47:23 --> Security Class Initialized
DEBUG - 2018-04-06 06:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:47:23 --> Input Class Initialized
INFO - 2018-04-06 06:47:23 --> Language Class Initialized
INFO - 2018-04-06 06:47:23 --> Loader Class Initialized
INFO - 2018-04-06 06:47:23 --> Helper loaded: url_helper
INFO - 2018-04-06 06:47:23 --> Helper loaded: file_helper
INFO - 2018-04-06 06:47:23 --> Helper loaded: date_helper
INFO - 2018-04-06 06:47:23 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:47:24 --> Controller Class Initialized
INFO - 2018-04-06 06:47:24 --> Model Class Initialized
INFO - 2018-04-06 06:47:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:47:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:47:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:47:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:47:24 --> Final output sent to browser
DEBUG - 2018-04-06 06:47:24 --> Total execution time: 0.9429
INFO - 2018-04-06 06:47:26 --> Config Class Initialized
INFO - 2018-04-06 06:47:26 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:47:26 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:47:26 --> Utf8 Class Initialized
INFO - 2018-04-06 06:48:43 --> Config Class Initialized
INFO - 2018-04-06 06:48:43 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:48:43 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:48:43 --> Utf8 Class Initialized
INFO - 2018-04-06 06:48:43 --> URI Class Initialized
INFO - 2018-04-06 06:48:43 --> Router Class Initialized
INFO - 2018-04-06 06:48:43 --> Output Class Initialized
INFO - 2018-04-06 06:48:43 --> Security Class Initialized
DEBUG - 2018-04-06 06:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:48:43 --> Input Class Initialized
INFO - 2018-04-06 06:48:43 --> Language Class Initialized
INFO - 2018-04-06 06:48:43 --> Loader Class Initialized
INFO - 2018-04-06 06:48:43 --> Helper loaded: url_helper
INFO - 2018-04-06 06:48:43 --> Helper loaded: file_helper
INFO - 2018-04-06 06:48:43 --> Helper loaded: date_helper
INFO - 2018-04-06 06:48:43 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:48:43 --> Controller Class Initialized
INFO - 2018-04-06 06:48:43 --> Model Class Initialized
INFO - 2018-04-06 06:48:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:48:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:48:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:48:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:48:43 --> Final output sent to browser
DEBUG - 2018-04-06 06:48:43 --> Total execution time: 0.4050
INFO - 2018-04-06 06:48:45 --> Config Class Initialized
INFO - 2018-04-06 06:48:45 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:48:45 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:48:45 --> Utf8 Class Initialized
INFO - 2018-04-06 06:48:45 --> URI Class Initialized
INFO - 2018-04-06 06:48:45 --> Router Class Initialized
INFO - 2018-04-06 06:48:45 --> Output Class Initialized
INFO - 2018-04-06 06:48:45 --> Security Class Initialized
DEBUG - 2018-04-06 06:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:48:45 --> Input Class Initialized
INFO - 2018-04-06 06:48:45 --> Language Class Initialized
INFO - 2018-04-06 06:48:45 --> Loader Class Initialized
INFO - 2018-04-06 06:48:45 --> Helper loaded: url_helper
INFO - 2018-04-06 06:48:45 --> Helper loaded: file_helper
INFO - 2018-04-06 06:48:45 --> Helper loaded: date_helper
INFO - 2018-04-06 06:48:45 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:48:45 --> Controller Class Initialized
INFO - 2018-04-06 06:48:45 --> Model Class Initialized
INFO - 2018-04-06 06:48:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:48:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:48:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:48:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:48:45 --> Final output sent to browser
DEBUG - 2018-04-06 06:48:45 --> Total execution time: 0.4309
INFO - 2018-04-06 06:48:47 --> Config Class Initialized
INFO - 2018-04-06 06:48:47 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:48:47 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:48:47 --> Utf8 Class Initialized
INFO - 2018-04-06 06:49:06 --> Config Class Initialized
INFO - 2018-04-06 06:49:06 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:49:06 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:49:06 --> Utf8 Class Initialized
INFO - 2018-04-06 06:49:07 --> Config Class Initialized
INFO - 2018-04-06 06:49:07 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:49:07 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:49:07 --> Utf8 Class Initialized
INFO - 2018-04-06 06:49:07 --> URI Class Initialized
INFO - 2018-04-06 06:49:07 --> Router Class Initialized
INFO - 2018-04-06 06:49:07 --> Output Class Initialized
INFO - 2018-04-06 06:49:07 --> Security Class Initialized
DEBUG - 2018-04-06 06:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:49:07 --> Input Class Initialized
INFO - 2018-04-06 06:49:07 --> Language Class Initialized
INFO - 2018-04-06 06:49:07 --> Loader Class Initialized
INFO - 2018-04-06 06:49:07 --> Helper loaded: url_helper
INFO - 2018-04-06 06:49:07 --> Helper loaded: file_helper
INFO - 2018-04-06 06:49:07 --> Helper loaded: date_helper
INFO - 2018-04-06 06:49:07 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:49:07 --> Controller Class Initialized
INFO - 2018-04-06 06:49:07 --> Model Class Initialized
INFO - 2018-04-06 06:49:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:49:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:49:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:49:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:49:07 --> Final output sent to browser
DEBUG - 2018-04-06 06:49:07 --> Total execution time: 0.3924
INFO - 2018-04-06 06:49:10 --> Config Class Initialized
INFO - 2018-04-06 06:49:10 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:49:10 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:49:10 --> Utf8 Class Initialized
INFO - 2018-04-06 06:49:10 --> URI Class Initialized
INFO - 2018-04-06 06:49:10 --> Router Class Initialized
INFO - 2018-04-06 06:49:10 --> Output Class Initialized
INFO - 2018-04-06 06:49:10 --> Security Class Initialized
DEBUG - 2018-04-06 06:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:49:10 --> Input Class Initialized
INFO - 2018-04-06 06:49:10 --> Language Class Initialized
INFO - 2018-04-06 06:49:10 --> Loader Class Initialized
INFO - 2018-04-06 06:49:10 --> Helper loaded: url_helper
INFO - 2018-04-06 06:49:10 --> Helper loaded: file_helper
INFO - 2018-04-06 06:49:10 --> Helper loaded: date_helper
INFO - 2018-04-06 06:49:10 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:49:10 --> Controller Class Initialized
INFO - 2018-04-06 06:49:10 --> Model Class Initialized
INFO - 2018-04-06 06:49:10 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:49:10 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:49:10 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:49:10 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:49:10 --> Final output sent to browser
DEBUG - 2018-04-06 06:49:10 --> Total execution time: 0.3708
INFO - 2018-04-06 06:49:12 --> Config Class Initialized
INFO - 2018-04-06 06:49:12 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:49:12 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:49:12 --> Utf8 Class Initialized
INFO - 2018-04-06 06:49:42 --> Config Class Initialized
INFO - 2018-04-06 06:49:42 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:49:42 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:49:42 --> Utf8 Class Initialized
INFO - 2018-04-06 06:50:16 --> Config Class Initialized
INFO - 2018-04-06 06:50:16 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:50:16 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:50:16 --> Utf8 Class Initialized
INFO - 2018-04-06 06:50:17 --> Config Class Initialized
INFO - 2018-04-06 06:50:17 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:50:17 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:50:17 --> Utf8 Class Initialized
INFO - 2018-04-06 06:50:39 --> Config Class Initialized
INFO - 2018-04-06 06:50:39 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:50:39 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:50:39 --> Utf8 Class Initialized
INFO - 2018-04-06 06:50:40 --> Config Class Initialized
INFO - 2018-04-06 06:50:40 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:50:40 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:50:40 --> Utf8 Class Initialized
INFO - 2018-04-06 06:50:42 --> Config Class Initialized
INFO - 2018-04-06 06:50:42 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:50:42 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:50:42 --> Utf8 Class Initialized
INFO - 2018-04-06 06:50:42 --> URI Class Initialized
INFO - 2018-04-06 06:50:42 --> Router Class Initialized
INFO - 2018-04-06 06:50:42 --> Output Class Initialized
INFO - 2018-04-06 06:50:42 --> Security Class Initialized
DEBUG - 2018-04-06 06:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:50:42 --> Input Class Initialized
INFO - 2018-04-06 06:50:42 --> Language Class Initialized
INFO - 2018-04-06 06:50:42 --> Loader Class Initialized
INFO - 2018-04-06 06:50:42 --> Helper loaded: url_helper
INFO - 2018-04-06 06:50:42 --> Helper loaded: file_helper
INFO - 2018-04-06 06:50:42 --> Helper loaded: date_helper
INFO - 2018-04-06 06:50:42 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:50:42 --> Controller Class Initialized
INFO - 2018-04-06 06:50:42 --> Model Class Initialized
INFO - 2018-04-06 06:50:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:50:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:50:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:50:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:50:42 --> Final output sent to browser
DEBUG - 2018-04-06 06:50:42 --> Total execution time: 0.3905
INFO - 2018-04-06 06:50:43 --> Config Class Initialized
INFO - 2018-04-06 06:50:43 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:50:43 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:50:43 --> Utf8 Class Initialized
INFO - 2018-04-06 06:50:43 --> URI Class Initialized
INFO - 2018-04-06 06:50:43 --> Router Class Initialized
INFO - 2018-04-06 06:50:43 --> Output Class Initialized
INFO - 2018-04-06 06:50:43 --> Security Class Initialized
DEBUG - 2018-04-06 06:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:50:43 --> Input Class Initialized
INFO - 2018-04-06 06:50:43 --> Language Class Initialized
INFO - 2018-04-06 06:50:43 --> Loader Class Initialized
INFO - 2018-04-06 06:50:43 --> Helper loaded: url_helper
INFO - 2018-04-06 06:50:43 --> Helper loaded: file_helper
INFO - 2018-04-06 06:50:44 --> Helper loaded: date_helper
INFO - 2018-04-06 06:50:44 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:50:44 --> Controller Class Initialized
INFO - 2018-04-06 06:50:44 --> Model Class Initialized
INFO - 2018-04-06 06:50:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:50:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:50:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:50:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:50:44 --> Final output sent to browser
DEBUG - 2018-04-06 06:50:44 --> Total execution time: 0.4171
INFO - 2018-04-06 06:50:46 --> Config Class Initialized
INFO - 2018-04-06 06:50:46 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:50:46 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:50:46 --> Utf8 Class Initialized
INFO - 2018-04-06 06:53:35 --> Config Class Initialized
INFO - 2018-04-06 06:53:35 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:53:35 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:53:35 --> Utf8 Class Initialized
INFO - 2018-04-06 06:53:35 --> URI Class Initialized
INFO - 2018-04-06 06:53:35 --> Router Class Initialized
INFO - 2018-04-06 06:53:35 --> Output Class Initialized
INFO - 2018-04-06 06:53:35 --> Security Class Initialized
DEBUG - 2018-04-06 06:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:53:35 --> Input Class Initialized
INFO - 2018-04-06 06:53:35 --> Language Class Initialized
INFO - 2018-04-06 06:53:35 --> Loader Class Initialized
INFO - 2018-04-06 06:53:35 --> Helper loaded: url_helper
INFO - 2018-04-06 06:53:35 --> Helper loaded: file_helper
INFO - 2018-04-06 06:53:35 --> Helper loaded: date_helper
INFO - 2018-04-06 06:53:35 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:53:35 --> Controller Class Initialized
INFO - 2018-04-06 06:53:35 --> Model Class Initialized
INFO - 2018-04-06 06:53:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:53:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:53:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:53:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:53:35 --> Final output sent to browser
DEBUG - 2018-04-06 06:53:35 --> Total execution time: 0.3915
INFO - 2018-04-06 06:53:37 --> Config Class Initialized
INFO - 2018-04-06 06:53:37 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:53:37 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:53:37 --> Utf8 Class Initialized
INFO - 2018-04-06 06:53:37 --> URI Class Initialized
INFO - 2018-04-06 06:53:37 --> Router Class Initialized
INFO - 2018-04-06 06:53:37 --> Output Class Initialized
INFO - 2018-04-06 06:53:37 --> Security Class Initialized
DEBUG - 2018-04-06 06:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:53:37 --> Input Class Initialized
INFO - 2018-04-06 06:53:37 --> Language Class Initialized
INFO - 2018-04-06 06:53:37 --> Loader Class Initialized
INFO - 2018-04-06 06:53:37 --> Helper loaded: url_helper
INFO - 2018-04-06 06:53:37 --> Helper loaded: file_helper
INFO - 2018-04-06 06:53:37 --> Helper loaded: date_helper
INFO - 2018-04-06 06:53:37 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:53:37 --> Controller Class Initialized
INFO - 2018-04-06 06:53:37 --> Model Class Initialized
INFO - 2018-04-06 06:54:03 --> Config Class Initialized
INFO - 2018-04-06 06:54:03 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:54:03 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:54:03 --> Utf8 Class Initialized
INFO - 2018-04-06 06:54:03 --> URI Class Initialized
INFO - 2018-04-06 06:54:03 --> Router Class Initialized
INFO - 2018-04-06 06:54:03 --> Output Class Initialized
INFO - 2018-04-06 06:54:03 --> Security Class Initialized
DEBUG - 2018-04-06 06:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:54:03 --> Input Class Initialized
INFO - 2018-04-06 06:54:03 --> Language Class Initialized
INFO - 2018-04-06 06:54:03 --> Loader Class Initialized
INFO - 2018-04-06 06:54:03 --> Helper loaded: url_helper
INFO - 2018-04-06 06:54:03 --> Helper loaded: file_helper
INFO - 2018-04-06 06:54:03 --> Helper loaded: date_helper
INFO - 2018-04-06 06:54:03 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:54:03 --> Controller Class Initialized
INFO - 2018-04-06 06:54:03 --> Model Class Initialized
INFO - 2018-04-06 06:54:05 --> Config Class Initialized
INFO - 2018-04-06 06:54:05 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:54:05 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:54:05 --> Utf8 Class Initialized
INFO - 2018-04-06 06:54:05 --> URI Class Initialized
INFO - 2018-04-06 06:54:05 --> Router Class Initialized
INFO - 2018-04-06 06:54:05 --> Output Class Initialized
INFO - 2018-04-06 06:54:05 --> Security Class Initialized
DEBUG - 2018-04-06 06:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:54:05 --> Input Class Initialized
INFO - 2018-04-06 06:54:05 --> Language Class Initialized
INFO - 2018-04-06 06:54:05 --> Loader Class Initialized
INFO - 2018-04-06 06:54:05 --> Helper loaded: url_helper
INFO - 2018-04-06 06:54:05 --> Helper loaded: file_helper
INFO - 2018-04-06 06:54:05 --> Helper loaded: date_helper
INFO - 2018-04-06 06:54:05 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:54:05 --> Controller Class Initialized
INFO - 2018-04-06 06:54:05 --> Model Class Initialized
INFO - 2018-04-06 06:54:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:54:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:54:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:54:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:54:05 --> Final output sent to browser
DEBUG - 2018-04-06 06:54:05 --> Total execution time: 0.5132
INFO - 2018-04-06 06:54:07 --> Config Class Initialized
INFO - 2018-04-06 06:54:07 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:54:07 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:54:07 --> Utf8 Class Initialized
INFO - 2018-04-06 06:54:07 --> URI Class Initialized
INFO - 2018-04-06 06:54:07 --> Router Class Initialized
INFO - 2018-04-06 06:54:07 --> Output Class Initialized
INFO - 2018-04-06 06:54:07 --> Security Class Initialized
DEBUG - 2018-04-06 06:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:54:07 --> Input Class Initialized
INFO - 2018-04-06 06:54:07 --> Language Class Initialized
INFO - 2018-04-06 06:54:08 --> Loader Class Initialized
INFO - 2018-04-06 06:54:08 --> Helper loaded: url_helper
INFO - 2018-04-06 06:54:08 --> Helper loaded: file_helper
INFO - 2018-04-06 06:54:08 --> Helper loaded: date_helper
INFO - 2018-04-06 06:54:08 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:54:08 --> Controller Class Initialized
INFO - 2018-04-06 06:54:08 --> Model Class Initialized
INFO - 2018-04-06 06:56:39 --> Config Class Initialized
INFO - 2018-04-06 06:56:39 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:56:39 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:56:39 --> Utf8 Class Initialized
INFO - 2018-04-06 06:56:39 --> URI Class Initialized
INFO - 2018-04-06 06:56:39 --> Router Class Initialized
INFO - 2018-04-06 06:56:39 --> Output Class Initialized
INFO - 2018-04-06 06:56:39 --> Security Class Initialized
DEBUG - 2018-04-06 06:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:56:39 --> Input Class Initialized
INFO - 2018-04-06 06:56:39 --> Language Class Initialized
ERROR - 2018-04-06 06:56:39 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 33
INFO - 2018-04-06 06:57:10 --> Config Class Initialized
INFO - 2018-04-06 06:57:10 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:57:10 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:57:10 --> Utf8 Class Initialized
INFO - 2018-04-06 06:57:10 --> URI Class Initialized
INFO - 2018-04-06 06:57:10 --> Router Class Initialized
INFO - 2018-04-06 06:57:10 --> Output Class Initialized
INFO - 2018-04-06 06:57:10 --> Security Class Initialized
DEBUG - 2018-04-06 06:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:57:10 --> Input Class Initialized
INFO - 2018-04-06 06:57:10 --> Language Class Initialized
ERROR - 2018-04-06 06:57:10 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 33
INFO - 2018-04-06 06:57:11 --> Config Class Initialized
INFO - 2018-04-06 06:57:11 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:57:11 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:57:11 --> Utf8 Class Initialized
INFO - 2018-04-06 06:57:11 --> URI Class Initialized
INFO - 2018-04-06 06:57:11 --> Router Class Initialized
INFO - 2018-04-06 06:57:11 --> Output Class Initialized
INFO - 2018-04-06 06:57:11 --> Security Class Initialized
DEBUG - 2018-04-06 06:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:57:11 --> Input Class Initialized
INFO - 2018-04-06 06:57:11 --> Language Class Initialized
ERROR - 2018-04-06 06:57:12 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 33
INFO - 2018-04-06 06:57:15 --> Config Class Initialized
INFO - 2018-04-06 06:57:15 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:57:15 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:57:15 --> Utf8 Class Initialized
INFO - 2018-04-06 06:57:15 --> URI Class Initialized
INFO - 2018-04-06 06:57:15 --> Router Class Initialized
INFO - 2018-04-06 06:57:15 --> Output Class Initialized
INFO - 2018-04-06 06:57:15 --> Security Class Initialized
DEBUG - 2018-04-06 06:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:57:15 --> Input Class Initialized
INFO - 2018-04-06 06:57:15 --> Language Class Initialized
ERROR - 2018-04-06 06:57:15 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 33
INFO - 2018-04-06 06:57:18 --> Config Class Initialized
INFO - 2018-04-06 06:57:18 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:57:18 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:57:18 --> Utf8 Class Initialized
INFO - 2018-04-06 06:57:18 --> URI Class Initialized
INFO - 2018-04-06 06:57:18 --> Router Class Initialized
INFO - 2018-04-06 06:57:18 --> Output Class Initialized
INFO - 2018-04-06 06:57:18 --> Security Class Initialized
DEBUG - 2018-04-06 06:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:57:18 --> Input Class Initialized
INFO - 2018-04-06 06:57:18 --> Language Class Initialized
ERROR - 2018-04-06 06:57:18 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 33
INFO - 2018-04-06 06:57:42 --> Config Class Initialized
INFO - 2018-04-06 06:57:42 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:57:42 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:57:42 --> Utf8 Class Initialized
INFO - 2018-04-06 06:57:42 --> URI Class Initialized
INFO - 2018-04-06 06:57:42 --> Router Class Initialized
INFO - 2018-04-06 06:57:42 --> Output Class Initialized
INFO - 2018-04-06 06:57:42 --> Security Class Initialized
DEBUG - 2018-04-06 06:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:57:42 --> Input Class Initialized
INFO - 2018-04-06 06:57:42 --> Language Class Initialized
INFO - 2018-04-06 06:57:42 --> Loader Class Initialized
INFO - 2018-04-06 06:57:42 --> Helper loaded: url_helper
INFO - 2018-04-06 06:57:42 --> Helper loaded: file_helper
INFO - 2018-04-06 06:57:42 --> Helper loaded: date_helper
INFO - 2018-04-06 06:57:42 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:57:43 --> Controller Class Initialized
INFO - 2018-04-06 06:57:43 --> Model Class Initialized
INFO - 2018-04-06 06:57:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-06 06:57:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-06 06:57:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-06 06:57:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-06 06:57:43 --> Final output sent to browser
DEBUG - 2018-04-06 06:57:43 --> Total execution time: 0.8607
INFO - 2018-04-06 06:57:45 --> Config Class Initialized
INFO - 2018-04-06 06:57:45 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:57:45 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:57:45 --> Utf8 Class Initialized
INFO - 2018-04-06 06:57:45 --> URI Class Initialized
INFO - 2018-04-06 06:57:45 --> Router Class Initialized
INFO - 2018-04-06 06:57:45 --> Output Class Initialized
INFO - 2018-04-06 06:57:45 --> Security Class Initialized
DEBUG - 2018-04-06 06:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:57:45 --> Input Class Initialized
INFO - 2018-04-06 06:57:45 --> Language Class Initialized
INFO - 2018-04-06 06:57:45 --> Loader Class Initialized
INFO - 2018-04-06 06:57:45 --> Helper loaded: url_helper
INFO - 2018-04-06 06:57:45 --> Helper loaded: file_helper
INFO - 2018-04-06 06:57:45 --> Helper loaded: date_helper
INFO - 2018-04-06 06:57:45 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:57:45 --> Controller Class Initialized
INFO - 2018-04-06 06:57:46 --> Model Class Initialized
INFO - 2018-04-06 06:58:13 --> Config Class Initialized
INFO - 2018-04-06 06:58:13 --> Hooks Class Initialized
DEBUG - 2018-04-06 06:58:13 --> UTF-8 Support Enabled
INFO - 2018-04-06 06:58:13 --> Utf8 Class Initialized
INFO - 2018-04-06 06:58:13 --> URI Class Initialized
INFO - 2018-04-06 06:58:13 --> Router Class Initialized
INFO - 2018-04-06 06:58:13 --> Output Class Initialized
INFO - 2018-04-06 06:58:13 --> Security Class Initialized
DEBUG - 2018-04-06 06:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-06 06:58:13 --> Input Class Initialized
INFO - 2018-04-06 06:58:13 --> Language Class Initialized
INFO - 2018-04-06 06:58:13 --> Loader Class Initialized
INFO - 2018-04-06 06:58:13 --> Helper loaded: url_helper
INFO - 2018-04-06 06:58:13 --> Helper loaded: file_helper
INFO - 2018-04-06 06:58:13 --> Helper loaded: date_helper
INFO - 2018-04-06 06:58:13 --> Database Driver Class Initialized
DEBUG - 2018-04-06 06:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-06 06:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-06 06:58:13 --> Controller Class Initialized
INFO - 2018-04-06 06:58:13 --> Model Class Initialized
