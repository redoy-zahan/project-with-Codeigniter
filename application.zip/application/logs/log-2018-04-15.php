<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-15 01:43:51 --> Config Class Initialized
INFO - 2018-04-15 01:43:51 --> Hooks Class Initialized
DEBUG - 2018-04-15 01:43:51 --> UTF-8 Support Enabled
INFO - 2018-04-15 01:43:51 --> Utf8 Class Initialized
INFO - 2018-04-15 01:43:51 --> URI Class Initialized
DEBUG - 2018-04-15 01:43:51 --> No URI present. Default controller set.
INFO - 2018-04-15 01:43:51 --> Router Class Initialized
INFO - 2018-04-15 01:43:51 --> Output Class Initialized
INFO - 2018-04-15 01:43:51 --> Security Class Initialized
DEBUG - 2018-04-15 01:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 01:43:51 --> Input Class Initialized
INFO - 2018-04-15 01:43:51 --> Language Class Initialized
INFO - 2018-04-15 01:43:51 --> Loader Class Initialized
INFO - 2018-04-15 01:43:51 --> Helper loaded: url_helper
INFO - 2018-04-15 01:43:51 --> Helper loaded: file_helper
INFO - 2018-04-15 01:43:51 --> Helper loaded: date_helper
INFO - 2018-04-15 01:43:51 --> Database Driver Class Initialized
DEBUG - 2018-04-15 01:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 01:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 01:43:51 --> Controller Class Initialized
INFO - 2018-04-15 01:43:51 --> Config Class Initialized
INFO - 2018-04-15 01:43:51 --> Hooks Class Initialized
DEBUG - 2018-04-15 01:43:52 --> UTF-8 Support Enabled
INFO - 2018-04-15 01:43:52 --> Utf8 Class Initialized
INFO - 2018-04-15 01:43:52 --> URI Class Initialized
INFO - 2018-04-15 01:43:52 --> Router Class Initialized
INFO - 2018-04-15 01:43:52 --> Output Class Initialized
INFO - 2018-04-15 01:43:52 --> Security Class Initialized
DEBUG - 2018-04-15 01:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 01:43:52 --> Input Class Initialized
INFO - 2018-04-15 01:43:52 --> Language Class Initialized
INFO - 2018-04-15 01:43:52 --> Loader Class Initialized
INFO - 2018-04-15 01:43:52 --> Helper loaded: url_helper
INFO - 2018-04-15 01:43:52 --> Helper loaded: file_helper
INFO - 2018-04-15 01:43:52 --> Helper loaded: date_helper
INFO - 2018-04-15 01:43:52 --> Database Driver Class Initialized
DEBUG - 2018-04-15 01:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 01:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 01:43:52 --> Controller Class Initialized
INFO - 2018-04-15 01:43:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 01:43:52 --> Final output sent to browser
DEBUG - 2018-04-15 01:43:52 --> Total execution time: 0.2937
INFO - 2018-04-15 01:45:40 --> Config Class Initialized
INFO - 2018-04-15 01:45:40 --> Hooks Class Initialized
DEBUG - 2018-04-15 01:45:40 --> UTF-8 Support Enabled
INFO - 2018-04-15 01:45:40 --> Utf8 Class Initialized
INFO - 2018-04-15 01:45:40 --> URI Class Initialized
DEBUG - 2018-04-15 01:45:40 --> No URI present. Default controller set.
INFO - 2018-04-15 01:45:40 --> Router Class Initialized
INFO - 2018-04-15 01:45:40 --> Output Class Initialized
INFO - 2018-04-15 01:45:40 --> Security Class Initialized
DEBUG - 2018-04-15 01:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 01:45:40 --> Input Class Initialized
INFO - 2018-04-15 01:45:40 --> Language Class Initialized
INFO - 2018-04-15 01:45:40 --> Loader Class Initialized
INFO - 2018-04-15 01:45:40 --> Helper loaded: url_helper
INFO - 2018-04-15 01:45:40 --> Helper loaded: file_helper
INFO - 2018-04-15 01:45:40 --> Helper loaded: date_helper
INFO - 2018-04-15 01:45:40 --> Database Driver Class Initialized
DEBUG - 2018-04-15 01:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 01:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 01:45:40 --> Controller Class Initialized
INFO - 2018-04-15 01:45:40 --> Config Class Initialized
INFO - 2018-04-15 01:45:40 --> Hooks Class Initialized
DEBUG - 2018-04-15 01:45:40 --> UTF-8 Support Enabled
INFO - 2018-04-15 01:45:40 --> Utf8 Class Initialized
INFO - 2018-04-15 01:45:40 --> URI Class Initialized
INFO - 2018-04-15 01:45:40 --> Router Class Initialized
INFO - 2018-04-15 01:45:40 --> Output Class Initialized
INFO - 2018-04-15 01:45:40 --> Security Class Initialized
DEBUG - 2018-04-15 01:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 01:45:40 --> Input Class Initialized
INFO - 2018-04-15 01:45:40 --> Language Class Initialized
INFO - 2018-04-15 01:45:40 --> Loader Class Initialized
INFO - 2018-04-15 01:45:40 --> Helper loaded: url_helper
INFO - 2018-04-15 01:45:40 --> Helper loaded: file_helper
INFO - 2018-04-15 01:45:40 --> Helper loaded: date_helper
INFO - 2018-04-15 01:45:40 --> Database Driver Class Initialized
DEBUG - 2018-04-15 01:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 01:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 01:45:40 --> Controller Class Initialized
INFO - 2018-04-15 01:45:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 01:45:40 --> Final output sent to browser
DEBUG - 2018-04-15 01:45:40 --> Total execution time: 0.2106
INFO - 2018-04-15 01:54:30 --> Config Class Initialized
INFO - 2018-04-15 01:54:30 --> Hooks Class Initialized
DEBUG - 2018-04-15 01:54:30 --> UTF-8 Support Enabled
INFO - 2018-04-15 01:54:30 --> Utf8 Class Initialized
INFO - 2018-04-15 01:54:30 --> URI Class Initialized
INFO - 2018-04-15 01:54:30 --> Router Class Initialized
INFO - 2018-04-15 01:54:30 --> Output Class Initialized
INFO - 2018-04-15 01:54:30 --> Security Class Initialized
DEBUG - 2018-04-15 01:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 01:54:30 --> Input Class Initialized
INFO - 2018-04-15 01:54:30 --> Language Class Initialized
ERROR - 2018-04-15 01:54:30 --> 404 Page Not Found: /index
INFO - 2018-04-15 01:59:18 --> Config Class Initialized
INFO - 2018-04-15 01:59:18 --> Hooks Class Initialized
DEBUG - 2018-04-15 01:59:18 --> UTF-8 Support Enabled
INFO - 2018-04-15 01:59:18 --> Utf8 Class Initialized
INFO - 2018-04-15 01:59:18 --> URI Class Initialized
DEBUG - 2018-04-15 01:59:18 --> No URI present. Default controller set.
INFO - 2018-04-15 01:59:18 --> Router Class Initialized
INFO - 2018-04-15 01:59:18 --> Output Class Initialized
INFO - 2018-04-15 01:59:18 --> Security Class Initialized
DEBUG - 2018-04-15 01:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 01:59:18 --> Input Class Initialized
INFO - 2018-04-15 01:59:18 --> Language Class Initialized
ERROR - 2018-04-15 01:59:18 --> 404 Page Not Found: Home/index
INFO - 2018-04-15 01:59:21 --> Config Class Initialized
INFO - 2018-04-15 01:59:21 --> Hooks Class Initialized
DEBUG - 2018-04-15 01:59:21 --> UTF-8 Support Enabled
INFO - 2018-04-15 01:59:21 --> Utf8 Class Initialized
INFO - 2018-04-15 01:59:21 --> URI Class Initialized
DEBUG - 2018-04-15 01:59:21 --> No URI present. Default controller set.
INFO - 2018-04-15 01:59:21 --> Router Class Initialized
INFO - 2018-04-15 01:59:22 --> Output Class Initialized
INFO - 2018-04-15 01:59:22 --> Security Class Initialized
DEBUG - 2018-04-15 01:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 01:59:22 --> Input Class Initialized
INFO - 2018-04-15 01:59:22 --> Language Class Initialized
ERROR - 2018-04-15 01:59:22 --> 404 Page Not Found: Home/index
INFO - 2018-04-15 01:59:59 --> Config Class Initialized
INFO - 2018-04-15 01:59:59 --> Hooks Class Initialized
DEBUG - 2018-04-15 01:59:59 --> UTF-8 Support Enabled
INFO - 2018-04-15 01:59:59 --> Utf8 Class Initialized
INFO - 2018-04-15 01:59:59 --> URI Class Initialized
DEBUG - 2018-04-15 01:59:59 --> No URI present. Default controller set.
INFO - 2018-04-15 01:59:59 --> Router Class Initialized
INFO - 2018-04-15 01:59:59 --> Output Class Initialized
INFO - 2018-04-15 01:59:59 --> Security Class Initialized
DEBUG - 2018-04-15 01:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 01:59:59 --> Input Class Initialized
INFO - 2018-04-15 01:59:59 --> Language Class Initialized
INFO - 2018-04-15 01:59:59 --> Loader Class Initialized
INFO - 2018-04-15 01:59:59 --> Helper loaded: url_helper
INFO - 2018-04-15 01:59:59 --> Helper loaded: file_helper
INFO - 2018-04-15 01:59:59 --> Helper loaded: date_helper
INFO - 2018-04-15 01:59:59 --> Database Driver Class Initialized
DEBUG - 2018-04-15 01:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 01:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 01:59:59 --> Controller Class Initialized
ERROR - 2018-04-15 01:59:59 --> Severity: Notice --> Undefined variable: allUser G:\xampp\htdocs\codeigniter\application\controllers\Home.php 14
ERROR - 2018-04-15 01:59:59 --> Severity: error --> Exception: Call to undefined method Home::layout() G:\xampp\htdocs\codeigniter\application\controllers\Home.php 15
INFO - 2018-04-15 02:00:34 --> Config Class Initialized
INFO - 2018-04-15 02:00:34 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:00:34 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:00:34 --> Utf8 Class Initialized
INFO - 2018-04-15 02:00:34 --> URI Class Initialized
DEBUG - 2018-04-15 02:00:34 --> No URI present. Default controller set.
INFO - 2018-04-15 02:00:34 --> Router Class Initialized
INFO - 2018-04-15 02:00:34 --> Output Class Initialized
INFO - 2018-04-15 02:00:34 --> Security Class Initialized
DEBUG - 2018-04-15 02:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:00:34 --> Input Class Initialized
INFO - 2018-04-15 02:00:34 --> Language Class Initialized
INFO - 2018-04-15 02:00:34 --> Loader Class Initialized
INFO - 2018-04-15 02:00:34 --> Helper loaded: url_helper
INFO - 2018-04-15 02:00:34 --> Helper loaded: file_helper
INFO - 2018-04-15 02:00:34 --> Helper loaded: date_helper
INFO - 2018-04-15 02:00:34 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:00:35 --> Controller Class Initialized
ERROR - 2018-04-15 02:00:35 --> Severity: error --> Exception: Call to undefined method Home::layout() G:\xampp\htdocs\codeigniter\application\controllers\Home.php 14
INFO - 2018-04-15 02:01:23 --> Config Class Initialized
INFO - 2018-04-15 02:01:23 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:01:23 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:01:23 --> Utf8 Class Initialized
INFO - 2018-04-15 02:01:23 --> URI Class Initialized
DEBUG - 2018-04-15 02:01:23 --> No URI present. Default controller set.
INFO - 2018-04-15 02:01:23 --> Router Class Initialized
INFO - 2018-04-15 02:01:23 --> Output Class Initialized
INFO - 2018-04-15 02:01:23 --> Security Class Initialized
DEBUG - 2018-04-15 02:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:01:23 --> Input Class Initialized
INFO - 2018-04-15 02:01:23 --> Language Class Initialized
INFO - 2018-04-15 02:01:23 --> Loader Class Initialized
INFO - 2018-04-15 02:01:23 --> Helper loaded: url_helper
INFO - 2018-04-15 02:01:23 --> Helper loaded: file_helper
INFO - 2018-04-15 02:01:23 --> Helper loaded: date_helper
INFO - 2018-04-15 02:01:23 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:01:23 --> Controller Class Initialized
INFO - 2018-04-15 02:01:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:01:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:01:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:01:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:01:23 --> Final output sent to browser
DEBUG - 2018-04-15 02:01:23 --> Total execution time: 0.2924
INFO - 2018-04-15 02:01:23 --> Config Class Initialized
INFO - 2018-04-15 02:01:23 --> Config Class Initialized
INFO - 2018-04-15 02:01:23 --> Hooks Class Initialized
INFO - 2018-04-15 02:01:23 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:01:23 --> UTF-8 Support Enabled
DEBUG - 2018-04-15 02:01:23 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:01:23 --> Utf8 Class Initialized
INFO - 2018-04-15 02:01:23 --> Utf8 Class Initialized
INFO - 2018-04-15 02:01:23 --> URI Class Initialized
INFO - 2018-04-15 02:01:23 --> URI Class Initialized
INFO - 2018-04-15 02:01:23 --> Router Class Initialized
INFO - 2018-04-15 02:01:23 --> Router Class Initialized
INFO - 2018-04-15 02:01:23 --> Output Class Initialized
INFO - 2018-04-15 02:01:23 --> Output Class Initialized
INFO - 2018-04-15 02:01:23 --> Security Class Initialized
INFO - 2018-04-15 02:01:23 --> Security Class Initialized
DEBUG - 2018-04-15 02:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-15 02:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:01:23 --> Input Class Initialized
INFO - 2018-04-15 02:01:23 --> Input Class Initialized
INFO - 2018-04-15 02:01:23 --> Language Class Initialized
INFO - 2018-04-15 02:01:23 --> Language Class Initialized
ERROR - 2018-04-15 02:01:23 --> 404 Page Not Found: Stylecss/index
ERROR - 2018-04-15 02:01:23 --> 404 Page Not Found: Imagesjpg/index
INFO - 2018-04-15 02:01:28 --> Config Class Initialized
INFO - 2018-04-15 02:01:28 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:01:28 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:01:28 --> Utf8 Class Initialized
INFO - 2018-04-15 02:01:28 --> URI Class Initialized
DEBUG - 2018-04-15 02:01:28 --> No URI present. Default controller set.
INFO - 2018-04-15 02:01:28 --> Router Class Initialized
INFO - 2018-04-15 02:01:28 --> Output Class Initialized
INFO - 2018-04-15 02:01:28 --> Security Class Initialized
DEBUG - 2018-04-15 02:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:01:28 --> Input Class Initialized
INFO - 2018-04-15 02:01:28 --> Language Class Initialized
INFO - 2018-04-15 02:01:28 --> Loader Class Initialized
INFO - 2018-04-15 02:01:28 --> Helper loaded: url_helper
INFO - 2018-04-15 02:01:28 --> Helper loaded: file_helper
INFO - 2018-04-15 02:01:28 --> Helper loaded: date_helper
INFO - 2018-04-15 02:01:28 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:01:28 --> Controller Class Initialized
INFO - 2018-04-15 02:01:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:01:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:01:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:01:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:01:28 --> Final output sent to browser
DEBUG - 2018-04-15 02:01:28 --> Total execution time: 0.3641
INFO - 2018-04-15 02:01:33 --> Config Class Initialized
INFO - 2018-04-15 02:01:33 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:01:33 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:01:33 --> Utf8 Class Initialized
INFO - 2018-04-15 02:01:33 --> URI Class Initialized
INFO - 2018-04-15 02:01:33 --> Router Class Initialized
INFO - 2018-04-15 02:01:33 --> Output Class Initialized
INFO - 2018-04-15 02:01:33 --> Security Class Initialized
DEBUG - 2018-04-15 02:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:01:33 --> Input Class Initialized
INFO - 2018-04-15 02:01:33 --> Language Class Initialized
ERROR - 2018-04-15 02:01:33 --> 404 Page Not Found: Stylecss/index
INFO - 2018-04-15 02:01:50 --> Config Class Initialized
INFO - 2018-04-15 02:01:50 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:01:50 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:01:50 --> Utf8 Class Initialized
INFO - 2018-04-15 02:01:50 --> URI Class Initialized
INFO - 2018-04-15 02:01:50 --> Router Class Initialized
INFO - 2018-04-15 02:01:50 --> Output Class Initialized
INFO - 2018-04-15 02:01:50 --> Security Class Initialized
DEBUG - 2018-04-15 02:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:01:50 --> Input Class Initialized
INFO - 2018-04-15 02:01:50 --> Language Class Initialized
ERROR - 2018-04-15 02:01:50 --> 404 Page Not Found: Stylecss/index
INFO - 2018-04-15 02:02:30 --> Config Class Initialized
INFO - 2018-04-15 02:02:30 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:02:30 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:02:30 --> Utf8 Class Initialized
INFO - 2018-04-15 02:02:30 --> URI Class Initialized
INFO - 2018-04-15 02:02:30 --> Router Class Initialized
INFO - 2018-04-15 02:02:30 --> Output Class Initialized
INFO - 2018-04-15 02:02:30 --> Security Class Initialized
DEBUG - 2018-04-15 02:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:02:30 --> Input Class Initialized
INFO - 2018-04-15 02:02:30 --> Language Class Initialized
ERROR - 2018-04-15 02:02:30 --> 404 Page Not Found: Stylecss/index
INFO - 2018-04-15 02:02:35 --> Config Class Initialized
INFO - 2018-04-15 02:02:35 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:02:35 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:02:35 --> Utf8 Class Initialized
INFO - 2018-04-15 02:02:35 --> URI Class Initialized
DEBUG - 2018-04-15 02:02:35 --> No URI present. Default controller set.
INFO - 2018-04-15 02:02:35 --> Router Class Initialized
INFO - 2018-04-15 02:02:35 --> Output Class Initialized
INFO - 2018-04-15 02:02:35 --> Security Class Initialized
DEBUG - 2018-04-15 02:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:02:35 --> Input Class Initialized
INFO - 2018-04-15 02:02:35 --> Language Class Initialized
INFO - 2018-04-15 02:02:35 --> Loader Class Initialized
INFO - 2018-04-15 02:02:35 --> Helper loaded: url_helper
INFO - 2018-04-15 02:02:35 --> Helper loaded: file_helper
INFO - 2018-04-15 02:02:35 --> Helper loaded: date_helper
INFO - 2018-04-15 02:02:35 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:02:35 --> Controller Class Initialized
INFO - 2018-04-15 02:02:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:02:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:02:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:02:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:02:35 --> Final output sent to browser
DEBUG - 2018-04-15 02:02:35 --> Total execution time: 0.2893
INFO - 2018-04-15 02:02:41 --> Config Class Initialized
INFO - 2018-04-15 02:02:41 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:02:41 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:02:41 --> Utf8 Class Initialized
INFO - 2018-04-15 02:02:41 --> URI Class Initialized
DEBUG - 2018-04-15 02:02:41 --> No URI present. Default controller set.
INFO - 2018-04-15 02:02:41 --> Router Class Initialized
INFO - 2018-04-15 02:02:41 --> Output Class Initialized
INFO - 2018-04-15 02:02:41 --> Security Class Initialized
DEBUG - 2018-04-15 02:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:02:41 --> Input Class Initialized
INFO - 2018-04-15 02:02:41 --> Language Class Initialized
INFO - 2018-04-15 02:02:41 --> Loader Class Initialized
INFO - 2018-04-15 02:02:41 --> Helper loaded: url_helper
INFO - 2018-04-15 02:02:41 --> Helper loaded: file_helper
INFO - 2018-04-15 02:02:41 --> Helper loaded: date_helper
INFO - 2018-04-15 02:02:41 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:02:41 --> Controller Class Initialized
INFO - 2018-04-15 02:02:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:02:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:02:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:02:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:02:41 --> Final output sent to browser
DEBUG - 2018-04-15 02:02:41 --> Total execution time: 0.2953
INFO - 2018-04-15 02:02:41 --> Config Class Initialized
INFO - 2018-04-15 02:02:41 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:02:41 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:02:41 --> Utf8 Class Initialized
INFO - 2018-04-15 02:02:41 --> URI Class Initialized
INFO - 2018-04-15 02:02:41 --> Router Class Initialized
INFO - 2018-04-15 02:02:42 --> Output Class Initialized
INFO - 2018-04-15 02:02:42 --> Security Class Initialized
DEBUG - 2018-04-15 02:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:02:42 --> Input Class Initialized
INFO - 2018-04-15 02:02:42 --> Language Class Initialized
ERROR - 2018-04-15 02:02:42 --> 404 Page Not Found: Imagesjpg/index
INFO - 2018-04-15 02:02:48 --> Config Class Initialized
INFO - 2018-04-15 02:02:48 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:02:48 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:02:48 --> Utf8 Class Initialized
INFO - 2018-04-15 02:02:48 --> URI Class Initialized
INFO - 2018-04-15 02:02:48 --> Router Class Initialized
INFO - 2018-04-15 02:02:48 --> Output Class Initialized
INFO - 2018-04-15 02:02:48 --> Security Class Initialized
DEBUG - 2018-04-15 02:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:02:48 --> Input Class Initialized
INFO - 2018-04-15 02:02:48 --> Language Class Initialized
ERROR - 2018-04-15 02:02:48 --> 404 Page Not Found: Assets/css
INFO - 2018-04-15 02:04:14 --> Config Class Initialized
INFO - 2018-04-15 02:04:14 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:04:14 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:04:14 --> Utf8 Class Initialized
INFO - 2018-04-15 02:04:14 --> URI Class Initialized
DEBUG - 2018-04-15 02:04:14 --> No URI present. Default controller set.
INFO - 2018-04-15 02:04:14 --> Router Class Initialized
INFO - 2018-04-15 02:04:14 --> Output Class Initialized
INFO - 2018-04-15 02:04:14 --> Security Class Initialized
DEBUG - 2018-04-15 02:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:04:14 --> Input Class Initialized
INFO - 2018-04-15 02:04:14 --> Language Class Initialized
INFO - 2018-04-15 02:04:14 --> Loader Class Initialized
INFO - 2018-04-15 02:04:14 --> Helper loaded: url_helper
INFO - 2018-04-15 02:04:14 --> Helper loaded: file_helper
INFO - 2018-04-15 02:04:14 --> Helper loaded: date_helper
INFO - 2018-04-15 02:04:14 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:04:14 --> Controller Class Initialized
INFO - 2018-04-15 02:04:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:04:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:04:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:04:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:04:14 --> Final output sent to browser
DEBUG - 2018-04-15 02:04:14 --> Total execution time: 0.2981
INFO - 2018-04-15 02:04:15 --> Config Class Initialized
INFO - 2018-04-15 02:04:15 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:04:15 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:04:15 --> Utf8 Class Initialized
INFO - 2018-04-15 02:04:15 --> URI Class Initialized
INFO - 2018-04-15 02:04:15 --> Router Class Initialized
INFO - 2018-04-15 02:04:15 --> Output Class Initialized
INFO - 2018-04-15 02:04:15 --> Security Class Initialized
DEBUG - 2018-04-15 02:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:04:15 --> Input Class Initialized
INFO - 2018-04-15 02:04:15 --> Language Class Initialized
ERROR - 2018-04-15 02:04:15 --> 404 Page Not Found: Assets/css
INFO - 2018-04-15 02:04:30 --> Config Class Initialized
INFO - 2018-04-15 02:04:30 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:04:30 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:04:30 --> Utf8 Class Initialized
INFO - 2018-04-15 02:04:30 --> URI Class Initialized
INFO - 2018-04-15 02:04:30 --> Router Class Initialized
INFO - 2018-04-15 02:04:30 --> Output Class Initialized
INFO - 2018-04-15 02:04:30 --> Security Class Initialized
DEBUG - 2018-04-15 02:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:04:30 --> Input Class Initialized
INFO - 2018-04-15 02:04:30 --> Language Class Initialized
INFO - 2018-04-15 02:04:30 --> Loader Class Initialized
INFO - 2018-04-15 02:04:30 --> Helper loaded: url_helper
INFO - 2018-04-15 02:04:30 --> Helper loaded: file_helper
INFO - 2018-04-15 02:04:30 --> Helper loaded: date_helper
INFO - 2018-04-15 02:04:30 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:04:30 --> Controller Class Initialized
INFO - 2018-04-15 02:04:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 02:04:31 --> Final output sent to browser
DEBUG - 2018-04-15 02:04:31 --> Total execution time: 0.3455
INFO - 2018-04-15 02:04:38 --> Config Class Initialized
INFO - 2018-04-15 02:04:38 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:04:38 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:04:38 --> Utf8 Class Initialized
INFO - 2018-04-15 02:04:38 --> URI Class Initialized
DEBUG - 2018-04-15 02:04:38 --> No URI present. Default controller set.
INFO - 2018-04-15 02:04:38 --> Router Class Initialized
INFO - 2018-04-15 02:04:38 --> Output Class Initialized
INFO - 2018-04-15 02:04:38 --> Security Class Initialized
DEBUG - 2018-04-15 02:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:04:38 --> Input Class Initialized
INFO - 2018-04-15 02:04:39 --> Language Class Initialized
INFO - 2018-04-15 02:04:39 --> Loader Class Initialized
INFO - 2018-04-15 02:04:39 --> Helper loaded: url_helper
INFO - 2018-04-15 02:04:39 --> Helper loaded: file_helper
INFO - 2018-04-15 02:04:39 --> Helper loaded: date_helper
INFO - 2018-04-15 02:04:39 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:04:39 --> Controller Class Initialized
INFO - 2018-04-15 02:04:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:04:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:04:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:04:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:04:39 --> Final output sent to browser
DEBUG - 2018-04-15 02:04:39 --> Total execution time: 0.2977
INFO - 2018-04-15 02:04:41 --> Config Class Initialized
INFO - 2018-04-15 02:04:41 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:04:41 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:04:41 --> Utf8 Class Initialized
INFO - 2018-04-15 02:04:41 --> URI Class Initialized
INFO - 2018-04-15 02:04:41 --> Router Class Initialized
INFO - 2018-04-15 02:04:41 --> Output Class Initialized
INFO - 2018-04-15 02:04:41 --> Security Class Initialized
DEBUG - 2018-04-15 02:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:04:41 --> Input Class Initialized
INFO - 2018-04-15 02:04:41 --> Language Class Initialized
INFO - 2018-04-15 02:04:41 --> Loader Class Initialized
INFO - 2018-04-15 02:04:41 --> Helper loaded: url_helper
INFO - 2018-04-15 02:04:41 --> Helper loaded: file_helper
INFO - 2018-04-15 02:04:41 --> Helper loaded: date_helper
INFO - 2018-04-15 02:04:41 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:04:41 --> Controller Class Initialized
INFO - 2018-04-15 02:04:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 02:04:41 --> Final output sent to browser
DEBUG - 2018-04-15 02:04:41 --> Total execution time: 0.2461
INFO - 2018-04-15 02:05:27 --> Config Class Initialized
INFO - 2018-04-15 02:05:27 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:05:27 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:05:27 --> Utf8 Class Initialized
INFO - 2018-04-15 02:05:27 --> URI Class Initialized
INFO - 2018-04-15 02:05:27 --> Router Class Initialized
INFO - 2018-04-15 02:05:27 --> Output Class Initialized
INFO - 2018-04-15 02:05:27 --> Security Class Initialized
DEBUG - 2018-04-15 02:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:05:27 --> Input Class Initialized
INFO - 2018-04-15 02:05:27 --> Language Class Initialized
INFO - 2018-04-15 02:05:27 --> Loader Class Initialized
INFO - 2018-04-15 02:05:27 --> Helper loaded: url_helper
INFO - 2018-04-15 02:05:27 --> Helper loaded: file_helper
INFO - 2018-04-15 02:05:27 --> Helper loaded: date_helper
INFO - 2018-04-15 02:05:27 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:05:27 --> Controller Class Initialized
INFO - 2018-04-15 02:05:27 --> Model Class Initialized
INFO - 2018-04-15 02:05:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 02:05:27 --> Final output sent to browser
DEBUG - 2018-04-15 02:05:27 --> Total execution time: 0.4216
INFO - 2018-04-15 02:05:52 --> Config Class Initialized
INFO - 2018-04-15 02:05:52 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:05:52 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:05:52 --> Utf8 Class Initialized
INFO - 2018-04-15 02:05:52 --> URI Class Initialized
INFO - 2018-04-15 02:05:52 --> Router Class Initialized
INFO - 2018-04-15 02:05:52 --> Output Class Initialized
INFO - 2018-04-15 02:05:52 --> Security Class Initialized
DEBUG - 2018-04-15 02:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:05:52 --> Input Class Initialized
INFO - 2018-04-15 02:05:52 --> Language Class Initialized
INFO - 2018-04-15 02:05:52 --> Loader Class Initialized
INFO - 2018-04-15 02:05:52 --> Helper loaded: url_helper
INFO - 2018-04-15 02:05:52 --> Helper loaded: file_helper
INFO - 2018-04-15 02:05:52 --> Helper loaded: date_helper
INFO - 2018-04-15 02:05:52 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:05:52 --> Controller Class Initialized
INFO - 2018-04-15 02:05:52 --> Model Class Initialized
INFO - 2018-04-15 02:05:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 02:05:52 --> Final output sent to browser
DEBUG - 2018-04-15 02:05:52 --> Total execution time: 0.2983
INFO - 2018-04-15 02:07:23 --> Config Class Initialized
INFO - 2018-04-15 02:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:07:23 --> Utf8 Class Initialized
INFO - 2018-04-15 02:07:23 --> URI Class Initialized
INFO - 2018-04-15 02:07:23 --> Router Class Initialized
INFO - 2018-04-15 02:07:23 --> Output Class Initialized
INFO - 2018-04-15 02:07:23 --> Security Class Initialized
DEBUG - 2018-04-15 02:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:07:23 --> Input Class Initialized
INFO - 2018-04-15 02:07:23 --> Language Class Initialized
INFO - 2018-04-15 02:07:23 --> Loader Class Initialized
INFO - 2018-04-15 02:07:23 --> Helper loaded: url_helper
INFO - 2018-04-15 02:07:23 --> Helper loaded: file_helper
INFO - 2018-04-15 02:07:23 --> Helper loaded: date_helper
INFO - 2018-04-15 02:07:23 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:07:23 --> Controller Class Initialized
INFO - 2018-04-15 02:07:23 --> Model Class Initialized
INFO - 2018-04-15 02:07:23 --> Final output sent to browser
DEBUG - 2018-04-15 02:07:23 --> Total execution time: 0.2879
INFO - 2018-04-15 02:07:23 --> Config Class Initialized
INFO - 2018-04-15 02:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:07:23 --> Utf8 Class Initialized
INFO - 2018-04-15 02:07:23 --> URI Class Initialized
INFO - 2018-04-15 02:07:23 --> Router Class Initialized
INFO - 2018-04-15 02:07:23 --> Output Class Initialized
INFO - 2018-04-15 02:07:23 --> Security Class Initialized
DEBUG - 2018-04-15 02:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:07:23 --> Input Class Initialized
INFO - 2018-04-15 02:07:23 --> Language Class Initialized
INFO - 2018-04-15 02:07:23 --> Loader Class Initialized
INFO - 2018-04-15 02:07:23 --> Helper loaded: url_helper
INFO - 2018-04-15 02:07:24 --> Helper loaded: file_helper
INFO - 2018-04-15 02:07:24 --> Helper loaded: date_helper
INFO - 2018-04-15 02:07:24 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:07:24 --> Controller Class Initialized
INFO - 2018-04-15 02:07:24 --> Model Class Initialized
INFO - 2018-04-15 02:07:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:07:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 02:07:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:07:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:07:24 --> Final output sent to browser
DEBUG - 2018-04-15 02:07:24 --> Total execution time: 0.2969
INFO - 2018-04-15 02:08:39 --> Config Class Initialized
INFO - 2018-04-15 02:08:39 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:08:39 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:08:39 --> Utf8 Class Initialized
INFO - 2018-04-15 02:08:39 --> URI Class Initialized
INFO - 2018-04-15 02:08:39 --> Router Class Initialized
INFO - 2018-04-15 02:08:39 --> Output Class Initialized
INFO - 2018-04-15 02:08:39 --> Security Class Initialized
DEBUG - 2018-04-15 02:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:08:39 --> Input Class Initialized
INFO - 2018-04-15 02:08:39 --> Language Class Initialized
INFO - 2018-04-15 02:08:39 --> Loader Class Initialized
INFO - 2018-04-15 02:08:39 --> Helper loaded: url_helper
INFO - 2018-04-15 02:08:39 --> Helper loaded: file_helper
INFO - 2018-04-15 02:08:39 --> Helper loaded: date_helper
INFO - 2018-04-15 02:08:39 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:08:39 --> Controller Class Initialized
INFO - 2018-04-15 02:08:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 02:08:39 --> Final output sent to browser
DEBUG - 2018-04-15 02:08:39 --> Total execution time: 0.2484
INFO - 2018-04-15 02:08:41 --> Config Class Initialized
INFO - 2018-04-15 02:08:41 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:08:41 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:08:41 --> Utf8 Class Initialized
INFO - 2018-04-15 02:08:41 --> URI Class Initialized
INFO - 2018-04-15 02:08:41 --> Router Class Initialized
INFO - 2018-04-15 02:08:41 --> Output Class Initialized
INFO - 2018-04-15 02:08:41 --> Security Class Initialized
DEBUG - 2018-04-15 02:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:08:41 --> Input Class Initialized
INFO - 2018-04-15 02:08:42 --> Language Class Initialized
INFO - 2018-04-15 02:08:42 --> Loader Class Initialized
INFO - 2018-04-15 02:08:42 --> Helper loaded: url_helper
INFO - 2018-04-15 02:08:42 --> Helper loaded: file_helper
INFO - 2018-04-15 02:08:42 --> Helper loaded: date_helper
INFO - 2018-04-15 02:08:42 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:08:42 --> Controller Class Initialized
INFO - 2018-04-15 02:08:42 --> Model Class Initialized
INFO - 2018-04-15 02:08:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:08:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 02:08:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:08:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:08:42 --> Final output sent to browser
DEBUG - 2018-04-15 02:08:42 --> Total execution time: 0.3395
INFO - 2018-04-15 02:13:41 --> Config Class Initialized
INFO - 2018-04-15 02:13:41 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:13:41 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:13:41 --> Utf8 Class Initialized
INFO - 2018-04-15 02:13:41 --> URI Class Initialized
INFO - 2018-04-15 02:13:41 --> Router Class Initialized
INFO - 2018-04-15 02:13:41 --> Output Class Initialized
INFO - 2018-04-15 02:13:41 --> Security Class Initialized
DEBUG - 2018-04-15 02:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:13:41 --> Input Class Initialized
INFO - 2018-04-15 02:13:41 --> Language Class Initialized
INFO - 2018-04-15 02:13:41 --> Loader Class Initialized
INFO - 2018-04-15 02:13:41 --> Helper loaded: url_helper
INFO - 2018-04-15 02:13:41 --> Helper loaded: file_helper
INFO - 2018-04-15 02:13:41 --> Helper loaded: date_helper
INFO - 2018-04-15 02:13:41 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:13:41 --> Controller Class Initialized
INFO - 2018-04-15 02:13:41 --> Model Class Initialized
ERROR - 2018-04-15 02:13:41 --> Severity: error --> Exception: syntax error, unexpected ')' G:\xampp\htdocs\codeigniter\application\views\layout_student\header.php 14
INFO - 2018-04-15 02:13:58 --> Config Class Initialized
INFO - 2018-04-15 02:13:58 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:13:58 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:13:58 --> Utf8 Class Initialized
INFO - 2018-04-15 02:13:58 --> URI Class Initialized
INFO - 2018-04-15 02:13:58 --> Router Class Initialized
INFO - 2018-04-15 02:13:58 --> Output Class Initialized
INFO - 2018-04-15 02:13:58 --> Security Class Initialized
DEBUG - 2018-04-15 02:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:13:58 --> Input Class Initialized
INFO - 2018-04-15 02:13:58 --> Language Class Initialized
INFO - 2018-04-15 02:13:58 --> Loader Class Initialized
INFO - 2018-04-15 02:13:58 --> Helper loaded: url_helper
INFO - 2018-04-15 02:13:58 --> Helper loaded: file_helper
INFO - 2018-04-15 02:13:58 --> Helper loaded: date_helper
INFO - 2018-04-15 02:13:58 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:13:58 --> Controller Class Initialized
INFO - 2018-04-15 02:13:58 --> Model Class Initialized
ERROR - 2018-04-15 02:13:58 --> Severity: error --> Exception: syntax error, unexpected ')' G:\xampp\htdocs\codeigniter\application\views\layout_student\header.php 14
INFO - 2018-04-15 02:14:01 --> Config Class Initialized
INFO - 2018-04-15 02:14:01 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:14:01 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:14:01 --> Utf8 Class Initialized
INFO - 2018-04-15 02:14:01 --> URI Class Initialized
INFO - 2018-04-15 02:14:01 --> Router Class Initialized
INFO - 2018-04-15 02:14:01 --> Output Class Initialized
INFO - 2018-04-15 02:14:01 --> Security Class Initialized
DEBUG - 2018-04-15 02:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:14:01 --> Input Class Initialized
INFO - 2018-04-15 02:14:01 --> Language Class Initialized
INFO - 2018-04-15 02:14:01 --> Loader Class Initialized
INFO - 2018-04-15 02:14:01 --> Helper loaded: url_helper
INFO - 2018-04-15 02:14:01 --> Helper loaded: file_helper
INFO - 2018-04-15 02:14:01 --> Helper loaded: date_helper
INFO - 2018-04-15 02:14:01 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:14:01 --> Controller Class Initialized
INFO - 2018-04-15 02:14:01 --> Model Class Initialized
ERROR - 2018-04-15 02:14:01 --> Severity: error --> Exception: syntax error, unexpected ')' G:\xampp\htdocs\codeigniter\application\views\layout_student\header.php 14
INFO - 2018-04-15 02:14:28 --> Config Class Initialized
INFO - 2018-04-15 02:14:29 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:14:29 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:14:29 --> Utf8 Class Initialized
INFO - 2018-04-15 02:14:29 --> URI Class Initialized
INFO - 2018-04-15 02:14:29 --> Router Class Initialized
INFO - 2018-04-15 02:14:29 --> Output Class Initialized
INFO - 2018-04-15 02:14:29 --> Security Class Initialized
DEBUG - 2018-04-15 02:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:14:29 --> Input Class Initialized
INFO - 2018-04-15 02:14:29 --> Language Class Initialized
INFO - 2018-04-15 02:14:29 --> Loader Class Initialized
INFO - 2018-04-15 02:14:29 --> Helper loaded: url_helper
INFO - 2018-04-15 02:14:29 --> Helper loaded: file_helper
INFO - 2018-04-15 02:14:29 --> Helper loaded: date_helper
INFO - 2018-04-15 02:14:29 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:14:29 --> Controller Class Initialized
INFO - 2018-04-15 02:14:29 --> Model Class Initialized
ERROR - 2018-04-15 02:14:29 --> Severity: error --> Exception: syntax error, unexpected ')' G:\xampp\htdocs\codeigniter\application\views\layout_student\header.php 14
INFO - 2018-04-15 02:14:31 --> Config Class Initialized
INFO - 2018-04-15 02:14:31 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:14:31 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:14:31 --> Utf8 Class Initialized
INFO - 2018-04-15 02:14:31 --> URI Class Initialized
INFO - 2018-04-15 02:14:31 --> Router Class Initialized
INFO - 2018-04-15 02:14:31 --> Output Class Initialized
INFO - 2018-04-15 02:14:31 --> Security Class Initialized
DEBUG - 2018-04-15 02:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:14:31 --> Input Class Initialized
INFO - 2018-04-15 02:14:31 --> Language Class Initialized
INFO - 2018-04-15 02:14:31 --> Loader Class Initialized
INFO - 2018-04-15 02:14:31 --> Helper loaded: url_helper
INFO - 2018-04-15 02:14:31 --> Helper loaded: file_helper
INFO - 2018-04-15 02:14:31 --> Helper loaded: date_helper
INFO - 2018-04-15 02:14:31 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:14:31 --> Controller Class Initialized
INFO - 2018-04-15 02:14:31 --> Model Class Initialized
ERROR - 2018-04-15 02:14:31 --> Severity: error --> Exception: syntax error, unexpected ')' G:\xampp\htdocs\codeigniter\application\views\layout_student\header.php 14
INFO - 2018-04-15 02:15:00 --> Config Class Initialized
INFO - 2018-04-15 02:15:00 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:15:00 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:15:00 --> Utf8 Class Initialized
INFO - 2018-04-15 02:15:00 --> URI Class Initialized
INFO - 2018-04-15 02:15:00 --> Router Class Initialized
INFO - 2018-04-15 02:15:00 --> Output Class Initialized
INFO - 2018-04-15 02:15:00 --> Security Class Initialized
DEBUG - 2018-04-15 02:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:15:00 --> Input Class Initialized
INFO - 2018-04-15 02:15:00 --> Language Class Initialized
INFO - 2018-04-15 02:15:00 --> Loader Class Initialized
INFO - 2018-04-15 02:15:00 --> Helper loaded: url_helper
INFO - 2018-04-15 02:15:00 --> Helper loaded: file_helper
INFO - 2018-04-15 02:15:00 --> Helper loaded: date_helper
INFO - 2018-04-15 02:15:00 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:15:00 --> Controller Class Initialized
INFO - 2018-04-15 02:15:00 --> Model Class Initialized
ERROR - 2018-04-15 02:15:00 --> Severity: error --> Exception: syntax error, unexpected ')' G:\xampp\htdocs\codeigniter\application\views\layout_student\header.php 14
INFO - 2018-04-15 02:15:15 --> Config Class Initialized
INFO - 2018-04-15 02:15:15 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:15:15 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:15:15 --> Utf8 Class Initialized
INFO - 2018-04-15 02:15:15 --> URI Class Initialized
INFO - 2018-04-15 02:15:15 --> Router Class Initialized
INFO - 2018-04-15 02:15:15 --> Output Class Initialized
INFO - 2018-04-15 02:15:15 --> Security Class Initialized
DEBUG - 2018-04-15 02:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:15:15 --> Input Class Initialized
INFO - 2018-04-15 02:15:15 --> Language Class Initialized
INFO - 2018-04-15 02:15:15 --> Loader Class Initialized
INFO - 2018-04-15 02:15:15 --> Helper loaded: url_helper
INFO - 2018-04-15 02:15:15 --> Helper loaded: file_helper
INFO - 2018-04-15 02:15:16 --> Helper loaded: date_helper
INFO - 2018-04-15 02:15:16 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:15:16 --> Controller Class Initialized
INFO - 2018-04-15 02:15:16 --> Model Class Initialized
ERROR - 2018-04-15 02:15:16 --> Severity: error --> Exception: Call to undefined function userdata() G:\xampp\htdocs\codeigniter\application\views\layout_student\header.php 24
INFO - 2018-04-15 02:15:29 --> Config Class Initialized
INFO - 2018-04-15 02:15:29 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:15:29 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:15:29 --> Utf8 Class Initialized
INFO - 2018-04-15 02:15:29 --> URI Class Initialized
INFO - 2018-04-15 02:15:29 --> Router Class Initialized
INFO - 2018-04-15 02:15:29 --> Output Class Initialized
INFO - 2018-04-15 02:15:29 --> Security Class Initialized
DEBUG - 2018-04-15 02:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:15:29 --> Input Class Initialized
INFO - 2018-04-15 02:15:29 --> Language Class Initialized
INFO - 2018-04-15 02:15:29 --> Loader Class Initialized
INFO - 2018-04-15 02:15:29 --> Helper loaded: url_helper
INFO - 2018-04-15 02:15:29 --> Helper loaded: file_helper
INFO - 2018-04-15 02:15:29 --> Helper loaded: date_helper
INFO - 2018-04-15 02:15:29 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:15:30 --> Controller Class Initialized
INFO - 2018-04-15 02:15:30 --> Model Class Initialized
ERROR - 2018-04-15 02:15:30 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting ',' or ')' G:\xampp\htdocs\codeigniter\application\views\layout_student\header.php 24
INFO - 2018-04-15 02:20:01 --> Config Class Initialized
INFO - 2018-04-15 02:20:01 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:20:01 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:20:01 --> Utf8 Class Initialized
INFO - 2018-04-15 02:20:01 --> URI Class Initialized
INFO - 2018-04-15 02:20:01 --> Router Class Initialized
INFO - 2018-04-15 02:20:01 --> Output Class Initialized
INFO - 2018-04-15 02:20:01 --> Security Class Initialized
DEBUG - 2018-04-15 02:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:20:01 --> Input Class Initialized
INFO - 2018-04-15 02:20:01 --> Language Class Initialized
INFO - 2018-04-15 02:20:01 --> Loader Class Initialized
INFO - 2018-04-15 02:20:01 --> Helper loaded: url_helper
INFO - 2018-04-15 02:20:01 --> Helper loaded: file_helper
INFO - 2018-04-15 02:20:01 --> Helper loaded: date_helper
INFO - 2018-04-15 02:20:01 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:20:01 --> Controller Class Initialized
INFO - 2018-04-15 02:20:01 --> Model Class Initialized
INFO - 2018-04-15 02:20:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:20:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 02:20:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:20:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:20:01 --> Final output sent to browser
DEBUG - 2018-04-15 02:20:01 --> Total execution time: 0.3164
INFO - 2018-04-15 02:21:26 --> Config Class Initialized
INFO - 2018-04-15 02:21:26 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:21:26 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:21:26 --> Utf8 Class Initialized
INFO - 2018-04-15 02:21:26 --> URI Class Initialized
INFO - 2018-04-15 02:21:26 --> Router Class Initialized
INFO - 2018-04-15 02:21:26 --> Output Class Initialized
INFO - 2018-04-15 02:21:26 --> Security Class Initialized
DEBUG - 2018-04-15 02:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:21:26 --> Input Class Initialized
INFO - 2018-04-15 02:21:26 --> Language Class Initialized
INFO - 2018-04-15 02:21:26 --> Loader Class Initialized
INFO - 2018-04-15 02:21:26 --> Helper loaded: url_helper
INFO - 2018-04-15 02:21:26 --> Helper loaded: file_helper
INFO - 2018-04-15 02:21:26 --> Helper loaded: date_helper
INFO - 2018-04-15 02:21:26 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:21:26 --> Controller Class Initialized
INFO - 2018-04-15 02:21:26 --> Model Class Initialized
INFO - 2018-04-15 02:21:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:21:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 02:21:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:21:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:21:26 --> Final output sent to browser
DEBUG - 2018-04-15 02:21:26 --> Total execution time: 0.3082
INFO - 2018-04-15 02:21:40 --> Config Class Initialized
INFO - 2018-04-15 02:21:40 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:21:40 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:21:41 --> Utf8 Class Initialized
INFO - 2018-04-15 02:21:41 --> URI Class Initialized
INFO - 2018-04-15 02:21:41 --> Router Class Initialized
INFO - 2018-04-15 02:21:41 --> Output Class Initialized
INFO - 2018-04-15 02:21:41 --> Security Class Initialized
DEBUG - 2018-04-15 02:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:21:41 --> Input Class Initialized
INFO - 2018-04-15 02:21:41 --> Language Class Initialized
ERROR - 2018-04-15 02:21:41 --> 404 Page Not Found: Logout/index
INFO - 2018-04-15 02:22:25 --> Config Class Initialized
INFO - 2018-04-15 02:22:25 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:22:25 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:22:25 --> Utf8 Class Initialized
INFO - 2018-04-15 02:22:25 --> URI Class Initialized
INFO - 2018-04-15 02:22:25 --> Router Class Initialized
INFO - 2018-04-15 02:22:25 --> Output Class Initialized
INFO - 2018-04-15 02:22:25 --> Security Class Initialized
DEBUG - 2018-04-15 02:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:22:25 --> Input Class Initialized
INFO - 2018-04-15 02:22:25 --> Language Class Initialized
INFO - 2018-04-15 02:22:25 --> Loader Class Initialized
INFO - 2018-04-15 02:22:25 --> Helper loaded: url_helper
INFO - 2018-04-15 02:22:25 --> Helper loaded: file_helper
INFO - 2018-04-15 02:22:25 --> Helper loaded: date_helper
INFO - 2018-04-15 02:22:25 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:22:25 --> Controller Class Initialized
INFO - 2018-04-15 02:22:25 --> Model Class Initialized
INFO - 2018-04-15 02:22:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:22:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 02:22:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:22:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:22:25 --> Final output sent to browser
DEBUG - 2018-04-15 02:22:25 --> Total execution time: 0.3294
INFO - 2018-04-15 02:22:28 --> Config Class Initialized
INFO - 2018-04-15 02:22:28 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:22:28 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:22:28 --> Utf8 Class Initialized
INFO - 2018-04-15 02:22:28 --> URI Class Initialized
INFO - 2018-04-15 02:22:28 --> Router Class Initialized
INFO - 2018-04-15 02:22:28 --> Output Class Initialized
INFO - 2018-04-15 02:22:28 --> Security Class Initialized
DEBUG - 2018-04-15 02:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:22:28 --> Input Class Initialized
INFO - 2018-04-15 02:22:28 --> Language Class Initialized
ERROR - 2018-04-15 02:22:28 --> 404 Page Not Found: Welcome/logout
INFO - 2018-04-15 02:23:00 --> Config Class Initialized
INFO - 2018-04-15 02:23:00 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:23:00 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:23:00 --> Utf8 Class Initialized
INFO - 2018-04-15 02:23:00 --> URI Class Initialized
INFO - 2018-04-15 02:23:00 --> Router Class Initialized
INFO - 2018-04-15 02:23:00 --> Output Class Initialized
INFO - 2018-04-15 02:23:00 --> Security Class Initialized
DEBUG - 2018-04-15 02:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:23:00 --> Input Class Initialized
INFO - 2018-04-15 02:23:00 --> Language Class Initialized
INFO - 2018-04-15 02:23:00 --> Loader Class Initialized
INFO - 2018-04-15 02:23:00 --> Helper loaded: url_helper
INFO - 2018-04-15 02:23:00 --> Helper loaded: file_helper
INFO - 2018-04-15 02:23:00 --> Helper loaded: date_helper
INFO - 2018-04-15 02:23:00 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:23:00 --> Controller Class Initialized
INFO - 2018-04-15 02:23:00 --> Model Class Initialized
INFO - 2018-04-15 02:23:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:23:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 02:23:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:23:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:23:01 --> Final output sent to browser
DEBUG - 2018-04-15 02:23:01 --> Total execution time: 0.3217
INFO - 2018-04-15 02:23:02 --> Config Class Initialized
INFO - 2018-04-15 02:23:02 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:23:02 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:23:02 --> Utf8 Class Initialized
INFO - 2018-04-15 02:23:02 --> URI Class Initialized
INFO - 2018-04-15 02:23:03 --> Router Class Initialized
INFO - 2018-04-15 02:23:03 --> Output Class Initialized
INFO - 2018-04-15 02:23:03 --> Security Class Initialized
DEBUG - 2018-04-15 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:23:03 --> Input Class Initialized
INFO - 2018-04-15 02:23:03 --> Language Class Initialized
INFO - 2018-04-15 02:23:03 --> Loader Class Initialized
INFO - 2018-04-15 02:23:03 --> Helper loaded: url_helper
INFO - 2018-04-15 02:23:03 --> Helper loaded: file_helper
INFO - 2018-04-15 02:23:03 --> Helper loaded: date_helper
INFO - 2018-04-15 02:23:03 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:23:03 --> Controller Class Initialized
DEBUG - 2018-04-15 02:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-15 02:23:03 --> Config Class Initialized
INFO - 2018-04-15 02:23:03 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:23:03 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:23:03 --> Utf8 Class Initialized
INFO - 2018-04-15 02:23:03 --> URI Class Initialized
INFO - 2018-04-15 02:23:03 --> Router Class Initialized
INFO - 2018-04-15 02:23:03 --> Output Class Initialized
INFO - 2018-04-15 02:23:03 --> Security Class Initialized
DEBUG - 2018-04-15 02:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:23:03 --> Input Class Initialized
INFO - 2018-04-15 02:23:03 --> Language Class Initialized
INFO - 2018-04-15 02:23:03 --> Loader Class Initialized
INFO - 2018-04-15 02:23:03 --> Helper loaded: url_helper
INFO - 2018-04-15 02:23:03 --> Helper loaded: file_helper
INFO - 2018-04-15 02:23:03 --> Helper loaded: date_helper
INFO - 2018-04-15 02:23:03 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:23:03 --> Controller Class Initialized
INFO - 2018-04-15 02:23:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 02:23:03 --> Final output sent to browser
DEBUG - 2018-04-15 02:23:03 --> Total execution time: 0.2508
INFO - 2018-04-15 02:23:22 --> Config Class Initialized
INFO - 2018-04-15 02:23:23 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:23:23 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:23:23 --> Utf8 Class Initialized
INFO - 2018-04-15 02:23:23 --> URI Class Initialized
DEBUG - 2018-04-15 02:23:23 --> No URI present. Default controller set.
INFO - 2018-04-15 02:23:23 --> Router Class Initialized
INFO - 2018-04-15 02:23:23 --> Output Class Initialized
INFO - 2018-04-15 02:23:23 --> Security Class Initialized
DEBUG - 2018-04-15 02:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:23:23 --> Input Class Initialized
INFO - 2018-04-15 02:23:23 --> Language Class Initialized
INFO - 2018-04-15 02:23:23 --> Loader Class Initialized
INFO - 2018-04-15 02:23:23 --> Helper loaded: url_helper
INFO - 2018-04-15 02:23:23 --> Helper loaded: file_helper
INFO - 2018-04-15 02:23:23 --> Helper loaded: date_helper
INFO - 2018-04-15 02:23:23 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:23:23 --> Controller Class Initialized
INFO - 2018-04-15 02:23:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:23:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:23:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:23:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:23:23 --> Final output sent to browser
DEBUG - 2018-04-15 02:23:23 --> Total execution time: 0.2999
INFO - 2018-04-15 02:24:24 --> Config Class Initialized
INFO - 2018-04-15 02:24:24 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:24:24 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:24:24 --> Utf8 Class Initialized
INFO - 2018-04-15 02:24:24 --> URI Class Initialized
INFO - 2018-04-15 02:24:24 --> Router Class Initialized
INFO - 2018-04-15 02:24:24 --> Output Class Initialized
INFO - 2018-04-15 02:24:24 --> Security Class Initialized
DEBUG - 2018-04-15 02:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:24:24 --> Input Class Initialized
INFO - 2018-04-15 02:24:24 --> Language Class Initialized
ERROR - 2018-04-15 02:24:24 --> 404 Page Not Found: Login/index
INFO - 2018-04-15 02:24:26 --> Config Class Initialized
INFO - 2018-04-15 02:24:27 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:24:27 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:24:27 --> Utf8 Class Initialized
INFO - 2018-04-15 02:24:27 --> URI Class Initialized
DEBUG - 2018-04-15 02:24:27 --> No URI present. Default controller set.
INFO - 2018-04-15 02:24:27 --> Router Class Initialized
INFO - 2018-04-15 02:24:27 --> Output Class Initialized
INFO - 2018-04-15 02:24:27 --> Security Class Initialized
DEBUG - 2018-04-15 02:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:24:27 --> Input Class Initialized
INFO - 2018-04-15 02:24:27 --> Language Class Initialized
INFO - 2018-04-15 02:24:27 --> Loader Class Initialized
INFO - 2018-04-15 02:24:27 --> Helper loaded: url_helper
INFO - 2018-04-15 02:24:27 --> Helper loaded: file_helper
INFO - 2018-04-15 02:24:27 --> Helper loaded: date_helper
INFO - 2018-04-15 02:24:27 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:24:27 --> Controller Class Initialized
INFO - 2018-04-15 02:24:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:24:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:24:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:24:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:24:27 --> Final output sent to browser
DEBUG - 2018-04-15 02:24:27 --> Total execution time: 0.3123
INFO - 2018-04-15 02:24:30 --> Config Class Initialized
INFO - 2018-04-15 02:24:30 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:24:30 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:24:30 --> Utf8 Class Initialized
INFO - 2018-04-15 02:24:30 --> URI Class Initialized
INFO - 2018-04-15 02:24:30 --> Router Class Initialized
INFO - 2018-04-15 02:24:30 --> Output Class Initialized
INFO - 2018-04-15 02:24:30 --> Security Class Initialized
DEBUG - 2018-04-15 02:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:24:30 --> Input Class Initialized
INFO - 2018-04-15 02:24:30 --> Language Class Initialized
ERROR - 2018-04-15 02:24:30 --> 404 Page Not Found: Homephp/index
INFO - 2018-04-15 02:24:48 --> Config Class Initialized
INFO - 2018-04-15 02:24:48 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:24:48 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:24:48 --> Utf8 Class Initialized
INFO - 2018-04-15 02:24:48 --> URI Class Initialized
DEBUG - 2018-04-15 02:24:48 --> No URI present. Default controller set.
INFO - 2018-04-15 02:24:48 --> Router Class Initialized
INFO - 2018-04-15 02:24:48 --> Output Class Initialized
INFO - 2018-04-15 02:24:48 --> Security Class Initialized
DEBUG - 2018-04-15 02:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:24:48 --> Input Class Initialized
INFO - 2018-04-15 02:24:48 --> Language Class Initialized
INFO - 2018-04-15 02:24:48 --> Loader Class Initialized
INFO - 2018-04-15 02:24:48 --> Helper loaded: url_helper
INFO - 2018-04-15 02:24:48 --> Helper loaded: file_helper
INFO - 2018-04-15 02:24:48 --> Helper loaded: date_helper
INFO - 2018-04-15 02:24:48 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:24:48 --> Controller Class Initialized
INFO - 2018-04-15 02:24:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:24:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:24:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:24:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:24:48 --> Final output sent to browser
DEBUG - 2018-04-15 02:24:48 --> Total execution time: 0.3251
INFO - 2018-04-15 02:24:49 --> Config Class Initialized
INFO - 2018-04-15 02:24:49 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:24:49 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:24:49 --> Utf8 Class Initialized
INFO - 2018-04-15 02:24:49 --> URI Class Initialized
DEBUG - 2018-04-15 02:24:49 --> No URI present. Default controller set.
INFO - 2018-04-15 02:24:49 --> Router Class Initialized
INFO - 2018-04-15 02:24:49 --> Output Class Initialized
INFO - 2018-04-15 02:24:49 --> Security Class Initialized
DEBUG - 2018-04-15 02:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:24:49 --> Input Class Initialized
INFO - 2018-04-15 02:24:49 --> Language Class Initialized
INFO - 2018-04-15 02:24:49 --> Loader Class Initialized
INFO - 2018-04-15 02:24:49 --> Helper loaded: url_helper
INFO - 2018-04-15 02:24:49 --> Helper loaded: file_helper
INFO - 2018-04-15 02:24:49 --> Helper loaded: date_helper
INFO - 2018-04-15 02:24:49 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:24:49 --> Controller Class Initialized
INFO - 2018-04-15 02:24:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:24:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:24:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:24:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:24:49 --> Final output sent to browser
DEBUG - 2018-04-15 02:24:49 --> Total execution time: 0.3616
INFO - 2018-04-15 02:24:51 --> Config Class Initialized
INFO - 2018-04-15 02:24:52 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:24:52 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:24:52 --> Utf8 Class Initialized
INFO - 2018-04-15 02:24:52 --> URI Class Initialized
INFO - 2018-04-15 02:24:52 --> Router Class Initialized
INFO - 2018-04-15 02:24:52 --> Output Class Initialized
INFO - 2018-04-15 02:24:52 --> Security Class Initialized
DEBUG - 2018-04-15 02:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:24:52 --> Input Class Initialized
INFO - 2018-04-15 02:24:52 --> Language Class Initialized
ERROR - 2018-04-15 02:24:52 --> 404 Page Not Found: Homephp/index
INFO - 2018-04-15 02:24:56 --> Config Class Initialized
INFO - 2018-04-15 02:24:56 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:24:56 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:24:56 --> Utf8 Class Initialized
INFO - 2018-04-15 02:24:56 --> URI Class Initialized
DEBUG - 2018-04-15 02:24:56 --> No URI present. Default controller set.
INFO - 2018-04-15 02:24:56 --> Router Class Initialized
INFO - 2018-04-15 02:24:56 --> Output Class Initialized
INFO - 2018-04-15 02:24:56 --> Security Class Initialized
DEBUG - 2018-04-15 02:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:24:56 --> Input Class Initialized
INFO - 2018-04-15 02:24:56 --> Language Class Initialized
INFO - 2018-04-15 02:24:56 --> Loader Class Initialized
INFO - 2018-04-15 02:24:56 --> Helper loaded: url_helper
INFO - 2018-04-15 02:24:56 --> Helper loaded: file_helper
INFO - 2018-04-15 02:24:56 --> Helper loaded: date_helper
INFO - 2018-04-15 02:24:56 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:24:56 --> Controller Class Initialized
INFO - 2018-04-15 02:24:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:24:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:24:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:24:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:24:56 --> Final output sent to browser
DEBUG - 2018-04-15 02:24:56 --> Total execution time: 0.3243
INFO - 2018-04-15 02:24:59 --> Config Class Initialized
INFO - 2018-04-15 02:24:59 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:24:59 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:24:59 --> Utf8 Class Initialized
INFO - 2018-04-15 02:24:59 --> URI Class Initialized
INFO - 2018-04-15 02:24:59 --> Router Class Initialized
INFO - 2018-04-15 02:24:59 --> Output Class Initialized
INFO - 2018-04-15 02:24:59 --> Security Class Initialized
DEBUG - 2018-04-15 02:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:24:59 --> Input Class Initialized
INFO - 2018-04-15 02:24:59 --> Language Class Initialized
ERROR - 2018-04-15 02:24:59 --> 404 Page Not Found: Donatephp/index
INFO - 2018-04-15 02:25:03 --> Config Class Initialized
INFO - 2018-04-15 02:25:03 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:25:03 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:25:03 --> Utf8 Class Initialized
INFO - 2018-04-15 02:25:03 --> URI Class Initialized
DEBUG - 2018-04-15 02:25:03 --> No URI present. Default controller set.
INFO - 2018-04-15 02:25:03 --> Router Class Initialized
INFO - 2018-04-15 02:25:03 --> Output Class Initialized
INFO - 2018-04-15 02:25:03 --> Security Class Initialized
DEBUG - 2018-04-15 02:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:25:03 --> Input Class Initialized
INFO - 2018-04-15 02:25:04 --> Language Class Initialized
INFO - 2018-04-15 02:25:04 --> Loader Class Initialized
INFO - 2018-04-15 02:25:04 --> Helper loaded: url_helper
INFO - 2018-04-15 02:25:04 --> Helper loaded: file_helper
INFO - 2018-04-15 02:25:04 --> Helper loaded: date_helper
INFO - 2018-04-15 02:25:04 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:25:04 --> Controller Class Initialized
INFO - 2018-04-15 02:25:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:25:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:25:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:25:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:25:04 --> Final output sent to browser
DEBUG - 2018-04-15 02:25:04 --> Total execution time: 0.3122
INFO - 2018-04-15 02:25:06 --> Config Class Initialized
INFO - 2018-04-15 02:25:06 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:25:06 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:25:06 --> Utf8 Class Initialized
INFO - 2018-04-15 02:25:06 --> URI Class Initialized
INFO - 2018-04-15 02:25:06 --> Router Class Initialized
INFO - 2018-04-15 02:25:06 --> Output Class Initialized
INFO - 2018-04-15 02:25:06 --> Security Class Initialized
DEBUG - 2018-04-15 02:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:25:06 --> Input Class Initialized
INFO - 2018-04-15 02:25:06 --> Language Class Initialized
ERROR - 2018-04-15 02:25:06 --> 404 Page Not Found: Homephp/index
INFO - 2018-04-15 02:25:08 --> Config Class Initialized
INFO - 2018-04-15 02:25:08 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:25:08 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:25:08 --> Utf8 Class Initialized
INFO - 2018-04-15 02:25:08 --> URI Class Initialized
DEBUG - 2018-04-15 02:25:08 --> No URI present. Default controller set.
INFO - 2018-04-15 02:25:08 --> Router Class Initialized
INFO - 2018-04-15 02:25:08 --> Output Class Initialized
INFO - 2018-04-15 02:25:08 --> Security Class Initialized
DEBUG - 2018-04-15 02:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:25:08 --> Input Class Initialized
INFO - 2018-04-15 02:25:08 --> Language Class Initialized
INFO - 2018-04-15 02:25:08 --> Loader Class Initialized
INFO - 2018-04-15 02:25:08 --> Helper loaded: url_helper
INFO - 2018-04-15 02:25:08 --> Helper loaded: file_helper
INFO - 2018-04-15 02:25:08 --> Helper loaded: date_helper
INFO - 2018-04-15 02:25:08 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:25:08 --> Controller Class Initialized
INFO - 2018-04-15 02:25:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:25:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:25:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:25:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:25:08 --> Final output sent to browser
DEBUG - 2018-04-15 02:25:08 --> Total execution time: 0.3246
INFO - 2018-04-15 02:25:11 --> Config Class Initialized
INFO - 2018-04-15 02:25:11 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:25:11 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:25:11 --> Utf8 Class Initialized
INFO - 2018-04-15 02:25:11 --> URI Class Initialized
INFO - 2018-04-15 02:25:11 --> Router Class Initialized
INFO - 2018-04-15 02:25:11 --> Output Class Initialized
INFO - 2018-04-15 02:25:11 --> Security Class Initialized
DEBUG - 2018-04-15 02:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:25:11 --> Input Class Initialized
INFO - 2018-04-15 02:25:11 --> Language Class Initialized
ERROR - 2018-04-15 02:25:11 --> 404 Page Not Found: Donatephp/index
INFO - 2018-04-15 02:25:14 --> Config Class Initialized
INFO - 2018-04-15 02:25:14 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:25:14 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:25:14 --> Utf8 Class Initialized
INFO - 2018-04-15 02:25:14 --> URI Class Initialized
DEBUG - 2018-04-15 02:25:14 --> No URI present. Default controller set.
INFO - 2018-04-15 02:25:14 --> Router Class Initialized
INFO - 2018-04-15 02:25:14 --> Output Class Initialized
INFO - 2018-04-15 02:25:14 --> Security Class Initialized
DEBUG - 2018-04-15 02:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:25:14 --> Input Class Initialized
INFO - 2018-04-15 02:25:14 --> Language Class Initialized
INFO - 2018-04-15 02:25:14 --> Loader Class Initialized
INFO - 2018-04-15 02:25:14 --> Helper loaded: url_helper
INFO - 2018-04-15 02:25:14 --> Helper loaded: file_helper
INFO - 2018-04-15 02:25:14 --> Helper loaded: date_helper
INFO - 2018-04-15 02:25:14 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:25:15 --> Controller Class Initialized
INFO - 2018-04-15 02:25:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:25:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:25:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:25:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:25:15 --> Final output sent to browser
DEBUG - 2018-04-15 02:25:15 --> Total execution time: 0.3268
INFO - 2018-04-15 02:32:27 --> Config Class Initialized
INFO - 2018-04-15 02:32:27 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:32:27 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:32:27 --> Utf8 Class Initialized
INFO - 2018-04-15 02:32:27 --> URI Class Initialized
INFO - 2018-04-15 02:32:27 --> Router Class Initialized
INFO - 2018-04-15 02:32:27 --> Output Class Initialized
INFO - 2018-04-15 02:32:27 --> Security Class Initialized
DEBUG - 2018-04-15 02:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:32:27 --> Input Class Initialized
INFO - 2018-04-15 02:32:27 --> Language Class Initialized
ERROR - 2018-04-15 02:32:27 --> 404 Page Not Found: Login/index
INFO - 2018-04-15 02:32:29 --> Config Class Initialized
INFO - 2018-04-15 02:32:29 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:32:29 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:32:29 --> Utf8 Class Initialized
INFO - 2018-04-15 02:32:29 --> URI Class Initialized
DEBUG - 2018-04-15 02:32:29 --> No URI present. Default controller set.
INFO - 2018-04-15 02:32:29 --> Router Class Initialized
INFO - 2018-04-15 02:32:29 --> Output Class Initialized
INFO - 2018-04-15 02:32:29 --> Security Class Initialized
DEBUG - 2018-04-15 02:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:32:29 --> Input Class Initialized
INFO - 2018-04-15 02:32:29 --> Language Class Initialized
INFO - 2018-04-15 02:32:29 --> Loader Class Initialized
INFO - 2018-04-15 02:32:29 --> Helper loaded: url_helper
INFO - 2018-04-15 02:32:29 --> Helper loaded: file_helper
INFO - 2018-04-15 02:32:29 --> Helper loaded: date_helper
INFO - 2018-04-15 02:32:29 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:32:29 --> Controller Class Initialized
INFO - 2018-04-15 02:32:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:32:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:32:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:32:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:32:30 --> Final output sent to browser
DEBUG - 2018-04-15 02:32:30 --> Total execution time: 0.3379
INFO - 2018-04-15 02:32:53 --> Config Class Initialized
INFO - 2018-04-15 02:32:53 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:32:53 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:32:53 --> Utf8 Class Initialized
INFO - 2018-04-15 02:32:53 --> URI Class Initialized
INFO - 2018-04-15 02:32:53 --> Router Class Initialized
INFO - 2018-04-15 02:32:53 --> Output Class Initialized
INFO - 2018-04-15 02:32:53 --> Security Class Initialized
DEBUG - 2018-04-15 02:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:32:53 --> Input Class Initialized
INFO - 2018-04-15 02:32:53 --> Language Class Initialized
ERROR - 2018-04-15 02:32:53 --> 404 Page Not Found: Login/index
INFO - 2018-04-15 02:32:55 --> Config Class Initialized
INFO - 2018-04-15 02:32:55 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:32:55 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:32:55 --> Utf8 Class Initialized
INFO - 2018-04-15 02:32:55 --> URI Class Initialized
DEBUG - 2018-04-15 02:32:55 --> No URI present. Default controller set.
INFO - 2018-04-15 02:32:55 --> Router Class Initialized
INFO - 2018-04-15 02:32:55 --> Output Class Initialized
INFO - 2018-04-15 02:32:55 --> Security Class Initialized
DEBUG - 2018-04-15 02:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:32:55 --> Input Class Initialized
INFO - 2018-04-15 02:32:55 --> Language Class Initialized
INFO - 2018-04-15 02:32:55 --> Loader Class Initialized
INFO - 2018-04-15 02:32:55 --> Helper loaded: url_helper
INFO - 2018-04-15 02:32:55 --> Helper loaded: file_helper
INFO - 2018-04-15 02:32:55 --> Helper loaded: date_helper
INFO - 2018-04-15 02:32:55 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:32:55 --> Controller Class Initialized
INFO - 2018-04-15 02:32:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:32:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:32:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:32:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:32:55 --> Final output sent to browser
DEBUG - 2018-04-15 02:32:55 --> Total execution time: 0.3735
INFO - 2018-04-15 02:32:56 --> Config Class Initialized
INFO - 2018-04-15 02:32:56 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:32:56 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:32:56 --> Utf8 Class Initialized
INFO - 2018-04-15 02:32:56 --> URI Class Initialized
DEBUG - 2018-04-15 02:32:56 --> No URI present. Default controller set.
INFO - 2018-04-15 02:32:56 --> Router Class Initialized
INFO - 2018-04-15 02:32:56 --> Output Class Initialized
INFO - 2018-04-15 02:32:56 --> Security Class Initialized
DEBUG - 2018-04-15 02:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:32:56 --> Input Class Initialized
INFO - 2018-04-15 02:32:56 --> Language Class Initialized
INFO - 2018-04-15 02:32:56 --> Loader Class Initialized
INFO - 2018-04-15 02:32:56 --> Helper loaded: url_helper
INFO - 2018-04-15 02:32:56 --> Helper loaded: file_helper
INFO - 2018-04-15 02:32:56 --> Helper loaded: date_helper
INFO - 2018-04-15 02:32:56 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:32:56 --> Controller Class Initialized
INFO - 2018-04-15 02:32:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:32:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:32:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:32:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:32:56 --> Final output sent to browser
DEBUG - 2018-04-15 02:32:56 --> Total execution time: 0.3642
INFO - 2018-04-15 02:32:58 --> Config Class Initialized
INFO - 2018-04-15 02:32:58 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:32:58 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:32:58 --> Utf8 Class Initialized
INFO - 2018-04-15 02:32:58 --> URI Class Initialized
INFO - 2018-04-15 02:32:58 --> Router Class Initialized
INFO - 2018-04-15 02:32:58 --> Output Class Initialized
INFO - 2018-04-15 02:32:58 --> Security Class Initialized
DEBUG - 2018-04-15 02:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:32:58 --> Input Class Initialized
INFO - 2018-04-15 02:32:58 --> Language Class Initialized
ERROR - 2018-04-15 02:32:58 --> 404 Page Not Found: Auth_Controller/login
INFO - 2018-04-15 02:33:00 --> Config Class Initialized
INFO - 2018-04-15 02:33:00 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:33:00 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:33:00 --> Utf8 Class Initialized
INFO - 2018-04-15 02:33:00 --> URI Class Initialized
DEBUG - 2018-04-15 02:33:00 --> No URI present. Default controller set.
INFO - 2018-04-15 02:33:00 --> Router Class Initialized
INFO - 2018-04-15 02:33:00 --> Output Class Initialized
INFO - 2018-04-15 02:33:00 --> Security Class Initialized
DEBUG - 2018-04-15 02:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:33:00 --> Input Class Initialized
INFO - 2018-04-15 02:33:00 --> Language Class Initialized
INFO - 2018-04-15 02:33:00 --> Loader Class Initialized
INFO - 2018-04-15 02:33:00 --> Helper loaded: url_helper
INFO - 2018-04-15 02:33:00 --> Helper loaded: file_helper
INFO - 2018-04-15 02:33:00 --> Helper loaded: date_helper
INFO - 2018-04-15 02:33:00 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:33:00 --> Controller Class Initialized
INFO - 2018-04-15 02:33:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:33:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:33:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:33:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:33:01 --> Final output sent to browser
DEBUG - 2018-04-15 02:33:01 --> Total execution time: 0.3176
INFO - 2018-04-15 02:33:34 --> Config Class Initialized
INFO - 2018-04-15 02:33:34 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:33:34 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:33:34 --> Utf8 Class Initialized
INFO - 2018-04-15 02:33:34 --> URI Class Initialized
DEBUG - 2018-04-15 02:33:35 --> No URI present. Default controller set.
INFO - 2018-04-15 02:33:35 --> Router Class Initialized
INFO - 2018-04-15 02:33:35 --> Output Class Initialized
INFO - 2018-04-15 02:33:35 --> Security Class Initialized
DEBUG - 2018-04-15 02:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:33:35 --> Input Class Initialized
INFO - 2018-04-15 02:33:35 --> Language Class Initialized
INFO - 2018-04-15 02:33:35 --> Loader Class Initialized
INFO - 2018-04-15 02:33:35 --> Helper loaded: url_helper
INFO - 2018-04-15 02:33:35 --> Helper loaded: file_helper
INFO - 2018-04-15 02:33:35 --> Helper loaded: date_helper
INFO - 2018-04-15 02:33:35 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:33:35 --> Controller Class Initialized
INFO - 2018-04-15 02:33:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:33:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:33:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:33:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:33:35 --> Final output sent to browser
DEBUG - 2018-04-15 02:33:35 --> Total execution time: 0.3289
INFO - 2018-04-15 02:33:36 --> Config Class Initialized
INFO - 2018-04-15 02:33:36 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:33:36 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:33:36 --> Utf8 Class Initialized
INFO - 2018-04-15 02:33:36 --> URI Class Initialized
INFO - 2018-04-15 02:33:36 --> Router Class Initialized
INFO - 2018-04-15 02:33:36 --> Output Class Initialized
INFO - 2018-04-15 02:33:36 --> Security Class Initialized
DEBUG - 2018-04-15 02:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:33:36 --> Input Class Initialized
INFO - 2018-04-15 02:33:36 --> Language Class Initialized
INFO - 2018-04-15 02:33:36 --> Loader Class Initialized
INFO - 2018-04-15 02:33:36 --> Helper loaded: url_helper
INFO - 2018-04-15 02:33:36 --> Helper loaded: file_helper
INFO - 2018-04-15 02:33:36 --> Helper loaded: date_helper
INFO - 2018-04-15 02:33:36 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:33:36 --> Controller Class Initialized
INFO - 2018-04-15 02:33:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 02:33:36 --> Final output sent to browser
DEBUG - 2018-04-15 02:33:36 --> Total execution time: 0.3159
INFO - 2018-04-15 02:33:39 --> Config Class Initialized
INFO - 2018-04-15 02:33:39 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:33:40 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:33:40 --> Utf8 Class Initialized
INFO - 2018-04-15 02:33:40 --> URI Class Initialized
DEBUG - 2018-04-15 02:33:40 --> No URI present. Default controller set.
INFO - 2018-04-15 02:33:40 --> Router Class Initialized
INFO - 2018-04-15 02:33:40 --> Output Class Initialized
INFO - 2018-04-15 02:33:40 --> Security Class Initialized
DEBUG - 2018-04-15 02:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:33:40 --> Input Class Initialized
INFO - 2018-04-15 02:33:40 --> Language Class Initialized
INFO - 2018-04-15 02:33:40 --> Loader Class Initialized
INFO - 2018-04-15 02:33:40 --> Helper loaded: url_helper
INFO - 2018-04-15 02:33:40 --> Helper loaded: file_helper
INFO - 2018-04-15 02:33:40 --> Helper loaded: date_helper
INFO - 2018-04-15 02:33:40 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:33:40 --> Controller Class Initialized
INFO - 2018-04-15 02:33:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:33:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:33:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:33:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:33:40 --> Final output sent to browser
DEBUG - 2018-04-15 02:33:40 --> Total execution time: 0.3370
INFO - 2018-04-15 02:33:42 --> Config Class Initialized
INFO - 2018-04-15 02:33:42 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:33:42 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:33:42 --> Utf8 Class Initialized
INFO - 2018-04-15 02:33:42 --> URI Class Initialized
INFO - 2018-04-15 02:33:42 --> Router Class Initialized
INFO - 2018-04-15 02:33:42 --> Output Class Initialized
INFO - 2018-04-15 02:33:42 --> Security Class Initialized
DEBUG - 2018-04-15 02:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:33:42 --> Input Class Initialized
INFO - 2018-04-15 02:33:42 --> Language Class Initialized
ERROR - 2018-04-15 02:33:42 --> 404 Page Not Found: Home/donate
INFO - 2018-04-15 02:33:44 --> Config Class Initialized
INFO - 2018-04-15 02:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:33:44 --> Utf8 Class Initialized
INFO - 2018-04-15 02:33:44 --> URI Class Initialized
DEBUG - 2018-04-15 02:33:44 --> No URI present. Default controller set.
INFO - 2018-04-15 02:33:44 --> Router Class Initialized
INFO - 2018-04-15 02:33:44 --> Output Class Initialized
INFO - 2018-04-15 02:33:44 --> Security Class Initialized
DEBUG - 2018-04-15 02:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:33:44 --> Input Class Initialized
INFO - 2018-04-15 02:33:44 --> Language Class Initialized
INFO - 2018-04-15 02:33:44 --> Loader Class Initialized
INFO - 2018-04-15 02:33:44 --> Helper loaded: url_helper
INFO - 2018-04-15 02:33:44 --> Helper loaded: file_helper
INFO - 2018-04-15 02:33:44 --> Helper loaded: date_helper
INFO - 2018-04-15 02:33:44 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:33:44 --> Controller Class Initialized
INFO - 2018-04-15 02:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:33:44 --> Final output sent to browser
DEBUG - 2018-04-15 02:33:44 --> Total execution time: 0.3849
INFO - 2018-04-15 02:33:47 --> Config Class Initialized
INFO - 2018-04-15 02:33:47 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:33:47 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:33:47 --> Utf8 Class Initialized
INFO - 2018-04-15 02:33:47 --> URI Class Initialized
INFO - 2018-04-15 02:33:47 --> Router Class Initialized
INFO - 2018-04-15 02:33:47 --> Output Class Initialized
INFO - 2018-04-15 02:33:47 --> Security Class Initialized
DEBUG - 2018-04-15 02:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:33:47 --> Input Class Initialized
INFO - 2018-04-15 02:33:47 --> Language Class Initialized
INFO - 2018-04-15 02:33:47 --> Loader Class Initialized
INFO - 2018-04-15 02:33:47 --> Helper loaded: url_helper
INFO - 2018-04-15 02:33:47 --> Helper loaded: file_helper
INFO - 2018-04-15 02:33:47 --> Helper loaded: date_helper
INFO - 2018-04-15 02:33:47 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:33:47 --> Controller Class Initialized
INFO - 2018-04-15 02:33:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 02:33:47 --> Final output sent to browser
DEBUG - 2018-04-15 02:33:47 --> Total execution time: 0.2785
INFO - 2018-04-15 02:33:50 --> Config Class Initialized
INFO - 2018-04-15 02:33:50 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:33:50 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:33:50 --> Utf8 Class Initialized
INFO - 2018-04-15 02:33:50 --> URI Class Initialized
DEBUG - 2018-04-15 02:33:50 --> No URI present. Default controller set.
INFO - 2018-04-15 02:33:50 --> Router Class Initialized
INFO - 2018-04-15 02:33:50 --> Output Class Initialized
INFO - 2018-04-15 02:33:50 --> Security Class Initialized
DEBUG - 2018-04-15 02:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:33:50 --> Input Class Initialized
INFO - 2018-04-15 02:33:50 --> Language Class Initialized
INFO - 2018-04-15 02:33:50 --> Loader Class Initialized
INFO - 2018-04-15 02:33:50 --> Helper loaded: url_helper
INFO - 2018-04-15 02:33:50 --> Helper loaded: file_helper
INFO - 2018-04-15 02:33:50 --> Helper loaded: date_helper
INFO - 2018-04-15 02:33:50 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:33:50 --> Controller Class Initialized
INFO - 2018-04-15 02:33:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:33:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:33:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:33:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:33:50 --> Final output sent to browser
DEBUG - 2018-04-15 02:33:50 --> Total execution time: 0.3386
INFO - 2018-04-15 02:37:40 --> Config Class Initialized
INFO - 2018-04-15 02:37:40 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:37:40 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:37:40 --> Utf8 Class Initialized
INFO - 2018-04-15 02:37:40 --> URI Class Initialized
DEBUG - 2018-04-15 02:37:40 --> No URI present. Default controller set.
INFO - 2018-04-15 02:37:40 --> Router Class Initialized
INFO - 2018-04-15 02:37:40 --> Output Class Initialized
INFO - 2018-04-15 02:37:40 --> Security Class Initialized
DEBUG - 2018-04-15 02:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:37:40 --> Input Class Initialized
INFO - 2018-04-15 02:37:40 --> Language Class Initialized
INFO - 2018-04-15 02:37:40 --> Loader Class Initialized
INFO - 2018-04-15 02:37:40 --> Helper loaded: url_helper
INFO - 2018-04-15 02:37:40 --> Helper loaded: file_helper
INFO - 2018-04-15 02:37:40 --> Helper loaded: date_helper
INFO - 2018-04-15 02:37:40 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:37:40 --> Controller Class Initialized
INFO - 2018-04-15 02:37:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:37:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:37:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:37:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:37:40 --> Final output sent to browser
DEBUG - 2018-04-15 02:37:40 --> Total execution time: 0.3478
INFO - 2018-04-15 02:37:42 --> Config Class Initialized
INFO - 2018-04-15 02:37:42 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:37:42 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:37:42 --> Utf8 Class Initialized
INFO - 2018-04-15 02:37:42 --> URI Class Initialized
INFO - 2018-04-15 02:37:42 --> Router Class Initialized
INFO - 2018-04-15 02:37:42 --> Output Class Initialized
INFO - 2018-04-15 02:37:42 --> Security Class Initialized
DEBUG - 2018-04-15 02:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:37:42 --> Input Class Initialized
INFO - 2018-04-15 02:37:42 --> Language Class Initialized
INFO - 2018-04-15 02:37:42 --> Loader Class Initialized
INFO - 2018-04-15 02:37:42 --> Helper loaded: url_helper
INFO - 2018-04-15 02:37:42 --> Helper loaded: file_helper
INFO - 2018-04-15 02:37:42 --> Helper loaded: date_helper
INFO - 2018-04-15 02:37:42 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:37:42 --> Controller Class Initialized
INFO - 2018-04-15 02:37:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:37:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:37:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:37:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:37:42 --> Final output sent to browser
DEBUG - 2018-04-15 02:37:42 --> Total execution time: 0.3413
INFO - 2018-04-15 02:37:42 --> Config Class Initialized
INFO - 2018-04-15 02:37:42 --> Config Class Initialized
INFO - 2018-04-15 02:37:42 --> Hooks Class Initialized
INFO - 2018-04-15 02:37:42 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:37:42 --> UTF-8 Support Enabled
DEBUG - 2018-04-15 02:37:42 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:37:42 --> Utf8 Class Initialized
INFO - 2018-04-15 02:37:42 --> Utf8 Class Initialized
INFO - 2018-04-15 02:37:42 --> URI Class Initialized
INFO - 2018-04-15 02:37:42 --> URI Class Initialized
INFO - 2018-04-15 02:37:42 --> Router Class Initialized
INFO - 2018-04-15 02:37:42 --> Router Class Initialized
INFO - 2018-04-15 02:37:42 --> Output Class Initialized
INFO - 2018-04-15 02:37:42 --> Output Class Initialized
INFO - 2018-04-15 02:37:42 --> Security Class Initialized
INFO - 2018-04-15 02:37:42 --> Security Class Initialized
DEBUG - 2018-04-15 02:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-15 02:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:37:43 --> Input Class Initialized
INFO - 2018-04-15 02:37:43 --> Input Class Initialized
INFO - 2018-04-15 02:37:43 --> Language Class Initialized
INFO - 2018-04-15 02:37:43 --> Language Class Initialized
ERROR - 2018-04-15 02:37:43 --> 404 Page Not Found: Home/assets
ERROR - 2018-04-15 02:37:43 --> 404 Page Not Found: Home/style.css
INFO - 2018-04-15 02:37:43 --> Config Class Initialized
INFO - 2018-04-15 02:37:43 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:37:43 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:37:43 --> Utf8 Class Initialized
INFO - 2018-04-15 02:37:43 --> URI Class Initialized
INFO - 2018-04-15 02:37:43 --> Router Class Initialized
INFO - 2018-04-15 02:37:43 --> Output Class Initialized
INFO - 2018-04-15 02:37:43 --> Security Class Initialized
DEBUG - 2018-04-15 02:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:37:43 --> Input Class Initialized
INFO - 2018-04-15 02:37:43 --> Language Class Initialized
ERROR - 2018-04-15 02:37:43 --> 404 Page Not Found: Home/images.jpg
INFO - 2018-04-15 02:38:58 --> Config Class Initialized
INFO - 2018-04-15 02:38:58 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:38:58 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:38:58 --> Utf8 Class Initialized
INFO - 2018-04-15 02:38:58 --> URI Class Initialized
INFO - 2018-04-15 02:38:58 --> Router Class Initialized
INFO - 2018-04-15 02:38:58 --> Output Class Initialized
INFO - 2018-04-15 02:38:58 --> Security Class Initialized
DEBUG - 2018-04-15 02:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:38:58 --> Input Class Initialized
INFO - 2018-04-15 02:38:58 --> Language Class Initialized
INFO - 2018-04-15 02:38:58 --> Loader Class Initialized
INFO - 2018-04-15 02:38:58 --> Helper loaded: url_helper
INFO - 2018-04-15 02:38:58 --> Helper loaded: file_helper
INFO - 2018-04-15 02:38:58 --> Helper loaded: date_helper
INFO - 2018-04-15 02:38:58 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:38:58 --> Controller Class Initialized
INFO - 2018-04-15 02:38:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:38:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:38:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:38:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:38:59 --> Final output sent to browser
DEBUG - 2018-04-15 02:38:59 --> Total execution time: 0.3278
INFO - 2018-04-15 02:39:26 --> Config Class Initialized
INFO - 2018-04-15 02:39:26 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:39:26 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:39:26 --> Utf8 Class Initialized
INFO - 2018-04-15 02:39:26 --> URI Class Initialized
INFO - 2018-04-15 02:39:26 --> Router Class Initialized
INFO - 2018-04-15 02:39:26 --> Output Class Initialized
INFO - 2018-04-15 02:39:26 --> Security Class Initialized
DEBUG - 2018-04-15 02:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:39:26 --> Input Class Initialized
INFO - 2018-04-15 02:39:26 --> Language Class Initialized
ERROR - 2018-04-15 02:39:26 --> 404 Page Not Found: Home/Home
INFO - 2018-04-15 02:39:29 --> Config Class Initialized
INFO - 2018-04-15 02:39:29 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:39:29 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:39:29 --> Utf8 Class Initialized
INFO - 2018-04-15 02:39:29 --> URI Class Initialized
INFO - 2018-04-15 02:39:29 --> Router Class Initialized
INFO - 2018-04-15 02:39:29 --> Output Class Initialized
INFO - 2018-04-15 02:39:29 --> Security Class Initialized
DEBUG - 2018-04-15 02:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:39:29 --> Input Class Initialized
INFO - 2018-04-15 02:39:29 --> Language Class Initialized
INFO - 2018-04-15 02:39:29 --> Loader Class Initialized
INFO - 2018-04-15 02:39:29 --> Helper loaded: url_helper
INFO - 2018-04-15 02:39:29 --> Helper loaded: file_helper
INFO - 2018-04-15 02:39:29 --> Helper loaded: date_helper
INFO - 2018-04-15 02:39:29 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:39:29 --> Controller Class Initialized
INFO - 2018-04-15 02:39:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:39:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:39:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:39:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:39:29 --> Final output sent to browser
DEBUG - 2018-04-15 02:39:29 --> Total execution time: 0.3148
INFO - 2018-04-15 02:39:31 --> Config Class Initialized
INFO - 2018-04-15 02:39:31 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:39:31 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:39:31 --> Utf8 Class Initialized
INFO - 2018-04-15 02:39:31 --> URI Class Initialized
INFO - 2018-04-15 02:39:31 --> Router Class Initialized
INFO - 2018-04-15 02:39:31 --> Output Class Initialized
INFO - 2018-04-15 02:39:31 --> Security Class Initialized
DEBUG - 2018-04-15 02:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:39:31 --> Input Class Initialized
INFO - 2018-04-15 02:39:31 --> Language Class Initialized
INFO - 2018-04-15 02:39:31 --> Loader Class Initialized
INFO - 2018-04-15 02:39:31 --> Helper loaded: url_helper
INFO - 2018-04-15 02:39:31 --> Helper loaded: file_helper
INFO - 2018-04-15 02:39:31 --> Helper loaded: date_helper
INFO - 2018-04-15 02:39:31 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:39:31 --> Controller Class Initialized
INFO - 2018-04-15 02:39:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:39:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:39:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:39:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:39:31 --> Final output sent to browser
DEBUG - 2018-04-15 02:39:31 --> Total execution time: 0.3811
INFO - 2018-04-15 02:39:32 --> Config Class Initialized
INFO - 2018-04-15 02:39:32 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:39:32 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:39:32 --> Utf8 Class Initialized
INFO - 2018-04-15 02:39:32 --> URI Class Initialized
INFO - 2018-04-15 02:39:32 --> Router Class Initialized
INFO - 2018-04-15 02:39:32 --> Output Class Initialized
INFO - 2018-04-15 02:39:32 --> Security Class Initialized
DEBUG - 2018-04-15 02:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:39:32 --> Input Class Initialized
INFO - 2018-04-15 02:39:32 --> Language Class Initialized
ERROR - 2018-04-15 02:39:32 --> 404 Page Not Found: Home/Home
INFO - 2018-04-15 02:42:05 --> Config Class Initialized
INFO - 2018-04-15 02:42:05 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:42:06 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:42:06 --> Utf8 Class Initialized
INFO - 2018-04-15 02:42:06 --> URI Class Initialized
INFO - 2018-04-15 02:42:06 --> Router Class Initialized
INFO - 2018-04-15 02:42:06 --> Output Class Initialized
INFO - 2018-04-15 02:42:06 --> Security Class Initialized
DEBUG - 2018-04-15 02:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:42:06 --> Input Class Initialized
INFO - 2018-04-15 02:42:06 --> Language Class Initialized
INFO - 2018-04-15 02:42:06 --> Loader Class Initialized
INFO - 2018-04-15 02:42:06 --> Helper loaded: url_helper
INFO - 2018-04-15 02:42:06 --> Helper loaded: file_helper
INFO - 2018-04-15 02:42:06 --> Helper loaded: date_helper
INFO - 2018-04-15 02:42:06 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:42:06 --> Controller Class Initialized
ERROR - 2018-04-15 02:42:06 --> Severity: error --> Exception: syntax error, unexpected '"?>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' G:\xampp\htdocs\codeigniter\application\views\layout_student\header.php 8
INFO - 2018-04-15 02:42:09 --> Config Class Initialized
INFO - 2018-04-15 02:42:09 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:42:09 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:42:09 --> Utf8 Class Initialized
INFO - 2018-04-15 02:42:09 --> URI Class Initialized
INFO - 2018-04-15 02:42:09 --> Router Class Initialized
INFO - 2018-04-15 02:42:09 --> Output Class Initialized
INFO - 2018-04-15 02:42:09 --> Security Class Initialized
DEBUG - 2018-04-15 02:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:42:09 --> Input Class Initialized
INFO - 2018-04-15 02:42:09 --> Language Class Initialized
INFO - 2018-04-15 02:42:09 --> Loader Class Initialized
INFO - 2018-04-15 02:42:09 --> Helper loaded: url_helper
INFO - 2018-04-15 02:42:09 --> Helper loaded: file_helper
INFO - 2018-04-15 02:42:09 --> Helper loaded: date_helper
INFO - 2018-04-15 02:42:09 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:42:09 --> Controller Class Initialized
ERROR - 2018-04-15 02:42:09 --> Severity: error --> Exception: syntax error, unexpected '"?>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' G:\xampp\htdocs\codeigniter\application\views\layout_student\header.php 8
INFO - 2018-04-15 02:42:54 --> Config Class Initialized
INFO - 2018-04-15 02:42:54 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:42:54 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:42:54 --> Utf8 Class Initialized
INFO - 2018-04-15 02:42:54 --> URI Class Initialized
INFO - 2018-04-15 02:42:54 --> Router Class Initialized
INFO - 2018-04-15 02:42:55 --> Output Class Initialized
INFO - 2018-04-15 02:42:55 --> Security Class Initialized
DEBUG - 2018-04-15 02:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:42:55 --> Input Class Initialized
INFO - 2018-04-15 02:42:55 --> Language Class Initialized
INFO - 2018-04-15 02:42:55 --> Loader Class Initialized
INFO - 2018-04-15 02:42:55 --> Helper loaded: url_helper
INFO - 2018-04-15 02:42:55 --> Helper loaded: file_helper
INFO - 2018-04-15 02:42:55 --> Helper loaded: date_helper
INFO - 2018-04-15 02:42:55 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:42:55 --> Controller Class Initialized
INFO - 2018-04-15 02:42:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:42:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:42:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:42:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:42:55 --> Final output sent to browser
DEBUG - 2018-04-15 02:42:55 --> Total execution time: 0.3685
INFO - 2018-04-15 02:42:58 --> Config Class Initialized
INFO - 2018-04-15 02:42:58 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:42:58 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:42:58 --> Utf8 Class Initialized
INFO - 2018-04-15 02:42:58 --> URI Class Initialized
INFO - 2018-04-15 02:42:58 --> Router Class Initialized
INFO - 2018-04-15 02:42:58 --> Output Class Initialized
INFO - 2018-04-15 02:42:58 --> Security Class Initialized
DEBUG - 2018-04-15 02:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:42:58 --> Input Class Initialized
INFO - 2018-04-15 02:42:59 --> Language Class Initialized
ERROR - 2018-04-15 02:42:59 --> 404 Page Not Found: Home/Home
INFO - 2018-04-15 02:43:02 --> Config Class Initialized
INFO - 2018-04-15 02:43:02 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:43:02 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:43:02 --> Utf8 Class Initialized
INFO - 2018-04-15 02:43:02 --> URI Class Initialized
INFO - 2018-04-15 02:43:02 --> Router Class Initialized
INFO - 2018-04-15 02:43:02 --> Output Class Initialized
INFO - 2018-04-15 02:43:02 --> Security Class Initialized
DEBUG - 2018-04-15 02:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:43:02 --> Input Class Initialized
INFO - 2018-04-15 02:43:02 --> Language Class Initialized
INFO - 2018-04-15 02:43:02 --> Loader Class Initialized
INFO - 2018-04-15 02:43:02 --> Helper loaded: url_helper
INFO - 2018-04-15 02:43:02 --> Helper loaded: file_helper
INFO - 2018-04-15 02:43:02 --> Helper loaded: date_helper
INFO - 2018-04-15 02:43:02 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:43:02 --> Controller Class Initialized
INFO - 2018-04-15 02:43:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:43:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:43:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:43:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:43:02 --> Final output sent to browser
DEBUG - 2018-04-15 02:43:02 --> Total execution time: 0.3335
INFO - 2018-04-15 02:43:37 --> Config Class Initialized
INFO - 2018-04-15 02:43:37 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:43:37 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:43:37 --> Utf8 Class Initialized
INFO - 2018-04-15 02:43:37 --> URI Class Initialized
INFO - 2018-04-15 02:43:37 --> Router Class Initialized
INFO - 2018-04-15 02:43:37 --> Output Class Initialized
INFO - 2018-04-15 02:43:37 --> Security Class Initialized
DEBUG - 2018-04-15 02:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:43:37 --> Input Class Initialized
INFO - 2018-04-15 02:43:37 --> Language Class Initialized
INFO - 2018-04-15 02:43:37 --> Loader Class Initialized
INFO - 2018-04-15 02:43:37 --> Helper loaded: url_helper
INFO - 2018-04-15 02:43:37 --> Helper loaded: file_helper
INFO - 2018-04-15 02:43:37 --> Helper loaded: date_helper
INFO - 2018-04-15 02:43:37 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:43:37 --> Controller Class Initialized
INFO - 2018-04-15 02:43:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:43:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:43:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:43:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:43:37 --> Final output sent to browser
DEBUG - 2018-04-15 02:43:37 --> Total execution time: 0.3305
INFO - 2018-04-15 02:43:39 --> Config Class Initialized
INFO - 2018-04-15 02:43:39 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:43:39 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:43:39 --> Utf8 Class Initialized
INFO - 2018-04-15 02:43:39 --> URI Class Initialized
INFO - 2018-04-15 02:43:39 --> Router Class Initialized
INFO - 2018-04-15 02:43:39 --> Output Class Initialized
INFO - 2018-04-15 02:43:39 --> Security Class Initialized
DEBUG - 2018-04-15 02:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:43:39 --> Input Class Initialized
INFO - 2018-04-15 02:43:39 --> Language Class Initialized
INFO - 2018-04-15 02:43:39 --> Loader Class Initialized
INFO - 2018-04-15 02:43:39 --> Helper loaded: url_helper
INFO - 2018-04-15 02:43:39 --> Helper loaded: file_helper
INFO - 2018-04-15 02:43:39 --> Helper loaded: date_helper
INFO - 2018-04-15 02:43:39 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:43:39 --> Controller Class Initialized
INFO - 2018-04-15 02:43:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:43:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:43:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:43:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:43:39 --> Final output sent to browser
DEBUG - 2018-04-15 02:43:39 --> Total execution time: 0.3433
INFO - 2018-04-15 02:43:41 --> Config Class Initialized
INFO - 2018-04-15 02:43:41 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:43:41 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:43:41 --> Utf8 Class Initialized
INFO - 2018-04-15 02:43:41 --> URI Class Initialized
INFO - 2018-04-15 02:43:41 --> Router Class Initialized
INFO - 2018-04-15 02:43:41 --> Output Class Initialized
INFO - 2018-04-15 02:43:41 --> Security Class Initialized
DEBUG - 2018-04-15 02:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:43:41 --> Input Class Initialized
INFO - 2018-04-15 02:43:41 --> Language Class Initialized
INFO - 2018-04-15 02:43:41 --> Loader Class Initialized
INFO - 2018-04-15 02:43:41 --> Helper loaded: url_helper
INFO - 2018-04-15 02:43:41 --> Helper loaded: file_helper
INFO - 2018-04-15 02:43:41 --> Helper loaded: date_helper
INFO - 2018-04-15 02:43:41 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:43:41 --> Controller Class Initialized
INFO - 2018-04-15 02:43:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:43:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 02:43:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:43:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:43:41 --> Final output sent to browser
DEBUG - 2018-04-15 02:43:41 --> Total execution time: 0.3754
INFO - 2018-04-15 02:43:43 --> Config Class Initialized
INFO - 2018-04-15 02:43:43 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:43:43 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:43:43 --> Utf8 Class Initialized
INFO - 2018-04-15 02:43:43 --> URI Class Initialized
INFO - 2018-04-15 02:43:43 --> Router Class Initialized
INFO - 2018-04-15 02:43:43 --> Output Class Initialized
INFO - 2018-04-15 02:43:43 --> Security Class Initialized
DEBUG - 2018-04-15 02:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:43:43 --> Input Class Initialized
INFO - 2018-04-15 02:43:43 --> Language Class Initialized
INFO - 2018-04-15 02:43:43 --> Loader Class Initialized
INFO - 2018-04-15 02:43:43 --> Helper loaded: url_helper
INFO - 2018-04-15 02:43:43 --> Helper loaded: file_helper
INFO - 2018-04-15 02:43:43 --> Helper loaded: date_helper
INFO - 2018-04-15 02:43:43 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:43:43 --> Controller Class Initialized
INFO - 2018-04-15 02:43:43 --> Final output sent to browser
DEBUG - 2018-04-15 02:43:43 --> Total execution time: 0.3402
INFO - 2018-04-15 02:44:00 --> Config Class Initialized
INFO - 2018-04-15 02:44:00 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:44:00 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:44:00 --> Utf8 Class Initialized
INFO - 2018-04-15 02:44:00 --> URI Class Initialized
INFO - 2018-04-15 02:44:00 --> Router Class Initialized
INFO - 2018-04-15 02:44:00 --> Output Class Initialized
INFO - 2018-04-15 02:44:00 --> Security Class Initialized
DEBUG - 2018-04-15 02:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:44:00 --> Input Class Initialized
INFO - 2018-04-15 02:44:00 --> Language Class Initialized
INFO - 2018-04-15 02:44:00 --> Loader Class Initialized
INFO - 2018-04-15 02:44:00 --> Helper loaded: url_helper
INFO - 2018-04-15 02:44:00 --> Helper loaded: file_helper
INFO - 2018-04-15 02:44:00 --> Helper loaded: date_helper
INFO - 2018-04-15 02:44:00 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:44:00 --> Controller Class Initialized
INFO - 2018-04-15 02:44:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:44:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 02:44:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:44:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:44:01 --> Final output sent to browser
DEBUG - 2018-04-15 02:44:01 --> Total execution time: 0.3369
INFO - 2018-04-15 02:44:03 --> Config Class Initialized
INFO - 2018-04-15 02:44:03 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:44:03 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:44:03 --> Utf8 Class Initialized
INFO - 2018-04-15 02:44:03 --> URI Class Initialized
INFO - 2018-04-15 02:44:03 --> Router Class Initialized
INFO - 2018-04-15 02:44:03 --> Output Class Initialized
INFO - 2018-04-15 02:44:03 --> Security Class Initialized
DEBUG - 2018-04-15 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:44:03 --> Input Class Initialized
INFO - 2018-04-15 02:44:03 --> Language Class Initialized
INFO - 2018-04-15 02:44:03 --> Loader Class Initialized
INFO - 2018-04-15 02:44:03 --> Helper loaded: url_helper
INFO - 2018-04-15 02:44:03 --> Helper loaded: file_helper
INFO - 2018-04-15 02:44:03 --> Helper loaded: date_helper
INFO - 2018-04-15 02:44:03 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:44:03 --> Controller Class Initialized
INFO - 2018-04-15 02:44:03 --> Final output sent to browser
DEBUG - 2018-04-15 02:44:03 --> Total execution time: 0.2875
INFO - 2018-04-15 02:44:06 --> Config Class Initialized
INFO - 2018-04-15 02:44:06 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:44:06 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:44:06 --> Utf8 Class Initialized
INFO - 2018-04-15 02:44:06 --> URI Class Initialized
INFO - 2018-04-15 02:44:06 --> Router Class Initialized
INFO - 2018-04-15 02:44:06 --> Output Class Initialized
INFO - 2018-04-15 02:44:06 --> Security Class Initialized
DEBUG - 2018-04-15 02:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:44:06 --> Input Class Initialized
INFO - 2018-04-15 02:44:06 --> Language Class Initialized
INFO - 2018-04-15 02:44:06 --> Loader Class Initialized
INFO - 2018-04-15 02:44:06 --> Helper loaded: url_helper
INFO - 2018-04-15 02:44:06 --> Helper loaded: file_helper
INFO - 2018-04-15 02:44:06 --> Helper loaded: date_helper
INFO - 2018-04-15 02:44:06 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:44:06 --> Controller Class Initialized
INFO - 2018-04-15 02:44:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:44:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 02:44:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:44:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:44:06 --> Final output sent to browser
DEBUG - 2018-04-15 02:44:06 --> Total execution time: 0.3392
INFO - 2018-04-15 02:44:09 --> Config Class Initialized
INFO - 2018-04-15 02:44:09 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:44:09 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:44:09 --> Utf8 Class Initialized
INFO - 2018-04-15 02:44:09 --> URI Class Initialized
INFO - 2018-04-15 02:44:09 --> Router Class Initialized
INFO - 2018-04-15 02:44:09 --> Output Class Initialized
INFO - 2018-04-15 02:44:09 --> Security Class Initialized
DEBUG - 2018-04-15 02:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:44:09 --> Input Class Initialized
INFO - 2018-04-15 02:44:09 --> Language Class Initialized
ERROR - 2018-04-15 02:44:09 --> 404 Page Not Found: Home/register
INFO - 2018-04-15 02:44:11 --> Config Class Initialized
INFO - 2018-04-15 02:44:11 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:44:11 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:44:11 --> Utf8 Class Initialized
INFO - 2018-04-15 02:44:11 --> URI Class Initialized
INFO - 2018-04-15 02:44:11 --> Router Class Initialized
INFO - 2018-04-15 02:44:11 --> Output Class Initialized
INFO - 2018-04-15 02:44:11 --> Security Class Initialized
DEBUG - 2018-04-15 02:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:44:11 --> Input Class Initialized
INFO - 2018-04-15 02:44:11 --> Language Class Initialized
INFO - 2018-04-15 02:44:11 --> Loader Class Initialized
INFO - 2018-04-15 02:44:11 --> Helper loaded: url_helper
INFO - 2018-04-15 02:44:11 --> Helper loaded: file_helper
INFO - 2018-04-15 02:44:11 --> Helper loaded: date_helper
INFO - 2018-04-15 02:44:11 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:44:11 --> Controller Class Initialized
INFO - 2018-04-15 02:44:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:44:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 02:44:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:44:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:44:11 --> Final output sent to browser
DEBUG - 2018-04-15 02:44:11 --> Total execution time: 0.3352
INFO - 2018-04-15 02:44:13 --> Config Class Initialized
INFO - 2018-04-15 02:44:13 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:44:13 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:44:13 --> Utf8 Class Initialized
INFO - 2018-04-15 02:44:13 --> URI Class Initialized
INFO - 2018-04-15 02:44:13 --> Router Class Initialized
INFO - 2018-04-15 02:44:13 --> Output Class Initialized
INFO - 2018-04-15 02:44:13 --> Security Class Initialized
DEBUG - 2018-04-15 02:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:44:13 --> Input Class Initialized
INFO - 2018-04-15 02:44:13 --> Language Class Initialized
INFO - 2018-04-15 02:44:13 --> Loader Class Initialized
INFO - 2018-04-15 02:44:13 --> Helper loaded: url_helper
INFO - 2018-04-15 02:44:13 --> Helper loaded: file_helper
INFO - 2018-04-15 02:44:13 --> Helper loaded: date_helper
INFO - 2018-04-15 02:44:13 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:44:13 --> Controller Class Initialized
INFO - 2018-04-15 02:44:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:44:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:44:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:44:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:44:13 --> Final output sent to browser
DEBUG - 2018-04-15 02:44:13 --> Total execution time: 0.3188
INFO - 2018-04-15 02:44:49 --> Config Class Initialized
INFO - 2018-04-15 02:44:49 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:44:49 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:44:49 --> Utf8 Class Initialized
INFO - 2018-04-15 02:44:49 --> URI Class Initialized
INFO - 2018-04-15 02:44:49 --> Router Class Initialized
INFO - 2018-04-15 02:44:49 --> Output Class Initialized
INFO - 2018-04-15 02:44:49 --> Security Class Initialized
DEBUG - 2018-04-15 02:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:44:49 --> Input Class Initialized
INFO - 2018-04-15 02:44:49 --> Language Class Initialized
INFO - 2018-04-15 02:44:49 --> Loader Class Initialized
INFO - 2018-04-15 02:44:49 --> Helper loaded: url_helper
INFO - 2018-04-15 02:44:49 --> Helper loaded: file_helper
INFO - 2018-04-15 02:44:49 --> Helper loaded: date_helper
INFO - 2018-04-15 02:44:49 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:44:49 --> Controller Class Initialized
INFO - 2018-04-15 02:44:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:44:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:44:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:44:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:44:50 --> Final output sent to browser
DEBUG - 2018-04-15 02:44:50 --> Total execution time: 0.3402
INFO - 2018-04-15 02:44:52 --> Config Class Initialized
INFO - 2018-04-15 02:44:52 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:44:52 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:44:52 --> Utf8 Class Initialized
INFO - 2018-04-15 02:44:52 --> URI Class Initialized
INFO - 2018-04-15 02:44:52 --> Router Class Initialized
INFO - 2018-04-15 02:44:52 --> Output Class Initialized
INFO - 2018-04-15 02:44:52 --> Security Class Initialized
DEBUG - 2018-04-15 02:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:44:52 --> Input Class Initialized
INFO - 2018-04-15 02:44:52 --> Language Class Initialized
INFO - 2018-04-15 02:44:52 --> Loader Class Initialized
INFO - 2018-04-15 02:44:52 --> Helper loaded: url_helper
INFO - 2018-04-15 02:44:52 --> Helper loaded: file_helper
INFO - 2018-04-15 02:44:52 --> Helper loaded: date_helper
INFO - 2018-04-15 02:44:52 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:44:52 --> Controller Class Initialized
INFO - 2018-04-15 02:44:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:44:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:44:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:44:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:44:52 --> Final output sent to browser
DEBUG - 2018-04-15 02:44:52 --> Total execution time: 0.3242
INFO - 2018-04-15 02:44:54 --> Config Class Initialized
INFO - 2018-04-15 02:44:54 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:44:54 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:44:54 --> Utf8 Class Initialized
INFO - 2018-04-15 02:44:54 --> URI Class Initialized
INFO - 2018-04-15 02:44:54 --> Router Class Initialized
INFO - 2018-04-15 02:44:54 --> Output Class Initialized
INFO - 2018-04-15 02:44:54 --> Security Class Initialized
DEBUG - 2018-04-15 02:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:44:54 --> Input Class Initialized
INFO - 2018-04-15 02:44:54 --> Language Class Initialized
ERROR - 2018-04-15 02:44:54 --> 404 Page Not Found: Home/register
INFO - 2018-04-15 02:46:11 --> Config Class Initialized
INFO - 2018-04-15 02:46:11 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:46:11 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:46:11 --> Utf8 Class Initialized
INFO - 2018-04-15 02:46:11 --> URI Class Initialized
INFO - 2018-04-15 02:46:11 --> Router Class Initialized
INFO - 2018-04-15 02:46:11 --> Output Class Initialized
INFO - 2018-04-15 02:46:11 --> Security Class Initialized
DEBUG - 2018-04-15 02:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:46:11 --> Input Class Initialized
INFO - 2018-04-15 02:46:11 --> Language Class Initialized
ERROR - 2018-04-15 02:46:11 --> 404 Page Not Found: Home/register
INFO - 2018-04-15 02:46:14 --> Config Class Initialized
INFO - 2018-04-15 02:46:14 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:46:14 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:46:14 --> Utf8 Class Initialized
INFO - 2018-04-15 02:46:14 --> URI Class Initialized
INFO - 2018-04-15 02:46:14 --> Router Class Initialized
INFO - 2018-04-15 02:46:14 --> Output Class Initialized
INFO - 2018-04-15 02:46:14 --> Security Class Initialized
DEBUG - 2018-04-15 02:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:46:14 --> Input Class Initialized
INFO - 2018-04-15 02:46:14 --> Language Class Initialized
INFO - 2018-04-15 02:46:14 --> Loader Class Initialized
INFO - 2018-04-15 02:46:14 --> Helper loaded: url_helper
INFO - 2018-04-15 02:46:14 --> Helper loaded: file_helper
INFO - 2018-04-15 02:46:14 --> Helper loaded: date_helper
INFO - 2018-04-15 02:46:14 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:46:14 --> Controller Class Initialized
INFO - 2018-04-15 02:46:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:46:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:46:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:46:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:46:14 --> Final output sent to browser
DEBUG - 2018-04-15 02:46:14 --> Total execution time: 0.3313
INFO - 2018-04-15 02:46:17 --> Config Class Initialized
INFO - 2018-04-15 02:46:17 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:46:17 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:46:17 --> Utf8 Class Initialized
INFO - 2018-04-15 02:46:17 --> URI Class Initialized
INFO - 2018-04-15 02:46:17 --> Router Class Initialized
INFO - 2018-04-15 02:46:17 --> Output Class Initialized
INFO - 2018-04-15 02:46:17 --> Security Class Initialized
DEBUG - 2018-04-15 02:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:46:17 --> Input Class Initialized
INFO - 2018-04-15 02:46:17 --> Language Class Initialized
INFO - 2018-04-15 02:46:17 --> Loader Class Initialized
INFO - 2018-04-15 02:46:17 --> Helper loaded: url_helper
INFO - 2018-04-15 02:46:17 --> Helper loaded: file_helper
INFO - 2018-04-15 02:46:17 --> Helper loaded: date_helper
INFO - 2018-04-15 02:46:17 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:46:17 --> Controller Class Initialized
INFO - 2018-04-15 02:46:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:46:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:46:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:46:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:46:18 --> Final output sent to browser
DEBUG - 2018-04-15 02:46:18 --> Total execution time: 0.3421
INFO - 2018-04-15 02:46:19 --> Config Class Initialized
INFO - 2018-04-15 02:46:19 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:46:19 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:46:19 --> Utf8 Class Initialized
INFO - 2018-04-15 02:46:19 --> URI Class Initialized
INFO - 2018-04-15 02:46:19 --> Router Class Initialized
INFO - 2018-04-15 02:46:19 --> Output Class Initialized
INFO - 2018-04-15 02:46:19 --> Security Class Initialized
DEBUG - 2018-04-15 02:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:46:19 --> Input Class Initialized
INFO - 2018-04-15 02:46:19 --> Language Class Initialized
INFO - 2018-04-15 02:46:19 --> Loader Class Initialized
INFO - 2018-04-15 02:46:19 --> Helper loaded: url_helper
INFO - 2018-04-15 02:46:19 --> Helper loaded: file_helper
INFO - 2018-04-15 02:46:19 --> Helper loaded: date_helper
INFO - 2018-04-15 02:46:19 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:46:19 --> Controller Class Initialized
INFO - 2018-04-15 02:46:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:46:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:46:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:46:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:46:19 --> Final output sent to browser
DEBUG - 2018-04-15 02:46:19 --> Total execution time: 0.3764
INFO - 2018-04-15 02:46:21 --> Config Class Initialized
INFO - 2018-04-15 02:46:21 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:46:21 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:46:21 --> Utf8 Class Initialized
INFO - 2018-04-15 02:46:21 --> URI Class Initialized
INFO - 2018-04-15 02:46:21 --> Router Class Initialized
INFO - 2018-04-15 02:46:21 --> Output Class Initialized
INFO - 2018-04-15 02:46:21 --> Security Class Initialized
DEBUG - 2018-04-15 02:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:46:21 --> Input Class Initialized
INFO - 2018-04-15 02:46:21 --> Language Class Initialized
INFO - 2018-04-15 02:46:21 --> Loader Class Initialized
INFO - 2018-04-15 02:46:21 --> Helper loaded: url_helper
INFO - 2018-04-15 02:46:21 --> Helper loaded: file_helper
INFO - 2018-04-15 02:46:21 --> Helper loaded: date_helper
INFO - 2018-04-15 02:46:21 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:46:21 --> Controller Class Initialized
INFO - 2018-04-15 02:46:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:46:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:46:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:46:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:46:21 --> Final output sent to browser
DEBUG - 2018-04-15 02:46:21 --> Total execution time: 0.3705
INFO - 2018-04-15 02:46:23 --> Config Class Initialized
INFO - 2018-04-15 02:46:23 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:46:23 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:46:23 --> Utf8 Class Initialized
INFO - 2018-04-15 02:46:23 --> URI Class Initialized
INFO - 2018-04-15 02:46:23 --> Router Class Initialized
INFO - 2018-04-15 02:46:23 --> Output Class Initialized
INFO - 2018-04-15 02:46:23 --> Security Class Initialized
DEBUG - 2018-04-15 02:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:46:23 --> Input Class Initialized
INFO - 2018-04-15 02:46:23 --> Language Class Initialized
INFO - 2018-04-15 02:46:23 --> Loader Class Initialized
INFO - 2018-04-15 02:46:23 --> Helper loaded: url_helper
INFO - 2018-04-15 02:46:23 --> Helper loaded: file_helper
INFO - 2018-04-15 02:46:23 --> Helper loaded: date_helper
INFO - 2018-04-15 02:46:23 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:46:23 --> Controller Class Initialized
INFO - 2018-04-15 02:46:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:46:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 02:46:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:46:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:46:23 --> Final output sent to browser
DEBUG - 2018-04-15 02:46:23 --> Total execution time: 0.3809
INFO - 2018-04-15 02:46:24 --> Config Class Initialized
INFO - 2018-04-15 02:46:24 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:46:25 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:46:25 --> Utf8 Class Initialized
INFO - 2018-04-15 02:46:25 --> URI Class Initialized
INFO - 2018-04-15 02:46:25 --> Router Class Initialized
INFO - 2018-04-15 02:46:25 --> Output Class Initialized
INFO - 2018-04-15 02:46:25 --> Security Class Initialized
DEBUG - 2018-04-15 02:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:46:25 --> Input Class Initialized
INFO - 2018-04-15 02:46:25 --> Language Class Initialized
INFO - 2018-04-15 02:46:25 --> Loader Class Initialized
INFO - 2018-04-15 02:46:25 --> Helper loaded: url_helper
INFO - 2018-04-15 02:46:25 --> Helper loaded: file_helper
INFO - 2018-04-15 02:46:25 --> Helper loaded: date_helper
INFO - 2018-04-15 02:46:25 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:46:25 --> Controller Class Initialized
INFO - 2018-04-15 02:46:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:46:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:46:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:46:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:46:25 --> Final output sent to browser
DEBUG - 2018-04-15 02:46:25 --> Total execution time: 0.3746
INFO - 2018-04-15 02:46:27 --> Config Class Initialized
INFO - 2018-04-15 02:46:27 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:46:27 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:46:27 --> Utf8 Class Initialized
INFO - 2018-04-15 02:46:27 --> URI Class Initialized
INFO - 2018-04-15 02:46:27 --> Router Class Initialized
INFO - 2018-04-15 02:46:27 --> Output Class Initialized
INFO - 2018-04-15 02:46:27 --> Security Class Initialized
DEBUG - 2018-04-15 02:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:46:27 --> Input Class Initialized
INFO - 2018-04-15 02:46:27 --> Language Class Initialized
ERROR - 2018-04-15 02:46:27 --> 404 Page Not Found: Home/register
INFO - 2018-04-15 02:48:38 --> Config Class Initialized
INFO - 2018-04-15 02:48:38 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:48:38 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:48:38 --> Utf8 Class Initialized
INFO - 2018-04-15 02:48:38 --> URI Class Initialized
INFO - 2018-04-15 02:48:38 --> Router Class Initialized
INFO - 2018-04-15 02:48:38 --> Output Class Initialized
INFO - 2018-04-15 02:48:38 --> Security Class Initialized
DEBUG - 2018-04-15 02:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:48:38 --> Input Class Initialized
INFO - 2018-04-15 02:48:38 --> Language Class Initialized
INFO - 2018-04-15 02:48:38 --> Loader Class Initialized
INFO - 2018-04-15 02:48:38 --> Helper loaded: url_helper
INFO - 2018-04-15 02:48:38 --> Helper loaded: file_helper
INFO - 2018-04-15 02:48:38 --> Helper loaded: date_helper
INFO - 2018-04-15 02:48:38 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:48:38 --> Controller Class Initialized
INFO - 2018-04-15 02:48:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:48:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:48:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:48:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:48:38 --> Final output sent to browser
DEBUG - 2018-04-15 02:48:38 --> Total execution time: 0.3536
INFO - 2018-04-15 02:48:41 --> Config Class Initialized
INFO - 2018-04-15 02:48:41 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:48:41 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:48:41 --> Utf8 Class Initialized
INFO - 2018-04-15 02:48:41 --> URI Class Initialized
INFO - 2018-04-15 02:48:41 --> Router Class Initialized
INFO - 2018-04-15 02:48:41 --> Output Class Initialized
INFO - 2018-04-15 02:48:41 --> Security Class Initialized
DEBUG - 2018-04-15 02:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:48:41 --> Input Class Initialized
INFO - 2018-04-15 02:48:41 --> Language Class Initialized
ERROR - 2018-04-15 02:48:41 --> 404 Page Not Found: Home/register
INFO - 2018-04-15 02:48:45 --> Config Class Initialized
INFO - 2018-04-15 02:48:45 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:48:45 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:48:45 --> Utf8 Class Initialized
INFO - 2018-04-15 02:48:45 --> URI Class Initialized
INFO - 2018-04-15 02:48:45 --> Router Class Initialized
INFO - 2018-04-15 02:48:45 --> Output Class Initialized
INFO - 2018-04-15 02:48:45 --> Security Class Initialized
DEBUG - 2018-04-15 02:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:48:45 --> Input Class Initialized
INFO - 2018-04-15 02:48:45 --> Language Class Initialized
INFO - 2018-04-15 02:48:45 --> Loader Class Initialized
INFO - 2018-04-15 02:48:45 --> Helper loaded: url_helper
INFO - 2018-04-15 02:48:45 --> Helper loaded: file_helper
INFO - 2018-04-15 02:48:45 --> Helper loaded: date_helper
INFO - 2018-04-15 02:48:45 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:48:45 --> Controller Class Initialized
INFO - 2018-04-15 02:48:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:48:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:48:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:48:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:48:46 --> Final output sent to browser
DEBUG - 2018-04-15 02:48:46 --> Total execution time: 0.3463
INFO - 2018-04-15 02:53:00 --> Config Class Initialized
INFO - 2018-04-15 02:53:01 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:53:01 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:53:01 --> Utf8 Class Initialized
INFO - 2018-04-15 02:53:01 --> URI Class Initialized
INFO - 2018-04-15 02:53:01 --> Router Class Initialized
INFO - 2018-04-15 02:53:01 --> Output Class Initialized
INFO - 2018-04-15 02:53:01 --> Security Class Initialized
DEBUG - 2018-04-15 02:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:53:01 --> Input Class Initialized
INFO - 2018-04-15 02:53:01 --> Language Class Initialized
INFO - 2018-04-15 02:53:01 --> Loader Class Initialized
INFO - 2018-04-15 02:53:01 --> Helper loaded: url_helper
INFO - 2018-04-15 02:53:01 --> Helper loaded: file_helper
INFO - 2018-04-15 02:53:01 --> Helper loaded: date_helper
INFO - 2018-04-15 02:53:01 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:53:01 --> Controller Class Initialized
INFO - 2018-04-15 02:53:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:53:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:53:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:53:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:53:01 --> Final output sent to browser
DEBUG - 2018-04-15 02:53:01 --> Total execution time: 0.3610
INFO - 2018-04-15 02:53:05 --> Config Class Initialized
INFO - 2018-04-15 02:53:05 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:53:05 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:53:05 --> Utf8 Class Initialized
INFO - 2018-04-15 02:53:05 --> URI Class Initialized
INFO - 2018-04-15 02:53:05 --> Router Class Initialized
INFO - 2018-04-15 02:53:05 --> Output Class Initialized
INFO - 2018-04-15 02:53:05 --> Security Class Initialized
DEBUG - 2018-04-15 02:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:53:05 --> Input Class Initialized
INFO - 2018-04-15 02:53:05 --> Language Class Initialized
INFO - 2018-04-15 02:53:05 --> Loader Class Initialized
INFO - 2018-04-15 02:53:05 --> Helper loaded: url_helper
INFO - 2018-04-15 02:53:05 --> Helper loaded: file_helper
INFO - 2018-04-15 02:53:05 --> Helper loaded: date_helper
INFO - 2018-04-15 02:53:05 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:53:05 --> Controller Class Initialized
INFO - 2018-04-15 02:53:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:53:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:53:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:53:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:53:05 --> Final output sent to browser
DEBUG - 2018-04-15 02:53:05 --> Total execution time: 0.3296
INFO - 2018-04-15 02:53:06 --> Config Class Initialized
INFO - 2018-04-15 02:53:06 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:53:06 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:53:06 --> Utf8 Class Initialized
INFO - 2018-04-15 02:53:06 --> URI Class Initialized
INFO - 2018-04-15 02:53:06 --> Router Class Initialized
INFO - 2018-04-15 02:53:06 --> Output Class Initialized
INFO - 2018-04-15 02:53:06 --> Security Class Initialized
DEBUG - 2018-04-15 02:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:53:06 --> Input Class Initialized
INFO - 2018-04-15 02:53:06 --> Language Class Initialized
INFO - 2018-04-15 02:53:06 --> Loader Class Initialized
INFO - 2018-04-15 02:53:07 --> Helper loaded: url_helper
INFO - 2018-04-15 02:53:07 --> Helper loaded: file_helper
INFO - 2018-04-15 02:53:07 --> Helper loaded: date_helper
INFO - 2018-04-15 02:53:07 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:53:07 --> Controller Class Initialized
INFO - 2018-04-15 02:53:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:53:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:53:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:53:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:53:07 --> Final output sent to browser
DEBUG - 2018-04-15 02:53:07 --> Total execution time: 0.4098
INFO - 2018-04-15 02:53:08 --> Config Class Initialized
INFO - 2018-04-15 02:53:08 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:53:08 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:53:08 --> Utf8 Class Initialized
INFO - 2018-04-15 02:53:08 --> URI Class Initialized
INFO - 2018-04-15 02:53:08 --> Router Class Initialized
INFO - 2018-04-15 02:53:08 --> Output Class Initialized
INFO - 2018-04-15 02:53:08 --> Security Class Initialized
DEBUG - 2018-04-15 02:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:53:08 --> Input Class Initialized
INFO - 2018-04-15 02:53:08 --> Language Class Initialized
INFO - 2018-04-15 02:53:08 --> Loader Class Initialized
INFO - 2018-04-15 02:53:08 --> Helper loaded: url_helper
INFO - 2018-04-15 02:53:08 --> Helper loaded: file_helper
INFO - 2018-04-15 02:53:08 --> Helper loaded: date_helper
INFO - 2018-04-15 02:53:08 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:53:08 --> Controller Class Initialized
INFO - 2018-04-15 02:53:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:53:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 02:53:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:53:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:53:08 --> Final output sent to browser
DEBUG - 2018-04-15 02:53:08 --> Total execution time: 0.3804
INFO - 2018-04-15 02:53:10 --> Config Class Initialized
INFO - 2018-04-15 02:53:10 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:53:10 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:53:10 --> Utf8 Class Initialized
INFO - 2018-04-15 02:53:10 --> URI Class Initialized
INFO - 2018-04-15 02:53:10 --> Router Class Initialized
INFO - 2018-04-15 02:53:10 --> Output Class Initialized
INFO - 2018-04-15 02:53:10 --> Security Class Initialized
DEBUG - 2018-04-15 02:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:53:10 --> Input Class Initialized
INFO - 2018-04-15 02:53:10 --> Language Class Initialized
INFO - 2018-04-15 02:53:10 --> Loader Class Initialized
INFO - 2018-04-15 02:53:10 --> Helper loaded: url_helper
INFO - 2018-04-15 02:53:10 --> Helper loaded: file_helper
INFO - 2018-04-15 02:53:10 --> Helper loaded: date_helper
INFO - 2018-04-15 02:53:10 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:53:10 --> Controller Class Initialized
INFO - 2018-04-15 02:53:10 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:53:10 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:53:10 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:53:10 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:53:10 --> Final output sent to browser
DEBUG - 2018-04-15 02:53:10 --> Total execution time: 0.3952
INFO - 2018-04-15 02:53:11 --> Config Class Initialized
INFO - 2018-04-15 02:53:12 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:53:12 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:53:12 --> Utf8 Class Initialized
INFO - 2018-04-15 02:53:12 --> URI Class Initialized
INFO - 2018-04-15 02:53:12 --> Router Class Initialized
INFO - 2018-04-15 02:53:12 --> Output Class Initialized
INFO - 2018-04-15 02:53:12 --> Security Class Initialized
DEBUG - 2018-04-15 02:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:53:12 --> Input Class Initialized
INFO - 2018-04-15 02:53:12 --> Language Class Initialized
ERROR - 2018-04-15 02:53:12 --> 404 Page Not Found: Home/register
INFO - 2018-04-15 02:53:57 --> Config Class Initialized
INFO - 2018-04-15 02:53:57 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:53:57 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:53:57 --> Utf8 Class Initialized
INFO - 2018-04-15 02:53:57 --> URI Class Initialized
INFO - 2018-04-15 02:53:57 --> Router Class Initialized
INFO - 2018-04-15 02:53:57 --> Output Class Initialized
INFO - 2018-04-15 02:53:57 --> Security Class Initialized
DEBUG - 2018-04-15 02:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:53:57 --> Input Class Initialized
INFO - 2018-04-15 02:53:57 --> Language Class Initialized
ERROR - 2018-04-15 02:53:57 --> 404 Page Not Found: Home/register
INFO - 2018-04-15 02:54:00 --> Config Class Initialized
INFO - 2018-04-15 02:54:00 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:54:00 --> Utf8 Class Initialized
INFO - 2018-04-15 02:54:00 --> URI Class Initialized
INFO - 2018-04-15 02:54:00 --> Router Class Initialized
INFO - 2018-04-15 02:54:01 --> Output Class Initialized
INFO - 2018-04-15 02:54:01 --> Security Class Initialized
DEBUG - 2018-04-15 02:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:54:01 --> Input Class Initialized
INFO - 2018-04-15 02:54:01 --> Language Class Initialized
INFO - 2018-04-15 02:54:01 --> Loader Class Initialized
INFO - 2018-04-15 02:54:01 --> Helper loaded: url_helper
INFO - 2018-04-15 02:54:01 --> Helper loaded: file_helper
INFO - 2018-04-15 02:54:01 --> Helper loaded: date_helper
INFO - 2018-04-15 02:54:01 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:54:01 --> Controller Class Initialized
INFO - 2018-04-15 02:54:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:54:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:54:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:54:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:54:01 --> Final output sent to browser
DEBUG - 2018-04-15 02:54:01 --> Total execution time: 0.3600
INFO - 2018-04-15 02:54:04 --> Config Class Initialized
INFO - 2018-04-15 02:54:04 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:54:04 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:54:04 --> Utf8 Class Initialized
INFO - 2018-04-15 02:54:04 --> URI Class Initialized
INFO - 2018-04-15 02:54:04 --> Router Class Initialized
INFO - 2018-04-15 02:54:04 --> Output Class Initialized
INFO - 2018-04-15 02:54:04 --> Security Class Initialized
DEBUG - 2018-04-15 02:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:54:04 --> Input Class Initialized
INFO - 2018-04-15 02:54:04 --> Language Class Initialized
INFO - 2018-04-15 02:54:04 --> Loader Class Initialized
INFO - 2018-04-15 02:54:04 --> Helper loaded: url_helper
INFO - 2018-04-15 02:54:04 --> Helper loaded: file_helper
INFO - 2018-04-15 02:54:04 --> Helper loaded: date_helper
INFO - 2018-04-15 02:54:04 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:54:04 --> Controller Class Initialized
INFO - 2018-04-15 02:54:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:54:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:54:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:54:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:54:05 --> Final output sent to browser
DEBUG - 2018-04-15 02:54:05 --> Total execution time: 0.3656
INFO - 2018-04-15 02:54:06 --> Config Class Initialized
INFO - 2018-04-15 02:54:06 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:54:06 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:54:06 --> Utf8 Class Initialized
INFO - 2018-04-15 02:54:06 --> URI Class Initialized
INFO - 2018-04-15 02:54:06 --> Router Class Initialized
INFO - 2018-04-15 02:54:06 --> Output Class Initialized
INFO - 2018-04-15 02:54:06 --> Security Class Initialized
DEBUG - 2018-04-15 02:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:54:06 --> Input Class Initialized
INFO - 2018-04-15 02:54:06 --> Language Class Initialized
ERROR - 2018-04-15 02:54:06 --> 404 Page Not Found: Register/register
INFO - 2018-04-15 02:54:38 --> Config Class Initialized
INFO - 2018-04-15 02:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:54:38 --> Utf8 Class Initialized
INFO - 2018-04-15 02:54:38 --> URI Class Initialized
INFO - 2018-04-15 02:54:38 --> Router Class Initialized
INFO - 2018-04-15 02:54:38 --> Output Class Initialized
INFO - 2018-04-15 02:54:38 --> Security Class Initialized
DEBUG - 2018-04-15 02:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:54:38 --> Input Class Initialized
INFO - 2018-04-15 02:54:38 --> Language Class Initialized
ERROR - 2018-04-15 02:54:38 --> 404 Page Not Found: Register/register
INFO - 2018-04-15 02:54:40 --> Config Class Initialized
INFO - 2018-04-15 02:54:40 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:54:40 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:54:40 --> Utf8 Class Initialized
INFO - 2018-04-15 02:54:40 --> URI Class Initialized
INFO - 2018-04-15 02:54:40 --> Router Class Initialized
INFO - 2018-04-15 02:54:40 --> Output Class Initialized
INFO - 2018-04-15 02:54:40 --> Security Class Initialized
DEBUG - 2018-04-15 02:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:54:40 --> Input Class Initialized
INFO - 2018-04-15 02:54:40 --> Language Class Initialized
INFO - 2018-04-15 02:54:40 --> Loader Class Initialized
INFO - 2018-04-15 02:54:40 --> Helper loaded: url_helper
INFO - 2018-04-15 02:54:40 --> Helper loaded: file_helper
INFO - 2018-04-15 02:54:40 --> Helper loaded: date_helper
INFO - 2018-04-15 02:54:40 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:54:40 --> Controller Class Initialized
INFO - 2018-04-15 02:54:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:54:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:54:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:54:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:54:40 --> Final output sent to browser
DEBUG - 2018-04-15 02:54:40 --> Total execution time: 0.4018
INFO - 2018-04-15 02:54:41 --> Config Class Initialized
INFO - 2018-04-15 02:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:54:41 --> Utf8 Class Initialized
INFO - 2018-04-15 02:54:41 --> URI Class Initialized
INFO - 2018-04-15 02:54:41 --> Router Class Initialized
INFO - 2018-04-15 02:54:41 --> Output Class Initialized
INFO - 2018-04-15 02:54:41 --> Security Class Initialized
DEBUG - 2018-04-15 02:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:54:41 --> Input Class Initialized
INFO - 2018-04-15 02:54:41 --> Language Class Initialized
INFO - 2018-04-15 02:54:41 --> Loader Class Initialized
INFO - 2018-04-15 02:54:41 --> Helper loaded: url_helper
INFO - 2018-04-15 02:54:41 --> Helper loaded: file_helper
INFO - 2018-04-15 02:54:42 --> Helper loaded: date_helper
INFO - 2018-04-15 02:54:42 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:54:42 --> Controller Class Initialized
INFO - 2018-04-15 02:54:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:54:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:54:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:54:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:54:42 --> Final output sent to browser
DEBUG - 2018-04-15 02:54:42 --> Total execution time: 0.4273
INFO - 2018-04-15 02:54:43 --> Config Class Initialized
INFO - 2018-04-15 02:54:43 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:54:43 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:54:43 --> Utf8 Class Initialized
INFO - 2018-04-15 02:54:44 --> URI Class Initialized
INFO - 2018-04-15 02:54:44 --> Router Class Initialized
INFO - 2018-04-15 02:54:44 --> Output Class Initialized
INFO - 2018-04-15 02:54:44 --> Security Class Initialized
DEBUG - 2018-04-15 02:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:54:44 --> Input Class Initialized
INFO - 2018-04-15 02:54:44 --> Language Class Initialized
INFO - 2018-04-15 02:54:44 --> Loader Class Initialized
INFO - 2018-04-15 02:54:44 --> Helper loaded: url_helper
INFO - 2018-04-15 02:54:44 --> Helper loaded: file_helper
INFO - 2018-04-15 02:54:44 --> Helper loaded: date_helper
INFO - 2018-04-15 02:54:44 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:54:44 --> Controller Class Initialized
INFO - 2018-04-15 02:54:44 --> Final output sent to browser
DEBUG - 2018-04-15 02:54:44 --> Total execution time: 0.3303
INFO - 2018-04-15 02:55:03 --> Config Class Initialized
INFO - 2018-04-15 02:55:03 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:55:03 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:55:03 --> Utf8 Class Initialized
INFO - 2018-04-15 02:55:03 --> URI Class Initialized
INFO - 2018-04-15 02:55:03 --> Router Class Initialized
INFO - 2018-04-15 02:55:03 --> Output Class Initialized
INFO - 2018-04-15 02:55:03 --> Security Class Initialized
DEBUG - 2018-04-15 02:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:55:03 --> Input Class Initialized
INFO - 2018-04-15 02:55:03 --> Language Class Initialized
INFO - 2018-04-15 02:55:03 --> Loader Class Initialized
INFO - 2018-04-15 02:55:03 --> Helper loaded: url_helper
INFO - 2018-04-15 02:55:03 --> Helper loaded: file_helper
INFO - 2018-04-15 02:55:03 --> Helper loaded: date_helper
INFO - 2018-04-15 02:55:03 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:55:03 --> Controller Class Initialized
INFO - 2018-04-15 02:55:03 --> Final output sent to browser
DEBUG - 2018-04-15 02:55:03 --> Total execution time: 0.3009
INFO - 2018-04-15 02:55:04 --> Config Class Initialized
INFO - 2018-04-15 02:55:04 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:55:04 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:55:04 --> Utf8 Class Initialized
INFO - 2018-04-15 02:55:04 --> URI Class Initialized
INFO - 2018-04-15 02:55:04 --> Router Class Initialized
INFO - 2018-04-15 02:55:04 --> Output Class Initialized
INFO - 2018-04-15 02:55:04 --> Security Class Initialized
DEBUG - 2018-04-15 02:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:55:04 --> Input Class Initialized
INFO - 2018-04-15 02:55:04 --> Language Class Initialized
INFO - 2018-04-15 02:55:04 --> Loader Class Initialized
INFO - 2018-04-15 02:55:04 --> Helper loaded: url_helper
INFO - 2018-04-15 02:55:05 --> Helper loaded: file_helper
INFO - 2018-04-15 02:55:05 --> Helper loaded: date_helper
INFO - 2018-04-15 02:55:05 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:55:05 --> Controller Class Initialized
INFO - 2018-04-15 02:55:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:55:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:55:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:55:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:55:05 --> Final output sent to browser
DEBUG - 2018-04-15 02:55:05 --> Total execution time: 0.3976
INFO - 2018-04-15 02:55:06 --> Config Class Initialized
INFO - 2018-04-15 02:55:06 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:55:06 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:55:06 --> Utf8 Class Initialized
INFO - 2018-04-15 02:55:06 --> URI Class Initialized
INFO - 2018-04-15 02:55:06 --> Router Class Initialized
INFO - 2018-04-15 02:55:06 --> Output Class Initialized
INFO - 2018-04-15 02:55:06 --> Security Class Initialized
DEBUG - 2018-04-15 02:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:55:06 --> Input Class Initialized
INFO - 2018-04-15 02:55:06 --> Language Class Initialized
INFO - 2018-04-15 02:55:06 --> Loader Class Initialized
INFO - 2018-04-15 02:55:06 --> Helper loaded: url_helper
INFO - 2018-04-15 02:55:06 --> Helper loaded: file_helper
INFO - 2018-04-15 02:55:07 --> Helper loaded: date_helper
INFO - 2018-04-15 02:55:07 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:55:07 --> Controller Class Initialized
INFO - 2018-04-15 02:55:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:55:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:55:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:55:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:55:07 --> Final output sent to browser
DEBUG - 2018-04-15 02:55:07 --> Total execution time: 0.3904
INFO - 2018-04-15 02:55:08 --> Config Class Initialized
INFO - 2018-04-15 02:55:08 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:55:08 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:55:08 --> Utf8 Class Initialized
INFO - 2018-04-15 02:55:08 --> URI Class Initialized
INFO - 2018-04-15 02:55:08 --> Router Class Initialized
INFO - 2018-04-15 02:55:08 --> Output Class Initialized
INFO - 2018-04-15 02:55:08 --> Security Class Initialized
DEBUG - 2018-04-15 02:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:55:09 --> Input Class Initialized
INFO - 2018-04-15 02:55:09 --> Language Class Initialized
INFO - 2018-04-15 02:55:09 --> Loader Class Initialized
INFO - 2018-04-15 02:55:09 --> Helper loaded: url_helper
INFO - 2018-04-15 02:55:09 --> Helper loaded: file_helper
INFO - 2018-04-15 02:55:09 --> Helper loaded: date_helper
INFO - 2018-04-15 02:55:09 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:55:09 --> Controller Class Initialized
INFO - 2018-04-15 02:55:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 02:55:09 --> Final output sent to browser
DEBUG - 2018-04-15 02:55:09 --> Total execution time: 0.3400
INFO - 2018-04-15 02:55:44 --> Config Class Initialized
INFO - 2018-04-15 02:55:44 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:55:44 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:55:44 --> Utf8 Class Initialized
INFO - 2018-04-15 02:55:44 --> URI Class Initialized
INFO - 2018-04-15 02:55:44 --> Router Class Initialized
INFO - 2018-04-15 02:55:44 --> Output Class Initialized
INFO - 2018-04-15 02:55:45 --> Security Class Initialized
DEBUG - 2018-04-15 02:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:55:45 --> Input Class Initialized
INFO - 2018-04-15 02:55:45 --> Language Class Initialized
INFO - 2018-04-15 02:55:45 --> Loader Class Initialized
INFO - 2018-04-15 02:55:45 --> Helper loaded: url_helper
INFO - 2018-04-15 02:55:45 --> Helper loaded: file_helper
INFO - 2018-04-15 02:55:45 --> Helper loaded: date_helper
INFO - 2018-04-15 02:55:45 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:55:45 --> Controller Class Initialized
INFO - 2018-04-15 02:55:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:55:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:55:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:55:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:55:45 --> Final output sent to browser
DEBUG - 2018-04-15 02:55:45 --> Total execution time: 0.3757
INFO - 2018-04-15 02:55:47 --> Config Class Initialized
INFO - 2018-04-15 02:55:47 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:55:47 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:55:47 --> Utf8 Class Initialized
INFO - 2018-04-15 02:55:47 --> URI Class Initialized
INFO - 2018-04-15 02:55:47 --> Router Class Initialized
INFO - 2018-04-15 02:55:47 --> Output Class Initialized
INFO - 2018-04-15 02:55:47 --> Security Class Initialized
DEBUG - 2018-04-15 02:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:55:47 --> Input Class Initialized
INFO - 2018-04-15 02:55:47 --> Language Class Initialized
INFO - 2018-04-15 02:55:47 --> Loader Class Initialized
INFO - 2018-04-15 02:55:47 --> Helper loaded: url_helper
INFO - 2018-04-15 02:55:47 --> Helper loaded: file_helper
INFO - 2018-04-15 02:55:47 --> Helper loaded: date_helper
INFO - 2018-04-15 02:55:47 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:55:48 --> Controller Class Initialized
INFO - 2018-04-15 02:55:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:55:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:55:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:55:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:55:48 --> Final output sent to browser
DEBUG - 2018-04-15 02:55:48 --> Total execution time: 0.3621
INFO - 2018-04-15 02:56:04 --> Config Class Initialized
INFO - 2018-04-15 02:56:04 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:56:04 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:56:04 --> Utf8 Class Initialized
INFO - 2018-04-15 02:56:04 --> URI Class Initialized
INFO - 2018-04-15 02:56:04 --> Router Class Initialized
INFO - 2018-04-15 02:56:04 --> Output Class Initialized
INFO - 2018-04-15 02:56:04 --> Security Class Initialized
DEBUG - 2018-04-15 02:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:56:04 --> Input Class Initialized
INFO - 2018-04-15 02:56:04 --> Language Class Initialized
INFO - 2018-04-15 02:56:04 --> Loader Class Initialized
INFO - 2018-04-15 02:56:04 --> Helper loaded: url_helper
INFO - 2018-04-15 02:56:04 --> Helper loaded: file_helper
INFO - 2018-04-15 02:56:05 --> Helper loaded: date_helper
INFO - 2018-04-15 02:56:05 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:56:05 --> Controller Class Initialized
INFO - 2018-04-15 02:56:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:56:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:56:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:56:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:56:05 --> Final output sent to browser
DEBUG - 2018-04-15 02:56:05 --> Total execution time: 0.3669
INFO - 2018-04-15 02:56:32 --> Config Class Initialized
INFO - 2018-04-15 02:56:32 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:56:32 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:56:32 --> Utf8 Class Initialized
INFO - 2018-04-15 02:56:32 --> URI Class Initialized
INFO - 2018-04-15 02:56:32 --> Router Class Initialized
INFO - 2018-04-15 02:56:32 --> Output Class Initialized
INFO - 2018-04-15 02:56:32 --> Security Class Initialized
DEBUG - 2018-04-15 02:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:56:32 --> Input Class Initialized
INFO - 2018-04-15 02:56:32 --> Language Class Initialized
INFO - 2018-04-15 02:56:32 --> Loader Class Initialized
INFO - 2018-04-15 02:56:32 --> Helper loaded: url_helper
INFO - 2018-04-15 02:56:32 --> Helper loaded: file_helper
INFO - 2018-04-15 02:56:32 --> Helper loaded: date_helper
INFO - 2018-04-15 02:56:32 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:56:32 --> Controller Class Initialized
INFO - 2018-04-15 02:56:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:56:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:56:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:56:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:56:32 --> Final output sent to browser
DEBUG - 2018-04-15 02:56:32 --> Total execution time: 0.3667
INFO - 2018-04-15 02:56:39 --> Config Class Initialized
INFO - 2018-04-15 02:56:39 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:56:39 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:56:39 --> Utf8 Class Initialized
INFO - 2018-04-15 02:56:39 --> URI Class Initialized
INFO - 2018-04-15 02:56:39 --> Router Class Initialized
INFO - 2018-04-15 02:56:39 --> Output Class Initialized
INFO - 2018-04-15 02:56:39 --> Security Class Initialized
DEBUG - 2018-04-15 02:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:56:39 --> Input Class Initialized
INFO - 2018-04-15 02:56:39 --> Language Class Initialized
INFO - 2018-04-15 02:56:39 --> Loader Class Initialized
INFO - 2018-04-15 02:56:39 --> Helper loaded: url_helper
INFO - 2018-04-15 02:56:39 --> Helper loaded: file_helper
INFO - 2018-04-15 02:56:39 --> Helper loaded: date_helper
INFO - 2018-04-15 02:56:39 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:56:40 --> Controller Class Initialized
INFO - 2018-04-15 02:56:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:56:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:56:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:56:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:56:40 --> Final output sent to browser
DEBUG - 2018-04-15 02:56:40 --> Total execution time: 0.3509
INFO - 2018-04-15 02:56:41 --> Config Class Initialized
INFO - 2018-04-15 02:56:41 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:56:41 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:56:41 --> Utf8 Class Initialized
INFO - 2018-04-15 02:56:41 --> URI Class Initialized
INFO - 2018-04-15 02:56:41 --> Router Class Initialized
INFO - 2018-04-15 02:56:41 --> Output Class Initialized
INFO - 2018-04-15 02:56:41 --> Security Class Initialized
DEBUG - 2018-04-15 02:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:56:41 --> Input Class Initialized
INFO - 2018-04-15 02:56:41 --> Language Class Initialized
INFO - 2018-04-15 02:56:41 --> Loader Class Initialized
INFO - 2018-04-15 02:56:41 --> Helper loaded: url_helper
INFO - 2018-04-15 02:56:41 --> Helper loaded: file_helper
INFO - 2018-04-15 02:56:41 --> Helper loaded: date_helper
INFO - 2018-04-15 02:56:41 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:56:41 --> Controller Class Initialized
INFO - 2018-04-15 02:56:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:56:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:56:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:56:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:56:41 --> Final output sent to browser
DEBUG - 2018-04-15 02:56:41 --> Total execution time: 0.4093
INFO - 2018-04-15 02:56:43 --> Config Class Initialized
INFO - 2018-04-15 02:56:43 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:56:43 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:56:43 --> Utf8 Class Initialized
INFO - 2018-04-15 02:56:43 --> URI Class Initialized
INFO - 2018-04-15 02:56:43 --> Router Class Initialized
INFO - 2018-04-15 02:56:43 --> Output Class Initialized
INFO - 2018-04-15 02:56:43 --> Security Class Initialized
DEBUG - 2018-04-15 02:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:56:43 --> Input Class Initialized
INFO - 2018-04-15 02:56:43 --> Language Class Initialized
INFO - 2018-04-15 02:56:43 --> Loader Class Initialized
INFO - 2018-04-15 02:56:43 --> Helper loaded: url_helper
INFO - 2018-04-15 02:56:43 --> Helper loaded: file_helper
INFO - 2018-04-15 02:56:43 --> Helper loaded: date_helper
INFO - 2018-04-15 02:56:43 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:56:43 --> Controller Class Initialized
INFO - 2018-04-15 02:56:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:56:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 02:56:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:56:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:56:43 --> Final output sent to browser
DEBUG - 2018-04-15 02:56:43 --> Total execution time: 0.4058
INFO - 2018-04-15 02:56:44 --> Config Class Initialized
INFO - 2018-04-15 02:56:44 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:56:44 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:56:44 --> Utf8 Class Initialized
INFO - 2018-04-15 02:56:44 --> URI Class Initialized
INFO - 2018-04-15 02:56:44 --> Router Class Initialized
INFO - 2018-04-15 02:56:44 --> Output Class Initialized
INFO - 2018-04-15 02:56:44 --> Security Class Initialized
DEBUG - 2018-04-15 02:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:56:44 --> Input Class Initialized
INFO - 2018-04-15 02:56:44 --> Language Class Initialized
INFO - 2018-04-15 02:56:44 --> Loader Class Initialized
INFO - 2018-04-15 02:56:44 --> Helper loaded: url_helper
INFO - 2018-04-15 02:56:44 --> Helper loaded: file_helper
INFO - 2018-04-15 02:56:44 --> Helper loaded: date_helper
INFO - 2018-04-15 02:56:44 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:56:45 --> Controller Class Initialized
INFO - 2018-04-15 02:56:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:56:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:56:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:56:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:56:45 --> Final output sent to browser
DEBUG - 2018-04-15 02:56:45 --> Total execution time: 0.4026
INFO - 2018-04-15 02:56:46 --> Config Class Initialized
INFO - 2018-04-15 02:56:46 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:56:46 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:56:46 --> Utf8 Class Initialized
INFO - 2018-04-15 02:56:46 --> URI Class Initialized
INFO - 2018-04-15 02:56:46 --> Router Class Initialized
INFO - 2018-04-15 02:56:46 --> Output Class Initialized
INFO - 2018-04-15 02:56:46 --> Security Class Initialized
DEBUG - 2018-04-15 02:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:56:46 --> Input Class Initialized
INFO - 2018-04-15 02:56:46 --> Language Class Initialized
INFO - 2018-04-15 02:56:46 --> Loader Class Initialized
INFO - 2018-04-15 02:56:46 --> Helper loaded: url_helper
INFO - 2018-04-15 02:56:46 --> Helper loaded: file_helper
INFO - 2018-04-15 02:56:46 --> Helper loaded: date_helper
INFO - 2018-04-15 02:56:46 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:56:46 --> Controller Class Initialized
INFO - 2018-04-15 02:56:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 02:56:46 --> Final output sent to browser
DEBUG - 2018-04-15 02:56:46 --> Total execution time: 0.3608
INFO - 2018-04-15 02:57:01 --> Config Class Initialized
INFO - 2018-04-15 02:57:01 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:57:01 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:57:01 --> Utf8 Class Initialized
INFO - 2018-04-15 02:57:01 --> URI Class Initialized
INFO - 2018-04-15 02:57:01 --> Router Class Initialized
INFO - 2018-04-15 02:57:01 --> Output Class Initialized
INFO - 2018-04-15 02:57:01 --> Security Class Initialized
DEBUG - 2018-04-15 02:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:57:01 --> Input Class Initialized
INFO - 2018-04-15 02:57:01 --> Language Class Initialized
INFO - 2018-04-15 02:57:01 --> Loader Class Initialized
INFO - 2018-04-15 02:57:01 --> Helper loaded: url_helper
INFO - 2018-04-15 02:57:01 --> Helper loaded: file_helper
INFO - 2018-04-15 02:57:01 --> Helper loaded: date_helper
INFO - 2018-04-15 02:57:01 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:57:01 --> Controller Class Initialized
INFO - 2018-04-15 02:57:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:57:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:57:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:57:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:57:02 --> Final output sent to browser
DEBUG - 2018-04-15 02:57:02 --> Total execution time: 0.3701
INFO - 2018-04-15 02:57:04 --> Config Class Initialized
INFO - 2018-04-15 02:57:04 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:57:04 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:57:04 --> Utf8 Class Initialized
INFO - 2018-04-15 02:57:04 --> URI Class Initialized
INFO - 2018-04-15 02:57:04 --> Router Class Initialized
INFO - 2018-04-15 02:57:04 --> Output Class Initialized
INFO - 2018-04-15 02:57:04 --> Security Class Initialized
DEBUG - 2018-04-15 02:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:57:04 --> Input Class Initialized
INFO - 2018-04-15 02:57:04 --> Language Class Initialized
INFO - 2018-04-15 02:57:04 --> Loader Class Initialized
INFO - 2018-04-15 02:57:04 --> Helper loaded: url_helper
INFO - 2018-04-15 02:57:04 --> Helper loaded: file_helper
INFO - 2018-04-15 02:57:04 --> Helper loaded: date_helper
INFO - 2018-04-15 02:57:04 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:57:04 --> Controller Class Initialized
INFO - 2018-04-15 02:57:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 02:57:04 --> Final output sent to browser
DEBUG - 2018-04-15 02:57:04 --> Total execution time: 0.3269
INFO - 2018-04-15 02:57:07 --> Config Class Initialized
INFO - 2018-04-15 02:57:07 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:57:07 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:57:08 --> Utf8 Class Initialized
INFO - 2018-04-15 02:57:08 --> URI Class Initialized
INFO - 2018-04-15 02:57:08 --> Router Class Initialized
INFO - 2018-04-15 02:57:08 --> Output Class Initialized
INFO - 2018-04-15 02:57:08 --> Security Class Initialized
DEBUG - 2018-04-15 02:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:57:08 --> Input Class Initialized
INFO - 2018-04-15 02:57:08 --> Language Class Initialized
INFO - 2018-04-15 02:57:08 --> Loader Class Initialized
INFO - 2018-04-15 02:57:08 --> Helper loaded: url_helper
INFO - 2018-04-15 02:57:08 --> Helper loaded: file_helper
INFO - 2018-04-15 02:57:08 --> Helper loaded: date_helper
INFO - 2018-04-15 02:57:08 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:57:08 --> Controller Class Initialized
INFO - 2018-04-15 02:57:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:57:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:57:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:57:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:57:08 --> Final output sent to browser
DEBUG - 2018-04-15 02:57:08 --> Total execution time: 0.3775
INFO - 2018-04-15 02:57:49 --> Config Class Initialized
INFO - 2018-04-15 02:57:49 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:57:49 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:57:49 --> Utf8 Class Initialized
INFO - 2018-04-15 02:57:49 --> URI Class Initialized
INFO - 2018-04-15 02:57:49 --> Router Class Initialized
INFO - 2018-04-15 02:57:49 --> Output Class Initialized
INFO - 2018-04-15 02:57:49 --> Security Class Initialized
DEBUG - 2018-04-15 02:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:57:49 --> Input Class Initialized
INFO - 2018-04-15 02:57:49 --> Language Class Initialized
INFO - 2018-04-15 02:57:49 --> Loader Class Initialized
INFO - 2018-04-15 02:57:49 --> Helper loaded: url_helper
INFO - 2018-04-15 02:57:49 --> Helper loaded: file_helper
INFO - 2018-04-15 02:57:49 --> Helper loaded: date_helper
INFO - 2018-04-15 02:57:49 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:57:49 --> Controller Class Initialized
INFO - 2018-04-15 02:57:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 02:57:49 --> Final output sent to browser
DEBUG - 2018-04-15 02:57:49 --> Total execution time: 0.3187
INFO - 2018-04-15 02:58:00 --> Config Class Initialized
INFO - 2018-04-15 02:58:00 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:58:00 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:58:00 --> Utf8 Class Initialized
INFO - 2018-04-15 02:58:00 --> URI Class Initialized
INFO - 2018-04-15 02:58:00 --> Router Class Initialized
INFO - 2018-04-15 02:58:00 --> Output Class Initialized
INFO - 2018-04-15 02:58:00 --> Security Class Initialized
DEBUG - 2018-04-15 02:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:58:00 --> Input Class Initialized
INFO - 2018-04-15 02:58:00 --> Language Class Initialized
INFO - 2018-04-15 02:58:00 --> Loader Class Initialized
INFO - 2018-04-15 02:58:00 --> Helper loaded: url_helper
INFO - 2018-04-15 02:58:00 --> Helper loaded: file_helper
INFO - 2018-04-15 02:58:00 --> Helper loaded: date_helper
INFO - 2018-04-15 02:58:00 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:58:00 --> Controller Class Initialized
INFO - 2018-04-15 02:58:00 --> Model Class Initialized
INFO - 2018-04-15 02:58:00 --> Final output sent to browser
DEBUG - 2018-04-15 02:58:00 --> Total execution time: 0.3156
INFO - 2018-04-15 02:58:00 --> Config Class Initialized
INFO - 2018-04-15 02:58:00 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:58:00 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:58:00 --> Utf8 Class Initialized
INFO - 2018-04-15 02:58:00 --> URI Class Initialized
INFO - 2018-04-15 02:58:00 --> Router Class Initialized
INFO - 2018-04-15 02:58:00 --> Output Class Initialized
INFO - 2018-04-15 02:58:00 --> Security Class Initialized
DEBUG - 2018-04-15 02:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:58:00 --> Input Class Initialized
INFO - 2018-04-15 02:58:00 --> Language Class Initialized
INFO - 2018-04-15 02:58:00 --> Loader Class Initialized
INFO - 2018-04-15 02:58:00 --> Helper loaded: url_helper
INFO - 2018-04-15 02:58:00 --> Helper loaded: file_helper
INFO - 2018-04-15 02:58:00 --> Helper loaded: date_helper
INFO - 2018-04-15 02:58:00 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:58:00 --> Controller Class Initialized
INFO - 2018-04-15 02:58:00 --> Model Class Initialized
INFO - 2018-04-15 02:58:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:58:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 02:58:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:58:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:58:00 --> Final output sent to browser
DEBUG - 2018-04-15 02:58:00 --> Total execution time: 0.3676
INFO - 2018-04-15 02:58:36 --> Config Class Initialized
INFO - 2018-04-15 02:58:36 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:58:36 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:58:36 --> Utf8 Class Initialized
INFO - 2018-04-15 02:58:36 --> URI Class Initialized
INFO - 2018-04-15 02:58:36 --> Router Class Initialized
INFO - 2018-04-15 02:58:36 --> Output Class Initialized
INFO - 2018-04-15 02:58:36 --> Security Class Initialized
DEBUG - 2018-04-15 02:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:58:36 --> Input Class Initialized
INFO - 2018-04-15 02:58:36 --> Language Class Initialized
INFO - 2018-04-15 02:58:36 --> Loader Class Initialized
INFO - 2018-04-15 02:58:36 --> Helper loaded: url_helper
INFO - 2018-04-15 02:58:36 --> Helper loaded: file_helper
INFO - 2018-04-15 02:58:36 --> Helper loaded: date_helper
INFO - 2018-04-15 02:58:36 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:58:36 --> Controller Class Initialized
DEBUG - 2018-04-15 02:58:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-15 02:58:36 --> Config Class Initialized
INFO - 2018-04-15 02:58:36 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:58:36 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:58:36 --> Utf8 Class Initialized
INFO - 2018-04-15 02:58:36 --> URI Class Initialized
DEBUG - 2018-04-15 02:58:36 --> No URI present. Default controller set.
INFO - 2018-04-15 02:58:36 --> Router Class Initialized
INFO - 2018-04-15 02:58:36 --> Output Class Initialized
INFO - 2018-04-15 02:58:36 --> Security Class Initialized
DEBUG - 2018-04-15 02:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:58:36 --> Input Class Initialized
INFO - 2018-04-15 02:58:36 --> Language Class Initialized
INFO - 2018-04-15 02:58:36 --> Loader Class Initialized
INFO - 2018-04-15 02:58:36 --> Helper loaded: url_helper
INFO - 2018-04-15 02:58:36 --> Helper loaded: file_helper
INFO - 2018-04-15 02:58:36 --> Helper loaded: date_helper
INFO - 2018-04-15 02:58:36 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:58:36 --> Controller Class Initialized
INFO - 2018-04-15 02:58:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:58:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:58:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:58:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:58:36 --> Final output sent to browser
DEBUG - 2018-04-15 02:58:36 --> Total execution time: 0.3759
INFO - 2018-04-15 02:58:43 --> Config Class Initialized
INFO - 2018-04-15 02:58:43 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:58:43 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:58:43 --> Utf8 Class Initialized
INFO - 2018-04-15 02:58:43 --> URI Class Initialized
INFO - 2018-04-15 02:58:43 --> Router Class Initialized
INFO - 2018-04-15 02:58:43 --> Output Class Initialized
INFO - 2018-04-15 02:58:43 --> Security Class Initialized
DEBUG - 2018-04-15 02:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:58:43 --> Input Class Initialized
INFO - 2018-04-15 02:58:43 --> Language Class Initialized
INFO - 2018-04-15 02:58:43 --> Loader Class Initialized
INFO - 2018-04-15 02:58:43 --> Helper loaded: url_helper
INFO - 2018-04-15 02:58:43 --> Helper loaded: file_helper
INFO - 2018-04-15 02:58:43 --> Helper loaded: date_helper
INFO - 2018-04-15 02:58:43 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:58:43 --> Controller Class Initialized
INFO - 2018-04-15 02:58:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:58:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 02:58:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:58:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:58:43 --> Final output sent to browser
DEBUG - 2018-04-15 02:58:43 --> Total execution time: 0.3774
INFO - 2018-04-15 02:58:44 --> Config Class Initialized
INFO - 2018-04-15 02:58:44 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:58:44 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:58:44 --> Utf8 Class Initialized
INFO - 2018-04-15 02:58:44 --> URI Class Initialized
INFO - 2018-04-15 02:58:44 --> Router Class Initialized
INFO - 2018-04-15 02:58:44 --> Output Class Initialized
INFO - 2018-04-15 02:58:44 --> Security Class Initialized
DEBUG - 2018-04-15 02:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:58:44 --> Input Class Initialized
INFO - 2018-04-15 02:58:44 --> Language Class Initialized
INFO - 2018-04-15 02:58:44 --> Loader Class Initialized
INFO - 2018-04-15 02:58:44 --> Helper loaded: url_helper
INFO - 2018-04-15 02:58:44 --> Helper loaded: file_helper
INFO - 2018-04-15 02:58:44 --> Helper loaded: date_helper
INFO - 2018-04-15 02:58:44 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:58:44 --> Controller Class Initialized
INFO - 2018-04-15 02:58:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:58:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 02:58:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:58:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:58:44 --> Final output sent to browser
DEBUG - 2018-04-15 02:58:44 --> Total execution time: 0.3712
INFO - 2018-04-15 02:58:45 --> Config Class Initialized
INFO - 2018-04-15 02:58:45 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:58:45 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:58:45 --> Utf8 Class Initialized
INFO - 2018-04-15 02:58:45 --> URI Class Initialized
INFO - 2018-04-15 02:58:45 --> Router Class Initialized
INFO - 2018-04-15 02:58:45 --> Output Class Initialized
INFO - 2018-04-15 02:58:45 --> Security Class Initialized
DEBUG - 2018-04-15 02:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:58:45 --> Input Class Initialized
INFO - 2018-04-15 02:58:45 --> Language Class Initialized
INFO - 2018-04-15 02:58:45 --> Loader Class Initialized
INFO - 2018-04-15 02:58:45 --> Helper loaded: url_helper
INFO - 2018-04-15 02:58:45 --> Helper loaded: file_helper
INFO - 2018-04-15 02:58:45 --> Helper loaded: date_helper
INFO - 2018-04-15 02:58:45 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:58:45 --> Controller Class Initialized
INFO - 2018-04-15 02:58:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:58:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:58:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:58:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:58:45 --> Final output sent to browser
DEBUG - 2018-04-15 02:58:45 --> Total execution time: 0.3647
INFO - 2018-04-15 02:58:46 --> Config Class Initialized
INFO - 2018-04-15 02:58:46 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:58:46 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:58:46 --> Utf8 Class Initialized
INFO - 2018-04-15 02:58:46 --> URI Class Initialized
INFO - 2018-04-15 02:58:46 --> Router Class Initialized
INFO - 2018-04-15 02:58:46 --> Output Class Initialized
INFO - 2018-04-15 02:58:46 --> Security Class Initialized
DEBUG - 2018-04-15 02:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:58:46 --> Input Class Initialized
INFO - 2018-04-15 02:58:46 --> Language Class Initialized
INFO - 2018-04-15 02:58:46 --> Loader Class Initialized
INFO - 2018-04-15 02:58:46 --> Helper loaded: url_helper
INFO - 2018-04-15 02:58:46 --> Helper loaded: file_helper
INFO - 2018-04-15 02:58:46 --> Helper loaded: date_helper
INFO - 2018-04-15 02:58:47 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:58:47 --> Controller Class Initialized
INFO - 2018-04-15 02:58:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 02:58:47 --> Final output sent to browser
DEBUG - 2018-04-15 02:58:47 --> Total execution time: 0.3253
INFO - 2018-04-15 02:58:54 --> Config Class Initialized
INFO - 2018-04-15 02:58:54 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:58:54 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:58:54 --> Utf8 Class Initialized
INFO - 2018-04-15 02:58:54 --> URI Class Initialized
INFO - 2018-04-15 02:58:54 --> Router Class Initialized
INFO - 2018-04-15 02:58:54 --> Output Class Initialized
INFO - 2018-04-15 02:58:54 --> Security Class Initialized
DEBUG - 2018-04-15 02:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:58:54 --> Input Class Initialized
INFO - 2018-04-15 02:58:54 --> Language Class Initialized
INFO - 2018-04-15 02:58:54 --> Loader Class Initialized
INFO - 2018-04-15 02:58:54 --> Helper loaded: url_helper
INFO - 2018-04-15 02:58:54 --> Helper loaded: file_helper
INFO - 2018-04-15 02:58:54 --> Helper loaded: date_helper
INFO - 2018-04-15 02:58:54 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:58:54 --> Controller Class Initialized
INFO - 2018-04-15 02:58:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:58:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 02:58:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:58:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:58:54 --> Final output sent to browser
DEBUG - 2018-04-15 02:58:54 --> Total execution time: 0.3821
INFO - 2018-04-15 02:58:56 --> Config Class Initialized
INFO - 2018-04-15 02:58:56 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:58:56 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:58:56 --> Utf8 Class Initialized
INFO - 2018-04-15 02:58:56 --> URI Class Initialized
INFO - 2018-04-15 02:58:56 --> Router Class Initialized
INFO - 2018-04-15 02:58:56 --> Output Class Initialized
INFO - 2018-04-15 02:58:56 --> Security Class Initialized
DEBUG - 2018-04-15 02:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:58:56 --> Input Class Initialized
INFO - 2018-04-15 02:58:56 --> Language Class Initialized
INFO - 2018-04-15 02:58:56 --> Loader Class Initialized
INFO - 2018-04-15 02:58:56 --> Helper loaded: url_helper
INFO - 2018-04-15 02:58:56 --> Helper loaded: file_helper
INFO - 2018-04-15 02:58:56 --> Helper loaded: date_helper
INFO - 2018-04-15 02:58:56 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:58:56 --> Controller Class Initialized
INFO - 2018-04-15 02:58:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 02:58:56 --> Final output sent to browser
DEBUG - 2018-04-15 02:58:56 --> Total execution time: 0.3318
INFO - 2018-04-15 02:59:07 --> Config Class Initialized
INFO - 2018-04-15 02:59:07 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:59:07 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:59:07 --> Utf8 Class Initialized
INFO - 2018-04-15 02:59:07 --> URI Class Initialized
INFO - 2018-04-15 02:59:07 --> Router Class Initialized
INFO - 2018-04-15 02:59:07 --> Output Class Initialized
INFO - 2018-04-15 02:59:07 --> Security Class Initialized
DEBUG - 2018-04-15 02:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:59:07 --> Input Class Initialized
INFO - 2018-04-15 02:59:07 --> Language Class Initialized
INFO - 2018-04-15 02:59:08 --> Loader Class Initialized
INFO - 2018-04-15 02:59:08 --> Helper loaded: url_helper
INFO - 2018-04-15 02:59:08 --> Helper loaded: file_helper
INFO - 2018-04-15 02:59:08 --> Helper loaded: date_helper
INFO - 2018-04-15 02:59:08 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:59:08 --> Controller Class Initialized
INFO - 2018-04-15 02:59:08 --> Model Class Initialized
INFO - 2018-04-15 02:59:08 --> Final output sent to browser
DEBUG - 2018-04-15 02:59:08 --> Total execution time: 0.3378
INFO - 2018-04-15 02:59:08 --> Config Class Initialized
INFO - 2018-04-15 02:59:08 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:59:08 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:59:08 --> Utf8 Class Initialized
INFO - 2018-04-15 02:59:08 --> URI Class Initialized
INFO - 2018-04-15 02:59:08 --> Router Class Initialized
INFO - 2018-04-15 02:59:08 --> Output Class Initialized
INFO - 2018-04-15 02:59:08 --> Security Class Initialized
DEBUG - 2018-04-15 02:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:59:08 --> Input Class Initialized
INFO - 2018-04-15 02:59:08 --> Language Class Initialized
INFO - 2018-04-15 02:59:08 --> Loader Class Initialized
INFO - 2018-04-15 02:59:08 --> Helper loaded: url_helper
INFO - 2018-04-15 02:59:08 --> Helper loaded: file_helper
INFO - 2018-04-15 02:59:08 --> Helper loaded: date_helper
INFO - 2018-04-15 02:59:08 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:59:08 --> Controller Class Initialized
INFO - 2018-04-15 02:59:08 --> Model Class Initialized
INFO - 2018-04-15 02:59:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-15 02:59:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-15 02:59:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-15 02:59:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-15 02:59:08 --> Final output sent to browser
DEBUG - 2018-04-15 02:59:08 --> Total execution time: 0.4619
INFO - 2018-04-15 02:59:08 --> Config Class Initialized
INFO - 2018-04-15 02:59:08 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:59:08 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:59:08 --> Utf8 Class Initialized
INFO - 2018-04-15 02:59:08 --> URI Class Initialized
INFO - 2018-04-15 02:59:08 --> Router Class Initialized
INFO - 2018-04-15 02:59:08 --> Output Class Initialized
INFO - 2018-04-15 02:59:08 --> Security Class Initialized
DEBUG - 2018-04-15 02:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:59:08 --> Input Class Initialized
INFO - 2018-04-15 02:59:08 --> Language Class Initialized
ERROR - 2018-04-15 02:59:08 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-15 02:59:17 --> Config Class Initialized
INFO - 2018-04-15 02:59:17 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:59:17 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:59:17 --> Utf8 Class Initialized
INFO - 2018-04-15 02:59:17 --> URI Class Initialized
INFO - 2018-04-15 02:59:17 --> Router Class Initialized
INFO - 2018-04-15 02:59:17 --> Output Class Initialized
INFO - 2018-04-15 02:59:17 --> Security Class Initialized
DEBUG - 2018-04-15 02:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:59:17 --> Input Class Initialized
INFO - 2018-04-15 02:59:17 --> Language Class Initialized
INFO - 2018-04-15 02:59:17 --> Loader Class Initialized
INFO - 2018-04-15 02:59:17 --> Helper loaded: url_helper
INFO - 2018-04-15 02:59:17 --> Helper loaded: file_helper
INFO - 2018-04-15 02:59:17 --> Helper loaded: date_helper
INFO - 2018-04-15 02:59:17 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:59:17 --> Controller Class Initialized
DEBUG - 2018-04-15 02:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-15 02:59:17 --> Config Class Initialized
INFO - 2018-04-15 02:59:17 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:59:17 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:59:17 --> Utf8 Class Initialized
INFO - 2018-04-15 02:59:17 --> URI Class Initialized
DEBUG - 2018-04-15 02:59:17 --> No URI present. Default controller set.
INFO - 2018-04-15 02:59:17 --> Router Class Initialized
INFO - 2018-04-15 02:59:17 --> Output Class Initialized
INFO - 2018-04-15 02:59:17 --> Security Class Initialized
DEBUG - 2018-04-15 02:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:59:17 --> Input Class Initialized
INFO - 2018-04-15 02:59:17 --> Language Class Initialized
INFO - 2018-04-15 02:59:17 --> Loader Class Initialized
INFO - 2018-04-15 02:59:17 --> Helper loaded: url_helper
INFO - 2018-04-15 02:59:17 --> Helper loaded: file_helper
INFO - 2018-04-15 02:59:17 --> Helper loaded: date_helper
INFO - 2018-04-15 02:59:17 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:59:17 --> Controller Class Initialized
INFO - 2018-04-15 02:59:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 02:59:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 02:59:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 02:59:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 02:59:17 --> Final output sent to browser
DEBUG - 2018-04-15 02:59:17 --> Total execution time: 0.3855
INFO - 2018-04-15 02:59:53 --> Config Class Initialized
INFO - 2018-04-15 02:59:53 --> Hooks Class Initialized
DEBUG - 2018-04-15 02:59:53 --> UTF-8 Support Enabled
INFO - 2018-04-15 02:59:53 --> Utf8 Class Initialized
INFO - 2018-04-15 02:59:53 --> URI Class Initialized
INFO - 2018-04-15 02:59:53 --> Router Class Initialized
INFO - 2018-04-15 02:59:53 --> Output Class Initialized
INFO - 2018-04-15 02:59:53 --> Security Class Initialized
DEBUG - 2018-04-15 02:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 02:59:53 --> Input Class Initialized
INFO - 2018-04-15 02:59:54 --> Language Class Initialized
INFO - 2018-04-15 02:59:54 --> Loader Class Initialized
INFO - 2018-04-15 02:59:54 --> Helper loaded: url_helper
INFO - 2018-04-15 02:59:54 --> Helper loaded: file_helper
INFO - 2018-04-15 02:59:54 --> Helper loaded: date_helper
INFO - 2018-04-15 02:59:54 --> Database Driver Class Initialized
DEBUG - 2018-04-15 02:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 02:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 02:59:54 --> Controller Class Initialized
INFO - 2018-04-15 02:59:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 02:59:54 --> Final output sent to browser
DEBUG - 2018-04-15 02:59:54 --> Total execution time: 0.3480
INFO - 2018-04-15 03:00:12 --> Config Class Initialized
INFO - 2018-04-15 03:00:12 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:12 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:12 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:12 --> URI Class Initialized
INFO - 2018-04-15 03:00:12 --> Router Class Initialized
INFO - 2018-04-15 03:00:12 --> Output Class Initialized
INFO - 2018-04-15 03:00:12 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:12 --> Input Class Initialized
INFO - 2018-04-15 03:00:12 --> Language Class Initialized
INFO - 2018-04-15 03:00:12 --> Loader Class Initialized
INFO - 2018-04-15 03:00:12 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:12 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:12 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:12 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:12 --> Controller Class Initialized
INFO - 2018-04-15 03:00:12 --> Model Class Initialized
INFO - 2018-04-15 03:00:12 --> Final output sent to browser
DEBUG - 2018-04-15 03:00:12 --> Total execution time: 0.3352
INFO - 2018-04-15 03:00:12 --> Config Class Initialized
INFO - 2018-04-15 03:00:12 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:12 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:12 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:12 --> URI Class Initialized
INFO - 2018-04-15 03:00:12 --> Router Class Initialized
INFO - 2018-04-15 03:00:12 --> Output Class Initialized
INFO - 2018-04-15 03:00:12 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:12 --> Input Class Initialized
INFO - 2018-04-15 03:00:12 --> Language Class Initialized
INFO - 2018-04-15 03:00:12 --> Loader Class Initialized
INFO - 2018-04-15 03:00:12 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:12 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:12 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:12 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:12 --> Controller Class Initialized
INFO - 2018-04-15 03:00:12 --> Model Class Initialized
INFO - 2018-04-15 03:00:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:00:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 03:00:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:00:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:00:12 --> Final output sent to browser
DEBUG - 2018-04-15 03:00:12 --> Total execution time: 0.3866
INFO - 2018-04-15 03:00:20 --> Config Class Initialized
INFO - 2018-04-15 03:00:20 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:20 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:20 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:20 --> URI Class Initialized
INFO - 2018-04-15 03:00:20 --> Router Class Initialized
INFO - 2018-04-15 03:00:20 --> Output Class Initialized
INFO - 2018-04-15 03:00:20 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:20 --> Input Class Initialized
INFO - 2018-04-15 03:00:20 --> Language Class Initialized
INFO - 2018-04-15 03:00:20 --> Loader Class Initialized
INFO - 2018-04-15 03:00:20 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:20 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:20 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:20 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:20 --> Controller Class Initialized
INFO - 2018-04-15 03:00:20 --> Config Class Initialized
INFO - 2018-04-15 03:00:20 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:20 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:20 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:20 --> URI Class Initialized
INFO - 2018-04-15 03:00:20 --> Router Class Initialized
INFO - 2018-04-15 03:00:20 --> Output Class Initialized
INFO - 2018-04-15 03:00:20 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:20 --> Input Class Initialized
INFO - 2018-04-15 03:00:20 --> Language Class Initialized
INFO - 2018-04-15 03:00:20 --> Loader Class Initialized
INFO - 2018-04-15 03:00:20 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:20 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:20 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:20 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:20 --> Controller Class Initialized
INFO - 2018-04-15 03:00:20 --> Model Class Initialized
INFO - 2018-04-15 03:00:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:00:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 03:00:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:00:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:00:20 --> Final output sent to browser
DEBUG - 2018-04-15 03:00:20 --> Total execution time: 0.3995
INFO - 2018-04-15 03:00:26 --> Config Class Initialized
INFO - 2018-04-15 03:00:26 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:26 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:26 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:26 --> URI Class Initialized
INFO - 2018-04-15 03:00:26 --> Router Class Initialized
INFO - 2018-04-15 03:00:27 --> Output Class Initialized
INFO - 2018-04-15 03:00:27 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:27 --> Input Class Initialized
INFO - 2018-04-15 03:00:27 --> Language Class Initialized
INFO - 2018-04-15 03:00:27 --> Config Class Initialized
INFO - 2018-04-15 03:00:27 --> Hooks Class Initialized
INFO - 2018-04-15 03:00:27 --> Loader Class Initialized
INFO - 2018-04-15 03:00:27 --> Helper loaded: url_helper
DEBUG - 2018-04-15 03:00:27 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:27 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:27 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:27 --> URI Class Initialized
INFO - 2018-04-15 03:00:27 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:27 --> Router Class Initialized
INFO - 2018-04-15 03:00:27 --> Database Driver Class Initialized
INFO - 2018-04-15 03:00:27 --> Output Class Initialized
DEBUG - 2018-04-15 03:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:27 --> Security Class Initialized
INFO - 2018-04-15 03:00:27 --> Controller Class Initialized
DEBUG - 2018-04-15 03:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:27 --> Input Class Initialized
INFO - 2018-04-15 03:00:27 --> Model Class Initialized
INFO - 2018-04-15 03:00:27 --> Language Class Initialized
INFO - 2018-04-15 03:00:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:00:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 03:00:27 --> Loader Class Initialized
INFO - 2018-04-15 03:00:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:00:27 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:00:27 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:27 --> Final output sent to browser
INFO - 2018-04-15 03:00:27 --> Helper loaded: date_helper
DEBUG - 2018-04-15 03:00:27 --> Total execution time: 0.3925
INFO - 2018-04-15 03:00:27 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:27 --> Controller Class Initialized
INFO - 2018-04-15 03:00:27 --> Model Class Initialized
INFO - 2018-04-15 03:00:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:00:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 03:00:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:00:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:00:27 --> Final output sent to browser
DEBUG - 2018-04-15 03:00:27 --> Total execution time: 0.3842
INFO - 2018-04-15 03:00:29 --> Config Class Initialized
INFO - 2018-04-15 03:00:29 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:29 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:29 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:29 --> URI Class Initialized
INFO - 2018-04-15 03:00:29 --> Router Class Initialized
INFO - 2018-04-15 03:00:29 --> Output Class Initialized
INFO - 2018-04-15 03:00:29 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:29 --> Input Class Initialized
INFO - 2018-04-15 03:00:29 --> Language Class Initialized
INFO - 2018-04-15 03:00:29 --> Loader Class Initialized
INFO - 2018-04-15 03:00:29 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:29 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:29 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:29 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:30 --> Controller Class Initialized
INFO - 2018-04-15 03:00:30 --> Model Class Initialized
INFO - 2018-04-15 03:00:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:00:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 03:00:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:00:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:00:30 --> Final output sent to browser
DEBUG - 2018-04-15 03:00:30 --> Total execution time: 0.3962
INFO - 2018-04-15 03:00:32 --> Config Class Initialized
INFO - 2018-04-15 03:00:32 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:32 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:32 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:32 --> URI Class Initialized
INFO - 2018-04-15 03:00:32 --> Router Class Initialized
INFO - 2018-04-15 03:00:32 --> Output Class Initialized
INFO - 2018-04-15 03:00:32 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:32 --> Input Class Initialized
INFO - 2018-04-15 03:00:32 --> Language Class Initialized
INFO - 2018-04-15 03:00:32 --> Loader Class Initialized
INFO - 2018-04-15 03:00:32 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:32 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:32 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:32 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:32 --> Controller Class Initialized
INFO - 2018-04-15 03:00:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:00:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 03:00:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:00:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:00:32 --> Final output sent to browser
DEBUG - 2018-04-15 03:00:32 --> Total execution time: 0.3766
INFO - 2018-04-15 03:00:34 --> Config Class Initialized
INFO - 2018-04-15 03:00:34 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:34 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:34 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:34 --> URI Class Initialized
INFO - 2018-04-15 03:00:34 --> Router Class Initialized
INFO - 2018-04-15 03:00:34 --> Output Class Initialized
INFO - 2018-04-15 03:00:34 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:34 --> Input Class Initialized
INFO - 2018-04-15 03:00:34 --> Language Class Initialized
INFO - 2018-04-15 03:00:34 --> Loader Class Initialized
INFO - 2018-04-15 03:00:34 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:34 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:34 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:34 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:34 --> Controller Class Initialized
INFO - 2018-04-15 03:00:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:00:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 03:00:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:00:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:00:34 --> Final output sent to browser
DEBUG - 2018-04-15 03:00:34 --> Total execution time: 0.4026
INFO - 2018-04-15 03:00:36 --> Config Class Initialized
INFO - 2018-04-15 03:00:36 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:36 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:36 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:36 --> URI Class Initialized
INFO - 2018-04-15 03:00:36 --> Router Class Initialized
INFO - 2018-04-15 03:00:36 --> Output Class Initialized
INFO - 2018-04-15 03:00:36 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:36 --> Input Class Initialized
INFO - 2018-04-15 03:00:36 --> Language Class Initialized
INFO - 2018-04-15 03:00:36 --> Loader Class Initialized
INFO - 2018-04-15 03:00:36 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:36 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:36 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:36 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:36 --> Controller Class Initialized
INFO - 2018-04-15 03:00:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:00:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 03:00:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:00:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:00:36 --> Final output sent to browser
DEBUG - 2018-04-15 03:00:36 --> Total execution time: 0.4544
INFO - 2018-04-15 03:00:37 --> Config Class Initialized
INFO - 2018-04-15 03:00:38 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:38 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:38 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:38 --> URI Class Initialized
INFO - 2018-04-15 03:00:38 --> Router Class Initialized
INFO - 2018-04-15 03:00:38 --> Output Class Initialized
INFO - 2018-04-15 03:00:38 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:38 --> Input Class Initialized
INFO - 2018-04-15 03:00:38 --> Language Class Initialized
INFO - 2018-04-15 03:00:38 --> Loader Class Initialized
INFO - 2018-04-15 03:00:38 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:38 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:38 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:38 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:38 --> Controller Class Initialized
INFO - 2018-04-15 03:00:38 --> Config Class Initialized
INFO - 2018-04-15 03:00:38 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:38 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:38 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:38 --> URI Class Initialized
INFO - 2018-04-15 03:00:38 --> Router Class Initialized
INFO - 2018-04-15 03:00:38 --> Output Class Initialized
INFO - 2018-04-15 03:00:38 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:38 --> Input Class Initialized
INFO - 2018-04-15 03:00:38 --> Language Class Initialized
INFO - 2018-04-15 03:00:38 --> Loader Class Initialized
INFO - 2018-04-15 03:00:38 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:38 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:38 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:38 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:38 --> Controller Class Initialized
INFO - 2018-04-15 03:00:38 --> Model Class Initialized
INFO - 2018-04-15 03:00:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:00:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 03:00:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:00:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:00:38 --> Final output sent to browser
DEBUG - 2018-04-15 03:00:38 --> Total execution time: 0.4410
INFO - 2018-04-15 03:00:43 --> Config Class Initialized
INFO - 2018-04-15 03:00:43 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:00:43 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:00:43 --> Utf8 Class Initialized
INFO - 2018-04-15 03:00:43 --> URI Class Initialized
INFO - 2018-04-15 03:00:43 --> Router Class Initialized
INFO - 2018-04-15 03:00:43 --> Output Class Initialized
INFO - 2018-04-15 03:00:43 --> Security Class Initialized
DEBUG - 2018-04-15 03:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:00:43 --> Input Class Initialized
INFO - 2018-04-15 03:00:43 --> Language Class Initialized
INFO - 2018-04-15 03:00:43 --> Loader Class Initialized
INFO - 2018-04-15 03:00:43 --> Helper loaded: url_helper
INFO - 2018-04-15 03:00:43 --> Helper loaded: file_helper
INFO - 2018-04-15 03:00:43 --> Helper loaded: date_helper
INFO - 2018-04-15 03:00:43 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:00:43 --> Controller Class Initialized
INFO - 2018-04-15 03:00:43 --> Model Class Initialized
INFO - 2018-04-15 03:00:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:00:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 03:00:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:00:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:00:43 --> Final output sent to browser
DEBUG - 2018-04-15 03:00:43 --> Total execution time: 0.3997
INFO - 2018-04-15 03:01:32 --> Config Class Initialized
INFO - 2018-04-15 03:01:32 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:01:32 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:01:32 --> Utf8 Class Initialized
INFO - 2018-04-15 03:01:32 --> URI Class Initialized
INFO - 2018-04-15 03:01:32 --> Router Class Initialized
INFO - 2018-04-15 03:01:32 --> Output Class Initialized
INFO - 2018-04-15 03:01:32 --> Security Class Initialized
DEBUG - 2018-04-15 03:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:01:32 --> Input Class Initialized
INFO - 2018-04-15 03:01:32 --> Language Class Initialized
INFO - 2018-04-15 03:01:32 --> Loader Class Initialized
INFO - 2018-04-15 03:01:32 --> Helper loaded: url_helper
INFO - 2018-04-15 03:01:32 --> Helper loaded: file_helper
INFO - 2018-04-15 03:01:32 --> Helper loaded: date_helper
INFO - 2018-04-15 03:01:32 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:01:32 --> Controller Class Initialized
INFO - 2018-04-15 03:01:32 --> Model Class Initialized
INFO - 2018-04-15 03:01:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:01:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 03:01:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:01:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:01:32 --> Final output sent to browser
DEBUG - 2018-04-15 03:01:32 --> Total execution time: 0.4122
INFO - 2018-04-15 03:01:33 --> Config Class Initialized
INFO - 2018-04-15 03:01:33 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:01:34 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:01:34 --> Utf8 Class Initialized
INFO - 2018-04-15 03:01:34 --> URI Class Initialized
DEBUG - 2018-04-15 03:01:34 --> No URI present. Default controller set.
INFO - 2018-04-15 03:01:34 --> Router Class Initialized
INFO - 2018-04-15 03:01:34 --> Output Class Initialized
INFO - 2018-04-15 03:01:34 --> Security Class Initialized
DEBUG - 2018-04-15 03:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:01:34 --> Input Class Initialized
INFO - 2018-04-15 03:01:34 --> Language Class Initialized
INFO - 2018-04-15 03:01:34 --> Loader Class Initialized
INFO - 2018-04-15 03:01:34 --> Helper loaded: url_helper
INFO - 2018-04-15 03:01:34 --> Helper loaded: file_helper
INFO - 2018-04-15 03:01:34 --> Helper loaded: date_helper
INFO - 2018-04-15 03:01:34 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:01:34 --> Controller Class Initialized
INFO - 2018-04-15 03:01:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:01:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 03:01:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:01:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:01:34 --> Final output sent to browser
DEBUG - 2018-04-15 03:01:34 --> Total execution time: 0.4598
INFO - 2018-04-15 03:01:38 --> Config Class Initialized
INFO - 2018-04-15 03:01:38 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:01:38 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:01:38 --> Utf8 Class Initialized
INFO - 2018-04-15 03:01:38 --> URI Class Initialized
INFO - 2018-04-15 03:01:38 --> Router Class Initialized
INFO - 2018-04-15 03:01:38 --> Output Class Initialized
INFO - 2018-04-15 03:01:38 --> Security Class Initialized
DEBUG - 2018-04-15 03:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:01:38 --> Input Class Initialized
INFO - 2018-04-15 03:01:38 --> Language Class Initialized
INFO - 2018-04-15 03:01:38 --> Loader Class Initialized
INFO - 2018-04-15 03:01:38 --> Helper loaded: url_helper
INFO - 2018-04-15 03:01:38 --> Helper loaded: file_helper
INFO - 2018-04-15 03:01:38 --> Helper loaded: date_helper
INFO - 2018-04-15 03:01:38 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:01:38 --> Controller Class Initialized
INFO - 2018-04-15 03:01:38 --> Config Class Initialized
INFO - 2018-04-15 03:01:38 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:01:38 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:01:38 --> Utf8 Class Initialized
INFO - 2018-04-15 03:01:38 --> URI Class Initialized
INFO - 2018-04-15 03:01:38 --> Router Class Initialized
INFO - 2018-04-15 03:01:38 --> Output Class Initialized
INFO - 2018-04-15 03:01:38 --> Security Class Initialized
DEBUG - 2018-04-15 03:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:01:38 --> Input Class Initialized
INFO - 2018-04-15 03:01:38 --> Language Class Initialized
INFO - 2018-04-15 03:01:38 --> Loader Class Initialized
INFO - 2018-04-15 03:01:38 --> Helper loaded: url_helper
INFO - 2018-04-15 03:01:38 --> Helper loaded: file_helper
INFO - 2018-04-15 03:01:38 --> Helper loaded: date_helper
INFO - 2018-04-15 03:01:38 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:01:39 --> Controller Class Initialized
INFO - 2018-04-15 03:01:39 --> Model Class Initialized
INFO - 2018-04-15 03:01:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:01:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 03:01:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:01:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:01:39 --> Final output sent to browser
DEBUG - 2018-04-15 03:01:39 --> Total execution time: 0.4108
INFO - 2018-04-15 03:01:43 --> Config Class Initialized
INFO - 2018-04-15 03:01:43 --> Hooks Class Initialized
DEBUG - 2018-04-15 03:01:43 --> UTF-8 Support Enabled
INFO - 2018-04-15 03:01:43 --> Utf8 Class Initialized
INFO - 2018-04-15 03:01:43 --> URI Class Initialized
DEBUG - 2018-04-15 03:01:43 --> No URI present. Default controller set.
INFO - 2018-04-15 03:01:43 --> Router Class Initialized
INFO - 2018-04-15 03:01:43 --> Output Class Initialized
INFO - 2018-04-15 03:01:43 --> Security Class Initialized
DEBUG - 2018-04-15 03:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 03:01:43 --> Input Class Initialized
INFO - 2018-04-15 03:01:43 --> Language Class Initialized
INFO - 2018-04-15 03:01:43 --> Loader Class Initialized
INFO - 2018-04-15 03:01:43 --> Helper loaded: url_helper
INFO - 2018-04-15 03:01:43 --> Helper loaded: file_helper
INFO - 2018-04-15 03:01:43 --> Helper loaded: date_helper
INFO - 2018-04-15 03:01:43 --> Database Driver Class Initialized
DEBUG - 2018-04-15 03:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 03:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 03:01:43 --> Controller Class Initialized
INFO - 2018-04-15 03:01:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 03:01:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 03:01:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 03:01:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 03:01:43 --> Final output sent to browser
DEBUG - 2018-04-15 03:01:43 --> Total execution time: 0.3935
INFO - 2018-04-15 05:30:59 --> Config Class Initialized
INFO - 2018-04-15 05:30:59 --> Hooks Class Initialized
DEBUG - 2018-04-15 05:30:59 --> UTF-8 Support Enabled
INFO - 2018-04-15 05:30:59 --> Utf8 Class Initialized
INFO - 2018-04-15 05:30:59 --> URI Class Initialized
DEBUG - 2018-04-15 05:30:59 --> No URI present. Default controller set.
INFO - 2018-04-15 05:30:59 --> Router Class Initialized
INFO - 2018-04-15 05:30:59 --> Output Class Initialized
INFO - 2018-04-15 05:30:59 --> Security Class Initialized
DEBUG - 2018-04-15 05:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 05:30:59 --> Input Class Initialized
INFO - 2018-04-15 05:30:59 --> Language Class Initialized
INFO - 2018-04-15 05:30:59 --> Loader Class Initialized
INFO - 2018-04-15 05:31:00 --> Helper loaded: url_helper
INFO - 2018-04-15 05:31:00 --> Helper loaded: file_helper
INFO - 2018-04-15 05:31:00 --> Helper loaded: date_helper
INFO - 2018-04-15 05:31:00 --> Database Driver Class Initialized
DEBUG - 2018-04-15 05:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 05:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 05:31:00 --> Controller Class Initialized
INFO - 2018-04-15 05:31:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 05:31:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 05:31:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 05:31:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 05:31:00 --> Final output sent to browser
DEBUG - 2018-04-15 05:31:00 --> Total execution time: 0.4747
INFO - 2018-04-15 05:31:04 --> Config Class Initialized
INFO - 2018-04-15 05:31:04 --> Hooks Class Initialized
DEBUG - 2018-04-15 05:31:04 --> UTF-8 Support Enabled
INFO - 2018-04-15 05:31:04 --> Utf8 Class Initialized
INFO - 2018-04-15 05:31:04 --> URI Class Initialized
DEBUG - 2018-04-15 05:31:04 --> No URI present. Default controller set.
INFO - 2018-04-15 05:31:04 --> Router Class Initialized
INFO - 2018-04-15 05:31:04 --> Output Class Initialized
INFO - 2018-04-15 05:31:04 --> Security Class Initialized
DEBUG - 2018-04-15 05:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 05:31:04 --> Input Class Initialized
INFO - 2018-04-15 05:31:04 --> Language Class Initialized
INFO - 2018-04-15 05:31:04 --> Loader Class Initialized
INFO - 2018-04-15 05:31:04 --> Helper loaded: url_helper
INFO - 2018-04-15 05:31:04 --> Helper loaded: file_helper
INFO - 2018-04-15 05:31:04 --> Helper loaded: date_helper
INFO - 2018-04-15 05:31:04 --> Database Driver Class Initialized
DEBUG - 2018-04-15 05:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 05:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 05:31:04 --> Controller Class Initialized
INFO - 2018-04-15 05:31:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 05:31:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 05:31:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 05:31:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 05:31:04 --> Final output sent to browser
DEBUG - 2018-04-15 05:31:04 --> Total execution time: 0.4466
INFO - 2018-04-15 05:31:06 --> Config Class Initialized
INFO - 2018-04-15 05:31:06 --> Hooks Class Initialized
DEBUG - 2018-04-15 05:31:06 --> UTF-8 Support Enabled
INFO - 2018-04-15 05:31:06 --> Utf8 Class Initialized
INFO - 2018-04-15 05:31:06 --> URI Class Initialized
INFO - 2018-04-15 05:31:06 --> Router Class Initialized
INFO - 2018-04-15 05:31:06 --> Output Class Initialized
INFO - 2018-04-15 05:31:06 --> Security Class Initialized
DEBUG - 2018-04-15 05:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 05:31:06 --> Input Class Initialized
INFO - 2018-04-15 05:31:06 --> Language Class Initialized
INFO - 2018-04-15 05:31:06 --> Loader Class Initialized
INFO - 2018-04-15 05:31:06 --> Helper loaded: url_helper
INFO - 2018-04-15 05:31:06 --> Helper loaded: file_helper
INFO - 2018-04-15 05:31:06 --> Helper loaded: date_helper
INFO - 2018-04-15 05:31:06 --> Database Driver Class Initialized
DEBUG - 2018-04-15 05:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 05:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 05:31:06 --> Controller Class Initialized
INFO - 2018-04-15 05:31:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 05:31:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 05:31:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 05:31:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 05:31:06 --> Final output sent to browser
DEBUG - 2018-04-15 05:31:06 --> Total execution time: 0.4503
INFO - 2018-04-15 05:31:08 --> Config Class Initialized
INFO - 2018-04-15 05:31:08 --> Hooks Class Initialized
DEBUG - 2018-04-15 05:31:08 --> UTF-8 Support Enabled
INFO - 2018-04-15 05:31:08 --> Utf8 Class Initialized
INFO - 2018-04-15 05:31:08 --> URI Class Initialized
INFO - 2018-04-15 05:31:08 --> Router Class Initialized
INFO - 2018-04-15 05:31:08 --> Output Class Initialized
INFO - 2018-04-15 05:31:08 --> Security Class Initialized
DEBUG - 2018-04-15 05:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 05:31:08 --> Input Class Initialized
INFO - 2018-04-15 05:31:08 --> Language Class Initialized
INFO - 2018-04-15 05:31:08 --> Loader Class Initialized
INFO - 2018-04-15 05:31:08 --> Helper loaded: url_helper
INFO - 2018-04-15 05:31:08 --> Helper loaded: file_helper
INFO - 2018-04-15 05:31:08 --> Helper loaded: date_helper
INFO - 2018-04-15 05:31:08 --> Database Driver Class Initialized
DEBUG - 2018-04-15 05:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 05:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 05:31:08 --> Controller Class Initialized
INFO - 2018-04-15 05:31:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 05:31:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 05:31:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 05:31:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 05:31:08 --> Final output sent to browser
DEBUG - 2018-04-15 05:31:08 --> Total execution time: 0.4665
INFO - 2018-04-15 05:31:09 --> Config Class Initialized
INFO - 2018-04-15 05:31:09 --> Hooks Class Initialized
DEBUG - 2018-04-15 05:31:09 --> UTF-8 Support Enabled
INFO - 2018-04-15 05:31:09 --> Utf8 Class Initialized
INFO - 2018-04-15 05:31:09 --> URI Class Initialized
INFO - 2018-04-15 05:31:09 --> Router Class Initialized
INFO - 2018-04-15 05:31:09 --> Output Class Initialized
INFO - 2018-04-15 05:31:09 --> Security Class Initialized
DEBUG - 2018-04-15 05:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 05:31:09 --> Input Class Initialized
INFO - 2018-04-15 05:31:09 --> Language Class Initialized
INFO - 2018-04-15 05:31:09 --> Loader Class Initialized
INFO - 2018-04-15 05:31:09 --> Helper loaded: url_helper
INFO - 2018-04-15 05:31:09 --> Helper loaded: file_helper
INFO - 2018-04-15 05:31:09 --> Helper loaded: date_helper
INFO - 2018-04-15 05:31:09 --> Database Driver Class Initialized
DEBUG - 2018-04-15 05:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 05:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 05:31:09 --> Controller Class Initialized
INFO - 2018-04-15 05:31:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 05:31:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 05:31:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 05:31:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 05:31:09 --> Final output sent to browser
DEBUG - 2018-04-15 05:31:09 --> Total execution time: 0.3870
INFO - 2018-04-15 05:31:11 --> Config Class Initialized
INFO - 2018-04-15 05:31:11 --> Hooks Class Initialized
DEBUG - 2018-04-15 05:31:11 --> UTF-8 Support Enabled
INFO - 2018-04-15 05:31:11 --> Utf8 Class Initialized
INFO - 2018-04-15 05:31:11 --> URI Class Initialized
INFO - 2018-04-15 05:31:11 --> Router Class Initialized
INFO - 2018-04-15 05:31:11 --> Output Class Initialized
INFO - 2018-04-15 05:31:11 --> Security Class Initialized
DEBUG - 2018-04-15 05:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 05:31:11 --> Input Class Initialized
INFO - 2018-04-15 05:31:11 --> Language Class Initialized
INFO - 2018-04-15 05:31:11 --> Loader Class Initialized
INFO - 2018-04-15 05:31:11 --> Helper loaded: url_helper
INFO - 2018-04-15 05:31:11 --> Helper loaded: file_helper
INFO - 2018-04-15 05:31:11 --> Helper loaded: date_helper
INFO - 2018-04-15 05:31:11 --> Database Driver Class Initialized
DEBUG - 2018-04-15 05:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 05:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 05:31:11 --> Controller Class Initialized
INFO - 2018-04-15 05:31:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 05:31:11 --> Final output sent to browser
DEBUG - 2018-04-15 05:31:11 --> Total execution time: 0.3925
INFO - 2018-04-15 05:35:57 --> Config Class Initialized
INFO - 2018-04-15 05:35:57 --> Hooks Class Initialized
DEBUG - 2018-04-15 05:35:57 --> UTF-8 Support Enabled
INFO - 2018-04-15 05:35:57 --> Utf8 Class Initialized
INFO - 2018-04-15 05:35:57 --> URI Class Initialized
INFO - 2018-04-15 05:35:57 --> Router Class Initialized
INFO - 2018-04-15 05:35:57 --> Output Class Initialized
INFO - 2018-04-15 05:35:57 --> Security Class Initialized
DEBUG - 2018-04-15 05:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 05:35:57 --> Input Class Initialized
INFO - 2018-04-15 05:35:57 --> Language Class Initialized
INFO - 2018-04-15 05:35:57 --> Loader Class Initialized
INFO - 2018-04-15 05:35:57 --> Helper loaded: url_helper
INFO - 2018-04-15 05:35:57 --> Helper loaded: file_helper
INFO - 2018-04-15 05:35:57 --> Helper loaded: date_helper
INFO - 2018-04-15 05:35:57 --> Database Driver Class Initialized
DEBUG - 2018-04-15 05:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 05:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 05:35:57 --> Controller Class Initialized
INFO - 2018-04-15 05:35:57 --> Model Class Initialized
ERROR - 2018-04-15 05:35:57 --> Query error: Column 'gender' cannot be null - Invalid query: INSERT INTO `user` (`user_type`, `name`, `email`, `gender`, `blood_group`, `phone`, `dob`, `weight`, `country`) VALUES (2, '', '', NULL, 'select group', '', '', '', 'select')
INFO - 2018-04-15 05:35:57 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-15 05:36:00 --> Config Class Initialized
INFO - 2018-04-15 05:36:00 --> Hooks Class Initialized
DEBUG - 2018-04-15 05:36:00 --> UTF-8 Support Enabled
INFO - 2018-04-15 05:36:00 --> Utf8 Class Initialized
INFO - 2018-04-15 05:36:00 --> URI Class Initialized
INFO - 2018-04-15 05:36:00 --> Router Class Initialized
INFO - 2018-04-15 05:36:00 --> Output Class Initialized
INFO - 2018-04-15 05:36:00 --> Security Class Initialized
DEBUG - 2018-04-15 05:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 05:36:00 --> Input Class Initialized
INFO - 2018-04-15 05:36:00 --> Language Class Initialized
INFO - 2018-04-15 05:36:00 --> Loader Class Initialized
INFO - 2018-04-15 05:36:00 --> Helper loaded: url_helper
INFO - 2018-04-15 05:36:00 --> Helper loaded: file_helper
INFO - 2018-04-15 05:36:00 --> Helper loaded: date_helper
INFO - 2018-04-15 05:36:00 --> Database Driver Class Initialized
DEBUG - 2018-04-15 05:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 05:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 05:36:00 --> Controller Class Initialized
INFO - 2018-04-15 05:36:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 05:36:00 --> Final output sent to browser
DEBUG - 2018-04-15 05:36:00 --> Total execution time: 0.3841
INFO - 2018-04-15 08:01:08 --> Config Class Initialized
INFO - 2018-04-15 08:01:08 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:01:08 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:01:08 --> Utf8 Class Initialized
INFO - 2018-04-15 08:01:08 --> URI Class Initialized
DEBUG - 2018-04-15 08:01:08 --> No URI present. Default controller set.
INFO - 2018-04-15 08:01:08 --> Router Class Initialized
INFO - 2018-04-15 08:01:08 --> Output Class Initialized
INFO - 2018-04-15 08:01:08 --> Security Class Initialized
DEBUG - 2018-04-15 08:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:01:08 --> Input Class Initialized
INFO - 2018-04-15 08:01:08 --> Language Class Initialized
INFO - 2018-04-15 08:01:08 --> Loader Class Initialized
INFO - 2018-04-15 08:01:08 --> Helper loaded: url_helper
INFO - 2018-04-15 08:01:08 --> Helper loaded: file_helper
INFO - 2018-04-15 08:01:08 --> Helper loaded: date_helper
INFO - 2018-04-15 08:01:08 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:01:08 --> Controller Class Initialized
INFO - 2018-04-15 08:01:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:01:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 08:01:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:01:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:01:08 --> Final output sent to browser
DEBUG - 2018-04-15 08:01:08 --> Total execution time: 0.8193
INFO - 2018-04-15 08:05:31 --> Config Class Initialized
INFO - 2018-04-15 08:05:31 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:05:31 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:05:31 --> Utf8 Class Initialized
INFO - 2018-04-15 08:05:31 --> URI Class Initialized
DEBUG - 2018-04-15 08:05:31 --> No URI present. Default controller set.
INFO - 2018-04-15 08:05:31 --> Router Class Initialized
INFO - 2018-04-15 08:05:31 --> Output Class Initialized
INFO - 2018-04-15 08:05:31 --> Security Class Initialized
DEBUG - 2018-04-15 08:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:05:31 --> Input Class Initialized
INFO - 2018-04-15 08:05:31 --> Language Class Initialized
INFO - 2018-04-15 08:05:31 --> Loader Class Initialized
INFO - 2018-04-15 08:05:31 --> Helper loaded: url_helper
INFO - 2018-04-15 08:05:31 --> Helper loaded: file_helper
INFO - 2018-04-15 08:05:31 --> Helper loaded: date_helper
INFO - 2018-04-15 08:05:31 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:05:31 --> Controller Class Initialized
INFO - 2018-04-15 08:05:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:05:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 08:05:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:05:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:05:31 --> Final output sent to browser
DEBUG - 2018-04-15 08:05:31 --> Total execution time: 0.4865
INFO - 2018-04-15 08:08:19 --> Config Class Initialized
INFO - 2018-04-15 08:08:19 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:08:19 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:08:19 --> Utf8 Class Initialized
INFO - 2018-04-15 08:08:19 --> URI Class Initialized
DEBUG - 2018-04-15 08:08:19 --> No URI present. Default controller set.
INFO - 2018-04-15 08:08:19 --> Router Class Initialized
INFO - 2018-04-15 08:08:19 --> Output Class Initialized
INFO - 2018-04-15 08:08:19 --> Security Class Initialized
DEBUG - 2018-04-15 08:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:08:19 --> Input Class Initialized
INFO - 2018-04-15 08:08:19 --> Language Class Initialized
INFO - 2018-04-15 08:08:19 --> Loader Class Initialized
INFO - 2018-04-15 08:08:19 --> Helper loaded: url_helper
INFO - 2018-04-15 08:08:19 --> Helper loaded: file_helper
INFO - 2018-04-15 08:08:19 --> Helper loaded: date_helper
INFO - 2018-04-15 08:08:19 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:08:19 --> Controller Class Initialized
INFO - 2018-04-15 08:08:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:08:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 08:08:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:08:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:08:19 --> Final output sent to browser
DEBUG - 2018-04-15 08:08:19 --> Total execution time: 0.5355
INFO - 2018-04-15 08:08:25 --> Config Class Initialized
INFO - 2018-04-15 08:08:25 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:08:25 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:08:25 --> Utf8 Class Initialized
INFO - 2018-04-15 08:08:25 --> URI Class Initialized
INFO - 2018-04-15 08:08:25 --> Router Class Initialized
INFO - 2018-04-15 08:08:25 --> Output Class Initialized
INFO - 2018-04-15 08:08:25 --> Security Class Initialized
DEBUG - 2018-04-15 08:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:08:25 --> Input Class Initialized
INFO - 2018-04-15 08:08:25 --> Language Class Initialized
INFO - 2018-04-15 08:08:25 --> Loader Class Initialized
INFO - 2018-04-15 08:08:25 --> Helper loaded: url_helper
INFO - 2018-04-15 08:08:25 --> Helper loaded: file_helper
INFO - 2018-04-15 08:08:25 --> Helper loaded: date_helper
INFO - 2018-04-15 08:08:25 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:08:25 --> Controller Class Initialized
INFO - 2018-04-15 08:08:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:08:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 08:08:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:08:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:08:25 --> Final output sent to browser
DEBUG - 2018-04-15 08:08:25 --> Total execution time: 0.4349
INFO - 2018-04-15 08:08:26 --> Config Class Initialized
INFO - 2018-04-15 08:08:26 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:08:26 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:08:27 --> Utf8 Class Initialized
INFO - 2018-04-15 08:08:27 --> URI Class Initialized
INFO - 2018-04-15 08:08:27 --> Router Class Initialized
INFO - 2018-04-15 08:08:27 --> Output Class Initialized
INFO - 2018-04-15 08:08:27 --> Security Class Initialized
DEBUG - 2018-04-15 08:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:08:27 --> Input Class Initialized
INFO - 2018-04-15 08:08:27 --> Language Class Initialized
INFO - 2018-04-15 08:08:27 --> Loader Class Initialized
INFO - 2018-04-15 08:08:27 --> Helper loaded: url_helper
INFO - 2018-04-15 08:08:27 --> Helper loaded: file_helper
INFO - 2018-04-15 08:08:27 --> Helper loaded: date_helper
INFO - 2018-04-15 08:08:27 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:08:27 --> Controller Class Initialized
INFO - 2018-04-15 08:08:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:08:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 08:08:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:08:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:08:27 --> Final output sent to browser
DEBUG - 2018-04-15 08:08:27 --> Total execution time: 0.4879
INFO - 2018-04-15 08:08:28 --> Config Class Initialized
INFO - 2018-04-15 08:08:28 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:08:28 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:08:28 --> Utf8 Class Initialized
INFO - 2018-04-15 08:08:29 --> URI Class Initialized
INFO - 2018-04-15 08:08:29 --> Router Class Initialized
INFO - 2018-04-15 08:08:29 --> Output Class Initialized
INFO - 2018-04-15 08:08:29 --> Security Class Initialized
DEBUG - 2018-04-15 08:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:08:29 --> Input Class Initialized
INFO - 2018-04-15 08:08:29 --> Language Class Initialized
INFO - 2018-04-15 08:08:29 --> Loader Class Initialized
INFO - 2018-04-15 08:08:29 --> Helper loaded: url_helper
INFO - 2018-04-15 08:08:29 --> Helper loaded: file_helper
INFO - 2018-04-15 08:08:29 --> Helper loaded: date_helper
INFO - 2018-04-15 08:08:29 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:08:29 --> Controller Class Initialized
INFO - 2018-04-15 08:08:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:08:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 08:08:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:08:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:08:29 --> Final output sent to browser
DEBUG - 2018-04-15 08:08:29 --> Total execution time: 0.4656
INFO - 2018-04-15 08:08:30 --> Config Class Initialized
INFO - 2018-04-15 08:08:30 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:08:30 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:08:30 --> Utf8 Class Initialized
INFO - 2018-04-15 08:08:30 --> URI Class Initialized
INFO - 2018-04-15 08:08:30 --> Router Class Initialized
INFO - 2018-04-15 08:08:30 --> Output Class Initialized
INFO - 2018-04-15 08:08:31 --> Security Class Initialized
DEBUG - 2018-04-15 08:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:08:31 --> Input Class Initialized
INFO - 2018-04-15 08:08:31 --> Language Class Initialized
INFO - 2018-04-15 08:08:31 --> Loader Class Initialized
INFO - 2018-04-15 08:08:31 --> Helper loaded: url_helper
INFO - 2018-04-15 08:08:31 --> Helper loaded: file_helper
INFO - 2018-04-15 08:08:31 --> Helper loaded: date_helper
INFO - 2018-04-15 08:08:31 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:08:31 --> Controller Class Initialized
INFO - 2018-04-15 08:08:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 08:08:31 --> Final output sent to browser
DEBUG - 2018-04-15 08:08:31 --> Total execution time: 0.3983
INFO - 2018-04-15 08:08:37 --> Config Class Initialized
INFO - 2018-04-15 08:08:37 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:08:37 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:08:37 --> Utf8 Class Initialized
INFO - 2018-04-15 08:08:37 --> URI Class Initialized
INFO - 2018-04-15 08:08:37 --> Router Class Initialized
INFO - 2018-04-15 08:08:37 --> Output Class Initialized
INFO - 2018-04-15 08:08:37 --> Security Class Initialized
DEBUG - 2018-04-15 08:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:08:37 --> Input Class Initialized
INFO - 2018-04-15 08:08:37 --> Language Class Initialized
INFO - 2018-04-15 08:08:37 --> Loader Class Initialized
INFO - 2018-04-15 08:08:37 --> Helper loaded: url_helper
INFO - 2018-04-15 08:08:37 --> Helper loaded: file_helper
INFO - 2018-04-15 08:08:37 --> Helper loaded: date_helper
INFO - 2018-04-15 08:08:37 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:08:37 --> Controller Class Initialized
INFO - 2018-04-15 08:08:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:08:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 08:08:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:08:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:08:37 --> Final output sent to browser
DEBUG - 2018-04-15 08:08:37 --> Total execution time: 0.4407
INFO - 2018-04-15 08:08:39 --> Config Class Initialized
INFO - 2018-04-15 08:08:39 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:08:39 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:08:39 --> Utf8 Class Initialized
INFO - 2018-04-15 08:08:39 --> URI Class Initialized
INFO - 2018-04-15 08:08:39 --> Router Class Initialized
INFO - 2018-04-15 08:08:39 --> Output Class Initialized
INFO - 2018-04-15 08:08:39 --> Security Class Initialized
DEBUG - 2018-04-15 08:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:08:39 --> Input Class Initialized
INFO - 2018-04-15 08:08:39 --> Language Class Initialized
INFO - 2018-04-15 08:08:39 --> Loader Class Initialized
INFO - 2018-04-15 08:08:39 --> Helper loaded: url_helper
INFO - 2018-04-15 08:08:39 --> Helper loaded: file_helper
INFO - 2018-04-15 08:08:39 --> Helper loaded: date_helper
INFO - 2018-04-15 08:08:39 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:08:39 --> Controller Class Initialized
INFO - 2018-04-15 08:08:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 08:08:39 --> Final output sent to browser
DEBUG - 2018-04-15 08:08:39 --> Total execution time: 0.4477
INFO - 2018-04-15 08:18:30 --> Config Class Initialized
INFO - 2018-04-15 08:18:30 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:18:30 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:18:30 --> Utf8 Class Initialized
INFO - 2018-04-15 08:18:30 --> URI Class Initialized
INFO - 2018-04-15 08:18:30 --> Router Class Initialized
INFO - 2018-04-15 08:18:31 --> Output Class Initialized
INFO - 2018-04-15 08:18:31 --> Security Class Initialized
DEBUG - 2018-04-15 08:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:18:31 --> Input Class Initialized
INFO - 2018-04-15 08:18:31 --> Language Class Initialized
INFO - 2018-04-15 08:18:31 --> Loader Class Initialized
INFO - 2018-04-15 08:18:31 --> Helper loaded: url_helper
INFO - 2018-04-15 08:18:31 --> Helper loaded: file_helper
INFO - 2018-04-15 08:18:31 --> Helper loaded: date_helper
INFO - 2018-04-15 08:18:31 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:18:31 --> Controller Class Initialized
INFO - 2018-04-15 08:18:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:18:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 08:18:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:18:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:18:32 --> Final output sent to browser
DEBUG - 2018-04-15 08:18:32 --> Total execution time: 1.5923
INFO - 2018-04-15 08:18:34 --> Config Class Initialized
INFO - 2018-04-15 08:18:34 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:18:34 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:18:34 --> Utf8 Class Initialized
INFO - 2018-04-15 08:18:34 --> URI Class Initialized
INFO - 2018-04-15 08:18:34 --> Router Class Initialized
INFO - 2018-04-15 08:18:34 --> Output Class Initialized
INFO - 2018-04-15 08:18:34 --> Security Class Initialized
DEBUG - 2018-04-15 08:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:18:34 --> Input Class Initialized
INFO - 2018-04-15 08:18:34 --> Language Class Initialized
INFO - 2018-04-15 08:18:34 --> Loader Class Initialized
INFO - 2018-04-15 08:18:34 --> Helper loaded: url_helper
INFO - 2018-04-15 08:18:34 --> Helper loaded: file_helper
INFO - 2018-04-15 08:18:34 --> Helper loaded: date_helper
INFO - 2018-04-15 08:18:34 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:18:34 --> Controller Class Initialized
INFO - 2018-04-15 08:18:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:18:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 08:18:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:18:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:18:34 --> Final output sent to browser
DEBUG - 2018-04-15 08:18:34 --> Total execution time: 0.4632
INFO - 2018-04-15 08:18:37 --> Config Class Initialized
INFO - 2018-04-15 08:18:37 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:18:37 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:18:37 --> Utf8 Class Initialized
INFO - 2018-04-15 08:18:37 --> URI Class Initialized
INFO - 2018-04-15 08:18:37 --> Router Class Initialized
INFO - 2018-04-15 08:18:37 --> Output Class Initialized
INFO - 2018-04-15 08:18:38 --> Security Class Initialized
DEBUG - 2018-04-15 08:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:18:38 --> Input Class Initialized
INFO - 2018-04-15 08:18:38 --> Language Class Initialized
INFO - 2018-04-15 08:18:38 --> Loader Class Initialized
INFO - 2018-04-15 08:18:38 --> Helper loaded: url_helper
INFO - 2018-04-15 08:18:38 --> Helper loaded: file_helper
INFO - 2018-04-15 08:18:38 --> Helper loaded: date_helper
INFO - 2018-04-15 08:18:38 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:18:38 --> Controller Class Initialized
INFO - 2018-04-15 08:18:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:18:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 08:18:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:18:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:18:38 --> Final output sent to browser
DEBUG - 2018-04-15 08:18:38 --> Total execution time: 0.4355
INFO - 2018-04-15 08:20:41 --> Config Class Initialized
INFO - 2018-04-15 08:20:41 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:20:41 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:20:42 --> Utf8 Class Initialized
INFO - 2018-04-15 08:20:42 --> URI Class Initialized
INFO - 2018-04-15 08:20:42 --> Router Class Initialized
INFO - 2018-04-15 08:20:42 --> Output Class Initialized
INFO - 2018-04-15 08:20:42 --> Security Class Initialized
DEBUG - 2018-04-15 08:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:20:42 --> Input Class Initialized
INFO - 2018-04-15 08:20:42 --> Language Class Initialized
INFO - 2018-04-15 08:20:42 --> Loader Class Initialized
INFO - 2018-04-15 08:20:42 --> Helper loaded: url_helper
INFO - 2018-04-15 08:20:42 --> Helper loaded: file_helper
INFO - 2018-04-15 08:20:42 --> Helper loaded: date_helper
INFO - 2018-04-15 08:20:42 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:20:42 --> Controller Class Initialized
INFO - 2018-04-15 08:20:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:20:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 08:20:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:20:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:20:42 --> Final output sent to browser
DEBUG - 2018-04-15 08:20:42 --> Total execution time: 0.4264
INFO - 2018-04-15 08:20:45 --> Config Class Initialized
INFO - 2018-04-15 08:20:45 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:20:45 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:20:45 --> Utf8 Class Initialized
INFO - 2018-04-15 08:20:45 --> URI Class Initialized
DEBUG - 2018-04-15 08:20:45 --> No URI present. Default controller set.
INFO - 2018-04-15 08:20:45 --> Router Class Initialized
INFO - 2018-04-15 08:20:45 --> Output Class Initialized
INFO - 2018-04-15 08:20:45 --> Security Class Initialized
DEBUG - 2018-04-15 08:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:20:45 --> Input Class Initialized
INFO - 2018-04-15 08:20:45 --> Language Class Initialized
INFO - 2018-04-15 08:20:45 --> Loader Class Initialized
INFO - 2018-04-15 08:20:45 --> Helper loaded: url_helper
INFO - 2018-04-15 08:20:45 --> Helper loaded: file_helper
INFO - 2018-04-15 08:20:45 --> Helper loaded: date_helper
INFO - 2018-04-15 08:20:45 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:20:45 --> Controller Class Initialized
INFO - 2018-04-15 08:20:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:20:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 08:20:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:20:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:20:46 --> Final output sent to browser
DEBUG - 2018-04-15 08:20:46 --> Total execution time: 0.7229
INFO - 2018-04-15 08:21:36 --> Config Class Initialized
INFO - 2018-04-15 08:21:36 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:21:36 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:21:36 --> Utf8 Class Initialized
INFO - 2018-04-15 08:21:36 --> URI Class Initialized
DEBUG - 2018-04-15 08:21:36 --> No URI present. Default controller set.
INFO - 2018-04-15 08:21:36 --> Router Class Initialized
INFO - 2018-04-15 08:21:36 --> Output Class Initialized
INFO - 2018-04-15 08:21:36 --> Security Class Initialized
DEBUG - 2018-04-15 08:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:21:36 --> Input Class Initialized
INFO - 2018-04-15 08:21:36 --> Language Class Initialized
INFO - 2018-04-15 08:21:36 --> Loader Class Initialized
INFO - 2018-04-15 08:21:36 --> Helper loaded: url_helper
INFO - 2018-04-15 08:21:36 --> Helper loaded: file_helper
INFO - 2018-04-15 08:21:36 --> Helper loaded: date_helper
INFO - 2018-04-15 08:21:36 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:21:36 --> Controller Class Initialized
INFO - 2018-04-15 08:21:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:21:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 08:21:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:21:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:21:36 --> Final output sent to browser
DEBUG - 2018-04-15 08:21:36 --> Total execution time: 0.5266
INFO - 2018-04-15 08:25:35 --> Config Class Initialized
INFO - 2018-04-15 08:25:35 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:25:35 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:25:35 --> Utf8 Class Initialized
INFO - 2018-04-15 08:25:36 --> URI Class Initialized
DEBUG - 2018-04-15 08:25:36 --> No URI present. Default controller set.
INFO - 2018-04-15 08:25:36 --> Router Class Initialized
INFO - 2018-04-15 08:25:36 --> Output Class Initialized
INFO - 2018-04-15 08:25:36 --> Security Class Initialized
DEBUG - 2018-04-15 08:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:25:36 --> Input Class Initialized
INFO - 2018-04-15 08:25:36 --> Language Class Initialized
INFO - 2018-04-15 08:25:36 --> Loader Class Initialized
INFO - 2018-04-15 08:25:36 --> Helper loaded: url_helper
INFO - 2018-04-15 08:25:36 --> Helper loaded: file_helper
INFO - 2018-04-15 08:25:36 --> Helper loaded: date_helper
INFO - 2018-04-15 08:25:36 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:25:36 --> Controller Class Initialized
INFO - 2018-04-15 08:25:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:25:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 08:25:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:25:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:25:36 --> Final output sent to browser
DEBUG - 2018-04-15 08:25:36 --> Total execution time: 0.4945
INFO - 2018-04-15 08:39:29 --> Config Class Initialized
INFO - 2018-04-15 08:39:29 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:39:29 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:39:29 --> Utf8 Class Initialized
INFO - 2018-04-15 08:39:30 --> URI Class Initialized
INFO - 2018-04-15 08:39:30 --> Router Class Initialized
INFO - 2018-04-15 08:39:30 --> Output Class Initialized
INFO - 2018-04-15 08:39:30 --> Security Class Initialized
DEBUG - 2018-04-15 08:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:39:30 --> Input Class Initialized
INFO - 2018-04-15 08:39:30 --> Language Class Initialized
INFO - 2018-04-15 08:39:30 --> Loader Class Initialized
INFO - 2018-04-15 08:39:30 --> Helper loaded: url_helper
INFO - 2018-04-15 08:39:30 --> Helper loaded: file_helper
INFO - 2018-04-15 08:39:30 --> Helper loaded: date_helper
INFO - 2018-04-15 08:39:30 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:39:30 --> Controller Class Initialized
INFO - 2018-04-15 08:39:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:39:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 08:39:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:39:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:39:30 --> Final output sent to browser
DEBUG - 2018-04-15 08:39:30 --> Total execution time: 0.6310
INFO - 2018-04-15 08:40:35 --> Config Class Initialized
INFO - 2018-04-15 08:40:35 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:40:35 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:40:35 --> Utf8 Class Initialized
INFO - 2018-04-15 08:40:35 --> URI Class Initialized
INFO - 2018-04-15 08:40:35 --> Router Class Initialized
INFO - 2018-04-15 08:40:35 --> Output Class Initialized
INFO - 2018-04-15 08:40:35 --> Security Class Initialized
DEBUG - 2018-04-15 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:40:35 --> Input Class Initialized
INFO - 2018-04-15 08:40:35 --> Language Class Initialized
INFO - 2018-04-15 08:40:35 --> Loader Class Initialized
INFO - 2018-04-15 08:40:35 --> Helper loaded: url_helper
INFO - 2018-04-15 08:40:35 --> Helper loaded: file_helper
INFO - 2018-04-15 08:40:35 --> Helper loaded: date_helper
INFO - 2018-04-15 08:40:35 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:40:35 --> Controller Class Initialized
INFO - 2018-04-15 08:40:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:40:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 08:40:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:40:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:40:35 --> Final output sent to browser
DEBUG - 2018-04-15 08:40:35 --> Total execution time: 0.4887
INFO - 2018-04-15 08:41:23 --> Config Class Initialized
INFO - 2018-04-15 08:41:23 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:41:24 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:41:24 --> Utf8 Class Initialized
INFO - 2018-04-15 08:41:24 --> URI Class Initialized
DEBUG - 2018-04-15 08:41:24 --> No URI present. Default controller set.
INFO - 2018-04-15 08:41:24 --> Router Class Initialized
INFO - 2018-04-15 08:41:24 --> Output Class Initialized
INFO - 2018-04-15 08:41:24 --> Security Class Initialized
DEBUG - 2018-04-15 08:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:41:24 --> Input Class Initialized
INFO - 2018-04-15 08:41:24 --> Language Class Initialized
INFO - 2018-04-15 08:41:24 --> Loader Class Initialized
INFO - 2018-04-15 08:41:24 --> Helper loaded: url_helper
INFO - 2018-04-15 08:41:24 --> Helper loaded: file_helper
INFO - 2018-04-15 08:41:24 --> Helper loaded: date_helper
INFO - 2018-04-15 08:41:24 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:41:24 --> Controller Class Initialized
INFO - 2018-04-15 08:41:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:41:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 08:41:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:41:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:41:24 --> Final output sent to browser
DEBUG - 2018-04-15 08:41:24 --> Total execution time: 0.4717
INFO - 2018-04-15 08:41:48 --> Config Class Initialized
INFO - 2018-04-15 08:41:48 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:41:48 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:41:48 --> Utf8 Class Initialized
INFO - 2018-04-15 08:41:48 --> URI Class Initialized
INFO - 2018-04-15 08:41:48 --> Router Class Initialized
INFO - 2018-04-15 08:41:48 --> Output Class Initialized
INFO - 2018-04-15 08:41:48 --> Security Class Initialized
DEBUG - 2018-04-15 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:41:48 --> Input Class Initialized
INFO - 2018-04-15 08:41:48 --> Language Class Initialized
INFO - 2018-04-15 08:41:48 --> Loader Class Initialized
INFO - 2018-04-15 08:41:48 --> Helper loaded: url_helper
INFO - 2018-04-15 08:41:48 --> Helper loaded: file_helper
INFO - 2018-04-15 08:41:48 --> Helper loaded: date_helper
INFO - 2018-04-15 08:41:48 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:41:49 --> Controller Class Initialized
INFO - 2018-04-15 08:41:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:41:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 08:41:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:41:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:41:49 --> Final output sent to browser
DEBUG - 2018-04-15 08:41:49 --> Total execution time: 0.4681
INFO - 2018-04-15 08:42:11 --> Config Class Initialized
INFO - 2018-04-15 08:42:11 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:42:11 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:42:11 --> Utf8 Class Initialized
INFO - 2018-04-15 08:42:11 --> URI Class Initialized
INFO - 2018-04-15 08:42:11 --> Router Class Initialized
INFO - 2018-04-15 08:42:11 --> Output Class Initialized
INFO - 2018-04-15 08:42:11 --> Security Class Initialized
DEBUG - 2018-04-15 08:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:42:11 --> Input Class Initialized
INFO - 2018-04-15 08:42:11 --> Language Class Initialized
INFO - 2018-04-15 08:42:11 --> Loader Class Initialized
INFO - 2018-04-15 08:42:11 --> Helper loaded: url_helper
INFO - 2018-04-15 08:42:11 --> Helper loaded: file_helper
INFO - 2018-04-15 08:42:11 --> Helper loaded: date_helper
INFO - 2018-04-15 08:42:11 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:42:11 --> Controller Class Initialized
INFO - 2018-04-15 08:42:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:42:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 08:42:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:42:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:42:11 --> Final output sent to browser
DEBUG - 2018-04-15 08:42:11 --> Total execution time: 0.4403
INFO - 2018-04-15 08:42:57 --> Config Class Initialized
INFO - 2018-04-15 08:42:57 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:42:57 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:42:57 --> Utf8 Class Initialized
INFO - 2018-04-15 08:42:57 --> URI Class Initialized
INFO - 2018-04-15 08:42:57 --> Router Class Initialized
INFO - 2018-04-15 08:42:57 --> Output Class Initialized
INFO - 2018-04-15 08:42:57 --> Security Class Initialized
DEBUG - 2018-04-15 08:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:42:57 --> Input Class Initialized
INFO - 2018-04-15 08:42:57 --> Language Class Initialized
INFO - 2018-04-15 08:42:57 --> Loader Class Initialized
INFO - 2018-04-15 08:42:58 --> Helper loaded: url_helper
INFO - 2018-04-15 08:42:58 --> Helper loaded: file_helper
INFO - 2018-04-15 08:42:58 --> Helper loaded: date_helper
INFO - 2018-04-15 08:42:58 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:42:58 --> Controller Class Initialized
INFO - 2018-04-15 08:42:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:42:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 08:42:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:42:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:42:58 --> Final output sent to browser
DEBUG - 2018-04-15 08:42:58 --> Total execution time: 0.4676
INFO - 2018-04-15 08:43:21 --> Config Class Initialized
INFO - 2018-04-15 08:43:21 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:43:21 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:43:21 --> Utf8 Class Initialized
INFO - 2018-04-15 08:43:21 --> URI Class Initialized
INFO - 2018-04-15 08:43:21 --> Router Class Initialized
INFO - 2018-04-15 08:43:21 --> Output Class Initialized
INFO - 2018-04-15 08:43:21 --> Security Class Initialized
DEBUG - 2018-04-15 08:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:43:21 --> Input Class Initialized
INFO - 2018-04-15 08:43:21 --> Language Class Initialized
INFO - 2018-04-15 08:43:21 --> Loader Class Initialized
INFO - 2018-04-15 08:43:21 --> Helper loaded: url_helper
INFO - 2018-04-15 08:43:21 --> Helper loaded: file_helper
INFO - 2018-04-15 08:43:21 --> Helper loaded: date_helper
INFO - 2018-04-15 08:43:21 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:43:21 --> Controller Class Initialized
INFO - 2018-04-15 08:43:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 08:43:21 --> Final output sent to browser
DEBUG - 2018-04-15 08:43:21 --> Total execution time: 0.4979
INFO - 2018-04-15 08:43:41 --> Config Class Initialized
INFO - 2018-04-15 08:43:41 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:43:41 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:43:41 --> Utf8 Class Initialized
INFO - 2018-04-15 08:43:41 --> URI Class Initialized
INFO - 2018-04-15 08:43:41 --> Router Class Initialized
INFO - 2018-04-15 08:43:41 --> Output Class Initialized
INFO - 2018-04-15 08:43:41 --> Security Class Initialized
DEBUG - 2018-04-15 08:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:43:41 --> Input Class Initialized
INFO - 2018-04-15 08:43:41 --> Language Class Initialized
INFO - 2018-04-15 08:43:41 --> Loader Class Initialized
INFO - 2018-04-15 08:43:41 --> Helper loaded: url_helper
INFO - 2018-04-15 08:43:41 --> Helper loaded: file_helper
INFO - 2018-04-15 08:43:41 --> Helper loaded: date_helper
INFO - 2018-04-15 08:43:41 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:43:41 --> Controller Class Initialized
INFO - 2018-04-15 08:43:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:43:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 08:43:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:43:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:43:42 --> Final output sent to browser
DEBUG - 2018-04-15 08:43:42 --> Total execution time: 0.4971
INFO - 2018-04-15 08:43:43 --> Config Class Initialized
INFO - 2018-04-15 08:43:43 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:43:43 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:43:43 --> Utf8 Class Initialized
INFO - 2018-04-15 08:43:43 --> URI Class Initialized
INFO - 2018-04-15 08:43:43 --> Router Class Initialized
INFO - 2018-04-15 08:43:43 --> Output Class Initialized
INFO - 2018-04-15 08:43:43 --> Security Class Initialized
DEBUG - 2018-04-15 08:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:43:43 --> Input Class Initialized
INFO - 2018-04-15 08:43:44 --> Language Class Initialized
INFO - 2018-04-15 08:43:44 --> Loader Class Initialized
INFO - 2018-04-15 08:43:44 --> Helper loaded: url_helper
INFO - 2018-04-15 08:43:44 --> Helper loaded: file_helper
INFO - 2018-04-15 08:43:44 --> Helper loaded: date_helper
INFO - 2018-04-15 08:43:44 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:43:44 --> Controller Class Initialized
INFO - 2018-04-15 08:43:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 08:43:44 --> Final output sent to browser
DEBUG - 2018-04-15 08:43:44 --> Total execution time: 0.8397
INFO - 2018-04-15 08:44:10 --> Config Class Initialized
INFO - 2018-04-15 08:44:10 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:44:10 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:44:10 --> Utf8 Class Initialized
INFO - 2018-04-15 08:44:10 --> URI Class Initialized
INFO - 2018-04-15 08:44:10 --> Router Class Initialized
INFO - 2018-04-15 08:44:10 --> Output Class Initialized
INFO - 2018-04-15 08:44:10 --> Security Class Initialized
DEBUG - 2018-04-15 08:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:44:10 --> Input Class Initialized
INFO - 2018-04-15 08:44:10 --> Language Class Initialized
INFO - 2018-04-15 08:44:10 --> Loader Class Initialized
INFO - 2018-04-15 08:44:10 --> Helper loaded: url_helper
INFO - 2018-04-15 08:44:10 --> Helper loaded: file_helper
INFO - 2018-04-15 08:44:11 --> Helper loaded: date_helper
INFO - 2018-04-15 08:44:11 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:44:11 --> Controller Class Initialized
INFO - 2018-04-15 08:44:11 --> Model Class Initialized
INFO - 2018-04-15 08:44:11 --> Final output sent to browser
DEBUG - 2018-04-15 08:44:11 --> Total execution time: 0.6487
INFO - 2018-04-15 08:44:11 --> Config Class Initialized
INFO - 2018-04-15 08:44:11 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:44:11 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:44:11 --> Utf8 Class Initialized
INFO - 2018-04-15 08:44:11 --> URI Class Initialized
INFO - 2018-04-15 08:44:11 --> Router Class Initialized
INFO - 2018-04-15 08:44:11 --> Output Class Initialized
INFO - 2018-04-15 08:44:11 --> Security Class Initialized
DEBUG - 2018-04-15 08:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:44:11 --> Input Class Initialized
INFO - 2018-04-15 08:44:11 --> Language Class Initialized
INFO - 2018-04-15 08:44:11 --> Loader Class Initialized
INFO - 2018-04-15 08:44:11 --> Helper loaded: url_helper
INFO - 2018-04-15 08:44:11 --> Helper loaded: file_helper
INFO - 2018-04-15 08:44:11 --> Helper loaded: date_helper
INFO - 2018-04-15 08:44:11 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:44:11 --> Controller Class Initialized
INFO - 2018-04-15 08:44:11 --> Model Class Initialized
INFO - 2018-04-15 08:44:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:44:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-15 08:44:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:44:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:44:12 --> Final output sent to browser
DEBUG - 2018-04-15 08:44:12 --> Total execution time: 0.5743
INFO - 2018-04-15 08:44:38 --> Config Class Initialized
INFO - 2018-04-15 08:44:38 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:44:38 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:44:38 --> Utf8 Class Initialized
INFO - 2018-04-15 08:44:38 --> URI Class Initialized
INFO - 2018-04-15 08:44:38 --> Router Class Initialized
INFO - 2018-04-15 08:44:38 --> Output Class Initialized
INFO - 2018-04-15 08:44:38 --> Security Class Initialized
DEBUG - 2018-04-15 08:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:44:38 --> Input Class Initialized
INFO - 2018-04-15 08:44:38 --> Language Class Initialized
INFO - 2018-04-15 08:44:38 --> Loader Class Initialized
INFO - 2018-04-15 08:44:38 --> Helper loaded: url_helper
INFO - 2018-04-15 08:44:38 --> Helper loaded: file_helper
INFO - 2018-04-15 08:44:38 --> Helper loaded: date_helper
INFO - 2018-04-15 08:44:38 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:44:38 --> Controller Class Initialized
INFO - 2018-04-15 08:44:39 --> Model Class Initialized
INFO - 2018-04-15 08:44:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:44:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-15 08:44:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:44:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:44:39 --> Final output sent to browser
DEBUG - 2018-04-15 08:44:39 --> Total execution time: 0.5177
INFO - 2018-04-15 08:47:19 --> Config Class Initialized
INFO - 2018-04-15 08:47:19 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:47:19 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:47:19 --> Utf8 Class Initialized
INFO - 2018-04-15 08:47:19 --> URI Class Initialized
INFO - 2018-04-15 08:47:19 --> Router Class Initialized
INFO - 2018-04-15 08:47:19 --> Output Class Initialized
INFO - 2018-04-15 08:47:19 --> Security Class Initialized
DEBUG - 2018-04-15 08:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:47:19 --> Input Class Initialized
INFO - 2018-04-15 08:47:19 --> Language Class Initialized
INFO - 2018-04-15 08:47:19 --> Loader Class Initialized
INFO - 2018-04-15 08:47:19 --> Helper loaded: url_helper
INFO - 2018-04-15 08:47:19 --> Helper loaded: file_helper
INFO - 2018-04-15 08:47:19 --> Helper loaded: date_helper
INFO - 2018-04-15 08:47:19 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:47:19 --> Controller Class Initialized
DEBUG - 2018-04-15 08:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-15 08:47:19 --> Config Class Initialized
INFO - 2018-04-15 08:47:19 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:47:19 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:47:19 --> Utf8 Class Initialized
INFO - 2018-04-15 08:47:19 --> URI Class Initialized
DEBUG - 2018-04-15 08:47:19 --> No URI present. Default controller set.
INFO - 2018-04-15 08:47:19 --> Router Class Initialized
INFO - 2018-04-15 08:47:19 --> Output Class Initialized
INFO - 2018-04-15 08:47:19 --> Security Class Initialized
DEBUG - 2018-04-15 08:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:47:20 --> Input Class Initialized
INFO - 2018-04-15 08:47:20 --> Language Class Initialized
INFO - 2018-04-15 08:47:20 --> Loader Class Initialized
INFO - 2018-04-15 08:47:20 --> Helper loaded: url_helper
INFO - 2018-04-15 08:47:20 --> Helper loaded: file_helper
INFO - 2018-04-15 08:47:20 --> Helper loaded: date_helper
INFO - 2018-04-15 08:47:20 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:47:20 --> Controller Class Initialized
INFO - 2018-04-15 08:47:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:47:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 08:47:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:47:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:47:20 --> Final output sent to browser
DEBUG - 2018-04-15 08:47:20 --> Total execution time: 0.4657
INFO - 2018-04-15 08:47:25 --> Config Class Initialized
INFO - 2018-04-15 08:47:25 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:47:25 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:47:25 --> Utf8 Class Initialized
INFO - 2018-04-15 08:47:25 --> URI Class Initialized
INFO - 2018-04-15 08:47:25 --> Router Class Initialized
INFO - 2018-04-15 08:47:25 --> Output Class Initialized
INFO - 2018-04-15 08:47:25 --> Security Class Initialized
DEBUG - 2018-04-15 08:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:47:25 --> Input Class Initialized
INFO - 2018-04-15 08:47:25 --> Language Class Initialized
INFO - 2018-04-15 08:47:25 --> Loader Class Initialized
INFO - 2018-04-15 08:47:25 --> Helper loaded: url_helper
INFO - 2018-04-15 08:47:25 --> Helper loaded: file_helper
INFO - 2018-04-15 08:47:25 --> Helper loaded: date_helper
INFO - 2018-04-15 08:47:25 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:47:25 --> Controller Class Initialized
INFO - 2018-04-15 08:47:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-15 08:47:25 --> Final output sent to browser
DEBUG - 2018-04-15 08:47:25 --> Total execution time: 0.4099
INFO - 2018-04-15 08:47:35 --> Config Class Initialized
INFO - 2018-04-15 08:47:35 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:47:35 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:47:35 --> Utf8 Class Initialized
INFO - 2018-04-15 08:47:35 --> URI Class Initialized
INFO - 2018-04-15 08:47:35 --> Router Class Initialized
INFO - 2018-04-15 08:47:35 --> Output Class Initialized
INFO - 2018-04-15 08:47:35 --> Security Class Initialized
DEBUG - 2018-04-15 08:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:47:35 --> Input Class Initialized
INFO - 2018-04-15 08:47:35 --> Language Class Initialized
INFO - 2018-04-15 08:47:35 --> Loader Class Initialized
INFO - 2018-04-15 08:47:35 --> Helper loaded: url_helper
INFO - 2018-04-15 08:47:35 --> Helper loaded: file_helper
INFO - 2018-04-15 08:47:35 --> Helper loaded: date_helper
INFO - 2018-04-15 08:47:35 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:47:35 --> Controller Class Initialized
INFO - 2018-04-15 08:47:35 --> Model Class Initialized
INFO - 2018-04-15 08:47:35 --> Final output sent to browser
DEBUG - 2018-04-15 08:47:35 --> Total execution time: 0.3999
INFO - 2018-04-15 08:47:35 --> Config Class Initialized
INFO - 2018-04-15 08:47:35 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:47:35 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:47:35 --> Utf8 Class Initialized
INFO - 2018-04-15 08:47:35 --> URI Class Initialized
INFO - 2018-04-15 08:47:35 --> Router Class Initialized
INFO - 2018-04-15 08:47:35 --> Output Class Initialized
INFO - 2018-04-15 08:47:35 --> Security Class Initialized
DEBUG - 2018-04-15 08:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:47:35 --> Input Class Initialized
INFO - 2018-04-15 08:47:35 --> Language Class Initialized
INFO - 2018-04-15 08:47:35 --> Loader Class Initialized
INFO - 2018-04-15 08:47:35 --> Helper loaded: url_helper
INFO - 2018-04-15 08:47:35 --> Helper loaded: file_helper
INFO - 2018-04-15 08:47:35 --> Helper loaded: date_helper
INFO - 2018-04-15 08:47:36 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:47:36 --> Controller Class Initialized
INFO - 2018-04-15 08:47:36 --> Model Class Initialized
INFO - 2018-04-15 08:47:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-15 08:47:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-15 08:47:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-15 08:47:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-15 08:47:36 --> Final output sent to browser
DEBUG - 2018-04-15 08:47:36 --> Total execution time: 0.6005
INFO - 2018-04-15 08:47:36 --> Config Class Initialized
INFO - 2018-04-15 08:47:36 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:47:36 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:47:36 --> Utf8 Class Initialized
INFO - 2018-04-15 08:47:36 --> URI Class Initialized
INFO - 2018-04-15 08:47:36 --> Router Class Initialized
INFO - 2018-04-15 08:47:36 --> Output Class Initialized
INFO - 2018-04-15 08:47:36 --> Security Class Initialized
DEBUG - 2018-04-15 08:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:47:36 --> Input Class Initialized
INFO - 2018-04-15 08:47:36 --> Language Class Initialized
ERROR - 2018-04-15 08:47:36 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-15 08:51:15 --> Config Class Initialized
INFO - 2018-04-15 08:51:15 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:51:15 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:51:15 --> Utf8 Class Initialized
INFO - 2018-04-15 08:51:15 --> URI Class Initialized
INFO - 2018-04-15 08:51:15 --> Router Class Initialized
INFO - 2018-04-15 08:51:15 --> Output Class Initialized
INFO - 2018-04-15 08:51:15 --> Security Class Initialized
DEBUG - 2018-04-15 08:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:51:15 --> Input Class Initialized
INFO - 2018-04-15 08:51:15 --> Language Class Initialized
INFO - 2018-04-15 08:51:15 --> Loader Class Initialized
INFO - 2018-04-15 08:51:15 --> Helper loaded: url_helper
INFO - 2018-04-15 08:51:15 --> Helper loaded: file_helper
INFO - 2018-04-15 08:51:15 --> Helper loaded: date_helper
INFO - 2018-04-15 08:51:15 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:51:15 --> Controller Class Initialized
DEBUG - 2018-04-15 08:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-15 08:51:15 --> Config Class Initialized
INFO - 2018-04-15 08:51:15 --> Hooks Class Initialized
DEBUG - 2018-04-15 08:51:15 --> UTF-8 Support Enabled
INFO - 2018-04-15 08:51:15 --> Utf8 Class Initialized
INFO - 2018-04-15 08:51:15 --> URI Class Initialized
DEBUG - 2018-04-15 08:51:15 --> No URI present. Default controller set.
INFO - 2018-04-15 08:51:15 --> Router Class Initialized
INFO - 2018-04-15 08:51:15 --> Output Class Initialized
INFO - 2018-04-15 08:51:15 --> Security Class Initialized
DEBUG - 2018-04-15 08:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 08:51:15 --> Input Class Initialized
INFO - 2018-04-15 08:51:15 --> Language Class Initialized
INFO - 2018-04-15 08:51:15 --> Loader Class Initialized
INFO - 2018-04-15 08:51:15 --> Helper loaded: url_helper
INFO - 2018-04-15 08:51:15 --> Helper loaded: file_helper
INFO - 2018-04-15 08:51:15 --> Helper loaded: date_helper
INFO - 2018-04-15 08:51:15 --> Database Driver Class Initialized
DEBUG - 2018-04-15 08:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 08:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 08:51:15 --> Controller Class Initialized
INFO - 2018-04-15 08:51:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 08:51:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 08:51:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 08:51:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 08:51:16 --> Final output sent to browser
DEBUG - 2018-04-15 08:51:16 --> Total execution time: 0.4488
INFO - 2018-04-15 10:48:07 --> Config Class Initialized
INFO - 2018-04-15 10:48:07 --> Hooks Class Initialized
DEBUG - 2018-04-15 10:48:07 --> UTF-8 Support Enabled
INFO - 2018-04-15 10:48:07 --> Utf8 Class Initialized
INFO - 2018-04-15 10:48:07 --> URI Class Initialized
INFO - 2018-04-15 10:48:07 --> Router Class Initialized
INFO - 2018-04-15 10:48:07 --> Output Class Initialized
INFO - 2018-04-15 10:48:07 --> Security Class Initialized
DEBUG - 2018-04-15 10:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 10:48:07 --> Input Class Initialized
INFO - 2018-04-15 10:48:07 --> Language Class Initialized
INFO - 2018-04-15 10:48:07 --> Loader Class Initialized
INFO - 2018-04-15 10:48:08 --> Helper loaded: url_helper
INFO - 2018-04-15 10:48:08 --> Helper loaded: file_helper
INFO - 2018-04-15 10:48:08 --> Helper loaded: date_helper
INFO - 2018-04-15 10:48:08 --> Database Driver Class Initialized
DEBUG - 2018-04-15 10:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 10:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 10:48:08 --> Controller Class Initialized
INFO - 2018-04-15 10:48:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 10:48:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 10:48:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 10:48:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 10:48:08 --> Final output sent to browser
DEBUG - 2018-04-15 10:48:08 --> Total execution time: 1.2870
INFO - 2018-04-15 10:48:57 --> Config Class Initialized
INFO - 2018-04-15 10:48:57 --> Hooks Class Initialized
DEBUG - 2018-04-15 10:48:57 --> UTF-8 Support Enabled
INFO - 2018-04-15 10:48:57 --> Utf8 Class Initialized
INFO - 2018-04-15 10:48:57 --> URI Class Initialized
DEBUG - 2018-04-15 10:48:57 --> No URI present. Default controller set.
INFO - 2018-04-15 10:48:57 --> Router Class Initialized
INFO - 2018-04-15 10:48:57 --> Output Class Initialized
INFO - 2018-04-15 10:48:57 --> Security Class Initialized
DEBUG - 2018-04-15 10:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 10:48:57 --> Input Class Initialized
INFO - 2018-04-15 10:48:57 --> Language Class Initialized
INFO - 2018-04-15 10:48:57 --> Loader Class Initialized
INFO - 2018-04-15 10:48:57 --> Helper loaded: url_helper
INFO - 2018-04-15 10:48:57 --> Helper loaded: file_helper
INFO - 2018-04-15 10:48:57 --> Helper loaded: date_helper
INFO - 2018-04-15 10:48:57 --> Database Driver Class Initialized
DEBUG - 2018-04-15 10:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 10:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 10:48:57 --> Controller Class Initialized
INFO - 2018-04-15 10:48:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 10:48:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 10:48:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 10:48:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 10:48:57 --> Final output sent to browser
DEBUG - 2018-04-15 10:48:57 --> Total execution time: 0.4914
INFO - 2018-04-15 10:48:58 --> Config Class Initialized
INFO - 2018-04-15 10:48:58 --> Hooks Class Initialized
DEBUG - 2018-04-15 10:48:58 --> UTF-8 Support Enabled
INFO - 2018-04-15 10:48:58 --> Utf8 Class Initialized
INFO - 2018-04-15 10:48:58 --> URI Class Initialized
INFO - 2018-04-15 10:48:58 --> Router Class Initialized
INFO - 2018-04-15 10:48:58 --> Output Class Initialized
INFO - 2018-04-15 10:48:58 --> Security Class Initialized
DEBUG - 2018-04-15 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 10:48:58 --> Input Class Initialized
INFO - 2018-04-15 10:48:58 --> Language Class Initialized
INFO - 2018-04-15 10:48:59 --> Loader Class Initialized
INFO - 2018-04-15 10:48:59 --> Helper loaded: url_helper
INFO - 2018-04-15 10:48:59 --> Helper loaded: file_helper
INFO - 2018-04-15 10:48:59 --> Helper loaded: date_helper
INFO - 2018-04-15 10:48:59 --> Database Driver Class Initialized
DEBUG - 2018-04-15 10:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 10:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 10:48:59 --> Controller Class Initialized
INFO - 2018-04-15 10:48:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 10:48:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/donate.php
INFO - 2018-04-15 10:48:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 10:48:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 10:48:59 --> Final output sent to browser
DEBUG - 2018-04-15 10:48:59 --> Total execution time: 0.4943
INFO - 2018-04-15 10:49:00 --> Config Class Initialized
INFO - 2018-04-15 10:49:00 --> Hooks Class Initialized
DEBUG - 2018-04-15 10:49:00 --> UTF-8 Support Enabled
INFO - 2018-04-15 10:49:00 --> Utf8 Class Initialized
INFO - 2018-04-15 10:49:00 --> URI Class Initialized
INFO - 2018-04-15 10:49:00 --> Router Class Initialized
INFO - 2018-04-15 10:49:00 --> Output Class Initialized
INFO - 2018-04-15 10:49:00 --> Security Class Initialized
DEBUG - 2018-04-15 10:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 10:49:00 --> Input Class Initialized
INFO - 2018-04-15 10:49:00 --> Language Class Initialized
INFO - 2018-04-15 10:49:00 --> Loader Class Initialized
INFO - 2018-04-15 10:49:00 --> Helper loaded: url_helper
INFO - 2018-04-15 10:49:00 --> Helper loaded: file_helper
INFO - 2018-04-15 10:49:00 --> Helper loaded: date_helper
INFO - 2018-04-15 10:49:01 --> Database Driver Class Initialized
DEBUG - 2018-04-15 10:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 10:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 10:49:01 --> Controller Class Initialized
INFO - 2018-04-15 10:49:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 10:49:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/need.php
INFO - 2018-04-15 10:49:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 10:49:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 10:49:01 --> Final output sent to browser
DEBUG - 2018-04-15 10:49:01 --> Total execution time: 0.5205
INFO - 2018-04-15 10:49:02 --> Config Class Initialized
INFO - 2018-04-15 10:49:02 --> Hooks Class Initialized
DEBUG - 2018-04-15 10:49:02 --> UTF-8 Support Enabled
INFO - 2018-04-15 10:49:02 --> Utf8 Class Initialized
INFO - 2018-04-15 10:49:02 --> URI Class Initialized
INFO - 2018-04-15 10:49:02 --> Router Class Initialized
INFO - 2018-04-15 10:49:02 --> Output Class Initialized
INFO - 2018-04-15 10:49:02 --> Security Class Initialized
DEBUG - 2018-04-15 10:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 10:49:02 --> Input Class Initialized
INFO - 2018-04-15 10:49:03 --> Language Class Initialized
INFO - 2018-04-15 10:49:03 --> Loader Class Initialized
INFO - 2018-04-15 10:49:03 --> Helper loaded: url_helper
INFO - 2018-04-15 10:49:03 --> Helper loaded: file_helper
INFO - 2018-04-15 10:49:03 --> Helper loaded: date_helper
INFO - 2018-04-15 10:49:03 --> Database Driver Class Initialized
DEBUG - 2018-04-15 10:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 10:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 10:49:03 --> Controller Class Initialized
INFO - 2018-04-15 10:49:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 10:49:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 10:49:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 10:49:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 10:49:03 --> Final output sent to browser
DEBUG - 2018-04-15 10:49:03 --> Total execution time: 0.4940
INFO - 2018-04-15 10:49:04 --> Config Class Initialized
INFO - 2018-04-15 10:49:04 --> Hooks Class Initialized
DEBUG - 2018-04-15 10:49:04 --> UTF-8 Support Enabled
INFO - 2018-04-15 10:49:04 --> Utf8 Class Initialized
INFO - 2018-04-15 10:49:04 --> URI Class Initialized
INFO - 2018-04-15 10:49:04 --> Router Class Initialized
INFO - 2018-04-15 10:49:04 --> Output Class Initialized
INFO - 2018-04-15 10:49:04 --> Security Class Initialized
DEBUG - 2018-04-15 10:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 10:49:04 --> Input Class Initialized
INFO - 2018-04-15 10:49:04 --> Language Class Initialized
INFO - 2018-04-15 10:49:04 --> Loader Class Initialized
INFO - 2018-04-15 10:49:04 --> Helper loaded: url_helper
INFO - 2018-04-15 10:49:04 --> Helper loaded: file_helper
INFO - 2018-04-15 10:49:04 --> Helper loaded: date_helper
INFO - 2018-04-15 10:49:04 --> Database Driver Class Initialized
DEBUG - 2018-04-15 10:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 10:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 10:49:04 --> Controller Class Initialized
INFO - 2018-04-15 10:49:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-15 10:49:04 --> Final output sent to browser
DEBUG - 2018-04-15 10:49:04 --> Total execution time: 0.4040
INFO - 2018-04-15 17:32:24 --> Config Class Initialized
INFO - 2018-04-15 17:32:24 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:32:24 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:32:24 --> Utf8 Class Initialized
INFO - 2018-04-15 17:32:24 --> URI Class Initialized
DEBUG - 2018-04-15 17:32:24 --> No URI present. Default controller set.
INFO - 2018-04-15 17:32:24 --> Router Class Initialized
INFO - 2018-04-15 17:32:24 --> Output Class Initialized
INFO - 2018-04-15 17:32:25 --> Security Class Initialized
DEBUG - 2018-04-15 17:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:32:25 --> Input Class Initialized
INFO - 2018-04-15 17:32:25 --> Language Class Initialized
INFO - 2018-04-15 17:32:25 --> Loader Class Initialized
INFO - 2018-04-15 17:32:25 --> Helper loaded: url_helper
INFO - 2018-04-15 17:32:25 --> Helper loaded: file_helper
INFO - 2018-04-15 17:32:25 --> Helper loaded: date_helper
INFO - 2018-04-15 17:32:26 --> Database Driver Class Initialized
DEBUG - 2018-04-15 17:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 17:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 17:32:26 --> Controller Class Initialized
INFO - 2018-04-15 17:32:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 17:32:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 17:32:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 17:32:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 17:32:26 --> Final output sent to browser
DEBUG - 2018-04-15 17:32:26 --> Total execution time: 2.3819
INFO - 2018-04-15 17:32:30 --> Config Class Initialized
INFO - 2018-04-15 17:32:30 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:32:30 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:32:30 --> Utf8 Class Initialized
INFO - 2018-04-15 17:32:30 --> URI Class Initialized
INFO - 2018-04-15 17:32:30 --> Router Class Initialized
INFO - 2018-04-15 17:32:30 --> Output Class Initialized
INFO - 2018-04-15 17:32:30 --> Security Class Initialized
DEBUG - 2018-04-15 17:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:32:30 --> Input Class Initialized
INFO - 2018-04-15 17:32:30 --> Language Class Initialized
INFO - 2018-04-15 17:32:30 --> Loader Class Initialized
INFO - 2018-04-15 17:32:31 --> Helper loaded: url_helper
INFO - 2018-04-15 17:32:31 --> Helper loaded: file_helper
INFO - 2018-04-15 17:32:31 --> Helper loaded: date_helper
INFO - 2018-04-15 17:32:31 --> Database Driver Class Initialized
DEBUG - 2018-04-15 17:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 17:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 17:32:31 --> Controller Class Initialized
INFO - 2018-04-15 17:32:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 17:32:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/contact.php
INFO - 2018-04-15 17:32:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 17:32:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 17:32:31 --> Final output sent to browser
DEBUG - 2018-04-15 17:32:31 --> Total execution time: 0.4818
INFO - 2018-04-15 17:33:44 --> Config Class Initialized
INFO - 2018-04-15 17:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:33:44 --> Utf8 Class Initialized
INFO - 2018-04-15 17:33:44 --> URI Class Initialized
DEBUG - 2018-04-15 17:33:44 --> No URI present. Default controller set.
INFO - 2018-04-15 17:33:44 --> Router Class Initialized
INFO - 2018-04-15 17:33:44 --> Output Class Initialized
INFO - 2018-04-15 17:33:44 --> Security Class Initialized
DEBUG - 2018-04-15 17:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:33:44 --> Input Class Initialized
INFO - 2018-04-15 17:33:44 --> Language Class Initialized
INFO - 2018-04-15 17:33:44 --> Loader Class Initialized
INFO - 2018-04-15 17:33:44 --> Helper loaded: url_helper
INFO - 2018-04-15 17:33:44 --> Helper loaded: file_helper
INFO - 2018-04-15 17:33:44 --> Helper loaded: date_helper
INFO - 2018-04-15 17:33:44 --> Database Driver Class Initialized
DEBUG - 2018-04-15 17:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 17:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 17:33:44 --> Controller Class Initialized
INFO - 2018-04-15 17:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 17:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 17:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 17:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 17:33:44 --> Final output sent to browser
DEBUG - 2018-04-15 17:33:44 --> Total execution time: 0.5078
INFO - 2018-04-15 17:35:35 --> Config Class Initialized
INFO - 2018-04-15 17:35:35 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:35:35 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:35:35 --> Utf8 Class Initialized
INFO - 2018-04-15 17:35:35 --> URI Class Initialized
DEBUG - 2018-04-15 17:35:35 --> No URI present. Default controller set.
INFO - 2018-04-15 17:35:35 --> Router Class Initialized
INFO - 2018-04-15 17:35:35 --> Output Class Initialized
INFO - 2018-04-15 17:35:35 --> Security Class Initialized
DEBUG - 2018-04-15 17:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:35:35 --> Input Class Initialized
INFO - 2018-04-15 17:35:35 --> Language Class Initialized
INFO - 2018-04-15 17:35:35 --> Loader Class Initialized
INFO - 2018-04-15 17:35:35 --> Helper loaded: url_helper
INFO - 2018-04-15 17:35:35 --> Helper loaded: file_helper
INFO - 2018-04-15 17:35:35 --> Helper loaded: date_helper
INFO - 2018-04-15 17:35:35 --> Database Driver Class Initialized
DEBUG - 2018-04-15 17:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 17:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 17:35:35 --> Controller Class Initialized
INFO - 2018-04-15 17:35:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 17:35:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 17:35:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 17:35:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 17:35:35 --> Final output sent to browser
DEBUG - 2018-04-15 17:35:35 --> Total execution time: 0.6483
INFO - 2018-04-15 17:35:40 --> Config Class Initialized
INFO - 2018-04-15 17:35:40 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:35:40 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:35:40 --> Utf8 Class Initialized
INFO - 2018-04-15 17:35:40 --> URI Class Initialized
INFO - 2018-04-15 17:35:40 --> Router Class Initialized
INFO - 2018-04-15 17:35:40 --> Output Class Initialized
INFO - 2018-04-15 17:35:40 --> Security Class Initialized
DEBUG - 2018-04-15 17:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:35:40 --> Input Class Initialized
INFO - 2018-04-15 17:35:40 --> Language Class Initialized
ERROR - 2018-04-15 17:35:40 --> 404 Page Not Found: Assets/css
INFO - 2018-04-15 17:51:30 --> Config Class Initialized
INFO - 2018-04-15 17:51:30 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:51:30 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:51:30 --> Utf8 Class Initialized
INFO - 2018-04-15 17:51:30 --> URI Class Initialized
DEBUG - 2018-04-15 17:51:30 --> No URI present. Default controller set.
INFO - 2018-04-15 17:51:30 --> Router Class Initialized
INFO - 2018-04-15 17:51:30 --> Output Class Initialized
INFO - 2018-04-15 17:51:30 --> Security Class Initialized
DEBUG - 2018-04-15 17:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:51:30 --> Input Class Initialized
INFO - 2018-04-15 17:51:30 --> Language Class Initialized
INFO - 2018-04-15 17:51:30 --> Loader Class Initialized
INFO - 2018-04-15 17:51:30 --> Helper loaded: url_helper
INFO - 2018-04-15 17:51:30 --> Helper loaded: file_helper
INFO - 2018-04-15 17:51:30 --> Helper loaded: date_helper
INFO - 2018-04-15 17:51:30 --> Database Driver Class Initialized
DEBUG - 2018-04-15 17:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 17:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 17:51:30 --> Controller Class Initialized
INFO - 2018-04-15 17:51:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 17:51:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 17:51:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 17:51:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 17:51:31 --> Final output sent to browser
DEBUG - 2018-04-15 17:51:31 --> Total execution time: 0.8585
INFO - 2018-04-15 17:51:31 --> Config Class Initialized
INFO - 2018-04-15 17:51:31 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:51:31 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:51:31 --> Utf8 Class Initialized
INFO - 2018-04-15 17:51:31 --> URI Class Initialized
INFO - 2018-04-15 17:51:31 --> Router Class Initialized
INFO - 2018-04-15 17:51:31 --> Output Class Initialized
INFO - 2018-04-15 17:51:31 --> Security Class Initialized
DEBUG - 2018-04-15 17:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:51:31 --> Input Class Initialized
INFO - 2018-04-15 17:51:31 --> Language Class Initialized
ERROR - 2018-04-15 17:51:31 --> 404 Page Not Found: Assets/css
INFO - 2018-04-15 17:51:49 --> Config Class Initialized
INFO - 2018-04-15 17:51:49 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:51:50 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:51:50 --> Utf8 Class Initialized
INFO - 2018-04-15 17:51:50 --> URI Class Initialized
DEBUG - 2018-04-15 17:51:50 --> No URI present. Default controller set.
INFO - 2018-04-15 17:51:50 --> Router Class Initialized
INFO - 2018-04-15 17:51:50 --> Output Class Initialized
INFO - 2018-04-15 17:51:50 --> Security Class Initialized
DEBUG - 2018-04-15 17:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:51:50 --> Input Class Initialized
INFO - 2018-04-15 17:51:50 --> Language Class Initialized
INFO - 2018-04-15 17:51:50 --> Loader Class Initialized
INFO - 2018-04-15 17:51:50 --> Helper loaded: url_helper
INFO - 2018-04-15 17:51:50 --> Helper loaded: file_helper
INFO - 2018-04-15 17:51:50 --> Helper loaded: date_helper
INFO - 2018-04-15 17:51:50 --> Database Driver Class Initialized
DEBUG - 2018-04-15 17:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 17:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 17:51:50 --> Controller Class Initialized
INFO - 2018-04-15 17:51:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 17:51:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 17:51:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 17:51:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 17:51:50 --> Final output sent to browser
DEBUG - 2018-04-15 17:51:50 --> Total execution time: 0.5249
INFO - 2018-04-15 17:52:35 --> Config Class Initialized
INFO - 2018-04-15 17:52:35 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:52:35 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:52:35 --> Utf8 Class Initialized
INFO - 2018-04-15 17:52:35 --> URI Class Initialized
DEBUG - 2018-04-15 17:52:35 --> No URI present. Default controller set.
INFO - 2018-04-15 17:52:35 --> Router Class Initialized
INFO - 2018-04-15 17:52:35 --> Output Class Initialized
INFO - 2018-04-15 17:52:35 --> Security Class Initialized
DEBUG - 2018-04-15 17:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:52:35 --> Input Class Initialized
INFO - 2018-04-15 17:52:35 --> Language Class Initialized
INFO - 2018-04-15 17:52:35 --> Loader Class Initialized
INFO - 2018-04-15 17:52:35 --> Helper loaded: url_helper
INFO - 2018-04-15 17:52:35 --> Helper loaded: file_helper
INFO - 2018-04-15 17:52:35 --> Helper loaded: date_helper
INFO - 2018-04-15 17:52:35 --> Database Driver Class Initialized
DEBUG - 2018-04-15 17:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 17:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 17:52:36 --> Controller Class Initialized
INFO - 2018-04-15 17:52:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 17:52:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 17:52:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 17:52:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 17:52:36 --> Final output sent to browser
DEBUG - 2018-04-15 17:52:36 --> Total execution time: 0.5041
INFO - 2018-04-15 17:52:52 --> Config Class Initialized
INFO - 2018-04-15 17:52:52 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:52:52 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:52:52 --> Utf8 Class Initialized
INFO - 2018-04-15 17:52:52 --> URI Class Initialized
DEBUG - 2018-04-15 17:52:52 --> No URI present. Default controller set.
INFO - 2018-04-15 17:52:52 --> Router Class Initialized
INFO - 2018-04-15 17:52:52 --> Output Class Initialized
INFO - 2018-04-15 17:52:52 --> Security Class Initialized
DEBUG - 2018-04-15 17:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:52:52 --> Input Class Initialized
INFO - 2018-04-15 17:52:52 --> Language Class Initialized
INFO - 2018-04-15 17:52:52 --> Loader Class Initialized
INFO - 2018-04-15 17:52:52 --> Helper loaded: url_helper
INFO - 2018-04-15 17:52:53 --> Helper loaded: file_helper
INFO - 2018-04-15 17:52:53 --> Helper loaded: date_helper
INFO - 2018-04-15 17:52:53 --> Database Driver Class Initialized
DEBUG - 2018-04-15 17:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 17:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 17:52:53 --> Controller Class Initialized
INFO - 2018-04-15 17:52:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 17:52:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 17:52:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 17:52:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 17:52:53 --> Final output sent to browser
DEBUG - 2018-04-15 17:52:53 --> Total execution time: 0.7444
INFO - 2018-04-15 17:52:58 --> Config Class Initialized
INFO - 2018-04-15 17:52:58 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:52:58 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:52:58 --> Utf8 Class Initialized
INFO - 2018-04-15 17:52:58 --> URI Class Initialized
INFO - 2018-04-15 17:52:58 --> Router Class Initialized
INFO - 2018-04-15 17:52:58 --> Output Class Initialized
INFO - 2018-04-15 17:52:58 --> Security Class Initialized
DEBUG - 2018-04-15 17:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:52:58 --> Input Class Initialized
INFO - 2018-04-15 17:52:58 --> Language Class Initialized
ERROR - 2018-04-15 17:52:58 --> 404 Page Not Found: Assets/css
INFO - 2018-04-15 17:54:11 --> Config Class Initialized
INFO - 2018-04-15 17:54:11 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:54:11 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:54:11 --> Utf8 Class Initialized
INFO - 2018-04-15 17:54:11 --> URI Class Initialized
DEBUG - 2018-04-15 17:54:11 --> No URI present. Default controller set.
INFO - 2018-04-15 17:54:11 --> Router Class Initialized
INFO - 2018-04-15 17:54:11 --> Output Class Initialized
INFO - 2018-04-15 17:54:11 --> Security Class Initialized
DEBUG - 2018-04-15 17:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:54:11 --> Input Class Initialized
INFO - 2018-04-15 17:54:11 --> Language Class Initialized
INFO - 2018-04-15 17:54:11 --> Loader Class Initialized
INFO - 2018-04-15 17:54:11 --> Helper loaded: url_helper
INFO - 2018-04-15 17:54:11 --> Helper loaded: file_helper
INFO - 2018-04-15 17:54:11 --> Helper loaded: date_helper
INFO - 2018-04-15 17:54:11 --> Database Driver Class Initialized
DEBUG - 2018-04-15 17:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 17:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 17:54:11 --> Controller Class Initialized
INFO - 2018-04-15 17:54:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 17:54:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 17:54:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 17:54:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 17:54:12 --> Final output sent to browser
DEBUG - 2018-04-15 17:54:12 --> Total execution time: 0.9444
INFO - 2018-04-15 17:54:12 --> Config Class Initialized
INFO - 2018-04-15 17:54:12 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:54:12 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:54:12 --> Utf8 Class Initialized
INFO - 2018-04-15 17:54:12 --> URI Class Initialized
INFO - 2018-04-15 17:54:12 --> Router Class Initialized
INFO - 2018-04-15 17:54:12 --> Output Class Initialized
INFO - 2018-04-15 17:54:12 --> Security Class Initialized
DEBUG - 2018-04-15 17:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:54:12 --> Input Class Initialized
INFO - 2018-04-15 17:54:12 --> Language Class Initialized
ERROR - 2018-04-15 17:54:12 --> 404 Page Not Found: Assets/css
INFO - 2018-04-15 17:54:19 --> Config Class Initialized
INFO - 2018-04-15 17:54:19 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:54:19 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:54:19 --> Utf8 Class Initialized
INFO - 2018-04-15 17:54:19 --> URI Class Initialized
INFO - 2018-04-15 17:54:19 --> Router Class Initialized
INFO - 2018-04-15 17:54:19 --> Output Class Initialized
INFO - 2018-04-15 17:54:19 --> Security Class Initialized
DEBUG - 2018-04-15 17:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:54:19 --> Input Class Initialized
INFO - 2018-04-15 17:54:19 --> Language Class Initialized
ERROR - 2018-04-15 17:54:19 --> 404 Page Not Found: Assets/css
INFO - 2018-04-15 17:54:35 --> Config Class Initialized
INFO - 2018-04-15 17:54:35 --> Hooks Class Initialized
DEBUG - 2018-04-15 17:54:35 --> UTF-8 Support Enabled
INFO - 2018-04-15 17:54:35 --> Utf8 Class Initialized
INFO - 2018-04-15 17:54:36 --> URI Class Initialized
DEBUG - 2018-04-15 17:54:36 --> No URI present. Default controller set.
INFO - 2018-04-15 17:54:36 --> Router Class Initialized
INFO - 2018-04-15 17:54:36 --> Output Class Initialized
INFO - 2018-04-15 17:54:36 --> Security Class Initialized
DEBUG - 2018-04-15 17:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-15 17:54:36 --> Input Class Initialized
INFO - 2018-04-15 17:54:36 --> Language Class Initialized
INFO - 2018-04-15 17:54:36 --> Loader Class Initialized
INFO - 2018-04-15 17:54:36 --> Helper loaded: url_helper
INFO - 2018-04-15 17:54:36 --> Helper loaded: file_helper
INFO - 2018-04-15 17:54:36 --> Helper loaded: date_helper
INFO - 2018-04-15 17:54:36 --> Database Driver Class Initialized
DEBUG - 2018-04-15 17:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-15 17:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-15 17:54:36 --> Controller Class Initialized
INFO - 2018-04-15 17:54:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-15 17:54:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/home.php
INFO - 2018-04-15 17:54:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-15 17:54:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-15 17:54:36 --> Final output sent to browser
DEBUG - 2018-04-15 17:54:36 --> Total execution time: 0.5404
