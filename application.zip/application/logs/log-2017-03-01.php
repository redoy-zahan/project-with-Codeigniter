<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-01 14:30:20 --> Config Class Initialized
INFO - 2017-03-01 14:30:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:30:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:30:20 --> Utf8 Class Initialized
INFO - 2017-03-01 14:30:20 --> URI Class Initialized
INFO - 2017-03-01 14:30:20 --> Router Class Initialized
INFO - 2017-03-01 14:30:20 --> Output Class Initialized
INFO - 2017-03-01 14:30:20 --> Security Class Initialized
DEBUG - 2017-03-01 14:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:30:20 --> Input Class Initialized
INFO - 2017-03-01 14:30:20 --> Language Class Initialized
INFO - 2017-03-01 14:30:21 --> Loader Class Initialized
INFO - 2017-03-01 14:30:21 --> Helper loaded: url_helper
INFO - 2017-03-01 14:30:21 --> Helper loaded: file_helper
INFO - 2017-03-01 14:30:21 --> Helper loaded: date_helper
INFO - 2017-03-01 14:30:21 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:30:21 --> Controller Class Initialized
INFO - 2017-03-01 14:30:21 --> Model Class Initialized
DEBUG - 2017-03-01 14:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:30:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-01 14:30:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-01 14:30:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/assign_exam.php
INFO - 2017-03-01 14:30:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-01 14:30:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-01 14:30:21 --> Final output sent to browser
DEBUG - 2017-03-01 14:30:21 --> Total execution time: 0.1481
INFO - 2017-03-01 14:37:00 --> Config Class Initialized
INFO - 2017-03-01 14:37:00 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:37:00 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:37:00 --> Utf8 Class Initialized
INFO - 2017-03-01 14:37:00 --> URI Class Initialized
INFO - 2017-03-01 14:37:00 --> Router Class Initialized
INFO - 2017-03-01 14:37:00 --> Output Class Initialized
INFO - 2017-03-01 14:37:00 --> Security Class Initialized
DEBUG - 2017-03-01 14:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:37:00 --> Input Class Initialized
INFO - 2017-03-01 14:37:00 --> Language Class Initialized
INFO - 2017-03-01 14:37:05 --> Config Class Initialized
INFO - 2017-03-01 14:37:05 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:37:05 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:37:05 --> Utf8 Class Initialized
INFO - 2017-03-01 14:37:05 --> URI Class Initialized
INFO - 2017-03-01 14:37:05 --> Router Class Initialized
INFO - 2017-03-01 14:37:05 --> Output Class Initialized
INFO - 2017-03-01 14:37:05 --> Security Class Initialized
DEBUG - 2017-03-01 14:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:37:05 --> Input Class Initialized
INFO - 2017-03-01 14:37:05 --> Language Class Initialized
INFO - 2017-03-01 14:37:07 --> Config Class Initialized
INFO - 2017-03-01 14:37:07 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:37:07 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:37:07 --> Utf8 Class Initialized
INFO - 2017-03-01 14:37:07 --> URI Class Initialized
DEBUG - 2017-03-01 14:37:07 --> No URI present. Default controller set.
INFO - 2017-03-01 14:37:07 --> Router Class Initialized
INFO - 2017-03-01 14:37:07 --> Output Class Initialized
INFO - 2017-03-01 14:37:07 --> Security Class Initialized
DEBUG - 2017-03-01 14:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:37:07 --> Input Class Initialized
INFO - 2017-03-01 14:37:07 --> Language Class Initialized
INFO - 2017-03-01 14:37:30 --> Config Class Initialized
INFO - 2017-03-01 14:37:30 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:37:30 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:37:30 --> Utf8 Class Initialized
INFO - 2017-03-01 14:37:30 --> URI Class Initialized
DEBUG - 2017-03-01 14:37:30 --> No URI present. Default controller set.
INFO - 2017-03-01 14:37:30 --> Router Class Initialized
INFO - 2017-03-01 14:37:30 --> Output Class Initialized
INFO - 2017-03-01 14:37:30 --> Security Class Initialized
DEBUG - 2017-03-01 14:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:37:30 --> Input Class Initialized
INFO - 2017-03-01 14:37:30 --> Language Class Initialized
INFO - 2017-03-01 14:37:30 --> Loader Class Initialized
INFO - 2017-03-01 14:37:30 --> Helper loaded: url_helper
INFO - 2017-03-01 14:37:30 --> Helper loaded: file_helper
INFO - 2017-03-01 14:37:30 --> Helper loaded: date_helper
INFO - 2017-03-01 14:37:30 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:37:30 --> Controller Class Initialized
INFO - 2017-03-01 14:37:30 --> Config Class Initialized
INFO - 2017-03-01 14:37:30 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:37:30 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:37:30 --> Utf8 Class Initialized
INFO - 2017-03-01 14:37:30 --> URI Class Initialized
INFO - 2017-03-01 14:37:30 --> Router Class Initialized
INFO - 2017-03-01 14:37:30 --> Output Class Initialized
INFO - 2017-03-01 14:37:30 --> Security Class Initialized
DEBUG - 2017-03-01 14:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:37:30 --> Input Class Initialized
INFO - 2017-03-01 14:37:30 --> Language Class Initialized
INFO - 2017-03-01 14:37:30 --> Loader Class Initialized
INFO - 2017-03-01 14:37:30 --> Helper loaded: url_helper
INFO - 2017-03-01 14:37:30 --> Helper loaded: file_helper
INFO - 2017-03-01 14:37:30 --> Helper loaded: date_helper
INFO - 2017-03-01 14:37:30 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:37:30 --> Controller Class Initialized
DEBUG - 2017-03-01 14:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:37:30 --> Config Class Initialized
INFO - 2017-03-01 14:37:30 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:37:30 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:37:30 --> Utf8 Class Initialized
INFO - 2017-03-01 14:37:30 --> URI Class Initialized
INFO - 2017-03-01 14:37:30 --> Router Class Initialized
INFO - 2017-03-01 14:37:30 --> Output Class Initialized
INFO - 2017-03-01 14:37:30 --> Security Class Initialized
DEBUG - 2017-03-01 14:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:37:30 --> Input Class Initialized
INFO - 2017-03-01 14:37:30 --> Language Class Initialized
INFO - 2017-03-01 14:37:30 --> Loader Class Initialized
INFO - 2017-03-01 14:37:30 --> Helper loaded: url_helper
INFO - 2017-03-01 14:37:30 --> Helper loaded: file_helper
INFO - 2017-03-01 14:37:30 --> Helper loaded: date_helper
INFO - 2017-03-01 14:37:30 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:37:30 --> Controller Class Initialized
INFO - 2017-03-01 14:37:30 --> Model Class Initialized
DEBUG - 2017-03-01 14:37:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-01 14:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:37:30 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-01 14:37:30 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-01 14:37:30 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/dashboard.php
INFO - 2017-03-01 14:37:30 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-01 14:37:30 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-01 14:37:30 --> Final output sent to browser
DEBUG - 2017-03-01 14:37:30 --> Total execution time: 0.1661
INFO - 2017-03-01 14:37:33 --> Config Class Initialized
INFO - 2017-03-01 14:37:33 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:37:33 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:37:33 --> Utf8 Class Initialized
INFO - 2017-03-01 14:37:33 --> URI Class Initialized
INFO - 2017-03-01 14:37:33 --> Router Class Initialized
INFO - 2017-03-01 14:37:33 --> Output Class Initialized
INFO - 2017-03-01 14:37:33 --> Security Class Initialized
DEBUG - 2017-03-01 14:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:37:33 --> Input Class Initialized
INFO - 2017-03-01 14:37:33 --> Language Class Initialized
INFO - 2017-03-01 14:37:33 --> Loader Class Initialized
INFO - 2017-03-01 14:37:33 --> Helper loaded: url_helper
INFO - 2017-03-01 14:37:33 --> Helper loaded: file_helper
INFO - 2017-03-01 14:37:33 --> Helper loaded: date_helper
INFO - 2017-03-01 14:37:33 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:37:33 --> Controller Class Initialized
DEBUG - 2017-03-01 14:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:37:33 --> Config Class Initialized
INFO - 2017-03-01 14:37:33 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:37:33 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:37:33 --> Utf8 Class Initialized
INFO - 2017-03-01 14:37:33 --> URI Class Initialized
INFO - 2017-03-01 14:37:33 --> Router Class Initialized
INFO - 2017-03-01 14:37:33 --> Output Class Initialized
INFO - 2017-03-01 14:37:33 --> Security Class Initialized
DEBUG - 2017-03-01 14:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:37:33 --> Input Class Initialized
INFO - 2017-03-01 14:37:33 --> Language Class Initialized
INFO - 2017-03-01 14:37:33 --> Loader Class Initialized
INFO - 2017-03-01 14:37:33 --> Helper loaded: url_helper
INFO - 2017-03-01 14:37:33 --> Helper loaded: file_helper
INFO - 2017-03-01 14:37:33 --> Helper loaded: date_helper
INFO - 2017-03-01 14:37:33 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:37:33 --> Controller Class Initialized
DEBUG - 2017-03-01 14:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:37:33 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-01 14:37:33 --> Final output sent to browser
DEBUG - 2017-03-01 14:37:33 --> Total execution time: 0.1279
INFO - 2017-03-01 14:37:34 --> Config Class Initialized
INFO - 2017-03-01 14:37:34 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:37:34 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:37:34 --> Utf8 Class Initialized
INFO - 2017-03-01 14:37:34 --> URI Class Initialized
INFO - 2017-03-01 14:37:34 --> Router Class Initialized
INFO - 2017-03-01 14:37:34 --> Output Class Initialized
INFO - 2017-03-01 14:37:34 --> Security Class Initialized
DEBUG - 2017-03-01 14:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:37:34 --> Input Class Initialized
INFO - 2017-03-01 14:37:34 --> Language Class Initialized
INFO - 2017-03-01 14:37:34 --> Loader Class Initialized
INFO - 2017-03-01 14:37:34 --> Helper loaded: url_helper
INFO - 2017-03-01 14:37:34 --> Helper loaded: file_helper
INFO - 2017-03-01 14:37:34 --> Helper loaded: date_helper
INFO - 2017-03-01 14:37:34 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:37:34 --> Controller Class Initialized
INFO - 2017-03-01 14:37:34 --> Model Class Initialized
DEBUG - 2017-03-01 14:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:37:34 --> Final output sent to browser
DEBUG - 2017-03-01 14:37:34 --> Total execution time: 0.1430
INFO - 2017-03-01 14:37:34 --> Config Class Initialized
INFO - 2017-03-01 14:37:34 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:37:34 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:37:34 --> Utf8 Class Initialized
INFO - 2017-03-01 14:37:34 --> URI Class Initialized
INFO - 2017-03-01 14:37:34 --> Router Class Initialized
INFO - 2017-03-01 14:37:34 --> Output Class Initialized
INFO - 2017-03-01 14:37:34 --> Security Class Initialized
DEBUG - 2017-03-01 14:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:37:34 --> Input Class Initialized
INFO - 2017-03-01 14:37:34 --> Language Class Initialized
INFO - 2017-03-01 14:37:34 --> Loader Class Initialized
INFO - 2017-03-01 14:37:34 --> Helper loaded: url_helper
INFO - 2017-03-01 14:37:34 --> Helper loaded: file_helper
INFO - 2017-03-01 14:37:34 --> Helper loaded: date_helper
INFO - 2017-03-01 14:37:34 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:37:34 --> Controller Class Initialized
DEBUG - 2017-03-01 14:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:37:34 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-01 14:37:34 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-01 14:37:34 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/dashboard.php
INFO - 2017-03-01 14:37:35 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-01 14:37:35 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-01 14:37:35 --> Final output sent to browser
DEBUG - 2017-03-01 14:37:35 --> Total execution time: 0.1635
INFO - 2017-03-01 14:38:34 --> Config Class Initialized
INFO - 2017-03-01 14:38:34 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:38:34 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:38:34 --> Utf8 Class Initialized
INFO - 2017-03-01 14:38:34 --> URI Class Initialized
INFO - 2017-03-01 14:38:34 --> Router Class Initialized
INFO - 2017-03-01 14:38:34 --> Output Class Initialized
INFO - 2017-03-01 14:38:34 --> Security Class Initialized
DEBUG - 2017-03-01 14:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:38:34 --> Input Class Initialized
INFO - 2017-03-01 14:38:34 --> Language Class Initialized
INFO - 2017-03-01 14:38:34 --> Loader Class Initialized
INFO - 2017-03-01 14:38:34 --> Helper loaded: url_helper
INFO - 2017-03-01 14:38:34 --> Helper loaded: file_helper
INFO - 2017-03-01 14:38:34 --> Helper loaded: date_helper
INFO - 2017-03-01 14:38:34 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:38:34 --> Controller Class Initialized
DEBUG - 2017-03-01 14:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:38:34 --> Config Class Initialized
INFO - 2017-03-01 14:38:34 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:38:34 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:38:34 --> Utf8 Class Initialized
INFO - 2017-03-01 14:38:34 --> URI Class Initialized
INFO - 2017-03-01 14:38:34 --> Router Class Initialized
INFO - 2017-03-01 14:38:34 --> Output Class Initialized
INFO - 2017-03-01 14:38:34 --> Security Class Initialized
DEBUG - 2017-03-01 14:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:38:34 --> Input Class Initialized
INFO - 2017-03-01 14:38:34 --> Language Class Initialized
INFO - 2017-03-01 14:38:34 --> Loader Class Initialized
INFO - 2017-03-01 14:38:34 --> Helper loaded: url_helper
INFO - 2017-03-01 14:38:34 --> Helper loaded: file_helper
INFO - 2017-03-01 14:38:34 --> Helper loaded: date_helper
INFO - 2017-03-01 14:38:34 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:38:34 --> Controller Class Initialized
DEBUG - 2017-03-01 14:38:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:38:34 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-01 14:38:34 --> Final output sent to browser
DEBUG - 2017-03-01 14:38:34 --> Total execution time: 0.1324
INFO - 2017-03-01 14:38:39 --> Config Class Initialized
INFO - 2017-03-01 14:38:39 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:38:39 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:38:39 --> Utf8 Class Initialized
INFO - 2017-03-01 14:38:39 --> URI Class Initialized
INFO - 2017-03-01 14:38:39 --> Router Class Initialized
INFO - 2017-03-01 14:38:39 --> Output Class Initialized
INFO - 2017-03-01 14:38:39 --> Security Class Initialized
DEBUG - 2017-03-01 14:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:38:39 --> Input Class Initialized
INFO - 2017-03-01 14:38:39 --> Language Class Initialized
INFO - 2017-03-01 14:38:39 --> Loader Class Initialized
INFO - 2017-03-01 14:38:39 --> Helper loaded: url_helper
INFO - 2017-03-01 14:38:39 --> Helper loaded: file_helper
INFO - 2017-03-01 14:38:39 --> Helper loaded: date_helper
INFO - 2017-03-01 14:38:39 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:38:39 --> Controller Class Initialized
INFO - 2017-03-01 14:38:39 --> Model Class Initialized
DEBUG - 2017-03-01 14:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:38:39 --> Config Class Initialized
INFO - 2017-03-01 14:38:39 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:38:39 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:38:39 --> Utf8 Class Initialized
INFO - 2017-03-01 14:38:39 --> URI Class Initialized
INFO - 2017-03-01 14:38:39 --> Router Class Initialized
INFO - 2017-03-01 14:38:39 --> Output Class Initialized
INFO - 2017-03-01 14:38:39 --> Security Class Initialized
DEBUG - 2017-03-01 14:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:38:39 --> Input Class Initialized
INFO - 2017-03-01 14:38:39 --> Language Class Initialized
INFO - 2017-03-01 14:38:39 --> Loader Class Initialized
INFO - 2017-03-01 14:38:39 --> Helper loaded: url_helper
INFO - 2017-03-01 14:38:39 --> Helper loaded: file_helper
INFO - 2017-03-01 14:38:39 --> Helper loaded: date_helper
INFO - 2017-03-01 14:38:39 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:38:39 --> Controller Class Initialized
INFO - 2017-03-01 14:38:39 --> Model Class Initialized
DEBUG - 2017-03-01 14:38:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-01 14:38:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:38:39 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-01 14:38:39 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-01 14:38:39 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/dashboard.php
INFO - 2017-03-01 14:38:39 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-01 14:38:39 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-01 14:38:39 --> Final output sent to browser
DEBUG - 2017-03-01 14:38:39 --> Total execution time: 0.1614
INFO - 2017-03-01 14:38:48 --> Config Class Initialized
INFO - 2017-03-01 14:38:48 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:38:48 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:38:48 --> Utf8 Class Initialized
INFO - 2017-03-01 14:38:48 --> URI Class Initialized
INFO - 2017-03-01 14:38:48 --> Router Class Initialized
INFO - 2017-03-01 14:38:48 --> Output Class Initialized
INFO - 2017-03-01 14:38:48 --> Security Class Initialized
DEBUG - 2017-03-01 14:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:38:48 --> Input Class Initialized
INFO - 2017-03-01 14:38:48 --> Language Class Initialized
INFO - 2017-03-01 14:38:48 --> Loader Class Initialized
INFO - 2017-03-01 14:38:48 --> Helper loaded: url_helper
INFO - 2017-03-01 14:38:48 --> Helper loaded: file_helper
INFO - 2017-03-01 14:38:48 --> Helper loaded: date_helper
INFO - 2017-03-01 14:38:48 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:38:48 --> Controller Class Initialized
INFO - 2017-03-01 14:38:48 --> Config Class Initialized
INFO - 2017-03-01 14:38:48 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:38:48 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:38:48 --> Utf8 Class Initialized
INFO - 2017-03-01 14:38:48 --> URI Class Initialized
INFO - 2017-03-01 14:38:48 --> Router Class Initialized
INFO - 2017-03-01 14:38:48 --> Output Class Initialized
INFO - 2017-03-01 14:38:48 --> Security Class Initialized
DEBUG - 2017-03-01 14:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:38:48 --> Input Class Initialized
INFO - 2017-03-01 14:38:48 --> Language Class Initialized
INFO - 2017-03-01 14:38:48 --> Loader Class Initialized
INFO - 2017-03-01 14:38:48 --> Helper loaded: url_helper
INFO - 2017-03-01 14:38:48 --> Helper loaded: file_helper
INFO - 2017-03-01 14:38:48 --> Helper loaded: date_helper
INFO - 2017-03-01 14:38:48 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:38:48 --> Controller Class Initialized
INFO - 2017-03-01 14:38:48 --> Model Class Initialized
DEBUG - 2017-03-01 14:38:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-01 14:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:38:48 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-01 14:38:48 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-01 14:38:48 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/dashboard.php
INFO - 2017-03-01 14:38:48 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-01 14:38:48 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-01 14:38:48 --> Final output sent to browser
DEBUG - 2017-03-01 14:38:48 --> Total execution time: 0.1641
INFO - 2017-03-01 14:39:41 --> Config Class Initialized
INFO - 2017-03-01 14:39:41 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:41 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:41 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:41 --> URI Class Initialized
INFO - 2017-03-01 14:39:41 --> Router Class Initialized
INFO - 2017-03-01 14:39:41 --> Output Class Initialized
INFO - 2017-03-01 14:39:41 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:41 --> Input Class Initialized
INFO - 2017-03-01 14:39:41 --> Language Class Initialized
INFO - 2017-03-01 14:39:41 --> Loader Class Initialized
INFO - 2017-03-01 14:39:41 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:41 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:41 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:41 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:41 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:41 --> Config Class Initialized
INFO - 2017-03-01 14:39:41 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:41 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:41 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:41 --> URI Class Initialized
INFO - 2017-03-01 14:39:41 --> Router Class Initialized
INFO - 2017-03-01 14:39:41 --> Output Class Initialized
INFO - 2017-03-01 14:39:41 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:41 --> Input Class Initialized
INFO - 2017-03-01 14:39:41 --> Language Class Initialized
INFO - 2017-03-01 14:39:41 --> Loader Class Initialized
INFO - 2017-03-01 14:39:41 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:41 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:41 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:41 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:41 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:41 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-01 14:39:41 --> Final output sent to browser
DEBUG - 2017-03-01 14:39:41 --> Total execution time: 0.1384
INFO - 2017-03-01 14:39:43 --> Config Class Initialized
INFO - 2017-03-01 14:39:43 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:43 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:43 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:43 --> URI Class Initialized
INFO - 2017-03-01 14:39:43 --> Router Class Initialized
INFO - 2017-03-01 14:39:43 --> Output Class Initialized
INFO - 2017-03-01 14:39:43 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:43 --> Input Class Initialized
INFO - 2017-03-01 14:39:43 --> Language Class Initialized
INFO - 2017-03-01 14:39:43 --> Loader Class Initialized
INFO - 2017-03-01 14:39:43 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:43 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:43 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:43 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:43 --> Controller Class Initialized
INFO - 2017-03-01 14:39:43 --> Model Class Initialized
DEBUG - 2017-03-01 14:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:43 --> Final output sent to browser
DEBUG - 2017-03-01 14:39:43 --> Total execution time: 0.1505
INFO - 2017-03-01 14:39:43 --> Config Class Initialized
INFO - 2017-03-01 14:39:43 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:43 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:43 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:43 --> URI Class Initialized
INFO - 2017-03-01 14:39:43 --> Router Class Initialized
INFO - 2017-03-01 14:39:43 --> Output Class Initialized
INFO - 2017-03-01 14:39:43 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:43 --> Input Class Initialized
INFO - 2017-03-01 14:39:43 --> Language Class Initialized
INFO - 2017-03-01 14:39:43 --> Loader Class Initialized
INFO - 2017-03-01 14:39:43 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:43 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:43 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:43 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:43 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:43 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-01 14:39:43 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-01 14:39:43 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/dashboard.php
INFO - 2017-03-01 14:39:43 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-01 14:39:43 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-01 14:39:43 --> Final output sent to browser
DEBUG - 2017-03-01 14:39:43 --> Total execution time: 0.1638
INFO - 2017-03-01 14:39:52 --> Config Class Initialized
INFO - 2017-03-01 14:39:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:52 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:52 --> URI Class Initialized
DEBUG - 2017-03-01 14:39:52 --> No URI present. Default controller set.
INFO - 2017-03-01 14:39:52 --> Router Class Initialized
INFO - 2017-03-01 14:39:52 --> Output Class Initialized
INFO - 2017-03-01 14:39:52 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:52 --> Input Class Initialized
INFO - 2017-03-01 14:39:52 --> Language Class Initialized
INFO - 2017-03-01 14:39:52 --> Loader Class Initialized
INFO - 2017-03-01 14:39:52 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:52 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:52 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:52 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:52 --> Controller Class Initialized
INFO - 2017-03-01 14:39:52 --> Config Class Initialized
INFO - 2017-03-01 14:39:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:52 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:52 --> URI Class Initialized
INFO - 2017-03-01 14:39:52 --> Router Class Initialized
INFO - 2017-03-01 14:39:52 --> Output Class Initialized
INFO - 2017-03-01 14:39:52 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:52 --> Input Class Initialized
INFO - 2017-03-01 14:39:52 --> Language Class Initialized
INFO - 2017-03-01 14:39:52 --> Loader Class Initialized
INFO - 2017-03-01 14:39:52 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:52 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:52 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:52 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:52 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:52 --> Config Class Initialized
INFO - 2017-03-01 14:39:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:52 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:52 --> URI Class Initialized
INFO - 2017-03-01 14:39:52 --> Router Class Initialized
INFO - 2017-03-01 14:39:52 --> Output Class Initialized
INFO - 2017-03-01 14:39:52 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:52 --> Input Class Initialized
INFO - 2017-03-01 14:39:52 --> Language Class Initialized
INFO - 2017-03-01 14:39:52 --> Loader Class Initialized
INFO - 2017-03-01 14:39:52 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:52 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:52 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:52 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:52 --> Controller Class Initialized
INFO - 2017-03-01 14:39:52 --> Config Class Initialized
INFO - 2017-03-01 14:39:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:52 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:52 --> URI Class Initialized
INFO - 2017-03-01 14:39:52 --> Router Class Initialized
INFO - 2017-03-01 14:39:52 --> Output Class Initialized
INFO - 2017-03-01 14:39:52 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:52 --> Input Class Initialized
INFO - 2017-03-01 14:39:52 --> Language Class Initialized
INFO - 2017-03-01 14:39:52 --> Loader Class Initialized
INFO - 2017-03-01 14:39:52 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:52 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:52 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:52 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:52 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:52 --> Config Class Initialized
INFO - 2017-03-01 14:39:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:52 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:52 --> URI Class Initialized
INFO - 2017-03-01 14:39:52 --> Router Class Initialized
INFO - 2017-03-01 14:39:52 --> Output Class Initialized
INFO - 2017-03-01 14:39:52 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:52 --> Input Class Initialized
INFO - 2017-03-01 14:39:52 --> Language Class Initialized
INFO - 2017-03-01 14:39:52 --> Loader Class Initialized
INFO - 2017-03-01 14:39:52 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:52 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:52 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:52 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:52 --> Controller Class Initialized
INFO - 2017-03-01 14:39:52 --> Config Class Initialized
INFO - 2017-03-01 14:39:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:52 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:52 --> URI Class Initialized
INFO - 2017-03-01 14:39:52 --> Router Class Initialized
INFO - 2017-03-01 14:39:52 --> Output Class Initialized
INFO - 2017-03-01 14:39:52 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:52 --> Input Class Initialized
INFO - 2017-03-01 14:39:52 --> Language Class Initialized
INFO - 2017-03-01 14:39:53 --> Loader Class Initialized
INFO - 2017-03-01 14:39:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:53 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:53 --> Config Class Initialized
INFO - 2017-03-01 14:39:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:53 --> URI Class Initialized
INFO - 2017-03-01 14:39:53 --> Router Class Initialized
INFO - 2017-03-01 14:39:53 --> Output Class Initialized
INFO - 2017-03-01 14:39:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:53 --> Input Class Initialized
INFO - 2017-03-01 14:39:53 --> Language Class Initialized
INFO - 2017-03-01 14:39:53 --> Loader Class Initialized
INFO - 2017-03-01 14:39:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:53 --> Controller Class Initialized
INFO - 2017-03-01 14:39:53 --> Config Class Initialized
INFO - 2017-03-01 14:39:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:53 --> URI Class Initialized
INFO - 2017-03-01 14:39:53 --> Router Class Initialized
INFO - 2017-03-01 14:39:53 --> Output Class Initialized
INFO - 2017-03-01 14:39:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:53 --> Input Class Initialized
INFO - 2017-03-01 14:39:53 --> Language Class Initialized
INFO - 2017-03-01 14:39:53 --> Loader Class Initialized
INFO - 2017-03-01 14:39:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:53 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:53 --> Config Class Initialized
INFO - 2017-03-01 14:39:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:53 --> URI Class Initialized
INFO - 2017-03-01 14:39:53 --> Router Class Initialized
INFO - 2017-03-01 14:39:53 --> Output Class Initialized
INFO - 2017-03-01 14:39:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:53 --> Input Class Initialized
INFO - 2017-03-01 14:39:53 --> Language Class Initialized
INFO - 2017-03-01 14:39:53 --> Loader Class Initialized
INFO - 2017-03-01 14:39:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:53 --> Controller Class Initialized
INFO - 2017-03-01 14:39:53 --> Config Class Initialized
INFO - 2017-03-01 14:39:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:53 --> URI Class Initialized
INFO - 2017-03-01 14:39:53 --> Router Class Initialized
INFO - 2017-03-01 14:39:53 --> Output Class Initialized
INFO - 2017-03-01 14:39:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:53 --> Input Class Initialized
INFO - 2017-03-01 14:39:53 --> Language Class Initialized
INFO - 2017-03-01 14:39:53 --> Loader Class Initialized
INFO - 2017-03-01 14:39:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:53 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:53 --> Config Class Initialized
INFO - 2017-03-01 14:39:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:53 --> URI Class Initialized
INFO - 2017-03-01 14:39:53 --> Router Class Initialized
INFO - 2017-03-01 14:39:53 --> Output Class Initialized
INFO - 2017-03-01 14:39:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:53 --> Input Class Initialized
INFO - 2017-03-01 14:39:53 --> Language Class Initialized
INFO - 2017-03-01 14:39:53 --> Loader Class Initialized
INFO - 2017-03-01 14:39:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:53 --> Controller Class Initialized
INFO - 2017-03-01 14:39:53 --> Config Class Initialized
INFO - 2017-03-01 14:39:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:53 --> URI Class Initialized
INFO - 2017-03-01 14:39:53 --> Router Class Initialized
INFO - 2017-03-01 14:39:53 --> Output Class Initialized
INFO - 2017-03-01 14:39:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:53 --> Input Class Initialized
INFO - 2017-03-01 14:39:53 --> Language Class Initialized
INFO - 2017-03-01 14:39:53 --> Loader Class Initialized
INFO - 2017-03-01 14:39:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:53 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:53 --> Config Class Initialized
INFO - 2017-03-01 14:39:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:53 --> URI Class Initialized
INFO - 2017-03-01 14:39:53 --> Router Class Initialized
INFO - 2017-03-01 14:39:54 --> Output Class Initialized
INFO - 2017-03-01 14:39:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:54 --> Input Class Initialized
INFO - 2017-03-01 14:39:54 --> Language Class Initialized
INFO - 2017-03-01 14:39:54 --> Loader Class Initialized
INFO - 2017-03-01 14:39:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:54 --> Controller Class Initialized
INFO - 2017-03-01 14:39:54 --> Config Class Initialized
INFO - 2017-03-01 14:39:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:54 --> URI Class Initialized
INFO - 2017-03-01 14:39:54 --> Router Class Initialized
INFO - 2017-03-01 14:39:54 --> Output Class Initialized
INFO - 2017-03-01 14:39:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:54 --> Input Class Initialized
INFO - 2017-03-01 14:39:54 --> Language Class Initialized
INFO - 2017-03-01 14:39:54 --> Loader Class Initialized
INFO - 2017-03-01 14:39:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:54 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:54 --> Config Class Initialized
INFO - 2017-03-01 14:39:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:54 --> URI Class Initialized
INFO - 2017-03-01 14:39:54 --> Router Class Initialized
INFO - 2017-03-01 14:39:54 --> Output Class Initialized
INFO - 2017-03-01 14:39:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:54 --> Input Class Initialized
INFO - 2017-03-01 14:39:54 --> Language Class Initialized
INFO - 2017-03-01 14:39:54 --> Loader Class Initialized
INFO - 2017-03-01 14:39:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:54 --> Controller Class Initialized
INFO - 2017-03-01 14:39:54 --> Config Class Initialized
INFO - 2017-03-01 14:39:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:54 --> URI Class Initialized
INFO - 2017-03-01 14:39:54 --> Router Class Initialized
INFO - 2017-03-01 14:39:54 --> Output Class Initialized
INFO - 2017-03-01 14:39:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:54 --> Input Class Initialized
INFO - 2017-03-01 14:39:54 --> Language Class Initialized
INFO - 2017-03-01 14:39:54 --> Loader Class Initialized
INFO - 2017-03-01 14:39:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:54 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:54 --> Config Class Initialized
INFO - 2017-03-01 14:39:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:54 --> URI Class Initialized
INFO - 2017-03-01 14:39:54 --> Router Class Initialized
INFO - 2017-03-01 14:39:54 --> Output Class Initialized
INFO - 2017-03-01 14:39:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:54 --> Input Class Initialized
INFO - 2017-03-01 14:39:54 --> Language Class Initialized
INFO - 2017-03-01 14:39:54 --> Loader Class Initialized
INFO - 2017-03-01 14:39:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:54 --> Controller Class Initialized
INFO - 2017-03-01 14:39:54 --> Config Class Initialized
INFO - 2017-03-01 14:39:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:54 --> URI Class Initialized
INFO - 2017-03-01 14:39:54 --> Router Class Initialized
INFO - 2017-03-01 14:39:54 --> Output Class Initialized
INFO - 2017-03-01 14:39:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:54 --> Input Class Initialized
INFO - 2017-03-01 14:39:54 --> Language Class Initialized
INFO - 2017-03-01 14:39:54 --> Loader Class Initialized
INFO - 2017-03-01 14:39:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:54 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:54 --> Config Class Initialized
INFO - 2017-03-01 14:39:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:54 --> URI Class Initialized
INFO - 2017-03-01 14:39:54 --> Router Class Initialized
INFO - 2017-03-01 14:39:54 --> Output Class Initialized
INFO - 2017-03-01 14:39:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:54 --> Input Class Initialized
INFO - 2017-03-01 14:39:54 --> Language Class Initialized
INFO - 2017-03-01 14:39:54 --> Loader Class Initialized
INFO - 2017-03-01 14:39:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:54 --> Controller Class Initialized
INFO - 2017-03-01 14:39:54 --> Config Class Initialized
INFO - 2017-03-01 14:39:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:54 --> URI Class Initialized
INFO - 2017-03-01 14:39:54 --> Router Class Initialized
INFO - 2017-03-01 14:39:55 --> Output Class Initialized
INFO - 2017-03-01 14:39:55 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:55 --> Input Class Initialized
INFO - 2017-03-01 14:39:55 --> Language Class Initialized
INFO - 2017-03-01 14:39:55 --> Loader Class Initialized
INFO - 2017-03-01 14:39:55 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:55 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:55 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:55 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:55 --> Controller Class Initialized
DEBUG - 2017-03-01 14:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:39:55 --> Config Class Initialized
INFO - 2017-03-01 14:39:55 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:39:55 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:39:55 --> Utf8 Class Initialized
INFO - 2017-03-01 14:39:55 --> URI Class Initialized
INFO - 2017-03-01 14:39:55 --> Router Class Initialized
INFO - 2017-03-01 14:39:55 --> Output Class Initialized
INFO - 2017-03-01 14:39:55 --> Security Class Initialized
DEBUG - 2017-03-01 14:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:39:55 --> Input Class Initialized
INFO - 2017-03-01 14:39:55 --> Language Class Initialized
INFO - 2017-03-01 14:39:55 --> Loader Class Initialized
INFO - 2017-03-01 14:39:55 --> Helper loaded: url_helper
INFO - 2017-03-01 14:39:55 --> Helper loaded: file_helper
INFO - 2017-03-01 14:39:55 --> Helper loaded: date_helper
INFO - 2017-03-01 14:39:55 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:39:55 --> Controller Class Initialized
INFO - 2017-03-01 14:40:18 --> Config Class Initialized
INFO - 2017-03-01 14:40:18 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:18 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:18 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:18 --> URI Class Initialized
DEBUG - 2017-03-01 14:40:18 --> No URI present. Default controller set.
INFO - 2017-03-01 14:40:18 --> Router Class Initialized
INFO - 2017-03-01 14:40:18 --> Output Class Initialized
INFO - 2017-03-01 14:40:18 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:18 --> Input Class Initialized
INFO - 2017-03-01 14:40:18 --> Language Class Initialized
INFO - 2017-03-01 14:40:19 --> Loader Class Initialized
INFO - 2017-03-01 14:40:19 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:19 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:19 --> Controller Class Initialized
INFO - 2017-03-01 14:40:19 --> Config Class Initialized
INFO - 2017-03-01 14:40:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:19 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:19 --> URI Class Initialized
INFO - 2017-03-01 14:40:19 --> Router Class Initialized
INFO - 2017-03-01 14:40:19 --> Output Class Initialized
INFO - 2017-03-01 14:40:19 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:19 --> Input Class Initialized
INFO - 2017-03-01 14:40:19 --> Language Class Initialized
INFO - 2017-03-01 14:40:19 --> Loader Class Initialized
INFO - 2017-03-01 14:40:19 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:19 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:19 --> Controller Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:40:19 --> Config Class Initialized
INFO - 2017-03-01 14:40:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:19 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:19 --> URI Class Initialized
INFO - 2017-03-01 14:40:19 --> Router Class Initialized
INFO - 2017-03-01 14:40:19 --> Output Class Initialized
INFO - 2017-03-01 14:40:19 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:19 --> Input Class Initialized
INFO - 2017-03-01 14:40:19 --> Language Class Initialized
INFO - 2017-03-01 14:40:19 --> Loader Class Initialized
INFO - 2017-03-01 14:40:19 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:19 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:19 --> Controller Class Initialized
INFO - 2017-03-01 14:40:19 --> Config Class Initialized
INFO - 2017-03-01 14:40:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:19 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:19 --> URI Class Initialized
INFO - 2017-03-01 14:40:19 --> Router Class Initialized
INFO - 2017-03-01 14:40:19 --> Output Class Initialized
INFO - 2017-03-01 14:40:19 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:19 --> Input Class Initialized
INFO - 2017-03-01 14:40:19 --> Language Class Initialized
INFO - 2017-03-01 14:40:19 --> Loader Class Initialized
INFO - 2017-03-01 14:40:19 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:19 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:19 --> Controller Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:40:19 --> Config Class Initialized
INFO - 2017-03-01 14:40:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:19 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:19 --> URI Class Initialized
INFO - 2017-03-01 14:40:19 --> Router Class Initialized
INFO - 2017-03-01 14:40:19 --> Output Class Initialized
INFO - 2017-03-01 14:40:19 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:19 --> Input Class Initialized
INFO - 2017-03-01 14:40:19 --> Language Class Initialized
INFO - 2017-03-01 14:40:19 --> Loader Class Initialized
INFO - 2017-03-01 14:40:19 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:19 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:19 --> Controller Class Initialized
INFO - 2017-03-01 14:40:19 --> Config Class Initialized
INFO - 2017-03-01 14:40:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:19 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:19 --> URI Class Initialized
INFO - 2017-03-01 14:40:19 --> Router Class Initialized
INFO - 2017-03-01 14:40:19 --> Output Class Initialized
INFO - 2017-03-01 14:40:19 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:19 --> Input Class Initialized
INFO - 2017-03-01 14:40:19 --> Language Class Initialized
INFO - 2017-03-01 14:40:19 --> Loader Class Initialized
INFO - 2017-03-01 14:40:19 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:19 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:19 --> Controller Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:40:19 --> Config Class Initialized
INFO - 2017-03-01 14:40:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:19 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:19 --> URI Class Initialized
INFO - 2017-03-01 14:40:19 --> Router Class Initialized
INFO - 2017-03-01 14:40:19 --> Output Class Initialized
INFO - 2017-03-01 14:40:19 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:19 --> Input Class Initialized
INFO - 2017-03-01 14:40:19 --> Language Class Initialized
INFO - 2017-03-01 14:40:19 --> Loader Class Initialized
INFO - 2017-03-01 14:40:19 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:19 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:19 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:19 --> Controller Class Initialized
INFO - 2017-03-01 14:40:19 --> Config Class Initialized
INFO - 2017-03-01 14:40:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:19 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:19 --> URI Class Initialized
INFO - 2017-03-01 14:40:19 --> Router Class Initialized
INFO - 2017-03-01 14:40:19 --> Output Class Initialized
INFO - 2017-03-01 14:40:19 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:20 --> Input Class Initialized
INFO - 2017-03-01 14:40:20 --> Language Class Initialized
INFO - 2017-03-01 14:40:20 --> Loader Class Initialized
INFO - 2017-03-01 14:40:20 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:20 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:20 --> Controller Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:40:20 --> Config Class Initialized
INFO - 2017-03-01 14:40:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:20 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:20 --> URI Class Initialized
INFO - 2017-03-01 14:40:20 --> Router Class Initialized
INFO - 2017-03-01 14:40:20 --> Output Class Initialized
INFO - 2017-03-01 14:40:20 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:20 --> Input Class Initialized
INFO - 2017-03-01 14:40:20 --> Language Class Initialized
INFO - 2017-03-01 14:40:20 --> Loader Class Initialized
INFO - 2017-03-01 14:40:20 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:20 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:20 --> Controller Class Initialized
INFO - 2017-03-01 14:40:20 --> Config Class Initialized
INFO - 2017-03-01 14:40:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:20 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:20 --> URI Class Initialized
INFO - 2017-03-01 14:40:20 --> Router Class Initialized
INFO - 2017-03-01 14:40:20 --> Output Class Initialized
INFO - 2017-03-01 14:40:20 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:20 --> Input Class Initialized
INFO - 2017-03-01 14:40:20 --> Language Class Initialized
INFO - 2017-03-01 14:40:20 --> Loader Class Initialized
INFO - 2017-03-01 14:40:20 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:20 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:20 --> Controller Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:40:20 --> Config Class Initialized
INFO - 2017-03-01 14:40:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:20 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:20 --> URI Class Initialized
INFO - 2017-03-01 14:40:20 --> Router Class Initialized
INFO - 2017-03-01 14:40:20 --> Output Class Initialized
INFO - 2017-03-01 14:40:20 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:20 --> Input Class Initialized
INFO - 2017-03-01 14:40:20 --> Language Class Initialized
INFO - 2017-03-01 14:40:20 --> Loader Class Initialized
INFO - 2017-03-01 14:40:20 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:20 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:20 --> Controller Class Initialized
INFO - 2017-03-01 14:40:20 --> Config Class Initialized
INFO - 2017-03-01 14:40:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:20 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:20 --> URI Class Initialized
INFO - 2017-03-01 14:40:20 --> Router Class Initialized
INFO - 2017-03-01 14:40:20 --> Output Class Initialized
INFO - 2017-03-01 14:40:20 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:20 --> Input Class Initialized
INFO - 2017-03-01 14:40:20 --> Language Class Initialized
INFO - 2017-03-01 14:40:20 --> Loader Class Initialized
INFO - 2017-03-01 14:40:20 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:20 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:20 --> Controller Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:40:20 --> Config Class Initialized
INFO - 2017-03-01 14:40:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:20 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:20 --> URI Class Initialized
INFO - 2017-03-01 14:40:20 --> Router Class Initialized
INFO - 2017-03-01 14:40:20 --> Output Class Initialized
INFO - 2017-03-01 14:40:20 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:20 --> Input Class Initialized
INFO - 2017-03-01 14:40:20 --> Language Class Initialized
INFO - 2017-03-01 14:40:20 --> Loader Class Initialized
INFO - 2017-03-01 14:40:20 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:20 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:20 --> Controller Class Initialized
INFO - 2017-03-01 14:40:20 --> Config Class Initialized
INFO - 2017-03-01 14:40:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:20 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:20 --> URI Class Initialized
INFO - 2017-03-01 14:40:20 --> Router Class Initialized
INFO - 2017-03-01 14:40:20 --> Output Class Initialized
INFO - 2017-03-01 14:40:20 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:20 --> Input Class Initialized
INFO - 2017-03-01 14:40:20 --> Language Class Initialized
INFO - 2017-03-01 14:40:20 --> Loader Class Initialized
INFO - 2017-03-01 14:40:20 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:20 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:20 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:20 --> Controller Class Initialized
DEBUG - 2017-03-01 14:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:40:20 --> Config Class Initialized
INFO - 2017-03-01 14:40:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:20 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:21 --> URI Class Initialized
INFO - 2017-03-01 14:40:21 --> Router Class Initialized
INFO - 2017-03-01 14:40:21 --> Output Class Initialized
INFO - 2017-03-01 14:40:21 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:21 --> Input Class Initialized
INFO - 2017-03-01 14:40:21 --> Language Class Initialized
INFO - 2017-03-01 14:40:21 --> Loader Class Initialized
INFO - 2017-03-01 14:40:21 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:21 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:21 --> Controller Class Initialized
INFO - 2017-03-01 14:40:21 --> Config Class Initialized
INFO - 2017-03-01 14:40:21 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:21 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:21 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:21 --> URI Class Initialized
INFO - 2017-03-01 14:40:21 --> Router Class Initialized
INFO - 2017-03-01 14:40:21 --> Output Class Initialized
INFO - 2017-03-01 14:40:21 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:21 --> Input Class Initialized
INFO - 2017-03-01 14:40:21 --> Language Class Initialized
INFO - 2017-03-01 14:40:21 --> Loader Class Initialized
INFO - 2017-03-01 14:40:21 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:21 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:21 --> Controller Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:40:21 --> Config Class Initialized
INFO - 2017-03-01 14:40:21 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:21 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:21 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:21 --> URI Class Initialized
INFO - 2017-03-01 14:40:21 --> Router Class Initialized
INFO - 2017-03-01 14:40:21 --> Output Class Initialized
INFO - 2017-03-01 14:40:21 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:21 --> Input Class Initialized
INFO - 2017-03-01 14:40:21 --> Language Class Initialized
INFO - 2017-03-01 14:40:21 --> Loader Class Initialized
INFO - 2017-03-01 14:40:21 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:21 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:21 --> Controller Class Initialized
INFO - 2017-03-01 14:40:21 --> Config Class Initialized
INFO - 2017-03-01 14:40:21 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:21 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:21 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:21 --> URI Class Initialized
INFO - 2017-03-01 14:40:21 --> Router Class Initialized
INFO - 2017-03-01 14:40:21 --> Output Class Initialized
INFO - 2017-03-01 14:40:21 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:21 --> Input Class Initialized
INFO - 2017-03-01 14:40:21 --> Language Class Initialized
INFO - 2017-03-01 14:40:21 --> Loader Class Initialized
INFO - 2017-03-01 14:40:21 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:21 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:21 --> Controller Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:40:21 --> Config Class Initialized
INFO - 2017-03-01 14:40:21 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:21 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:21 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:21 --> URI Class Initialized
INFO - 2017-03-01 14:40:21 --> Router Class Initialized
INFO - 2017-03-01 14:40:21 --> Output Class Initialized
INFO - 2017-03-01 14:40:21 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:21 --> Input Class Initialized
INFO - 2017-03-01 14:40:21 --> Language Class Initialized
INFO - 2017-03-01 14:40:21 --> Loader Class Initialized
INFO - 2017-03-01 14:40:21 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:21 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:21 --> Controller Class Initialized
INFO - 2017-03-01 14:40:21 --> Config Class Initialized
INFO - 2017-03-01 14:40:21 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:21 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:21 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:21 --> URI Class Initialized
INFO - 2017-03-01 14:40:21 --> Router Class Initialized
INFO - 2017-03-01 14:40:21 --> Output Class Initialized
INFO - 2017-03-01 14:40:21 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:21 --> Input Class Initialized
INFO - 2017-03-01 14:40:21 --> Language Class Initialized
INFO - 2017-03-01 14:40:21 --> Loader Class Initialized
INFO - 2017-03-01 14:40:21 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:21 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:21 --> Controller Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:40:21 --> Config Class Initialized
INFO - 2017-03-01 14:40:21 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:40:21 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:40:21 --> Utf8 Class Initialized
INFO - 2017-03-01 14:40:21 --> URI Class Initialized
INFO - 2017-03-01 14:40:21 --> Router Class Initialized
INFO - 2017-03-01 14:40:21 --> Output Class Initialized
INFO - 2017-03-01 14:40:21 --> Security Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:40:21 --> Input Class Initialized
INFO - 2017-03-01 14:40:21 --> Language Class Initialized
INFO - 2017-03-01 14:40:21 --> Loader Class Initialized
INFO - 2017-03-01 14:40:21 --> Helper loaded: url_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: file_helper
INFO - 2017-03-01 14:40:21 --> Helper loaded: date_helper
INFO - 2017-03-01 14:40:21 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:40:21 --> Controller Class Initialized
INFO - 2017-03-01 14:42:52 --> Config Class Initialized
INFO - 2017-03-01 14:42:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:52 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:52 --> URI Class Initialized
INFO - 2017-03-01 14:42:52 --> Router Class Initialized
INFO - 2017-03-01 14:42:52 --> Output Class Initialized
INFO - 2017-03-01 14:42:52 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:52 --> Input Class Initialized
INFO - 2017-03-01 14:42:52 --> Language Class Initialized
INFO - 2017-03-01 14:42:52 --> Loader Class Initialized
INFO - 2017-03-01 14:42:52 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:52 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:52 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:52 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:52 --> Controller Class Initialized
INFO - 2017-03-01 14:42:52 --> Config Class Initialized
INFO - 2017-03-01 14:42:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:52 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:52 --> URI Class Initialized
INFO - 2017-03-01 14:42:52 --> Router Class Initialized
INFO - 2017-03-01 14:42:52 --> Output Class Initialized
INFO - 2017-03-01 14:42:52 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:52 --> Input Class Initialized
INFO - 2017-03-01 14:42:52 --> Language Class Initialized
INFO - 2017-03-01 14:42:52 --> Loader Class Initialized
INFO - 2017-03-01 14:42:52 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:52 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:52 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:52 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:52 --> Controller Class Initialized
INFO - 2017-03-01 14:42:52 --> Config Class Initialized
INFO - 2017-03-01 14:42:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:52 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:52 --> URI Class Initialized
INFO - 2017-03-01 14:42:52 --> Router Class Initialized
INFO - 2017-03-01 14:42:52 --> Output Class Initialized
INFO - 2017-03-01 14:42:52 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:52 --> Input Class Initialized
INFO - 2017-03-01 14:42:52 --> Language Class Initialized
INFO - 2017-03-01 14:42:52 --> Loader Class Initialized
INFO - 2017-03-01 14:42:52 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:52 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:53 --> Controller Class Initialized
INFO - 2017-03-01 14:42:53 --> Config Class Initialized
INFO - 2017-03-01 14:42:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:53 --> URI Class Initialized
INFO - 2017-03-01 14:42:53 --> Router Class Initialized
INFO - 2017-03-01 14:42:53 --> Output Class Initialized
INFO - 2017-03-01 14:42:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:53 --> Input Class Initialized
INFO - 2017-03-01 14:42:53 --> Language Class Initialized
INFO - 2017-03-01 14:42:53 --> Loader Class Initialized
INFO - 2017-03-01 14:42:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:53 --> Controller Class Initialized
INFO - 2017-03-01 14:42:53 --> Config Class Initialized
INFO - 2017-03-01 14:42:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:53 --> URI Class Initialized
INFO - 2017-03-01 14:42:53 --> Router Class Initialized
INFO - 2017-03-01 14:42:53 --> Output Class Initialized
INFO - 2017-03-01 14:42:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:53 --> Input Class Initialized
INFO - 2017-03-01 14:42:53 --> Language Class Initialized
INFO - 2017-03-01 14:42:53 --> Loader Class Initialized
INFO - 2017-03-01 14:42:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:53 --> Controller Class Initialized
INFO - 2017-03-01 14:42:53 --> Config Class Initialized
INFO - 2017-03-01 14:42:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:53 --> URI Class Initialized
INFO - 2017-03-01 14:42:53 --> Router Class Initialized
INFO - 2017-03-01 14:42:53 --> Output Class Initialized
INFO - 2017-03-01 14:42:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:53 --> Input Class Initialized
INFO - 2017-03-01 14:42:53 --> Language Class Initialized
INFO - 2017-03-01 14:42:53 --> Loader Class Initialized
INFO - 2017-03-01 14:42:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:53 --> Controller Class Initialized
INFO - 2017-03-01 14:42:53 --> Config Class Initialized
INFO - 2017-03-01 14:42:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:53 --> URI Class Initialized
INFO - 2017-03-01 14:42:53 --> Router Class Initialized
INFO - 2017-03-01 14:42:53 --> Output Class Initialized
INFO - 2017-03-01 14:42:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:53 --> Input Class Initialized
INFO - 2017-03-01 14:42:53 --> Language Class Initialized
INFO - 2017-03-01 14:42:53 --> Loader Class Initialized
INFO - 2017-03-01 14:42:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:53 --> Controller Class Initialized
INFO - 2017-03-01 14:42:53 --> Config Class Initialized
INFO - 2017-03-01 14:42:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:53 --> URI Class Initialized
INFO - 2017-03-01 14:42:53 --> Router Class Initialized
INFO - 2017-03-01 14:42:53 --> Output Class Initialized
INFO - 2017-03-01 14:42:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:53 --> Input Class Initialized
INFO - 2017-03-01 14:42:53 --> Language Class Initialized
INFO - 2017-03-01 14:42:53 --> Loader Class Initialized
INFO - 2017-03-01 14:42:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:53 --> Controller Class Initialized
INFO - 2017-03-01 14:42:53 --> Config Class Initialized
INFO - 2017-03-01 14:42:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:53 --> URI Class Initialized
INFO - 2017-03-01 14:42:53 --> Router Class Initialized
INFO - 2017-03-01 14:42:53 --> Output Class Initialized
INFO - 2017-03-01 14:42:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:53 --> Input Class Initialized
INFO - 2017-03-01 14:42:53 --> Language Class Initialized
INFO - 2017-03-01 14:42:53 --> Loader Class Initialized
INFO - 2017-03-01 14:42:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:53 --> Controller Class Initialized
INFO - 2017-03-01 14:42:53 --> Config Class Initialized
INFO - 2017-03-01 14:42:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:53 --> URI Class Initialized
INFO - 2017-03-01 14:42:53 --> Router Class Initialized
INFO - 2017-03-01 14:42:53 --> Output Class Initialized
INFO - 2017-03-01 14:42:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:53 --> Input Class Initialized
INFO - 2017-03-01 14:42:53 --> Language Class Initialized
INFO - 2017-03-01 14:42:54 --> Loader Class Initialized
INFO - 2017-03-01 14:42:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:54 --> Controller Class Initialized
INFO - 2017-03-01 14:42:54 --> Config Class Initialized
INFO - 2017-03-01 14:42:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:54 --> URI Class Initialized
INFO - 2017-03-01 14:42:54 --> Router Class Initialized
INFO - 2017-03-01 14:42:54 --> Output Class Initialized
INFO - 2017-03-01 14:42:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:54 --> Input Class Initialized
INFO - 2017-03-01 14:42:54 --> Language Class Initialized
INFO - 2017-03-01 14:42:54 --> Loader Class Initialized
INFO - 2017-03-01 14:42:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:54 --> Controller Class Initialized
INFO - 2017-03-01 14:42:54 --> Config Class Initialized
INFO - 2017-03-01 14:42:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:54 --> URI Class Initialized
INFO - 2017-03-01 14:42:54 --> Router Class Initialized
INFO - 2017-03-01 14:42:54 --> Output Class Initialized
INFO - 2017-03-01 14:42:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:54 --> Input Class Initialized
INFO - 2017-03-01 14:42:54 --> Language Class Initialized
INFO - 2017-03-01 14:42:54 --> Loader Class Initialized
INFO - 2017-03-01 14:42:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:54 --> Controller Class Initialized
INFO - 2017-03-01 14:42:54 --> Config Class Initialized
INFO - 2017-03-01 14:42:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:54 --> URI Class Initialized
INFO - 2017-03-01 14:42:54 --> Router Class Initialized
INFO - 2017-03-01 14:42:54 --> Output Class Initialized
INFO - 2017-03-01 14:42:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:54 --> Input Class Initialized
INFO - 2017-03-01 14:42:54 --> Language Class Initialized
INFO - 2017-03-01 14:42:54 --> Loader Class Initialized
INFO - 2017-03-01 14:42:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:54 --> Controller Class Initialized
INFO - 2017-03-01 14:42:54 --> Config Class Initialized
INFO - 2017-03-01 14:42:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:54 --> URI Class Initialized
INFO - 2017-03-01 14:42:54 --> Router Class Initialized
INFO - 2017-03-01 14:42:54 --> Output Class Initialized
INFO - 2017-03-01 14:42:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:54 --> Input Class Initialized
INFO - 2017-03-01 14:42:54 --> Language Class Initialized
INFO - 2017-03-01 14:42:54 --> Loader Class Initialized
INFO - 2017-03-01 14:42:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:54 --> Controller Class Initialized
INFO - 2017-03-01 14:42:54 --> Config Class Initialized
INFO - 2017-03-01 14:42:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:54 --> URI Class Initialized
INFO - 2017-03-01 14:42:54 --> Router Class Initialized
INFO - 2017-03-01 14:42:54 --> Output Class Initialized
INFO - 2017-03-01 14:42:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:54 --> Input Class Initialized
INFO - 2017-03-01 14:42:54 --> Language Class Initialized
INFO - 2017-03-01 14:42:54 --> Loader Class Initialized
INFO - 2017-03-01 14:42:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:54 --> Controller Class Initialized
INFO - 2017-03-01 14:42:54 --> Config Class Initialized
INFO - 2017-03-01 14:42:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:54 --> URI Class Initialized
INFO - 2017-03-01 14:42:54 --> Router Class Initialized
INFO - 2017-03-01 14:42:54 --> Output Class Initialized
INFO - 2017-03-01 14:42:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:54 --> Input Class Initialized
INFO - 2017-03-01 14:42:54 --> Language Class Initialized
INFO - 2017-03-01 14:42:54 --> Loader Class Initialized
INFO - 2017-03-01 14:42:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:54 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:54 --> Controller Class Initialized
INFO - 2017-03-01 14:42:54 --> Config Class Initialized
INFO - 2017-03-01 14:42:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:55 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:55 --> URI Class Initialized
INFO - 2017-03-01 14:42:55 --> Router Class Initialized
INFO - 2017-03-01 14:42:55 --> Output Class Initialized
INFO - 2017-03-01 14:42:55 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:55 --> Input Class Initialized
INFO - 2017-03-01 14:42:55 --> Language Class Initialized
INFO - 2017-03-01 14:42:55 --> Loader Class Initialized
INFO - 2017-03-01 14:42:55 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:55 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:55 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:55 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:55 --> Controller Class Initialized
INFO - 2017-03-01 14:42:55 --> Config Class Initialized
INFO - 2017-03-01 14:42:55 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:55 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:55 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:55 --> URI Class Initialized
INFO - 2017-03-01 14:42:55 --> Router Class Initialized
INFO - 2017-03-01 14:42:55 --> Output Class Initialized
INFO - 2017-03-01 14:42:55 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:55 --> Input Class Initialized
INFO - 2017-03-01 14:42:55 --> Language Class Initialized
INFO - 2017-03-01 14:42:55 --> Loader Class Initialized
INFO - 2017-03-01 14:42:55 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:55 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:55 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:55 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:55 --> Controller Class Initialized
INFO - 2017-03-01 14:42:55 --> Config Class Initialized
INFO - 2017-03-01 14:42:55 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:55 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:55 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:55 --> URI Class Initialized
INFO - 2017-03-01 14:42:55 --> Router Class Initialized
INFO - 2017-03-01 14:42:55 --> Output Class Initialized
INFO - 2017-03-01 14:42:55 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:55 --> Input Class Initialized
INFO - 2017-03-01 14:42:55 --> Language Class Initialized
INFO - 2017-03-01 14:42:55 --> Loader Class Initialized
INFO - 2017-03-01 14:42:55 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:55 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:55 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:55 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:55 --> Controller Class Initialized
INFO - 2017-03-01 14:42:55 --> Config Class Initialized
INFO - 2017-03-01 14:42:55 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:55 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:55 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:55 --> URI Class Initialized
INFO - 2017-03-01 14:42:55 --> Router Class Initialized
INFO - 2017-03-01 14:42:55 --> Output Class Initialized
INFO - 2017-03-01 14:42:55 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:55 --> Input Class Initialized
INFO - 2017-03-01 14:42:55 --> Language Class Initialized
INFO - 2017-03-01 14:42:55 --> Loader Class Initialized
INFO - 2017-03-01 14:42:55 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:55 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:55 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:55 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:55 --> Controller Class Initialized
INFO - 2017-03-01 14:42:55 --> Config Class Initialized
INFO - 2017-03-01 14:42:55 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:55 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:55 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:55 --> URI Class Initialized
INFO - 2017-03-01 14:42:55 --> Router Class Initialized
INFO - 2017-03-01 14:42:55 --> Output Class Initialized
INFO - 2017-03-01 14:42:55 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:55 --> Input Class Initialized
INFO - 2017-03-01 14:42:55 --> Language Class Initialized
INFO - 2017-03-01 14:42:55 --> Loader Class Initialized
INFO - 2017-03-01 14:42:55 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:55 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:55 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:55 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:55 --> Controller Class Initialized
INFO - 2017-03-01 14:42:59 --> Config Class Initialized
INFO - 2017-03-01 14:42:59 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:59 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:59 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:59 --> URI Class Initialized
DEBUG - 2017-03-01 14:42:59 --> No URI present. Default controller set.
INFO - 2017-03-01 14:42:59 --> Router Class Initialized
INFO - 2017-03-01 14:42:59 --> Output Class Initialized
INFO - 2017-03-01 14:42:59 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:59 --> Input Class Initialized
INFO - 2017-03-01 14:42:59 --> Language Class Initialized
INFO - 2017-03-01 14:42:59 --> Loader Class Initialized
INFO - 2017-03-01 14:42:59 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:59 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:59 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:59 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:59 --> Controller Class Initialized
INFO - 2017-03-01 14:42:59 --> Config Class Initialized
INFO - 2017-03-01 14:42:59 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:59 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:59 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:59 --> URI Class Initialized
INFO - 2017-03-01 14:42:59 --> Router Class Initialized
INFO - 2017-03-01 14:42:59 --> Output Class Initialized
INFO - 2017-03-01 14:42:59 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:59 --> Input Class Initialized
INFO - 2017-03-01 14:42:59 --> Language Class Initialized
INFO - 2017-03-01 14:42:59 --> Loader Class Initialized
INFO - 2017-03-01 14:42:59 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:59 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:59 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:59 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:59 --> Controller Class Initialized
INFO - 2017-03-01 14:42:59 --> Config Class Initialized
INFO - 2017-03-01 14:42:59 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:59 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:59 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:59 --> URI Class Initialized
INFO - 2017-03-01 14:42:59 --> Router Class Initialized
INFO - 2017-03-01 14:42:59 --> Output Class Initialized
INFO - 2017-03-01 14:42:59 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:59 --> Input Class Initialized
INFO - 2017-03-01 14:42:59 --> Language Class Initialized
INFO - 2017-03-01 14:42:59 --> Loader Class Initialized
INFO - 2017-03-01 14:42:59 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:59 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:59 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:59 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:59 --> Controller Class Initialized
INFO - 2017-03-01 14:42:59 --> Config Class Initialized
INFO - 2017-03-01 14:42:59 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:59 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:59 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:59 --> URI Class Initialized
INFO - 2017-03-01 14:42:59 --> Router Class Initialized
INFO - 2017-03-01 14:42:59 --> Output Class Initialized
INFO - 2017-03-01 14:42:59 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:59 --> Input Class Initialized
INFO - 2017-03-01 14:42:59 --> Language Class Initialized
INFO - 2017-03-01 14:42:59 --> Loader Class Initialized
INFO - 2017-03-01 14:42:59 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:59 --> Helper loaded: file_helper
INFO - 2017-03-01 14:42:59 --> Helper loaded: date_helper
INFO - 2017-03-01 14:42:59 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:59 --> Controller Class Initialized
INFO - 2017-03-01 14:42:59 --> Config Class Initialized
INFO - 2017-03-01 14:42:59 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:59 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:00 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:00 --> URI Class Initialized
INFO - 2017-03-01 14:43:00 --> Router Class Initialized
INFO - 2017-03-01 14:43:00 --> Output Class Initialized
INFO - 2017-03-01 14:43:00 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:00 --> Input Class Initialized
INFO - 2017-03-01 14:43:00 --> Language Class Initialized
INFO - 2017-03-01 14:43:00 --> Loader Class Initialized
INFO - 2017-03-01 14:43:00 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:00 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:00 --> Controller Class Initialized
INFO - 2017-03-01 14:43:00 --> Config Class Initialized
INFO - 2017-03-01 14:43:00 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:00 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:00 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:00 --> URI Class Initialized
INFO - 2017-03-01 14:43:00 --> Router Class Initialized
INFO - 2017-03-01 14:43:00 --> Output Class Initialized
INFO - 2017-03-01 14:43:00 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:00 --> Input Class Initialized
INFO - 2017-03-01 14:43:00 --> Language Class Initialized
INFO - 2017-03-01 14:43:00 --> Loader Class Initialized
INFO - 2017-03-01 14:43:00 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:00 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:00 --> Controller Class Initialized
INFO - 2017-03-01 14:43:00 --> Config Class Initialized
INFO - 2017-03-01 14:43:00 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:00 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:00 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:00 --> URI Class Initialized
INFO - 2017-03-01 14:43:00 --> Router Class Initialized
INFO - 2017-03-01 14:43:00 --> Output Class Initialized
INFO - 2017-03-01 14:43:00 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:00 --> Input Class Initialized
INFO - 2017-03-01 14:43:00 --> Language Class Initialized
INFO - 2017-03-01 14:43:00 --> Loader Class Initialized
INFO - 2017-03-01 14:43:00 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:00 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:00 --> Controller Class Initialized
INFO - 2017-03-01 14:43:00 --> Config Class Initialized
INFO - 2017-03-01 14:43:00 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:00 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:00 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:00 --> URI Class Initialized
INFO - 2017-03-01 14:43:00 --> Router Class Initialized
INFO - 2017-03-01 14:43:00 --> Output Class Initialized
INFO - 2017-03-01 14:43:00 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:00 --> Input Class Initialized
INFO - 2017-03-01 14:43:00 --> Language Class Initialized
INFO - 2017-03-01 14:43:00 --> Loader Class Initialized
INFO - 2017-03-01 14:43:00 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:00 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:00 --> Controller Class Initialized
INFO - 2017-03-01 14:43:00 --> Config Class Initialized
INFO - 2017-03-01 14:43:00 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:00 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:00 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:00 --> URI Class Initialized
INFO - 2017-03-01 14:43:00 --> Router Class Initialized
INFO - 2017-03-01 14:43:00 --> Output Class Initialized
INFO - 2017-03-01 14:43:00 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:00 --> Input Class Initialized
INFO - 2017-03-01 14:43:00 --> Language Class Initialized
INFO - 2017-03-01 14:43:00 --> Loader Class Initialized
INFO - 2017-03-01 14:43:00 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:00 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:00 --> Controller Class Initialized
INFO - 2017-03-01 14:43:00 --> Config Class Initialized
INFO - 2017-03-01 14:43:00 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:00 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:00 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:00 --> URI Class Initialized
INFO - 2017-03-01 14:43:00 --> Router Class Initialized
INFO - 2017-03-01 14:43:00 --> Output Class Initialized
INFO - 2017-03-01 14:43:00 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:00 --> Input Class Initialized
INFO - 2017-03-01 14:43:00 --> Language Class Initialized
INFO - 2017-03-01 14:43:00 --> Loader Class Initialized
INFO - 2017-03-01 14:43:00 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:00 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:00 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:00 --> Controller Class Initialized
INFO - 2017-03-01 14:43:00 --> Config Class Initialized
INFO - 2017-03-01 14:43:00 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:00 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:00 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:00 --> URI Class Initialized
INFO - 2017-03-01 14:43:00 --> Router Class Initialized
INFO - 2017-03-01 14:43:00 --> Output Class Initialized
INFO - 2017-03-01 14:43:00 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:00 --> Input Class Initialized
INFO - 2017-03-01 14:43:01 --> Language Class Initialized
INFO - 2017-03-01 14:43:01 --> Loader Class Initialized
INFO - 2017-03-01 14:43:01 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:01 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:01 --> Controller Class Initialized
INFO - 2017-03-01 14:43:01 --> Config Class Initialized
INFO - 2017-03-01 14:43:01 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:01 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:01 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:01 --> URI Class Initialized
INFO - 2017-03-01 14:43:01 --> Router Class Initialized
INFO - 2017-03-01 14:43:01 --> Output Class Initialized
INFO - 2017-03-01 14:43:01 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:01 --> Input Class Initialized
INFO - 2017-03-01 14:43:01 --> Language Class Initialized
INFO - 2017-03-01 14:43:01 --> Loader Class Initialized
INFO - 2017-03-01 14:43:01 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:01 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:01 --> Controller Class Initialized
INFO - 2017-03-01 14:43:01 --> Config Class Initialized
INFO - 2017-03-01 14:43:01 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:01 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:01 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:01 --> URI Class Initialized
INFO - 2017-03-01 14:43:01 --> Router Class Initialized
INFO - 2017-03-01 14:43:01 --> Output Class Initialized
INFO - 2017-03-01 14:43:01 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:01 --> Input Class Initialized
INFO - 2017-03-01 14:43:01 --> Language Class Initialized
INFO - 2017-03-01 14:43:01 --> Loader Class Initialized
INFO - 2017-03-01 14:43:01 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:01 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:01 --> Controller Class Initialized
INFO - 2017-03-01 14:43:01 --> Config Class Initialized
INFO - 2017-03-01 14:43:01 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:01 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:01 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:01 --> URI Class Initialized
INFO - 2017-03-01 14:43:01 --> Router Class Initialized
INFO - 2017-03-01 14:43:01 --> Output Class Initialized
INFO - 2017-03-01 14:43:01 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:01 --> Input Class Initialized
INFO - 2017-03-01 14:43:01 --> Language Class Initialized
INFO - 2017-03-01 14:43:01 --> Loader Class Initialized
INFO - 2017-03-01 14:43:01 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:01 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:01 --> Controller Class Initialized
INFO - 2017-03-01 14:43:01 --> Config Class Initialized
INFO - 2017-03-01 14:43:01 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:01 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:01 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:01 --> URI Class Initialized
INFO - 2017-03-01 14:43:01 --> Router Class Initialized
INFO - 2017-03-01 14:43:01 --> Output Class Initialized
INFO - 2017-03-01 14:43:01 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:01 --> Input Class Initialized
INFO - 2017-03-01 14:43:01 --> Language Class Initialized
INFO - 2017-03-01 14:43:01 --> Loader Class Initialized
INFO - 2017-03-01 14:43:01 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:01 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:01 --> Controller Class Initialized
INFO - 2017-03-01 14:43:01 --> Config Class Initialized
INFO - 2017-03-01 14:43:01 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:01 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:01 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:01 --> URI Class Initialized
INFO - 2017-03-01 14:43:01 --> Router Class Initialized
INFO - 2017-03-01 14:43:01 --> Output Class Initialized
INFO - 2017-03-01 14:43:01 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:01 --> Input Class Initialized
INFO - 2017-03-01 14:43:01 --> Language Class Initialized
INFO - 2017-03-01 14:43:01 --> Loader Class Initialized
INFO - 2017-03-01 14:43:01 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:01 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:01 --> Controller Class Initialized
INFO - 2017-03-01 14:43:01 --> Config Class Initialized
INFO - 2017-03-01 14:43:01 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:01 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:01 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:01 --> URI Class Initialized
INFO - 2017-03-01 14:43:01 --> Router Class Initialized
INFO - 2017-03-01 14:43:01 --> Output Class Initialized
INFO - 2017-03-01 14:43:01 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:01 --> Input Class Initialized
INFO - 2017-03-01 14:43:01 --> Language Class Initialized
INFO - 2017-03-01 14:43:01 --> Loader Class Initialized
INFO - 2017-03-01 14:43:01 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:01 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:01 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:02 --> Controller Class Initialized
INFO - 2017-03-01 14:43:02 --> Config Class Initialized
INFO - 2017-03-01 14:43:02 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:02 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:02 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:02 --> URI Class Initialized
INFO - 2017-03-01 14:43:02 --> Router Class Initialized
INFO - 2017-03-01 14:43:02 --> Output Class Initialized
INFO - 2017-03-01 14:43:02 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:02 --> Input Class Initialized
INFO - 2017-03-01 14:43:02 --> Language Class Initialized
INFO - 2017-03-01 14:43:02 --> Loader Class Initialized
INFO - 2017-03-01 14:43:02 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:02 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:02 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:02 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:02 --> Controller Class Initialized
INFO - 2017-03-01 14:43:02 --> Config Class Initialized
INFO - 2017-03-01 14:43:02 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:02 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:02 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:02 --> URI Class Initialized
INFO - 2017-03-01 14:43:02 --> Router Class Initialized
INFO - 2017-03-01 14:43:02 --> Output Class Initialized
INFO - 2017-03-01 14:43:02 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:02 --> Input Class Initialized
INFO - 2017-03-01 14:43:02 --> Language Class Initialized
INFO - 2017-03-01 14:43:02 --> Loader Class Initialized
INFO - 2017-03-01 14:43:02 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:02 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:02 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:02 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:02 --> Controller Class Initialized
INFO - 2017-03-01 14:43:02 --> Config Class Initialized
INFO - 2017-03-01 14:43:02 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:02 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:02 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:02 --> URI Class Initialized
INFO - 2017-03-01 14:43:02 --> Router Class Initialized
INFO - 2017-03-01 14:43:02 --> Output Class Initialized
INFO - 2017-03-01 14:43:02 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:02 --> Input Class Initialized
INFO - 2017-03-01 14:43:02 --> Language Class Initialized
INFO - 2017-03-01 14:43:02 --> Loader Class Initialized
INFO - 2017-03-01 14:43:02 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:02 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:02 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:02 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:02 --> Controller Class Initialized
INFO - 2017-03-01 14:43:02 --> Config Class Initialized
INFO - 2017-03-01 14:43:02 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:02 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:02 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:02 --> URI Class Initialized
INFO - 2017-03-01 14:43:02 --> Router Class Initialized
INFO - 2017-03-01 14:43:02 --> Output Class Initialized
INFO - 2017-03-01 14:43:02 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:02 --> Input Class Initialized
INFO - 2017-03-01 14:43:02 --> Language Class Initialized
INFO - 2017-03-01 14:43:02 --> Loader Class Initialized
INFO - 2017-03-01 14:43:02 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:02 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:02 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:02 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:02 --> Controller Class Initialized
INFO - 2017-03-01 14:43:18 --> Config Class Initialized
INFO - 2017-03-01 14:43:18 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:18 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:18 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:18 --> URI Class Initialized
INFO - 2017-03-01 14:43:18 --> Router Class Initialized
INFO - 2017-03-01 14:43:18 --> Output Class Initialized
INFO - 2017-03-01 14:43:18 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:18 --> Input Class Initialized
INFO - 2017-03-01 14:43:18 --> Language Class Initialized
INFO - 2017-03-01 14:43:18 --> Loader Class Initialized
INFO - 2017-03-01 14:43:18 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:19 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:19 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:19 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:19 --> Controller Class Initialized
DEBUG - 2017-03-01 14:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:43:19 --> Config Class Initialized
INFO - 2017-03-01 14:43:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:19 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:19 --> URI Class Initialized
INFO - 2017-03-01 14:43:19 --> Router Class Initialized
INFO - 2017-03-01 14:43:19 --> Output Class Initialized
INFO - 2017-03-01 14:43:19 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:19 --> Input Class Initialized
INFO - 2017-03-01 14:43:19 --> Language Class Initialized
INFO - 2017-03-01 14:43:19 --> Loader Class Initialized
INFO - 2017-03-01 14:43:19 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:19 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:19 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:19 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:19 --> Controller Class Initialized
INFO - 2017-03-01 14:43:19 --> Config Class Initialized
INFO - 2017-03-01 14:43:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:19 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:19 --> URI Class Initialized
INFO - 2017-03-01 14:43:19 --> Router Class Initialized
INFO - 2017-03-01 14:43:19 --> Output Class Initialized
INFO - 2017-03-01 14:43:19 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:19 --> Input Class Initialized
INFO - 2017-03-01 14:43:19 --> Language Class Initialized
INFO - 2017-03-01 14:43:19 --> Loader Class Initialized
INFO - 2017-03-01 14:43:19 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:19 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:19 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:19 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:19 --> Controller Class Initialized
INFO - 2017-03-01 14:43:19 --> Model Class Initialized
DEBUG - 2017-03-01 14:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-01 14:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:43:19 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-01 14:43:19 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-01 14:43:19 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/dashboard.php
INFO - 2017-03-01 14:43:19 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-01 14:43:19 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-01 14:43:19 --> Final output sent to browser
DEBUG - 2017-03-01 14:43:19 --> Total execution time: 0.2145
INFO - 2017-03-01 14:43:23 --> Config Class Initialized
INFO - 2017-03-01 14:43:23 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:23 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:23 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:23 --> URI Class Initialized
INFO - 2017-03-01 14:43:23 --> Router Class Initialized
INFO - 2017-03-01 14:43:23 --> Output Class Initialized
INFO - 2017-03-01 14:43:23 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:23 --> Input Class Initialized
INFO - 2017-03-01 14:43:23 --> Language Class Initialized
INFO - 2017-03-01 14:43:23 --> Loader Class Initialized
INFO - 2017-03-01 14:43:23 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:23 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:23 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:23 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:23 --> Controller Class Initialized
DEBUG - 2017-03-01 14:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:43:23 --> Config Class Initialized
INFO - 2017-03-01 14:43:23 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:23 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:23 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:23 --> URI Class Initialized
INFO - 2017-03-01 14:43:23 --> Router Class Initialized
INFO - 2017-03-01 14:43:24 --> Output Class Initialized
INFO - 2017-03-01 14:43:24 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:24 --> Input Class Initialized
INFO - 2017-03-01 14:43:24 --> Language Class Initialized
INFO - 2017-03-01 14:43:24 --> Loader Class Initialized
INFO - 2017-03-01 14:43:24 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:24 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:24 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:24 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:24 --> Controller Class Initialized
INFO - 2017-03-01 14:43:24 --> Config Class Initialized
INFO - 2017-03-01 14:43:24 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:24 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:24 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:24 --> URI Class Initialized
INFO - 2017-03-01 14:43:24 --> Router Class Initialized
INFO - 2017-03-01 14:43:24 --> Output Class Initialized
INFO - 2017-03-01 14:43:24 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:24 --> Input Class Initialized
INFO - 2017-03-01 14:43:24 --> Language Class Initialized
INFO - 2017-03-01 14:43:24 --> Loader Class Initialized
INFO - 2017-03-01 14:43:24 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:24 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:24 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:24 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:24 --> Controller Class Initialized
INFO - 2017-03-01 14:43:24 --> Model Class Initialized
DEBUG - 2017-03-01 14:43:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-01 14:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:43:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-01 14:43:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-01 14:43:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/dashboard.php
INFO - 2017-03-01 14:43:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-01 14:43:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-01 14:43:24 --> Final output sent to browser
DEBUG - 2017-03-01 14:43:24 --> Total execution time: 0.2118
INFO - 2017-03-01 14:43:50 --> Config Class Initialized
INFO - 2017-03-01 14:43:50 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:50 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:50 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:50 --> URI Class Initialized
INFO - 2017-03-01 14:43:50 --> Router Class Initialized
INFO - 2017-03-01 14:43:50 --> Output Class Initialized
INFO - 2017-03-01 14:43:50 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:50 --> Input Class Initialized
INFO - 2017-03-01 14:43:50 --> Language Class Initialized
INFO - 2017-03-01 14:43:50 --> Loader Class Initialized
INFO - 2017-03-01 14:43:50 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:50 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:50 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:50 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:50 --> Controller Class Initialized
INFO - 2017-03-01 14:43:50 --> Model Class Initialized
DEBUG - 2017-03-01 14:43:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2017-03-01 14:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:43:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-01 14:43:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-01 14:43:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/dashboard.php
INFO - 2017-03-01 14:43:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-01 14:43:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-01 14:43:50 --> Final output sent to browser
DEBUG - 2017-03-01 14:43:50 --> Total execution time: 0.2285
INFO - 2017-03-01 14:43:52 --> Config Class Initialized
INFO - 2017-03-01 14:43:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:52 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:52 --> URI Class Initialized
INFO - 2017-03-01 14:43:52 --> Router Class Initialized
INFO - 2017-03-01 14:43:52 --> Output Class Initialized
INFO - 2017-03-01 14:43:52 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:52 --> Input Class Initialized
INFO - 2017-03-01 14:43:52 --> Language Class Initialized
INFO - 2017-03-01 14:43:52 --> Loader Class Initialized
INFO - 2017-03-01 14:43:52 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:52 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:53 --> Controller Class Initialized
DEBUG - 2017-03-01 14:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:43:53 --> Config Class Initialized
INFO - 2017-03-01 14:43:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:53 --> URI Class Initialized
INFO - 2017-03-01 14:43:53 --> Router Class Initialized
INFO - 2017-03-01 14:43:53 --> Output Class Initialized
INFO - 2017-03-01 14:43:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:53 --> Input Class Initialized
INFO - 2017-03-01 14:43:53 --> Language Class Initialized
INFO - 2017-03-01 14:43:53 --> Loader Class Initialized
INFO - 2017-03-01 14:43:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:53 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:53 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:53 --> Controller Class Initialized
INFO - 2017-03-01 14:43:53 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-01 14:43:53 --> Final output sent to browser
DEBUG - 2017-03-01 14:43:53 --> Total execution time: 0.1629
INFO - 2017-03-01 14:43:56 --> Config Class Initialized
INFO - 2017-03-01 14:43:56 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:56 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:56 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:56 --> URI Class Initialized
INFO - 2017-03-01 14:43:56 --> Router Class Initialized
INFO - 2017-03-01 14:43:56 --> Output Class Initialized
INFO - 2017-03-01 14:43:56 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:56 --> Input Class Initialized
INFO - 2017-03-01 14:43:56 --> Language Class Initialized
INFO - 2017-03-01 14:43:56 --> Loader Class Initialized
INFO - 2017-03-01 14:43:56 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:56 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:56 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:56 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:56 --> Controller Class Initialized
INFO - 2017-03-01 14:43:56 --> Config Class Initialized
INFO - 2017-03-01 14:43:56 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:56 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:56 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:56 --> URI Class Initialized
INFO - 2017-03-01 14:43:56 --> Router Class Initialized
INFO - 2017-03-01 14:43:56 --> Output Class Initialized
INFO - 2017-03-01 14:43:56 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:56 --> Input Class Initialized
INFO - 2017-03-01 14:43:56 --> Language Class Initialized
INFO - 2017-03-01 14:43:56 --> Loader Class Initialized
INFO - 2017-03-01 14:43:56 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:56 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:56 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:56 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:56 --> Controller Class Initialized
INFO - 2017-03-01 14:43:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-01 14:43:56 --> Final output sent to browser
DEBUG - 2017-03-01 14:43:56 --> Total execution time: 0.1603
INFO - 2017-03-01 14:43:59 --> Config Class Initialized
INFO - 2017-03-01 14:43:59 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:59 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:59 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:59 --> URI Class Initialized
INFO - 2017-03-01 14:43:59 --> Router Class Initialized
INFO - 2017-03-01 14:43:59 --> Output Class Initialized
INFO - 2017-03-01 14:43:59 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:59 --> Input Class Initialized
INFO - 2017-03-01 14:43:59 --> Language Class Initialized
INFO - 2017-03-01 14:43:59 --> Loader Class Initialized
INFO - 2017-03-01 14:43:59 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:59 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:59 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:59 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:59 --> Controller Class Initialized
INFO - 2017-03-01 14:43:59 --> Model Class Initialized
DEBUG - 2017-03-01 14:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:43:59 --> Final output sent to browser
DEBUG - 2017-03-01 14:43:59 --> Total execution time: 0.1863
INFO - 2017-03-01 14:43:59 --> Config Class Initialized
INFO - 2017-03-01 14:43:59 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:43:59 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:43:59 --> Utf8 Class Initialized
INFO - 2017-03-01 14:43:59 --> URI Class Initialized
INFO - 2017-03-01 14:43:59 --> Router Class Initialized
INFO - 2017-03-01 14:43:59 --> Output Class Initialized
INFO - 2017-03-01 14:43:59 --> Security Class Initialized
DEBUG - 2017-03-01 14:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:43:59 --> Input Class Initialized
INFO - 2017-03-01 14:43:59 --> Language Class Initialized
INFO - 2017-03-01 14:43:59 --> Loader Class Initialized
INFO - 2017-03-01 14:43:59 --> Helper loaded: url_helper
INFO - 2017-03-01 14:43:59 --> Helper loaded: file_helper
INFO - 2017-03-01 14:43:59 --> Helper loaded: date_helper
INFO - 2017-03-01 14:43:59 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:43:59 --> Controller Class Initialized
DEBUG - 2017-03-01 14:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:43:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-01 14:43:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-01 14:43:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/dashboard.php
INFO - 2017-03-01 14:43:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-01 14:43:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-01 14:43:59 --> Final output sent to browser
DEBUG - 2017-03-01 14:43:59 --> Total execution time: 0.2049
INFO - 2017-03-01 14:44:02 --> Config Class Initialized
INFO - 2017-03-01 14:44:02 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:44:02 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:44:02 --> Utf8 Class Initialized
INFO - 2017-03-01 14:44:02 --> URI Class Initialized
INFO - 2017-03-01 14:44:02 --> Router Class Initialized
INFO - 2017-03-01 14:44:02 --> Output Class Initialized
INFO - 2017-03-01 14:44:02 --> Security Class Initialized
DEBUG - 2017-03-01 14:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:44:02 --> Input Class Initialized
INFO - 2017-03-01 14:44:02 --> Language Class Initialized
INFO - 2017-03-01 14:44:02 --> Loader Class Initialized
INFO - 2017-03-01 14:44:02 --> Helper loaded: url_helper
INFO - 2017-03-01 14:44:02 --> Helper loaded: file_helper
INFO - 2017-03-01 14:44:02 --> Helper loaded: date_helper
INFO - 2017-03-01 14:44:02 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:44:02 --> Controller Class Initialized
DEBUG - 2017-03-01 14:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:44:02 --> Config Class Initialized
INFO - 2017-03-01 14:44:02 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:44:02 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:44:02 --> Utf8 Class Initialized
INFO - 2017-03-01 14:44:02 --> URI Class Initialized
INFO - 2017-03-01 14:44:02 --> Router Class Initialized
INFO - 2017-03-01 14:44:02 --> Output Class Initialized
INFO - 2017-03-01 14:44:02 --> Security Class Initialized
DEBUG - 2017-03-01 14:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:44:02 --> Input Class Initialized
INFO - 2017-03-01 14:44:02 --> Language Class Initialized
INFO - 2017-03-01 14:44:02 --> Loader Class Initialized
INFO - 2017-03-01 14:44:02 --> Helper loaded: url_helper
INFO - 2017-03-01 14:44:02 --> Helper loaded: file_helper
INFO - 2017-03-01 14:44:02 --> Helper loaded: date_helper
INFO - 2017-03-01 14:44:02 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:44:02 --> Controller Class Initialized
INFO - 2017-03-01 14:44:02 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-01 14:44:02 --> Final output sent to browser
DEBUG - 2017-03-01 14:44:02 --> Total execution time: 0.1875
INFO - 2017-03-01 14:44:06 --> Config Class Initialized
INFO - 2017-03-01 14:44:06 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:44:06 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:44:06 --> Utf8 Class Initialized
INFO - 2017-03-01 14:44:07 --> URI Class Initialized
INFO - 2017-03-01 14:44:07 --> Router Class Initialized
INFO - 2017-03-01 14:44:07 --> Output Class Initialized
INFO - 2017-03-01 14:44:07 --> Security Class Initialized
DEBUG - 2017-03-01 14:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:44:07 --> Input Class Initialized
INFO - 2017-03-01 14:44:07 --> Language Class Initialized
INFO - 2017-03-01 14:44:07 --> Loader Class Initialized
INFO - 2017-03-01 14:44:07 --> Helper loaded: url_helper
INFO - 2017-03-01 14:44:07 --> Helper loaded: file_helper
INFO - 2017-03-01 14:44:07 --> Helper loaded: date_helper
INFO - 2017-03-01 14:44:07 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:44:07 --> Controller Class Initialized
INFO - 2017-03-01 14:44:07 --> Model Class Initialized
DEBUG - 2017-03-01 14:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:44:07 --> Final output sent to browser
DEBUG - 2017-03-01 14:44:07 --> Total execution time: 0.1861
INFO - 2017-03-01 14:44:07 --> Config Class Initialized
INFO - 2017-03-01 14:44:07 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:44:07 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:44:07 --> Utf8 Class Initialized
INFO - 2017-03-01 14:44:07 --> URI Class Initialized
INFO - 2017-03-01 14:44:07 --> Router Class Initialized
INFO - 2017-03-01 14:44:07 --> Output Class Initialized
INFO - 2017-03-01 14:44:07 --> Security Class Initialized
DEBUG - 2017-03-01 14:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:44:07 --> Input Class Initialized
INFO - 2017-03-01 14:44:07 --> Language Class Initialized
INFO - 2017-03-01 14:44:07 --> Loader Class Initialized
INFO - 2017-03-01 14:44:07 --> Helper loaded: url_helper
INFO - 2017-03-01 14:44:07 --> Helper loaded: file_helper
INFO - 2017-03-01 14:44:07 --> Helper loaded: date_helper
INFO - 2017-03-01 14:44:07 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:44:07 --> Controller Class Initialized
DEBUG - 2017-03-01 14:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:44:07 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-01 14:44:07 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-01 14:44:07 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/dashboard.php
INFO - 2017-03-01 14:44:07 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-01 14:44:07 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-01 14:44:07 --> Final output sent to browser
DEBUG - 2017-03-01 14:44:07 --> Total execution time: 0.2061
INFO - 2017-03-01 14:44:10 --> Config Class Initialized
INFO - 2017-03-01 14:44:10 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:44:10 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:44:10 --> Utf8 Class Initialized
INFO - 2017-03-01 14:44:10 --> URI Class Initialized
INFO - 2017-03-01 14:44:10 --> Router Class Initialized
INFO - 2017-03-01 14:44:10 --> Output Class Initialized
INFO - 2017-03-01 14:44:10 --> Security Class Initialized
DEBUG - 2017-03-01 14:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:44:10 --> Input Class Initialized
INFO - 2017-03-01 14:44:10 --> Language Class Initialized
INFO - 2017-03-01 14:44:10 --> Loader Class Initialized
INFO - 2017-03-01 14:44:10 --> Helper loaded: url_helper
INFO - 2017-03-01 14:44:10 --> Helper loaded: file_helper
INFO - 2017-03-01 14:44:10 --> Helper loaded: date_helper
INFO - 2017-03-01 14:44:10 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:44:10 --> Controller Class Initialized
INFO - 2017-03-01 14:44:10 --> Model Class Initialized
DEBUG - 2017-03-01 14:44:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:44:10 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-01 14:44:10 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-01 14:44:10 --> File loaded: E:\XAMPP\htdocs\ci\application\views\teacher/create_teacher.php
INFO - 2017-03-01 14:44:10 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-01 14:44:10 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-01 14:44:10 --> Final output sent to browser
DEBUG - 2017-03-01 14:44:10 --> Total execution time: 0.2134
INFO - 2017-03-01 14:44:20 --> Config Class Initialized
INFO - 2017-03-01 14:44:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:44:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:44:20 --> Utf8 Class Initialized
INFO - 2017-03-01 14:44:20 --> URI Class Initialized
INFO - 2017-03-01 14:44:20 --> Router Class Initialized
INFO - 2017-03-01 14:44:20 --> Output Class Initialized
INFO - 2017-03-01 14:44:20 --> Security Class Initialized
DEBUG - 2017-03-01 14:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:44:20 --> Input Class Initialized
INFO - 2017-03-01 14:44:20 --> Language Class Initialized
INFO - 2017-03-01 14:44:20 --> Loader Class Initialized
INFO - 2017-03-01 14:44:20 --> Helper loaded: url_helper
INFO - 2017-03-01 14:44:20 --> Helper loaded: file_helper
INFO - 2017-03-01 14:44:20 --> Helper loaded: date_helper
INFO - 2017-03-01 14:44:20 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:44:20 --> Controller Class Initialized
INFO - 2017-03-01 14:44:20 --> Model Class Initialized
DEBUG - 2017-03-01 14:44:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:44:20 --> Final output sent to browser
DEBUG - 2017-03-01 14:44:20 --> Total execution time: 0.1856
INFO - 2017-03-01 14:44:20 --> Config Class Initialized
INFO - 2017-03-01 14:44:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:44:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:44:20 --> Utf8 Class Initialized
INFO - 2017-03-01 14:44:20 --> URI Class Initialized
INFO - 2017-03-01 14:44:20 --> Router Class Initialized
INFO - 2017-03-01 14:44:20 --> Output Class Initialized
INFO - 2017-03-01 14:44:20 --> Security Class Initialized
DEBUG - 2017-03-01 14:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:44:20 --> Input Class Initialized
INFO - 2017-03-01 14:44:21 --> Language Class Initialized
INFO - 2017-03-01 14:44:21 --> Loader Class Initialized
INFO - 2017-03-01 14:44:21 --> Helper loaded: url_helper
INFO - 2017-03-01 14:44:21 --> Helper loaded: file_helper
INFO - 2017-03-01 14:44:21 --> Helper loaded: date_helper
INFO - 2017-03-01 14:44:21 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:44:21 --> Controller Class Initialized
DEBUG - 2017-03-01 14:44:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:44:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-01 14:44:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-01 14:44:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/dashboard.php
INFO - 2017-03-01 14:44:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-01 14:44:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-01 14:44:21 --> Final output sent to browser
DEBUG - 2017-03-01 14:44:21 --> Total execution time: 0.2118
INFO - 2017-03-01 14:44:24 --> Config Class Initialized
INFO - 2017-03-01 14:44:24 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:44:24 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:44:24 --> Utf8 Class Initialized
INFO - 2017-03-01 14:44:24 --> URI Class Initialized
INFO - 2017-03-01 14:44:24 --> Router Class Initialized
INFO - 2017-03-01 14:44:24 --> Output Class Initialized
INFO - 2017-03-01 14:44:24 --> Security Class Initialized
DEBUG - 2017-03-01 14:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:44:24 --> Input Class Initialized
INFO - 2017-03-01 14:44:24 --> Language Class Initialized
INFO - 2017-03-01 14:44:24 --> Loader Class Initialized
INFO - 2017-03-01 14:44:24 --> Helper loaded: url_helper
INFO - 2017-03-01 14:44:24 --> Helper loaded: file_helper
INFO - 2017-03-01 14:44:24 --> Helper loaded: date_helper
INFO - 2017-03-01 14:44:24 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:44:24 --> Controller Class Initialized
INFO - 2017-03-01 14:44:24 --> Config Class Initialized
INFO - 2017-03-01 14:44:24 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:44:24 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:44:24 --> Utf8 Class Initialized
INFO - 2017-03-01 14:44:24 --> URI Class Initialized
INFO - 2017-03-01 14:44:24 --> Router Class Initialized
INFO - 2017-03-01 14:44:24 --> Output Class Initialized
INFO - 2017-03-01 14:44:24 --> Security Class Initialized
DEBUG - 2017-03-01 14:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:44:24 --> Input Class Initialized
INFO - 2017-03-01 14:44:24 --> Language Class Initialized
INFO - 2017-03-01 14:44:24 --> Loader Class Initialized
INFO - 2017-03-01 14:44:24 --> Helper loaded: url_helper
INFO - 2017-03-01 14:44:24 --> Helper loaded: file_helper
INFO - 2017-03-01 14:44:24 --> Helper loaded: date_helper
INFO - 2017-03-01 14:44:24 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 14:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:44:24 --> Controller Class Initialized
DEBUG - 2017-03-01 14:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:44:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-01 14:44:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-01 14:44:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/dashboard.php
INFO - 2017-03-01 14:44:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-01 14:44:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-01 14:44:24 --> Final output sent to browser
DEBUG - 2017-03-01 14:44:24 --> Total execution time: 0.2075
