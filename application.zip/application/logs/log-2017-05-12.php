<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-05-12 08:17:28 --> Config Class Initialized
INFO - 2017-05-12 08:17:28 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:17:28 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:17:28 --> Utf8 Class Initialized
INFO - 2017-05-12 08:17:28 --> URI Class Initialized
DEBUG - 2017-05-12 08:17:28 --> No URI present. Default controller set.
INFO - 2017-05-12 08:17:28 --> Router Class Initialized
INFO - 2017-05-12 08:17:28 --> Output Class Initialized
INFO - 2017-05-12 08:17:28 --> Security Class Initialized
DEBUG - 2017-05-12 08:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:17:28 --> Input Class Initialized
INFO - 2017-05-12 08:17:28 --> Language Class Initialized
INFO - 2017-05-12 08:17:28 --> Loader Class Initialized
INFO - 2017-05-12 08:17:28 --> Helper loaded: url_helper
INFO - 2017-05-12 08:17:28 --> Helper loaded: file_helper
INFO - 2017-05-12 08:17:28 --> Helper loaded: date_helper
INFO - 2017-05-12 08:17:28 --> Database Driver Class Initialized
DEBUG - 2017-05-12 08:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-05-12 08:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-12 08:17:28 --> Controller Class Initialized
INFO - 2017-05-12 08:17:29 --> Config Class Initialized
INFO - 2017-05-12 08:17:29 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:17:29 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:17:29 --> Utf8 Class Initialized
INFO - 2017-05-12 08:17:29 --> URI Class Initialized
INFO - 2017-05-12 08:17:29 --> Router Class Initialized
INFO - 2017-05-12 08:17:29 --> Output Class Initialized
INFO - 2017-05-12 08:17:29 --> Security Class Initialized
DEBUG - 2017-05-12 08:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:17:29 --> Input Class Initialized
INFO - 2017-05-12 08:17:29 --> Language Class Initialized
INFO - 2017-05-12 08:17:29 --> Loader Class Initialized
INFO - 2017-05-12 08:17:29 --> Helper loaded: url_helper
INFO - 2017-05-12 08:17:29 --> Helper loaded: file_helper
INFO - 2017-05-12 08:17:29 --> Helper loaded: date_helper
INFO - 2017-05-12 08:17:29 --> Database Driver Class Initialized
DEBUG - 2017-05-12 08:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-05-12 08:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-12 08:17:29 --> Controller Class Initialized
INFO - 2017-05-12 08:17:29 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-05-12 08:17:29 --> Final output sent to browser
DEBUG - 2017-05-12 08:17:29 --> Total execution time: 0.0250
INFO - 2017-05-12 08:23:52 --> Config Class Initialized
INFO - 2017-05-12 08:23:52 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:23:52 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:23:52 --> Utf8 Class Initialized
INFO - 2017-05-12 08:23:52 --> URI Class Initialized
INFO - 2017-05-12 08:23:52 --> Router Class Initialized
INFO - 2017-05-12 08:23:52 --> Output Class Initialized
INFO - 2017-05-12 08:23:52 --> Security Class Initialized
DEBUG - 2017-05-12 08:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:23:52 --> Input Class Initialized
INFO - 2017-05-12 08:23:52 --> Language Class Initialized
INFO - 2017-05-12 08:23:52 --> Loader Class Initialized
INFO - 2017-05-12 08:23:52 --> Helper loaded: url_helper
INFO - 2017-05-12 08:23:52 --> Helper loaded: file_helper
INFO - 2017-05-12 08:23:52 --> Helper loaded: date_helper
INFO - 2017-05-12 08:23:52 --> Database Driver Class Initialized
DEBUG - 2017-05-12 08:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-05-12 08:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-12 08:23:52 --> Controller Class Initialized
INFO - 2017-05-12 08:23:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-05-12 08:23:52 --> Final output sent to browser
DEBUG - 2017-05-12 08:23:52 --> Total execution time: 0.0192
INFO - 2017-05-12 08:26:53 --> Config Class Initialized
INFO - 2017-05-12 08:26:53 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:26:53 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:26:53 --> Utf8 Class Initialized
INFO - 2017-05-12 08:26:53 --> URI Class Initialized
INFO - 2017-05-12 08:26:53 --> Router Class Initialized
INFO - 2017-05-12 08:26:53 --> Output Class Initialized
INFO - 2017-05-12 08:26:53 --> Security Class Initialized
DEBUG - 2017-05-12 08:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:26:53 --> Input Class Initialized
INFO - 2017-05-12 08:26:53 --> Language Class Initialized
INFO - 2017-05-12 08:26:53 --> Loader Class Initialized
INFO - 2017-05-12 08:26:53 --> Helper loaded: url_helper
INFO - 2017-05-12 08:26:53 --> Helper loaded: file_helper
INFO - 2017-05-12 08:26:53 --> Helper loaded: date_helper
INFO - 2017-05-12 08:26:53 --> Database Driver Class Initialized
DEBUG - 2017-05-12 08:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-05-12 08:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-12 08:26:53 --> Controller Class Initialized
INFO - 2017-05-12 08:26:53 --> Model Class Initialized
INFO - 2017-05-12 08:26:53 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-05-12 08:26:53 --> Final output sent to browser
DEBUG - 2017-05-12 08:26:53 --> Total execution time: 0.0861
INFO - 2017-05-12 08:29:05 --> Config Class Initialized
INFO - 2017-05-12 08:29:05 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:29:05 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:29:05 --> Utf8 Class Initialized
INFO - 2017-05-12 08:29:05 --> URI Class Initialized
INFO - 2017-05-12 08:29:05 --> Router Class Initialized
INFO - 2017-05-12 08:29:05 --> Output Class Initialized
INFO - 2017-05-12 08:29:05 --> Security Class Initialized
DEBUG - 2017-05-12 08:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:29:05 --> Input Class Initialized
INFO - 2017-05-12 08:29:05 --> Language Class Initialized
INFO - 2017-05-12 08:29:05 --> Loader Class Initialized
INFO - 2017-05-12 08:29:05 --> Helper loaded: url_helper
INFO - 2017-05-12 08:29:05 --> Helper loaded: file_helper
INFO - 2017-05-12 08:29:05 --> Helper loaded: date_helper
INFO - 2017-05-12 08:29:05 --> Database Driver Class Initialized
DEBUG - 2017-05-12 08:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-05-12 08:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-12 08:29:05 --> Controller Class Initialized
INFO - 2017-05-12 08:29:05 --> Model Class Initialized
INFO - 2017-05-12 08:29:05 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-05-12 08:29:05 --> Final output sent to browser
DEBUG - 2017-05-12 08:29:05 --> Total execution time: 0.0209
INFO - 2017-05-12 08:30:10 --> Config Class Initialized
INFO - 2017-05-12 08:30:10 --> Hooks Class Initialized
DEBUG - 2017-05-12 08:30:10 --> UTF-8 Support Enabled
INFO - 2017-05-12 08:30:10 --> Utf8 Class Initialized
INFO - 2017-05-12 08:30:10 --> URI Class Initialized
INFO - 2017-05-12 08:30:10 --> Router Class Initialized
INFO - 2017-05-12 08:30:10 --> Output Class Initialized
INFO - 2017-05-12 08:30:10 --> Security Class Initialized
DEBUG - 2017-05-12 08:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-12 08:30:10 --> Input Class Initialized
INFO - 2017-05-12 08:30:10 --> Language Class Initialized
INFO - 2017-05-12 08:30:10 --> Loader Class Initialized
INFO - 2017-05-12 08:30:10 --> Helper loaded: url_helper
INFO - 2017-05-12 08:30:10 --> Helper loaded: file_helper
INFO - 2017-05-12 08:30:10 --> Helper loaded: date_helper
INFO - 2017-05-12 08:30:10 --> Database Driver Class Initialized
DEBUG - 2017-05-12 08:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-05-12 08:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-12 08:30:10 --> Controller Class Initialized
INFO - 2017-05-12 08:30:10 --> Model Class Initialized
INFO - 2017-05-12 08:30:10 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-05-12 08:30:10 --> Final output sent to browser
DEBUG - 2017-05-12 08:30:10 --> Total execution time: 0.0227
