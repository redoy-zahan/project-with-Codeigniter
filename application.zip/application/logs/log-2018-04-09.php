<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-09 05:05:52 --> Config Class Initialized
INFO - 2018-04-09 05:05:52 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:05:52 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:05:52 --> Utf8 Class Initialized
INFO - 2018-04-09 05:05:52 --> URI Class Initialized
INFO - 2018-04-09 05:05:52 --> Router Class Initialized
INFO - 2018-04-09 05:05:52 --> Output Class Initialized
INFO - 2018-04-09 05:05:52 --> Security Class Initialized
DEBUG - 2018-04-09 05:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:05:52 --> Input Class Initialized
INFO - 2018-04-09 05:05:52 --> Language Class Initialized
INFO - 2018-04-09 05:05:53 --> Loader Class Initialized
INFO - 2018-04-09 05:05:53 --> Helper loaded: url_helper
INFO - 2018-04-09 05:05:53 --> Helper loaded: file_helper
INFO - 2018-04-09 05:05:53 --> Helper loaded: date_helper
INFO - 2018-04-09 05:05:53 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:05:53 --> Controller Class Initialized
INFO - 2018-04-09 05:05:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-09 05:05:53 --> Final output sent to browser
DEBUG - 2018-04-09 05:05:53 --> Total execution time: 1.2968
INFO - 2018-04-09 05:06:00 --> Config Class Initialized
INFO - 2018-04-09 05:06:00 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:06:00 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:06:00 --> Utf8 Class Initialized
INFO - 2018-04-09 05:06:00 --> URI Class Initialized
INFO - 2018-04-09 05:06:00 --> Router Class Initialized
INFO - 2018-04-09 05:06:00 --> Output Class Initialized
INFO - 2018-04-09 05:06:00 --> Security Class Initialized
DEBUG - 2018-04-09 05:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:06:00 --> Input Class Initialized
INFO - 2018-04-09 05:06:00 --> Language Class Initialized
INFO - 2018-04-09 05:06:00 --> Loader Class Initialized
INFO - 2018-04-09 05:06:00 --> Helper loaded: url_helper
INFO - 2018-04-09 05:06:00 --> Helper loaded: file_helper
INFO - 2018-04-09 05:06:00 --> Helper loaded: date_helper
INFO - 2018-04-09 05:06:00 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:06:00 --> Controller Class Initialized
INFO - 2018-04-09 05:06:00 --> Model Class Initialized
INFO - 2018-04-09 05:06:00 --> Final output sent to browser
DEBUG - 2018-04-09 05:06:00 --> Total execution time: 0.4664
INFO - 2018-04-09 05:06:00 --> Config Class Initialized
INFO - 2018-04-09 05:06:00 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:06:00 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:06:00 --> Utf8 Class Initialized
INFO - 2018-04-09 05:06:00 --> URI Class Initialized
INFO - 2018-04-09 05:06:00 --> Router Class Initialized
INFO - 2018-04-09 05:06:00 --> Output Class Initialized
INFO - 2018-04-09 05:06:00 --> Security Class Initialized
DEBUG - 2018-04-09 05:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:06:00 --> Input Class Initialized
INFO - 2018-04-09 05:06:00 --> Language Class Initialized
ERROR - 2018-04-09 05:06:00 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 82
INFO - 2018-04-09 05:06:20 --> Config Class Initialized
INFO - 2018-04-09 05:06:20 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:06:20 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:06:20 --> Utf8 Class Initialized
INFO - 2018-04-09 05:06:20 --> URI Class Initialized
INFO - 2018-04-09 05:06:20 --> Router Class Initialized
INFO - 2018-04-09 05:06:20 --> Output Class Initialized
INFO - 2018-04-09 05:06:20 --> Security Class Initialized
DEBUG - 2018-04-09 05:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:06:20 --> Input Class Initialized
INFO - 2018-04-09 05:06:20 --> Language Class Initialized
ERROR - 2018-04-09 05:06:20 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 77
INFO - 2018-04-09 05:06:22 --> Config Class Initialized
INFO - 2018-04-09 05:06:22 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:06:22 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:06:22 --> Utf8 Class Initialized
INFO - 2018-04-09 05:06:22 --> URI Class Initialized
INFO - 2018-04-09 05:06:22 --> Router Class Initialized
INFO - 2018-04-09 05:06:22 --> Output Class Initialized
INFO - 2018-04-09 05:06:22 --> Security Class Initialized
DEBUG - 2018-04-09 05:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:06:22 --> Input Class Initialized
INFO - 2018-04-09 05:06:22 --> Language Class Initialized
ERROR - 2018-04-09 05:06:22 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 77
INFO - 2018-04-09 05:06:23 --> Config Class Initialized
INFO - 2018-04-09 05:06:23 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:06:23 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:06:23 --> Utf8 Class Initialized
INFO - 2018-04-09 05:06:23 --> URI Class Initialized
INFO - 2018-04-09 05:06:23 --> Router Class Initialized
INFO - 2018-04-09 05:06:23 --> Output Class Initialized
INFO - 2018-04-09 05:06:23 --> Security Class Initialized
DEBUG - 2018-04-09 05:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:06:23 --> Input Class Initialized
INFO - 2018-04-09 05:06:23 --> Language Class Initialized
ERROR - 2018-04-09 05:06:23 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 77
INFO - 2018-04-09 05:06:50 --> Config Class Initialized
INFO - 2018-04-09 05:06:50 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:06:50 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:06:50 --> Utf8 Class Initialized
INFO - 2018-04-09 05:06:50 --> URI Class Initialized
INFO - 2018-04-09 05:06:50 --> Router Class Initialized
INFO - 2018-04-09 05:06:50 --> Output Class Initialized
INFO - 2018-04-09 05:06:50 --> Security Class Initialized
DEBUG - 2018-04-09 05:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:06:50 --> Input Class Initialized
INFO - 2018-04-09 05:06:50 --> Language Class Initialized
ERROR - 2018-04-09 05:06:50 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 77
INFO - 2018-04-09 05:06:53 --> Config Class Initialized
INFO - 2018-04-09 05:06:53 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:06:53 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:06:53 --> Utf8 Class Initialized
INFO - 2018-04-09 05:06:53 --> URI Class Initialized
INFO - 2018-04-09 05:06:54 --> Router Class Initialized
INFO - 2018-04-09 05:06:54 --> Output Class Initialized
INFO - 2018-04-09 05:06:54 --> Security Class Initialized
DEBUG - 2018-04-09 05:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:06:54 --> Input Class Initialized
INFO - 2018-04-09 05:06:54 --> Language Class Initialized
ERROR - 2018-04-09 05:06:54 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 77
INFO - 2018-04-09 05:07:19 --> Config Class Initialized
INFO - 2018-04-09 05:07:19 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:07:19 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:07:19 --> Utf8 Class Initialized
INFO - 2018-04-09 05:07:19 --> URI Class Initialized
INFO - 2018-04-09 05:07:19 --> Router Class Initialized
INFO - 2018-04-09 05:07:19 --> Output Class Initialized
INFO - 2018-04-09 05:07:19 --> Security Class Initialized
DEBUG - 2018-04-09 05:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:07:19 --> Input Class Initialized
INFO - 2018-04-09 05:07:19 --> Language Class Initialized
INFO - 2018-04-09 05:07:19 --> Loader Class Initialized
INFO - 2018-04-09 05:07:19 --> Helper loaded: url_helper
INFO - 2018-04-09 05:07:19 --> Helper loaded: file_helper
INFO - 2018-04-09 05:07:19 --> Helper loaded: date_helper
INFO - 2018-04-09 05:07:20 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:07:20 --> Controller Class Initialized
INFO - 2018-04-09 05:07:20 --> Model Class Initialized
INFO - 2018-04-09 05:07:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 05:07:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 05:07:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 05:07:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 05:07:20 --> Final output sent to browser
DEBUG - 2018-04-09 05:07:20 --> Total execution time: 0.4530
INFO - 2018-04-09 05:07:23 --> Config Class Initialized
INFO - 2018-04-09 05:07:23 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:07:23 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:07:23 --> Utf8 Class Initialized
INFO - 2018-04-09 05:07:23 --> URI Class Initialized
INFO - 2018-04-09 05:07:23 --> Router Class Initialized
INFO - 2018-04-09 05:07:23 --> Output Class Initialized
INFO - 2018-04-09 05:07:23 --> Security Class Initialized
DEBUG - 2018-04-09 05:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:07:23 --> Input Class Initialized
INFO - 2018-04-09 05:07:23 --> Language Class Initialized
INFO - 2018-04-09 05:07:23 --> Loader Class Initialized
INFO - 2018-04-09 05:07:23 --> Helper loaded: url_helper
INFO - 2018-04-09 05:07:23 --> Helper loaded: file_helper
INFO - 2018-04-09 05:07:23 --> Helper loaded: date_helper
INFO - 2018-04-09 05:07:23 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:07:23 --> Controller Class Initialized
INFO - 2018-04-09 05:07:23 --> Model Class Initialized
INFO - 2018-04-09 05:07:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 05:07:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 05:07:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 05:07:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 05:07:23 --> Final output sent to browser
DEBUG - 2018-04-09 05:07:23 --> Total execution time: 0.2976
INFO - 2018-04-09 05:20:33 --> Config Class Initialized
INFO - 2018-04-09 05:20:33 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:20:33 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:20:33 --> Utf8 Class Initialized
INFO - 2018-04-09 05:20:33 --> URI Class Initialized
INFO - 2018-04-09 05:20:33 --> Router Class Initialized
INFO - 2018-04-09 05:20:33 --> Output Class Initialized
INFO - 2018-04-09 05:20:33 --> Security Class Initialized
DEBUG - 2018-04-09 05:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:20:33 --> Input Class Initialized
INFO - 2018-04-09 05:20:33 --> Language Class Initialized
INFO - 2018-04-09 05:20:33 --> Loader Class Initialized
INFO - 2018-04-09 05:20:33 --> Helper loaded: url_helper
INFO - 2018-04-09 05:20:33 --> Helper loaded: file_helper
INFO - 2018-04-09 05:20:33 --> Helper loaded: date_helper
INFO - 2018-04-09 05:20:33 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:20:33 --> Controller Class Initialized
INFO - 2018-04-09 05:20:33 --> Model Class Initialized
INFO - 2018-04-09 05:20:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 05:20:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 05:20:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 05:20:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 05:20:33 --> Final output sent to browser
DEBUG - 2018-04-09 05:20:33 --> Total execution time: 0.3015
INFO - 2018-04-09 05:20:50 --> Config Class Initialized
INFO - 2018-04-09 05:20:50 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:20:50 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:20:50 --> Utf8 Class Initialized
INFO - 2018-04-09 05:20:50 --> URI Class Initialized
INFO - 2018-04-09 05:20:50 --> Router Class Initialized
INFO - 2018-04-09 05:20:50 --> Output Class Initialized
INFO - 2018-04-09 05:20:50 --> Security Class Initialized
DEBUG - 2018-04-09 05:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:20:50 --> Input Class Initialized
INFO - 2018-04-09 05:20:50 --> Language Class Initialized
INFO - 2018-04-09 05:20:50 --> Loader Class Initialized
INFO - 2018-04-09 05:20:50 --> Helper loaded: url_helper
INFO - 2018-04-09 05:20:50 --> Helper loaded: file_helper
INFO - 2018-04-09 05:20:50 --> Helper loaded: date_helper
INFO - 2018-04-09 05:20:51 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:20:51 --> Controller Class Initialized
INFO - 2018-04-09 05:20:51 --> Model Class Initialized
INFO - 2018-04-09 05:20:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 05:20:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 05:20:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 05:20:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 05:20:51 --> Final output sent to browser
DEBUG - 2018-04-09 05:20:51 --> Total execution time: 0.2924
INFO - 2018-04-09 05:22:59 --> Config Class Initialized
INFO - 2018-04-09 05:22:59 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:22:59 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:22:59 --> Utf8 Class Initialized
INFO - 2018-04-09 05:22:59 --> URI Class Initialized
INFO - 2018-04-09 05:22:59 --> Router Class Initialized
INFO - 2018-04-09 05:22:59 --> Output Class Initialized
INFO - 2018-04-09 05:22:59 --> Security Class Initialized
DEBUG - 2018-04-09 05:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:22:59 --> Input Class Initialized
INFO - 2018-04-09 05:22:59 --> Language Class Initialized
ERROR - 2018-04-09 05:22:59 --> 404 Page Not Found: Stud_controller/update_info
INFO - 2018-04-09 05:23:08 --> Config Class Initialized
INFO - 2018-04-09 05:23:08 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:23:08 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:23:08 --> Utf8 Class Initialized
INFO - 2018-04-09 05:23:08 --> URI Class Initialized
INFO - 2018-04-09 05:23:08 --> Router Class Initialized
INFO - 2018-04-09 05:23:08 --> Output Class Initialized
INFO - 2018-04-09 05:23:08 --> Security Class Initialized
DEBUG - 2018-04-09 05:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:23:08 --> Input Class Initialized
INFO - 2018-04-09 05:23:08 --> Language Class Initialized
ERROR - 2018-04-09 05:23:08 --> 404 Page Not Found: Stud_controller/update_info
INFO - 2018-04-09 05:24:22 --> Config Class Initialized
INFO - 2018-04-09 05:24:22 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:24:22 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:24:22 --> Utf8 Class Initialized
INFO - 2018-04-09 05:24:22 --> URI Class Initialized
INFO - 2018-04-09 05:24:22 --> Router Class Initialized
INFO - 2018-04-09 05:24:22 --> Output Class Initialized
INFO - 2018-04-09 05:24:22 --> Security Class Initialized
DEBUG - 2018-04-09 05:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:24:22 --> Input Class Initialized
INFO - 2018-04-09 05:24:22 --> Language Class Initialized
ERROR - 2018-04-09 05:24:22 --> 404 Page Not Found: Stud_controller/update_info
INFO - 2018-04-09 05:24:29 --> Config Class Initialized
INFO - 2018-04-09 05:24:29 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:24:29 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:24:29 --> Utf8 Class Initialized
INFO - 2018-04-09 05:24:29 --> URI Class Initialized
INFO - 2018-04-09 05:24:29 --> Router Class Initialized
INFO - 2018-04-09 05:24:29 --> Output Class Initialized
INFO - 2018-04-09 05:24:29 --> Security Class Initialized
DEBUG - 2018-04-09 05:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:24:29 --> Input Class Initialized
INFO - 2018-04-09 05:24:29 --> Language Class Initialized
ERROR - 2018-04-09 05:24:29 --> 404 Page Not Found: Stud_controller/update_info
INFO - 2018-04-09 05:26:20 --> Config Class Initialized
INFO - 2018-04-09 05:26:20 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:26:20 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:26:20 --> Utf8 Class Initialized
INFO - 2018-04-09 05:26:20 --> URI Class Initialized
INFO - 2018-04-09 05:26:20 --> Router Class Initialized
INFO - 2018-04-09 05:26:20 --> Output Class Initialized
INFO - 2018-04-09 05:26:20 --> Security Class Initialized
DEBUG - 2018-04-09 05:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:26:20 --> Input Class Initialized
INFO - 2018-04-09 05:26:20 --> Language Class Initialized
INFO - 2018-04-09 05:26:20 --> Loader Class Initialized
INFO - 2018-04-09 05:26:20 --> Helper loaded: url_helper
INFO - 2018-04-09 05:26:20 --> Helper loaded: file_helper
INFO - 2018-04-09 05:26:20 --> Helper loaded: date_helper
INFO - 2018-04-09 05:26:20 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:26:20 --> Controller Class Initialized
INFO - 2018-04-09 05:26:20 --> Model Class Initialized
INFO - 2018-04-09 05:26:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 05:26:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 05:26:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 05:26:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 05:26:20 --> Final output sent to browser
DEBUG - 2018-04-09 05:26:20 --> Total execution time: 0.3058
INFO - 2018-04-09 05:26:22 --> Config Class Initialized
INFO - 2018-04-09 05:26:22 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:26:22 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:26:22 --> Utf8 Class Initialized
INFO - 2018-04-09 05:26:22 --> URI Class Initialized
INFO - 2018-04-09 05:26:22 --> Router Class Initialized
INFO - 2018-04-09 05:26:22 --> Output Class Initialized
INFO - 2018-04-09 05:26:22 --> Security Class Initialized
DEBUG - 2018-04-09 05:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:26:22 --> Input Class Initialized
INFO - 2018-04-09 05:26:22 --> Language Class Initialized
INFO - 2018-04-09 05:26:22 --> Loader Class Initialized
INFO - 2018-04-09 05:26:22 --> Helper loaded: url_helper
INFO - 2018-04-09 05:26:22 --> Helper loaded: file_helper
INFO - 2018-04-09 05:26:22 --> Helper loaded: date_helper
INFO - 2018-04-09 05:26:22 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:26:23 --> Controller Class Initialized
INFO - 2018-04-09 05:26:23 --> Model Class Initialized
INFO - 2018-04-09 05:29:02 --> Config Class Initialized
INFO - 2018-04-09 05:29:02 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:29:02 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:29:02 --> Utf8 Class Initialized
INFO - 2018-04-09 05:29:02 --> URI Class Initialized
INFO - 2018-04-09 05:29:02 --> Router Class Initialized
INFO - 2018-04-09 05:29:02 --> Output Class Initialized
INFO - 2018-04-09 05:29:02 --> Security Class Initialized
DEBUG - 2018-04-09 05:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:29:02 --> Input Class Initialized
INFO - 2018-04-09 05:29:02 --> Language Class Initialized
ERROR - 2018-04-09 05:29:02 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 50
INFO - 2018-04-09 05:29:52 --> Config Class Initialized
INFO - 2018-04-09 05:29:52 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:29:52 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:29:52 --> Utf8 Class Initialized
INFO - 2018-04-09 05:29:52 --> URI Class Initialized
INFO - 2018-04-09 05:29:52 --> Router Class Initialized
INFO - 2018-04-09 05:29:52 --> Output Class Initialized
INFO - 2018-04-09 05:29:52 --> Security Class Initialized
DEBUG - 2018-04-09 05:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:29:52 --> Input Class Initialized
INFO - 2018-04-09 05:29:52 --> Language Class Initialized
INFO - 2018-04-09 05:29:52 --> Loader Class Initialized
INFO - 2018-04-09 05:29:52 --> Helper loaded: url_helper
INFO - 2018-04-09 05:29:52 --> Helper loaded: file_helper
INFO - 2018-04-09 05:29:52 --> Helper loaded: date_helper
INFO - 2018-04-09 05:29:52 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:29:52 --> Controller Class Initialized
INFO - 2018-04-09 05:29:52 --> Model Class Initialized
INFO - 2018-04-09 05:29:52 --> Final output sent to browser
DEBUG - 2018-04-09 05:29:52 --> Total execution time: 0.2517
INFO - 2018-04-09 05:29:55 --> Config Class Initialized
INFO - 2018-04-09 05:29:55 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:29:55 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:29:55 --> Utf8 Class Initialized
INFO - 2018-04-09 05:29:55 --> URI Class Initialized
INFO - 2018-04-09 05:29:55 --> Router Class Initialized
INFO - 2018-04-09 05:29:55 --> Output Class Initialized
INFO - 2018-04-09 05:29:55 --> Security Class Initialized
DEBUG - 2018-04-09 05:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:29:55 --> Input Class Initialized
INFO - 2018-04-09 05:29:55 --> Language Class Initialized
INFO - 2018-04-09 05:29:56 --> Loader Class Initialized
INFO - 2018-04-09 05:29:56 --> Helper loaded: url_helper
INFO - 2018-04-09 05:29:56 --> Helper loaded: file_helper
INFO - 2018-04-09 05:29:56 --> Helper loaded: date_helper
INFO - 2018-04-09 05:29:56 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:29:56 --> Controller Class Initialized
INFO - 2018-04-09 05:29:56 --> Model Class Initialized
INFO - 2018-04-09 05:29:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 05:29:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 05:29:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 05:29:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 05:29:56 --> Final output sent to browser
DEBUG - 2018-04-09 05:29:56 --> Total execution time: 0.3395
INFO - 2018-04-09 05:29:57 --> Config Class Initialized
INFO - 2018-04-09 05:29:57 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:29:57 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:29:57 --> Utf8 Class Initialized
INFO - 2018-04-09 05:29:57 --> URI Class Initialized
INFO - 2018-04-09 05:29:57 --> Router Class Initialized
INFO - 2018-04-09 05:29:57 --> Output Class Initialized
INFO - 2018-04-09 05:29:57 --> Security Class Initialized
DEBUG - 2018-04-09 05:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:29:57 --> Input Class Initialized
INFO - 2018-04-09 05:29:57 --> Language Class Initialized
INFO - 2018-04-09 05:29:57 --> Loader Class Initialized
INFO - 2018-04-09 05:29:57 --> Helper loaded: url_helper
INFO - 2018-04-09 05:29:57 --> Helper loaded: file_helper
INFO - 2018-04-09 05:29:58 --> Helper loaded: date_helper
INFO - 2018-04-09 05:29:58 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:29:58 --> Controller Class Initialized
INFO - 2018-04-09 05:29:58 --> Model Class Initialized
INFO - 2018-04-09 05:29:58 --> Final output sent to browser
DEBUG - 2018-04-09 05:29:58 --> Total execution time: 0.2877
INFO - 2018-04-09 05:31:06 --> Config Class Initialized
INFO - 2018-04-09 05:31:06 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:31:06 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:31:06 --> Utf8 Class Initialized
INFO - 2018-04-09 05:31:06 --> URI Class Initialized
INFO - 2018-04-09 05:31:06 --> Router Class Initialized
INFO - 2018-04-09 05:31:06 --> Output Class Initialized
INFO - 2018-04-09 05:31:06 --> Security Class Initialized
DEBUG - 2018-04-09 05:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:31:06 --> Input Class Initialized
INFO - 2018-04-09 05:31:06 --> Language Class Initialized
INFO - 2018-04-09 05:31:06 --> Loader Class Initialized
INFO - 2018-04-09 05:31:06 --> Helper loaded: url_helper
INFO - 2018-04-09 05:31:06 --> Helper loaded: file_helper
INFO - 2018-04-09 05:31:06 --> Helper loaded: date_helper
INFO - 2018-04-09 05:31:06 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:31:06 --> Controller Class Initialized
ERROR - 2018-04-09 05:31:06 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-09 05:34:06 --> Config Class Initialized
INFO - 2018-04-09 05:34:06 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:34:06 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:34:06 --> Utf8 Class Initialized
INFO - 2018-04-09 05:34:06 --> URI Class Initialized
INFO - 2018-04-09 05:34:06 --> Router Class Initialized
INFO - 2018-04-09 05:34:06 --> Output Class Initialized
INFO - 2018-04-09 05:34:06 --> Security Class Initialized
DEBUG - 2018-04-09 05:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:34:06 --> Input Class Initialized
INFO - 2018-04-09 05:34:06 --> Language Class Initialized
INFO - 2018-04-09 05:34:06 --> Loader Class Initialized
INFO - 2018-04-09 05:34:06 --> Helper loaded: url_helper
INFO - 2018-04-09 05:34:06 --> Helper loaded: file_helper
INFO - 2018-04-09 05:34:06 --> Helper loaded: date_helper
INFO - 2018-04-09 05:34:06 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:34:06 --> Controller Class Initialized
ERROR - 2018-04-09 05:34:06 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-09 05:37:00 --> Config Class Initialized
INFO - 2018-04-09 05:37:00 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:37:00 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:37:00 --> Utf8 Class Initialized
INFO - 2018-04-09 05:37:00 --> URI Class Initialized
INFO - 2018-04-09 05:37:00 --> Router Class Initialized
INFO - 2018-04-09 05:37:00 --> Output Class Initialized
INFO - 2018-04-09 05:37:00 --> Security Class Initialized
DEBUG - 2018-04-09 05:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:37:00 --> Input Class Initialized
INFO - 2018-04-09 05:37:00 --> Language Class Initialized
INFO - 2018-04-09 05:37:00 --> Loader Class Initialized
INFO - 2018-04-09 05:37:00 --> Helper loaded: url_helper
INFO - 2018-04-09 05:37:00 --> Helper loaded: file_helper
INFO - 2018-04-09 05:37:00 --> Helper loaded: date_helper
INFO - 2018-04-09 05:37:00 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:37:00 --> Controller Class Initialized
INFO - 2018-04-09 05:37:00 --> Model Class Initialized
ERROR - 2018-04-09 05:37:00 --> Severity: error --> Exception: Call to undefined method Stud_Model::update() G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-09 05:39:08 --> Config Class Initialized
INFO - 2018-04-09 05:39:08 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:39:08 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:39:08 --> Utf8 Class Initialized
INFO - 2018-04-09 05:39:08 --> URI Class Initialized
INFO - 2018-04-09 05:39:08 --> Router Class Initialized
INFO - 2018-04-09 05:39:08 --> Output Class Initialized
INFO - 2018-04-09 05:39:08 --> Security Class Initialized
DEBUG - 2018-04-09 05:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:39:08 --> Input Class Initialized
INFO - 2018-04-09 05:39:08 --> Language Class Initialized
INFO - 2018-04-09 05:39:08 --> Loader Class Initialized
INFO - 2018-04-09 05:39:08 --> Helper loaded: url_helper
INFO - 2018-04-09 05:39:08 --> Helper loaded: file_helper
INFO - 2018-04-09 05:39:08 --> Helper loaded: date_helper
INFO - 2018-04-09 05:39:08 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:39:09 --> Controller Class Initialized
INFO - 2018-04-09 05:39:09 --> Model Class Initialized
INFO - 2018-04-09 05:39:09 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-09 05:41:00 --> Config Class Initialized
INFO - 2018-04-09 05:41:00 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:41:00 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:41:00 --> Utf8 Class Initialized
INFO - 2018-04-09 05:41:00 --> URI Class Initialized
INFO - 2018-04-09 05:41:00 --> Router Class Initialized
INFO - 2018-04-09 05:41:00 --> Output Class Initialized
INFO - 2018-04-09 05:41:01 --> Security Class Initialized
DEBUG - 2018-04-09 05:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:41:01 --> Input Class Initialized
INFO - 2018-04-09 05:41:01 --> Language Class Initialized
INFO - 2018-04-09 05:41:01 --> Loader Class Initialized
INFO - 2018-04-09 05:41:01 --> Helper loaded: url_helper
INFO - 2018-04-09 05:41:01 --> Helper loaded: file_helper
INFO - 2018-04-09 05:41:01 --> Helper loaded: date_helper
INFO - 2018-04-09 05:41:01 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:41:01 --> Controller Class Initialized
INFO - 2018-04-09 05:41:01 --> Model Class Initialized
INFO - 2018-04-09 05:45:55 --> Config Class Initialized
INFO - 2018-04-09 05:45:55 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:45:55 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:45:55 --> Utf8 Class Initialized
INFO - 2018-04-09 05:45:55 --> URI Class Initialized
INFO - 2018-04-09 05:45:55 --> Router Class Initialized
INFO - 2018-04-09 05:45:55 --> Output Class Initialized
INFO - 2018-04-09 05:45:55 --> Security Class Initialized
DEBUG - 2018-04-09 05:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:45:55 --> Input Class Initialized
INFO - 2018-04-09 05:45:55 --> Language Class Initialized
INFO - 2018-04-09 05:45:55 --> Loader Class Initialized
INFO - 2018-04-09 05:45:55 --> Helper loaded: url_helper
INFO - 2018-04-09 05:45:55 --> Helper loaded: file_helper
INFO - 2018-04-09 05:45:55 --> Helper loaded: date_helper
INFO - 2018-04-09 05:45:55 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:45:55 --> Controller Class Initialized
INFO - 2018-04-09 05:45:55 --> Model Class Initialized
INFO - 2018-04-09 05:53:24 --> Config Class Initialized
INFO - 2018-04-09 05:53:24 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:53:24 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:53:24 --> Utf8 Class Initialized
INFO - 2018-04-09 05:53:24 --> URI Class Initialized
INFO - 2018-04-09 05:53:24 --> Router Class Initialized
INFO - 2018-04-09 05:53:24 --> Output Class Initialized
INFO - 2018-04-09 05:53:24 --> Security Class Initialized
DEBUG - 2018-04-09 05:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:53:24 --> Input Class Initialized
INFO - 2018-04-09 05:53:24 --> Language Class Initialized
INFO - 2018-04-09 05:53:24 --> Loader Class Initialized
INFO - 2018-04-09 05:53:24 --> Helper loaded: url_helper
INFO - 2018-04-09 05:53:24 --> Helper loaded: file_helper
INFO - 2018-04-09 05:53:24 --> Helper loaded: date_helper
INFO - 2018-04-09 05:53:24 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:53:24 --> Controller Class Initialized
INFO - 2018-04-09 05:53:24 --> Model Class Initialized
ERROR - 2018-04-09 05:53:24 --> Severity: Notice --> Undefined variable: user G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
ERROR - 2018-04-09 05:53:24 --> Severity: Warning --> Invalid argument supplied for foreach() G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
INFO - 2018-04-09 05:53:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 05:53:24 --> Final output sent to browser
DEBUG - 2018-04-09 05:53:24 --> Total execution time: 0.2981
INFO - 2018-04-09 05:56:57 --> Config Class Initialized
INFO - 2018-04-09 05:56:57 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:56:57 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:56:57 --> Utf8 Class Initialized
INFO - 2018-04-09 05:56:57 --> URI Class Initialized
INFO - 2018-04-09 05:56:57 --> Router Class Initialized
INFO - 2018-04-09 05:56:57 --> Output Class Initialized
INFO - 2018-04-09 05:56:57 --> Security Class Initialized
DEBUG - 2018-04-09 05:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:56:57 --> Input Class Initialized
INFO - 2018-04-09 05:56:57 --> Language Class Initialized
INFO - 2018-04-09 05:56:57 --> Loader Class Initialized
INFO - 2018-04-09 05:56:57 --> Helper loaded: url_helper
INFO - 2018-04-09 05:56:57 --> Helper loaded: file_helper
INFO - 2018-04-09 05:56:57 --> Helper loaded: date_helper
INFO - 2018-04-09 05:56:57 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:56:57 --> Controller Class Initialized
INFO - 2018-04-09 05:56:57 --> Model Class Initialized
INFO - 2018-04-09 05:56:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 05:56:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 05:56:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 05:56:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 05:56:57 --> Final output sent to browser
DEBUG - 2018-04-09 05:56:57 --> Total execution time: 0.3076
INFO - 2018-04-09 05:58:42 --> Config Class Initialized
INFO - 2018-04-09 05:58:42 --> Hooks Class Initialized
DEBUG - 2018-04-09 05:58:42 --> UTF-8 Support Enabled
INFO - 2018-04-09 05:58:42 --> Utf8 Class Initialized
INFO - 2018-04-09 05:58:42 --> URI Class Initialized
INFO - 2018-04-09 05:58:42 --> Router Class Initialized
INFO - 2018-04-09 05:58:42 --> Output Class Initialized
INFO - 2018-04-09 05:58:42 --> Security Class Initialized
DEBUG - 2018-04-09 05:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 05:58:42 --> Input Class Initialized
INFO - 2018-04-09 05:58:42 --> Language Class Initialized
INFO - 2018-04-09 05:58:42 --> Loader Class Initialized
INFO - 2018-04-09 05:58:42 --> Helper loaded: url_helper
INFO - 2018-04-09 05:58:42 --> Helper loaded: file_helper
INFO - 2018-04-09 05:58:42 --> Helper loaded: date_helper
INFO - 2018-04-09 05:58:42 --> Database Driver Class Initialized
DEBUG - 2018-04-09 05:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 05:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 05:58:42 --> Controller Class Initialized
INFO - 2018-04-09 05:58:43 --> Model Class Initialized
INFO - 2018-04-09 05:58:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 05:58:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 05:58:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 05:58:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 05:58:43 --> Final output sent to browser
DEBUG - 2018-04-09 05:58:43 --> Total execution time: 0.3136
INFO - 2018-04-09 06:06:45 --> Config Class Initialized
INFO - 2018-04-09 06:06:45 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:06:45 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:06:45 --> Utf8 Class Initialized
INFO - 2018-04-09 06:06:45 --> URI Class Initialized
INFO - 2018-04-09 06:06:45 --> Router Class Initialized
INFO - 2018-04-09 06:06:45 --> Output Class Initialized
INFO - 2018-04-09 06:06:45 --> Security Class Initialized
DEBUG - 2018-04-09 06:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:06:45 --> Input Class Initialized
INFO - 2018-04-09 06:06:45 --> Language Class Initialized
INFO - 2018-04-09 06:06:45 --> Loader Class Initialized
INFO - 2018-04-09 06:06:45 --> Helper loaded: url_helper
INFO - 2018-04-09 06:06:45 --> Helper loaded: file_helper
INFO - 2018-04-09 06:06:45 --> Helper loaded: date_helper
INFO - 2018-04-09 06:06:45 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:06:46 --> Controller Class Initialized
INFO - 2018-04-09 06:06:46 --> Model Class Initialized
INFO - 2018-04-09 06:06:46 --> Final output sent to browser
DEBUG - 2018-04-09 06:06:46 --> Total execution time: 0.2557
INFO - 2018-04-09 06:06:48 --> Config Class Initialized
INFO - 2018-04-09 06:06:48 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:06:48 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:06:48 --> Utf8 Class Initialized
INFO - 2018-04-09 06:06:48 --> URI Class Initialized
INFO - 2018-04-09 06:06:48 --> Router Class Initialized
INFO - 2018-04-09 06:06:48 --> Output Class Initialized
INFO - 2018-04-09 06:06:48 --> Security Class Initialized
DEBUG - 2018-04-09 06:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:06:48 --> Input Class Initialized
INFO - 2018-04-09 06:06:48 --> Language Class Initialized
INFO - 2018-04-09 06:06:48 --> Loader Class Initialized
INFO - 2018-04-09 06:06:48 --> Helper loaded: url_helper
INFO - 2018-04-09 06:06:48 --> Helper loaded: file_helper
INFO - 2018-04-09 06:06:48 --> Helper loaded: date_helper
INFO - 2018-04-09 06:06:48 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:06:48 --> Controller Class Initialized
INFO - 2018-04-09 06:06:48 --> Model Class Initialized
INFO - 2018-04-09 06:06:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:06:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:06:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:06:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:06:48 --> Final output sent to browser
DEBUG - 2018-04-09 06:06:48 --> Total execution time: 0.4334
INFO - 2018-04-09 06:06:50 --> Config Class Initialized
INFO - 2018-04-09 06:06:50 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:06:50 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:06:50 --> Utf8 Class Initialized
INFO - 2018-04-09 06:06:50 --> URI Class Initialized
INFO - 2018-04-09 06:06:50 --> Router Class Initialized
INFO - 2018-04-09 06:06:50 --> Output Class Initialized
INFO - 2018-04-09 06:06:50 --> Security Class Initialized
DEBUG - 2018-04-09 06:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:06:50 --> Input Class Initialized
INFO - 2018-04-09 06:06:50 --> Language Class Initialized
INFO - 2018-04-09 06:06:50 --> Loader Class Initialized
INFO - 2018-04-09 06:06:50 --> Helper loaded: url_helper
INFO - 2018-04-09 06:06:50 --> Helper loaded: file_helper
INFO - 2018-04-09 06:06:50 --> Helper loaded: date_helper
INFO - 2018-04-09 06:06:50 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:06:50 --> Controller Class Initialized
INFO - 2018-04-09 06:06:50 --> Model Class Initialized
INFO - 2018-04-09 06:06:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:06:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:06:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:06:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:06:50 --> Final output sent to browser
DEBUG - 2018-04-09 06:06:50 --> Total execution time: 0.3169
INFO - 2018-04-09 06:06:52 --> Config Class Initialized
INFO - 2018-04-09 06:06:52 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:06:52 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:06:52 --> Utf8 Class Initialized
INFO - 2018-04-09 06:06:53 --> URI Class Initialized
INFO - 2018-04-09 06:06:53 --> Router Class Initialized
INFO - 2018-04-09 06:06:53 --> Output Class Initialized
INFO - 2018-04-09 06:06:53 --> Security Class Initialized
DEBUG - 2018-04-09 06:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:06:53 --> Input Class Initialized
INFO - 2018-04-09 06:06:53 --> Language Class Initialized
INFO - 2018-04-09 06:06:53 --> Loader Class Initialized
INFO - 2018-04-09 06:06:53 --> Helper loaded: url_helper
INFO - 2018-04-09 06:06:53 --> Helper loaded: file_helper
INFO - 2018-04-09 06:06:53 --> Helper loaded: date_helper
INFO - 2018-04-09 06:06:53 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:06:53 --> Controller Class Initialized
INFO - 2018-04-09 06:06:53 --> Model Class Initialized
INFO - 2018-04-09 06:06:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:06:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:06:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:06:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:06:53 --> Final output sent to browser
DEBUG - 2018-04-09 06:06:53 --> Total execution time: 0.3257
INFO - 2018-04-09 06:06:56 --> Config Class Initialized
INFO - 2018-04-09 06:06:56 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:06:56 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:06:56 --> Utf8 Class Initialized
INFO - 2018-04-09 06:06:56 --> URI Class Initialized
INFO - 2018-04-09 06:06:56 --> Router Class Initialized
INFO - 2018-04-09 06:06:56 --> Output Class Initialized
INFO - 2018-04-09 06:06:56 --> Security Class Initialized
DEBUG - 2018-04-09 06:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:06:56 --> Input Class Initialized
INFO - 2018-04-09 06:06:56 --> Language Class Initialized
INFO - 2018-04-09 06:06:56 --> Loader Class Initialized
INFO - 2018-04-09 06:06:56 --> Helper loaded: url_helper
INFO - 2018-04-09 06:06:56 --> Helper loaded: file_helper
INFO - 2018-04-09 06:06:56 --> Helper loaded: date_helper
INFO - 2018-04-09 06:06:56 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:06:56 --> Controller Class Initialized
INFO - 2018-04-09 06:06:56 --> Model Class Initialized
INFO - 2018-04-09 06:06:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:06:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:06:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:06:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:06:56 --> Final output sent to browser
DEBUG - 2018-04-09 06:06:57 --> Total execution time: 0.3201
INFO - 2018-04-09 06:07:11 --> Config Class Initialized
INFO - 2018-04-09 06:07:11 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:07:11 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:07:11 --> Utf8 Class Initialized
INFO - 2018-04-09 06:07:11 --> URI Class Initialized
INFO - 2018-04-09 06:07:11 --> Router Class Initialized
INFO - 2018-04-09 06:07:11 --> Output Class Initialized
INFO - 2018-04-09 06:07:11 --> Security Class Initialized
DEBUG - 2018-04-09 06:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:07:12 --> Input Class Initialized
INFO - 2018-04-09 06:07:12 --> Language Class Initialized
INFO - 2018-04-09 06:07:12 --> Loader Class Initialized
INFO - 2018-04-09 06:07:12 --> Helper loaded: url_helper
INFO - 2018-04-09 06:07:12 --> Helper loaded: file_helper
INFO - 2018-04-09 06:07:12 --> Helper loaded: date_helper
INFO - 2018-04-09 06:07:12 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:07:12 --> Controller Class Initialized
INFO - 2018-04-09 06:07:12 --> Model Class Initialized
INFO - 2018-04-09 06:07:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:07:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:07:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:07:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:07:12 --> Final output sent to browser
DEBUG - 2018-04-09 06:07:12 --> Total execution time: 0.3153
INFO - 2018-04-09 06:08:37 --> Config Class Initialized
INFO - 2018-04-09 06:08:37 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:08:37 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:08:37 --> Utf8 Class Initialized
INFO - 2018-04-09 06:08:37 --> URI Class Initialized
INFO - 2018-04-09 06:08:37 --> Router Class Initialized
INFO - 2018-04-09 06:08:37 --> Output Class Initialized
INFO - 2018-04-09 06:08:37 --> Security Class Initialized
DEBUG - 2018-04-09 06:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:08:37 --> Input Class Initialized
INFO - 2018-04-09 06:08:37 --> Language Class Initialized
INFO - 2018-04-09 06:08:37 --> Loader Class Initialized
INFO - 2018-04-09 06:08:37 --> Helper loaded: url_helper
INFO - 2018-04-09 06:08:37 --> Helper loaded: file_helper
INFO - 2018-04-09 06:08:37 --> Helper loaded: date_helper
INFO - 2018-04-09 06:08:37 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:08:37 --> Controller Class Initialized
INFO - 2018-04-09 06:08:37 --> Model Class Initialized
INFO - 2018-04-09 06:08:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:08:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:08:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:08:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:08:37 --> Final output sent to browser
DEBUG - 2018-04-09 06:08:37 --> Total execution time: 0.3268
INFO - 2018-04-09 06:08:41 --> Config Class Initialized
INFO - 2018-04-09 06:08:41 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:08:41 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:08:41 --> Utf8 Class Initialized
INFO - 2018-04-09 06:08:41 --> URI Class Initialized
INFO - 2018-04-09 06:08:41 --> Router Class Initialized
INFO - 2018-04-09 06:08:41 --> Output Class Initialized
INFO - 2018-04-09 06:08:41 --> Security Class Initialized
DEBUG - 2018-04-09 06:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:08:41 --> Input Class Initialized
INFO - 2018-04-09 06:08:41 --> Language Class Initialized
INFO - 2018-04-09 06:08:42 --> Loader Class Initialized
INFO - 2018-04-09 06:08:42 --> Helper loaded: url_helper
INFO - 2018-04-09 06:08:42 --> Helper loaded: file_helper
INFO - 2018-04-09 06:08:42 --> Helper loaded: date_helper
INFO - 2018-04-09 06:08:42 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:08:42 --> Controller Class Initialized
INFO - 2018-04-09 06:08:42 --> Model Class Initialized
INFO - 2018-04-09 06:08:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:08:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:08:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:08:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:08:42 --> Final output sent to browser
DEBUG - 2018-04-09 06:08:42 --> Total execution time: 0.3240
INFO - 2018-04-09 06:09:03 --> Config Class Initialized
INFO - 2018-04-09 06:09:03 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:09:03 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:09:03 --> Utf8 Class Initialized
INFO - 2018-04-09 06:09:03 --> URI Class Initialized
INFO - 2018-04-09 06:09:03 --> Router Class Initialized
INFO - 2018-04-09 06:09:03 --> Output Class Initialized
INFO - 2018-04-09 06:09:03 --> Security Class Initialized
DEBUG - 2018-04-09 06:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:09:03 --> Input Class Initialized
INFO - 2018-04-09 06:09:03 --> Language Class Initialized
INFO - 2018-04-09 06:09:03 --> Loader Class Initialized
INFO - 2018-04-09 06:09:03 --> Helper loaded: url_helper
INFO - 2018-04-09 06:09:03 --> Helper loaded: file_helper
INFO - 2018-04-09 06:09:03 --> Helper loaded: date_helper
INFO - 2018-04-09 06:09:03 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:09:03 --> Controller Class Initialized
INFO - 2018-04-09 06:09:03 --> Model Class Initialized
INFO - 2018-04-09 06:09:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:09:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:09:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:09:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:09:03 --> Final output sent to browser
DEBUG - 2018-04-09 06:09:03 --> Total execution time: 0.3180
INFO - 2018-04-09 06:09:14 --> Config Class Initialized
INFO - 2018-04-09 06:09:14 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:09:14 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:09:14 --> Utf8 Class Initialized
INFO - 2018-04-09 06:09:14 --> URI Class Initialized
INFO - 2018-04-09 06:09:14 --> Router Class Initialized
INFO - 2018-04-09 06:09:14 --> Output Class Initialized
INFO - 2018-04-09 06:09:14 --> Security Class Initialized
DEBUG - 2018-04-09 06:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:09:14 --> Input Class Initialized
INFO - 2018-04-09 06:09:14 --> Language Class Initialized
INFO - 2018-04-09 06:09:14 --> Loader Class Initialized
INFO - 2018-04-09 06:09:14 --> Helper loaded: url_helper
INFO - 2018-04-09 06:09:14 --> Helper loaded: file_helper
INFO - 2018-04-09 06:09:14 --> Helper loaded: date_helper
INFO - 2018-04-09 06:09:14 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:09:14 --> Controller Class Initialized
INFO - 2018-04-09 06:09:14 --> Model Class Initialized
INFO - 2018-04-09 06:09:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:09:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:09:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:09:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:09:14 --> Final output sent to browser
DEBUG - 2018-04-09 06:09:14 --> Total execution time: 0.3181
INFO - 2018-04-09 06:09:44 --> Config Class Initialized
INFO - 2018-04-09 06:09:44 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:09:44 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:09:44 --> Utf8 Class Initialized
INFO - 2018-04-09 06:09:44 --> URI Class Initialized
INFO - 2018-04-09 06:09:44 --> Router Class Initialized
INFO - 2018-04-09 06:09:44 --> Output Class Initialized
INFO - 2018-04-09 06:09:44 --> Security Class Initialized
DEBUG - 2018-04-09 06:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:09:44 --> Input Class Initialized
INFO - 2018-04-09 06:09:44 --> Language Class Initialized
INFO - 2018-04-09 06:09:44 --> Loader Class Initialized
INFO - 2018-04-09 06:09:44 --> Helper loaded: url_helper
INFO - 2018-04-09 06:09:44 --> Helper loaded: file_helper
INFO - 2018-04-09 06:09:44 --> Helper loaded: date_helper
INFO - 2018-04-09 06:09:44 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:09:44 --> Controller Class Initialized
INFO - 2018-04-09 06:09:44 --> Model Class Initialized
INFO - 2018-04-09 06:09:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:09:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:09:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:09:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:09:44 --> Final output sent to browser
DEBUG - 2018-04-09 06:09:44 --> Total execution time: 0.3220
INFO - 2018-04-09 06:09:45 --> Config Class Initialized
INFO - 2018-04-09 06:09:45 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:09:45 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:09:45 --> Utf8 Class Initialized
INFO - 2018-04-09 06:09:46 --> URI Class Initialized
INFO - 2018-04-09 06:09:46 --> Router Class Initialized
INFO - 2018-04-09 06:09:46 --> Output Class Initialized
INFO - 2018-04-09 06:09:46 --> Security Class Initialized
DEBUG - 2018-04-09 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:09:46 --> Input Class Initialized
INFO - 2018-04-09 06:09:46 --> Language Class Initialized
INFO - 2018-04-09 06:09:46 --> Loader Class Initialized
INFO - 2018-04-09 06:09:46 --> Helper loaded: url_helper
INFO - 2018-04-09 06:09:46 --> Helper loaded: file_helper
INFO - 2018-04-09 06:09:46 --> Helper loaded: date_helper
INFO - 2018-04-09 06:09:46 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:09:46 --> Controller Class Initialized
INFO - 2018-04-09 06:09:46 --> Model Class Initialized
INFO - 2018-04-09 06:09:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:09:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:09:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:09:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:09:46 --> Final output sent to browser
DEBUG - 2018-04-09 06:09:46 --> Total execution time: 0.3724
INFO - 2018-04-09 06:09:53 --> Config Class Initialized
INFO - 2018-04-09 06:09:53 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:09:53 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:09:53 --> Utf8 Class Initialized
INFO - 2018-04-09 06:09:53 --> URI Class Initialized
INFO - 2018-04-09 06:09:53 --> Router Class Initialized
INFO - 2018-04-09 06:09:53 --> Output Class Initialized
INFO - 2018-04-09 06:09:53 --> Security Class Initialized
DEBUG - 2018-04-09 06:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:09:53 --> Input Class Initialized
INFO - 2018-04-09 06:09:53 --> Language Class Initialized
INFO - 2018-04-09 06:09:53 --> Loader Class Initialized
INFO - 2018-04-09 06:09:53 --> Helper loaded: url_helper
INFO - 2018-04-09 06:09:53 --> Helper loaded: file_helper
INFO - 2018-04-09 06:09:53 --> Helper loaded: date_helper
INFO - 2018-04-09 06:09:53 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:09:53 --> Controller Class Initialized
DEBUG - 2018-04-09 06:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-09 06:09:53 --> Config Class Initialized
INFO - 2018-04-09 06:09:53 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:09:53 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:09:53 --> Utf8 Class Initialized
INFO - 2018-04-09 06:09:53 --> URI Class Initialized
INFO - 2018-04-09 06:09:53 --> Router Class Initialized
INFO - 2018-04-09 06:09:53 --> Output Class Initialized
INFO - 2018-04-09 06:09:53 --> Security Class Initialized
DEBUG - 2018-04-09 06:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:09:54 --> Input Class Initialized
INFO - 2018-04-09 06:09:54 --> Language Class Initialized
INFO - 2018-04-09 06:09:54 --> Loader Class Initialized
INFO - 2018-04-09 06:09:54 --> Helper loaded: url_helper
INFO - 2018-04-09 06:09:54 --> Helper loaded: file_helper
INFO - 2018-04-09 06:09:54 --> Helper loaded: date_helper
INFO - 2018-04-09 06:09:54 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:09:54 --> Controller Class Initialized
INFO - 2018-04-09 06:09:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-09 06:09:54 --> Final output sent to browser
DEBUG - 2018-04-09 06:09:54 --> Total execution time: 0.2668
INFO - 2018-04-09 06:10:06 --> Config Class Initialized
INFO - 2018-04-09 06:10:06 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:10:06 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:10:06 --> Utf8 Class Initialized
INFO - 2018-04-09 06:10:06 --> URI Class Initialized
INFO - 2018-04-09 06:10:06 --> Router Class Initialized
INFO - 2018-04-09 06:10:06 --> Output Class Initialized
INFO - 2018-04-09 06:10:06 --> Security Class Initialized
DEBUG - 2018-04-09 06:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:10:06 --> Input Class Initialized
INFO - 2018-04-09 06:10:06 --> Language Class Initialized
INFO - 2018-04-09 06:10:06 --> Loader Class Initialized
INFO - 2018-04-09 06:10:06 --> Helper loaded: url_helper
INFO - 2018-04-09 06:10:06 --> Helper loaded: file_helper
INFO - 2018-04-09 06:10:06 --> Helper loaded: date_helper
INFO - 2018-04-09 06:10:06 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:10:06 --> Controller Class Initialized
INFO - 2018-04-09 06:10:06 --> Model Class Initialized
INFO - 2018-04-09 06:10:06 --> Final output sent to browser
DEBUG - 2018-04-09 06:10:06 --> Total execution time: 0.2823
INFO - 2018-04-09 06:10:06 --> Config Class Initialized
INFO - 2018-04-09 06:10:06 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:10:06 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:10:06 --> Utf8 Class Initialized
INFO - 2018-04-09 06:10:06 --> URI Class Initialized
INFO - 2018-04-09 06:10:06 --> Router Class Initialized
INFO - 2018-04-09 06:10:06 --> Output Class Initialized
INFO - 2018-04-09 06:10:06 --> Security Class Initialized
DEBUG - 2018-04-09 06:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:10:06 --> Input Class Initialized
INFO - 2018-04-09 06:10:06 --> Language Class Initialized
INFO - 2018-04-09 06:10:06 --> Loader Class Initialized
INFO - 2018-04-09 06:10:06 --> Helper loaded: url_helper
INFO - 2018-04-09 06:10:06 --> Helper loaded: file_helper
INFO - 2018-04-09 06:10:06 --> Helper loaded: date_helper
INFO - 2018-04-09 06:10:06 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:10:06 --> Controller Class Initialized
INFO - 2018-04-09 06:10:06 --> Model Class Initialized
INFO - 2018-04-09 06:10:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:10:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:10:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:10:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:10:07 --> Final output sent to browser
DEBUG - 2018-04-09 06:10:07 --> Total execution time: 0.3167
INFO - 2018-04-09 06:12:12 --> Config Class Initialized
INFO - 2018-04-09 06:12:12 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:12:12 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:12:12 --> Utf8 Class Initialized
INFO - 2018-04-09 06:12:12 --> URI Class Initialized
INFO - 2018-04-09 06:12:12 --> Router Class Initialized
INFO - 2018-04-09 06:12:12 --> Output Class Initialized
INFO - 2018-04-09 06:12:12 --> Security Class Initialized
DEBUG - 2018-04-09 06:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:12:12 --> Input Class Initialized
INFO - 2018-04-09 06:12:12 --> Language Class Initialized
INFO - 2018-04-09 06:12:12 --> Loader Class Initialized
INFO - 2018-04-09 06:12:12 --> Helper loaded: url_helper
INFO - 2018-04-09 06:12:12 --> Helper loaded: file_helper
INFO - 2018-04-09 06:12:12 --> Helper loaded: date_helper
INFO - 2018-04-09 06:12:12 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:12:12 --> Controller Class Initialized
INFO - 2018-04-09 06:12:12 --> Model Class Initialized
INFO - 2018-04-09 06:12:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:12:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:12:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:12:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:12:12 --> Final output sent to browser
DEBUG - 2018-04-09 06:12:12 --> Total execution time: 0.3193
INFO - 2018-04-09 06:12:21 --> Config Class Initialized
INFO - 2018-04-09 06:12:21 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:12:21 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:12:21 --> Utf8 Class Initialized
INFO - 2018-04-09 06:12:21 --> URI Class Initialized
INFO - 2018-04-09 06:12:21 --> Router Class Initialized
INFO - 2018-04-09 06:12:21 --> Output Class Initialized
INFO - 2018-04-09 06:12:21 --> Security Class Initialized
DEBUG - 2018-04-09 06:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:12:21 --> Input Class Initialized
INFO - 2018-04-09 06:12:21 --> Language Class Initialized
INFO - 2018-04-09 06:12:21 --> Loader Class Initialized
INFO - 2018-04-09 06:12:21 --> Helper loaded: url_helper
INFO - 2018-04-09 06:12:21 --> Helper loaded: file_helper
INFO - 2018-04-09 06:12:22 --> Helper loaded: date_helper
INFO - 2018-04-09 06:12:22 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:12:22 --> Controller Class Initialized
INFO - 2018-04-09 06:12:22 --> Model Class Initialized
INFO - 2018-04-09 06:12:22 --> Config Class Initialized
INFO - 2018-04-09 06:12:22 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:12:22 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:12:22 --> Utf8 Class Initialized
INFO - 2018-04-09 06:12:22 --> URI Class Initialized
INFO - 2018-04-09 06:12:22 --> Router Class Initialized
INFO - 2018-04-09 06:12:22 --> Output Class Initialized
INFO - 2018-04-09 06:12:22 --> Security Class Initialized
DEBUG - 2018-04-09 06:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:12:22 --> Input Class Initialized
INFO - 2018-04-09 06:12:22 --> Language Class Initialized
INFO - 2018-04-09 06:12:22 --> Loader Class Initialized
INFO - 2018-04-09 06:12:22 --> Helper loaded: url_helper
INFO - 2018-04-09 06:12:22 --> Helper loaded: file_helper
INFO - 2018-04-09 06:12:22 --> Helper loaded: date_helper
INFO - 2018-04-09 06:12:22 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:12:22 --> Controller Class Initialized
INFO - 2018-04-09 06:12:22 --> Model Class Initialized
INFO - 2018-04-09 06:12:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:12:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:12:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:12:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:12:22 --> Final output sent to browser
DEBUG - 2018-04-09 06:12:22 --> Total execution time: 0.3195
INFO - 2018-04-09 06:12:28 --> Config Class Initialized
INFO - 2018-04-09 06:12:28 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:12:28 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:12:28 --> Utf8 Class Initialized
INFO - 2018-04-09 06:12:28 --> URI Class Initialized
INFO - 2018-04-09 06:12:28 --> Router Class Initialized
INFO - 2018-04-09 06:12:29 --> Output Class Initialized
INFO - 2018-04-09 06:12:29 --> Security Class Initialized
DEBUG - 2018-04-09 06:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:12:29 --> Input Class Initialized
INFO - 2018-04-09 06:12:29 --> Language Class Initialized
INFO - 2018-04-09 06:12:29 --> Loader Class Initialized
INFO - 2018-04-09 06:12:29 --> Helper loaded: url_helper
INFO - 2018-04-09 06:12:29 --> Helper loaded: file_helper
INFO - 2018-04-09 06:12:29 --> Helper loaded: date_helper
INFO - 2018-04-09 06:12:29 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:12:29 --> Controller Class Initialized
INFO - 2018-04-09 06:12:29 --> Model Class Initialized
INFO - 2018-04-09 06:12:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:12:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:12:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:12:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:12:29 --> Final output sent to browser
DEBUG - 2018-04-09 06:12:29 --> Total execution time: 0.3301
INFO - 2018-04-09 06:15:21 --> Config Class Initialized
INFO - 2018-04-09 06:15:21 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:15:21 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:15:21 --> Utf8 Class Initialized
INFO - 2018-04-09 06:15:21 --> URI Class Initialized
INFO - 2018-04-09 06:15:21 --> Router Class Initialized
INFO - 2018-04-09 06:15:21 --> Output Class Initialized
INFO - 2018-04-09 06:15:21 --> Security Class Initialized
DEBUG - 2018-04-09 06:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:15:21 --> Input Class Initialized
INFO - 2018-04-09 06:15:21 --> Language Class Initialized
INFO - 2018-04-09 06:15:21 --> Loader Class Initialized
INFO - 2018-04-09 06:15:21 --> Helper loaded: url_helper
INFO - 2018-04-09 06:15:21 --> Helper loaded: file_helper
INFO - 2018-04-09 06:15:21 --> Helper loaded: date_helper
INFO - 2018-04-09 06:15:21 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:15:21 --> Controller Class Initialized
INFO - 2018-04-09 06:15:21 --> Model Class Initialized
INFO - 2018-04-09 06:16:13 --> Config Class Initialized
INFO - 2018-04-09 06:16:13 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:16:13 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:16:13 --> Utf8 Class Initialized
INFO - 2018-04-09 06:16:13 --> URI Class Initialized
INFO - 2018-04-09 06:16:13 --> Router Class Initialized
INFO - 2018-04-09 06:16:13 --> Output Class Initialized
INFO - 2018-04-09 06:16:13 --> Security Class Initialized
DEBUG - 2018-04-09 06:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:16:13 --> Input Class Initialized
INFO - 2018-04-09 06:16:13 --> Language Class Initialized
INFO - 2018-04-09 06:16:13 --> Loader Class Initialized
INFO - 2018-04-09 06:16:13 --> Helper loaded: url_helper
INFO - 2018-04-09 06:16:13 --> Helper loaded: file_helper
INFO - 2018-04-09 06:16:13 --> Helper loaded: date_helper
INFO - 2018-04-09 06:16:13 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:16:13 --> Controller Class Initialized
INFO - 2018-04-09 06:16:13 --> Model Class Initialized
INFO - 2018-04-09 06:17:14 --> Config Class Initialized
INFO - 2018-04-09 06:17:14 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:17:14 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:17:14 --> Utf8 Class Initialized
INFO - 2018-04-09 06:17:14 --> URI Class Initialized
INFO - 2018-04-09 06:17:14 --> Router Class Initialized
INFO - 2018-04-09 06:17:14 --> Output Class Initialized
INFO - 2018-04-09 06:17:14 --> Security Class Initialized
DEBUG - 2018-04-09 06:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:17:14 --> Input Class Initialized
INFO - 2018-04-09 06:17:14 --> Language Class Initialized
INFO - 2018-04-09 06:17:14 --> Loader Class Initialized
INFO - 2018-04-09 06:17:14 --> Helper loaded: url_helper
INFO - 2018-04-09 06:17:14 --> Helper loaded: file_helper
INFO - 2018-04-09 06:17:14 --> Helper loaded: date_helper
INFO - 2018-04-09 06:17:14 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:17:14 --> Controller Class Initialized
INFO - 2018-04-09 06:17:14 --> Model Class Initialized
INFO - 2018-04-09 06:17:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:17:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:17:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:17:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:17:14 --> Final output sent to browser
DEBUG - 2018-04-09 06:17:14 --> Total execution time: 0.3474
INFO - 2018-04-09 06:17:17 --> Config Class Initialized
INFO - 2018-04-09 06:17:17 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:17:17 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:17:17 --> Utf8 Class Initialized
INFO - 2018-04-09 06:17:17 --> URI Class Initialized
INFO - 2018-04-09 06:17:17 --> Router Class Initialized
INFO - 2018-04-09 06:17:17 --> Output Class Initialized
INFO - 2018-04-09 06:17:17 --> Security Class Initialized
DEBUG - 2018-04-09 06:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:17:17 --> Input Class Initialized
INFO - 2018-04-09 06:17:17 --> Language Class Initialized
INFO - 2018-04-09 06:17:17 --> Loader Class Initialized
INFO - 2018-04-09 06:17:17 --> Helper loaded: url_helper
INFO - 2018-04-09 06:17:17 --> Helper loaded: file_helper
INFO - 2018-04-09 06:17:17 --> Helper loaded: date_helper
INFO - 2018-04-09 06:17:17 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:17:18 --> Controller Class Initialized
INFO - 2018-04-09 06:17:18 --> Model Class Initialized
INFO - 2018-04-09 06:17:20 --> Config Class Initialized
INFO - 2018-04-09 06:17:20 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:17:20 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:17:20 --> Utf8 Class Initialized
INFO - 2018-04-09 06:17:20 --> URI Class Initialized
INFO - 2018-04-09 06:17:20 --> Router Class Initialized
INFO - 2018-04-09 06:17:20 --> Output Class Initialized
INFO - 2018-04-09 06:17:20 --> Security Class Initialized
DEBUG - 2018-04-09 06:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:17:20 --> Input Class Initialized
INFO - 2018-04-09 06:17:20 --> Language Class Initialized
INFO - 2018-04-09 06:17:20 --> Loader Class Initialized
INFO - 2018-04-09 06:17:20 --> Helper loaded: url_helper
INFO - 2018-04-09 06:17:20 --> Helper loaded: file_helper
INFO - 2018-04-09 06:17:20 --> Helper loaded: date_helper
INFO - 2018-04-09 06:17:20 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:17:20 --> Controller Class Initialized
INFO - 2018-04-09 06:17:20 --> Model Class Initialized
INFO - 2018-04-09 06:17:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:17:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:17:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:17:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:17:20 --> Final output sent to browser
DEBUG - 2018-04-09 06:17:20 --> Total execution time: 0.3306
INFO - 2018-04-09 06:17:22 --> Config Class Initialized
INFO - 2018-04-09 06:17:22 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:17:22 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:17:22 --> Utf8 Class Initialized
INFO - 2018-04-09 06:17:22 --> URI Class Initialized
INFO - 2018-04-09 06:17:22 --> Router Class Initialized
INFO - 2018-04-09 06:17:22 --> Output Class Initialized
INFO - 2018-04-09 06:17:22 --> Security Class Initialized
DEBUG - 2018-04-09 06:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:17:22 --> Input Class Initialized
INFO - 2018-04-09 06:17:22 --> Language Class Initialized
INFO - 2018-04-09 06:17:22 --> Loader Class Initialized
INFO - 2018-04-09 06:17:22 --> Helper loaded: url_helper
INFO - 2018-04-09 06:17:22 --> Helper loaded: file_helper
INFO - 2018-04-09 06:17:22 --> Helper loaded: date_helper
INFO - 2018-04-09 06:17:22 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:17:22 --> Controller Class Initialized
INFO - 2018-04-09 06:17:22 --> Model Class Initialized
INFO - 2018-04-09 06:17:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:17:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:17:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:17:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:17:22 --> Final output sent to browser
DEBUG - 2018-04-09 06:17:22 --> Total execution time: 0.3601
INFO - 2018-04-09 06:17:26 --> Config Class Initialized
INFO - 2018-04-09 06:17:26 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:17:26 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:17:26 --> Utf8 Class Initialized
INFO - 2018-04-09 06:17:26 --> URI Class Initialized
INFO - 2018-04-09 06:17:26 --> Router Class Initialized
INFO - 2018-04-09 06:17:26 --> Output Class Initialized
INFO - 2018-04-09 06:17:26 --> Security Class Initialized
DEBUG - 2018-04-09 06:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:17:27 --> Input Class Initialized
INFO - 2018-04-09 06:17:27 --> Language Class Initialized
INFO - 2018-04-09 06:17:27 --> Loader Class Initialized
INFO - 2018-04-09 06:17:27 --> Helper loaded: url_helper
INFO - 2018-04-09 06:17:27 --> Helper loaded: file_helper
INFO - 2018-04-09 06:17:27 --> Helper loaded: date_helper
INFO - 2018-04-09 06:17:27 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:17:27 --> Controller Class Initialized
INFO - 2018-04-09 06:17:27 --> Model Class Initialized
INFO - 2018-04-09 06:17:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:17:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:17:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:17:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:17:27 --> Final output sent to browser
DEBUG - 2018-04-09 06:17:27 --> Total execution time: 0.3262
INFO - 2018-04-09 06:19:00 --> Config Class Initialized
INFO - 2018-04-09 06:19:00 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:19:00 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:19:00 --> Utf8 Class Initialized
INFO - 2018-04-09 06:19:00 --> URI Class Initialized
INFO - 2018-04-09 06:19:00 --> Router Class Initialized
INFO - 2018-04-09 06:19:00 --> Output Class Initialized
INFO - 2018-04-09 06:19:00 --> Security Class Initialized
DEBUG - 2018-04-09 06:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:19:00 --> Input Class Initialized
INFO - 2018-04-09 06:19:00 --> Language Class Initialized
INFO - 2018-04-09 06:19:00 --> Loader Class Initialized
INFO - 2018-04-09 06:19:00 --> Helper loaded: url_helper
INFO - 2018-04-09 06:19:00 --> Helper loaded: file_helper
INFO - 2018-04-09 06:19:00 --> Helper loaded: date_helper
INFO - 2018-04-09 06:19:00 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:19:00 --> Controller Class Initialized
INFO - 2018-04-09 06:19:00 --> Model Class Initialized
INFO - 2018-04-09 06:19:32 --> Config Class Initialized
INFO - 2018-04-09 06:19:32 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:19:32 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:19:32 --> Utf8 Class Initialized
INFO - 2018-04-09 06:19:32 --> URI Class Initialized
INFO - 2018-04-09 06:19:32 --> Router Class Initialized
INFO - 2018-04-09 06:19:33 --> Output Class Initialized
INFO - 2018-04-09 06:19:33 --> Security Class Initialized
DEBUG - 2018-04-09 06:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:19:33 --> Input Class Initialized
INFO - 2018-04-09 06:19:33 --> Language Class Initialized
INFO - 2018-04-09 06:19:33 --> Loader Class Initialized
INFO - 2018-04-09 06:19:33 --> Helper loaded: url_helper
INFO - 2018-04-09 06:19:33 --> Helper loaded: file_helper
INFO - 2018-04-09 06:19:33 --> Helper loaded: date_helper
INFO - 2018-04-09 06:19:33 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:19:33 --> Controller Class Initialized
INFO - 2018-04-09 06:19:33 --> Model Class Initialized
INFO - 2018-04-09 06:19:33 --> Config Class Initialized
INFO - 2018-04-09 06:19:33 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:19:33 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:19:33 --> Utf8 Class Initialized
INFO - 2018-04-09 06:19:33 --> URI Class Initialized
INFO - 2018-04-09 06:19:33 --> Router Class Initialized
INFO - 2018-04-09 06:19:33 --> Output Class Initialized
INFO - 2018-04-09 06:19:33 --> Security Class Initialized
DEBUG - 2018-04-09 06:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:19:33 --> Input Class Initialized
INFO - 2018-04-09 06:19:33 --> Language Class Initialized
INFO - 2018-04-09 06:19:33 --> Loader Class Initialized
INFO - 2018-04-09 06:19:33 --> Helper loaded: url_helper
INFO - 2018-04-09 06:19:33 --> Helper loaded: file_helper
INFO - 2018-04-09 06:19:33 --> Helper loaded: date_helper
INFO - 2018-04-09 06:19:33 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:19:33 --> Controller Class Initialized
INFO - 2018-04-09 06:19:33 --> Model Class Initialized
INFO - 2018-04-09 06:19:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:19:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:19:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:19:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:19:33 --> Final output sent to browser
DEBUG - 2018-04-09 06:19:33 --> Total execution time: 0.3514
INFO - 2018-04-09 06:19:41 --> Config Class Initialized
INFO - 2018-04-09 06:19:41 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:19:41 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:19:41 --> Utf8 Class Initialized
INFO - 2018-04-09 06:19:41 --> URI Class Initialized
INFO - 2018-04-09 06:19:41 --> Router Class Initialized
INFO - 2018-04-09 06:19:41 --> Output Class Initialized
INFO - 2018-04-09 06:19:41 --> Security Class Initialized
DEBUG - 2018-04-09 06:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:19:41 --> Input Class Initialized
INFO - 2018-04-09 06:19:41 --> Language Class Initialized
INFO - 2018-04-09 06:19:41 --> Loader Class Initialized
INFO - 2018-04-09 06:19:41 --> Helper loaded: url_helper
INFO - 2018-04-09 06:19:41 --> Helper loaded: file_helper
INFO - 2018-04-09 06:19:41 --> Helper loaded: date_helper
INFO - 2018-04-09 06:19:41 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:19:41 --> Controller Class Initialized
DEBUG - 2018-04-09 06:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-09 06:19:41 --> Config Class Initialized
INFO - 2018-04-09 06:19:41 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:19:41 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:19:41 --> Utf8 Class Initialized
INFO - 2018-04-09 06:19:41 --> URI Class Initialized
INFO - 2018-04-09 06:19:41 --> Router Class Initialized
INFO - 2018-04-09 06:19:41 --> Output Class Initialized
INFO - 2018-04-09 06:19:41 --> Security Class Initialized
DEBUG - 2018-04-09 06:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:19:41 --> Input Class Initialized
INFO - 2018-04-09 06:19:41 --> Language Class Initialized
INFO - 2018-04-09 06:19:41 --> Loader Class Initialized
INFO - 2018-04-09 06:19:41 --> Helper loaded: url_helper
INFO - 2018-04-09 06:19:41 --> Helper loaded: file_helper
INFO - 2018-04-09 06:19:41 --> Helper loaded: date_helper
INFO - 2018-04-09 06:19:41 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:19:41 --> Controller Class Initialized
INFO - 2018-04-09 06:19:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-09 06:19:41 --> Final output sent to browser
DEBUG - 2018-04-09 06:19:41 --> Total execution time: 0.2857
INFO - 2018-04-09 06:19:49 --> Config Class Initialized
INFO - 2018-04-09 06:19:49 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:19:49 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:19:49 --> Utf8 Class Initialized
INFO - 2018-04-09 06:19:49 --> URI Class Initialized
INFO - 2018-04-09 06:19:49 --> Router Class Initialized
INFO - 2018-04-09 06:19:49 --> Output Class Initialized
INFO - 2018-04-09 06:19:49 --> Security Class Initialized
DEBUG - 2018-04-09 06:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:19:49 --> Input Class Initialized
INFO - 2018-04-09 06:19:49 --> Language Class Initialized
INFO - 2018-04-09 06:19:49 --> Loader Class Initialized
INFO - 2018-04-09 06:19:49 --> Helper loaded: url_helper
INFO - 2018-04-09 06:19:49 --> Helper loaded: file_helper
INFO - 2018-04-09 06:19:49 --> Helper loaded: date_helper
INFO - 2018-04-09 06:19:49 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:19:49 --> Controller Class Initialized
INFO - 2018-04-09 06:19:49 --> Model Class Initialized
INFO - 2018-04-09 06:19:49 --> Final output sent to browser
DEBUG - 2018-04-09 06:19:49 --> Total execution time: 0.2877
INFO - 2018-04-09 06:19:49 --> Config Class Initialized
INFO - 2018-04-09 06:19:49 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:19:49 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:19:49 --> Utf8 Class Initialized
INFO - 2018-04-09 06:19:49 --> URI Class Initialized
INFO - 2018-04-09 06:19:49 --> Router Class Initialized
INFO - 2018-04-09 06:19:49 --> Output Class Initialized
INFO - 2018-04-09 06:19:49 --> Security Class Initialized
DEBUG - 2018-04-09 06:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:19:49 --> Input Class Initialized
INFO - 2018-04-09 06:19:49 --> Language Class Initialized
INFO - 2018-04-09 06:19:49 --> Loader Class Initialized
INFO - 2018-04-09 06:19:49 --> Helper loaded: url_helper
INFO - 2018-04-09 06:19:49 --> Helper loaded: file_helper
INFO - 2018-04-09 06:19:49 --> Helper loaded: date_helper
INFO - 2018-04-09 06:19:49 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:19:49 --> Controller Class Initialized
INFO - 2018-04-09 06:19:49 --> Model Class Initialized
INFO - 2018-04-09 06:19:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:19:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:19:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:19:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:19:49 --> Final output sent to browser
DEBUG - 2018-04-09 06:19:49 --> Total execution time: 0.3250
INFO - 2018-04-09 06:19:52 --> Config Class Initialized
INFO - 2018-04-09 06:19:52 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:19:52 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:19:52 --> Utf8 Class Initialized
INFO - 2018-04-09 06:19:52 --> URI Class Initialized
INFO - 2018-04-09 06:19:52 --> Router Class Initialized
INFO - 2018-04-09 06:19:52 --> Output Class Initialized
INFO - 2018-04-09 06:19:53 --> Security Class Initialized
DEBUG - 2018-04-09 06:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:19:53 --> Input Class Initialized
INFO - 2018-04-09 06:19:53 --> Language Class Initialized
INFO - 2018-04-09 06:19:53 --> Loader Class Initialized
INFO - 2018-04-09 06:19:53 --> Helper loaded: url_helper
INFO - 2018-04-09 06:19:53 --> Helper loaded: file_helper
INFO - 2018-04-09 06:19:53 --> Helper loaded: date_helper
INFO - 2018-04-09 06:19:53 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:19:53 --> Controller Class Initialized
INFO - 2018-04-09 06:19:53 --> Model Class Initialized
INFO - 2018-04-09 06:19:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:19:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:19:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:19:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:19:53 --> Final output sent to browser
DEBUG - 2018-04-09 06:19:53 --> Total execution time: 0.3303
INFO - 2018-04-09 06:20:31 --> Config Class Initialized
INFO - 2018-04-09 06:20:31 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:20:31 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:20:31 --> Utf8 Class Initialized
INFO - 2018-04-09 06:20:31 --> URI Class Initialized
INFO - 2018-04-09 06:20:31 --> Router Class Initialized
INFO - 2018-04-09 06:20:31 --> Output Class Initialized
INFO - 2018-04-09 06:20:31 --> Security Class Initialized
DEBUG - 2018-04-09 06:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:20:31 --> Input Class Initialized
INFO - 2018-04-09 06:20:31 --> Language Class Initialized
INFO - 2018-04-09 06:20:31 --> Loader Class Initialized
INFO - 2018-04-09 06:20:31 --> Helper loaded: url_helper
INFO - 2018-04-09 06:20:31 --> Helper loaded: file_helper
INFO - 2018-04-09 06:20:31 --> Helper loaded: date_helper
INFO - 2018-04-09 06:20:31 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:20:31 --> Controller Class Initialized
INFO - 2018-04-09 06:20:31 --> Model Class Initialized
INFO - 2018-04-09 06:20:31 --> Config Class Initialized
INFO - 2018-04-09 06:20:31 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:20:31 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:20:31 --> Utf8 Class Initialized
INFO - 2018-04-09 06:20:31 --> URI Class Initialized
INFO - 2018-04-09 06:20:31 --> Router Class Initialized
INFO - 2018-04-09 06:20:31 --> Output Class Initialized
INFO - 2018-04-09 06:20:31 --> Security Class Initialized
DEBUG - 2018-04-09 06:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:20:31 --> Input Class Initialized
INFO - 2018-04-09 06:20:31 --> Language Class Initialized
INFO - 2018-04-09 06:20:31 --> Loader Class Initialized
INFO - 2018-04-09 06:20:31 --> Helper loaded: url_helper
INFO - 2018-04-09 06:20:31 --> Helper loaded: file_helper
INFO - 2018-04-09 06:20:31 --> Helper loaded: date_helper
INFO - 2018-04-09 06:20:31 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:20:31 --> Controller Class Initialized
INFO - 2018-04-09 06:20:31 --> Model Class Initialized
INFO - 2018-04-09 06:20:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:20:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:20:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:20:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:20:31 --> Final output sent to browser
DEBUG - 2018-04-09 06:20:31 --> Total execution time: 0.3258
INFO - 2018-04-09 06:20:36 --> Config Class Initialized
INFO - 2018-04-09 06:20:36 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:20:36 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:20:36 --> Utf8 Class Initialized
INFO - 2018-04-09 06:20:36 --> URI Class Initialized
INFO - 2018-04-09 06:20:36 --> Router Class Initialized
INFO - 2018-04-09 06:20:36 --> Output Class Initialized
INFO - 2018-04-09 06:20:36 --> Security Class Initialized
DEBUG - 2018-04-09 06:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:20:36 --> Input Class Initialized
INFO - 2018-04-09 06:20:36 --> Language Class Initialized
INFO - 2018-04-09 06:20:36 --> Loader Class Initialized
INFO - 2018-04-09 06:20:36 --> Helper loaded: url_helper
INFO - 2018-04-09 06:20:36 --> Helper loaded: file_helper
INFO - 2018-04-09 06:20:36 --> Helper loaded: date_helper
INFO - 2018-04-09 06:20:36 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:20:36 --> Controller Class Initialized
INFO - 2018-04-09 06:20:36 --> Model Class Initialized
INFO - 2018-04-09 06:20:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:20:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:20:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:20:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:20:36 --> Final output sent to browser
DEBUG - 2018-04-09 06:20:36 --> Total execution time: 0.3371
INFO - 2018-04-09 06:20:44 --> Config Class Initialized
INFO - 2018-04-09 06:20:44 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:20:44 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:20:44 --> Utf8 Class Initialized
INFO - 2018-04-09 06:20:44 --> URI Class Initialized
INFO - 2018-04-09 06:20:44 --> Router Class Initialized
INFO - 2018-04-09 06:20:44 --> Output Class Initialized
INFO - 2018-04-09 06:20:44 --> Security Class Initialized
DEBUG - 2018-04-09 06:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:20:44 --> Input Class Initialized
INFO - 2018-04-09 06:20:44 --> Language Class Initialized
INFO - 2018-04-09 06:20:44 --> Loader Class Initialized
INFO - 2018-04-09 06:20:44 --> Helper loaded: url_helper
INFO - 2018-04-09 06:20:44 --> Helper loaded: file_helper
INFO - 2018-04-09 06:20:44 --> Helper loaded: date_helper
INFO - 2018-04-09 06:20:44 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:20:44 --> Controller Class Initialized
INFO - 2018-04-09 06:20:44 --> Model Class Initialized
INFO - 2018-04-09 06:20:45 --> Config Class Initialized
INFO - 2018-04-09 06:20:45 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:20:45 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:20:45 --> Utf8 Class Initialized
INFO - 2018-04-09 06:20:45 --> URI Class Initialized
INFO - 2018-04-09 06:20:45 --> Router Class Initialized
INFO - 2018-04-09 06:20:45 --> Output Class Initialized
INFO - 2018-04-09 06:20:45 --> Security Class Initialized
DEBUG - 2018-04-09 06:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:20:45 --> Input Class Initialized
INFO - 2018-04-09 06:20:45 --> Language Class Initialized
INFO - 2018-04-09 06:20:45 --> Loader Class Initialized
INFO - 2018-04-09 06:20:45 --> Helper loaded: url_helper
INFO - 2018-04-09 06:20:45 --> Helper loaded: file_helper
INFO - 2018-04-09 06:20:45 --> Helper loaded: date_helper
INFO - 2018-04-09 06:20:45 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:20:45 --> Controller Class Initialized
INFO - 2018-04-09 06:20:45 --> Model Class Initialized
INFO - 2018-04-09 06:20:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:20:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:20:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:20:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:20:45 --> Final output sent to browser
DEBUG - 2018-04-09 06:20:45 --> Total execution time: 0.3513
INFO - 2018-04-09 06:22:29 --> Config Class Initialized
INFO - 2018-04-09 06:22:29 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:22:29 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:22:29 --> Utf8 Class Initialized
INFO - 2018-04-09 06:22:29 --> URI Class Initialized
INFO - 2018-04-09 06:22:29 --> Router Class Initialized
INFO - 2018-04-09 06:22:29 --> Output Class Initialized
INFO - 2018-04-09 06:22:29 --> Security Class Initialized
DEBUG - 2018-04-09 06:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:22:29 --> Input Class Initialized
INFO - 2018-04-09 06:22:29 --> Language Class Initialized
INFO - 2018-04-09 06:22:29 --> Loader Class Initialized
INFO - 2018-04-09 06:22:29 --> Helper loaded: url_helper
INFO - 2018-04-09 06:22:29 --> Helper loaded: file_helper
INFO - 2018-04-09 06:22:29 --> Helper loaded: date_helper
INFO - 2018-04-09 06:22:29 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:22:29 --> Controller Class Initialized
INFO - 2018-04-09 06:22:29 --> Model Class Initialized
INFO - 2018-04-09 06:22:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:22:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:22:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:22:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:22:29 --> Final output sent to browser
DEBUG - 2018-04-09 06:22:29 --> Total execution time: 0.3342
INFO - 2018-04-09 06:28:55 --> Config Class Initialized
INFO - 2018-04-09 06:28:55 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:28:55 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:28:55 --> Utf8 Class Initialized
INFO - 2018-04-09 06:28:55 --> URI Class Initialized
INFO - 2018-04-09 06:28:55 --> Router Class Initialized
INFO - 2018-04-09 06:28:55 --> Output Class Initialized
INFO - 2018-04-09 06:28:55 --> Security Class Initialized
DEBUG - 2018-04-09 06:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:28:55 --> Input Class Initialized
INFO - 2018-04-09 06:28:56 --> Language Class Initialized
INFO - 2018-04-09 06:28:56 --> Loader Class Initialized
INFO - 2018-04-09 06:28:56 --> Helper loaded: url_helper
INFO - 2018-04-09 06:28:56 --> Helper loaded: file_helper
INFO - 2018-04-09 06:28:56 --> Helper loaded: date_helper
INFO - 2018-04-09 06:28:56 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:28:56 --> Controller Class Initialized
INFO - 2018-04-09 06:28:56 --> Model Class Initialized
INFO - 2018-04-09 06:28:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:28:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:28:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:28:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:28:56 --> Final output sent to browser
DEBUG - 2018-04-09 06:28:56 --> Total execution time: 0.3454
INFO - 2018-04-09 06:31:59 --> Config Class Initialized
INFO - 2018-04-09 06:31:59 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:31:59 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:31:59 --> Utf8 Class Initialized
INFO - 2018-04-09 06:31:59 --> URI Class Initialized
INFO - 2018-04-09 06:31:59 --> Router Class Initialized
INFO - 2018-04-09 06:31:59 --> Output Class Initialized
INFO - 2018-04-09 06:31:59 --> Security Class Initialized
DEBUG - 2018-04-09 06:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:31:59 --> Input Class Initialized
INFO - 2018-04-09 06:31:59 --> Language Class Initialized
INFO - 2018-04-09 06:31:59 --> Loader Class Initialized
INFO - 2018-04-09 06:31:59 --> Helper loaded: url_helper
INFO - 2018-04-09 06:31:59 --> Helper loaded: file_helper
INFO - 2018-04-09 06:31:59 --> Helper loaded: date_helper
INFO - 2018-04-09 06:31:59 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:31:59 --> Controller Class Initialized
INFO - 2018-04-09 06:31:59 --> Model Class Initialized
INFO - 2018-04-09 06:31:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:31:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:31:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:31:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:31:59 --> Final output sent to browser
DEBUG - 2018-04-09 06:31:59 --> Total execution time: 0.3604
INFO - 2018-04-09 06:32:03 --> Config Class Initialized
INFO - 2018-04-09 06:32:03 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:32:03 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:32:03 --> Utf8 Class Initialized
INFO - 2018-04-09 06:32:03 --> URI Class Initialized
INFO - 2018-04-09 06:32:03 --> Router Class Initialized
INFO - 2018-04-09 06:32:03 --> Output Class Initialized
INFO - 2018-04-09 06:32:03 --> Security Class Initialized
DEBUG - 2018-04-09 06:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:32:03 --> Input Class Initialized
INFO - 2018-04-09 06:32:03 --> Language Class Initialized
INFO - 2018-04-09 06:32:03 --> Loader Class Initialized
INFO - 2018-04-09 06:32:03 --> Helper loaded: url_helper
INFO - 2018-04-09 06:32:03 --> Helper loaded: file_helper
INFO - 2018-04-09 06:32:03 --> Helper loaded: date_helper
INFO - 2018-04-09 06:32:03 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:32:03 --> Controller Class Initialized
INFO - 2018-04-09 06:32:03 --> Model Class Initialized
INFO - 2018-04-09 06:32:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:32:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:32:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:32:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:32:03 --> Final output sent to browser
DEBUG - 2018-04-09 06:32:03 --> Total execution time: 0.3439
INFO - 2018-04-09 06:32:06 --> Config Class Initialized
INFO - 2018-04-09 06:32:06 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:32:06 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:32:06 --> Utf8 Class Initialized
INFO - 2018-04-09 06:32:06 --> URI Class Initialized
INFO - 2018-04-09 06:32:06 --> Router Class Initialized
INFO - 2018-04-09 06:32:06 --> Output Class Initialized
INFO - 2018-04-09 06:32:06 --> Security Class Initialized
DEBUG - 2018-04-09 06:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:32:06 --> Input Class Initialized
INFO - 2018-04-09 06:32:06 --> Language Class Initialized
INFO - 2018-04-09 06:32:06 --> Loader Class Initialized
INFO - 2018-04-09 06:32:06 --> Helper loaded: url_helper
INFO - 2018-04-09 06:32:06 --> Helper loaded: file_helper
INFO - 2018-04-09 06:32:06 --> Helper loaded: date_helper
INFO - 2018-04-09 06:32:06 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:32:06 --> Controller Class Initialized
INFO - 2018-04-09 06:32:06 --> Model Class Initialized
INFO - 2018-04-09 06:32:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:32:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:32:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:32:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:32:06 --> Final output sent to browser
DEBUG - 2018-04-09 06:32:06 --> Total execution time: 0.3406
INFO - 2018-04-09 06:32:11 --> Config Class Initialized
INFO - 2018-04-09 06:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:32:11 --> Utf8 Class Initialized
INFO - 2018-04-09 06:32:12 --> URI Class Initialized
INFO - 2018-04-09 06:32:12 --> Router Class Initialized
INFO - 2018-04-09 06:32:12 --> Output Class Initialized
INFO - 2018-04-09 06:32:12 --> Security Class Initialized
DEBUG - 2018-04-09 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:32:12 --> Input Class Initialized
INFO - 2018-04-09 06:32:12 --> Language Class Initialized
INFO - 2018-04-09 06:32:12 --> Loader Class Initialized
INFO - 2018-04-09 06:32:12 --> Helper loaded: url_helper
INFO - 2018-04-09 06:32:12 --> Helper loaded: file_helper
INFO - 2018-04-09 06:32:12 --> Helper loaded: date_helper
INFO - 2018-04-09 06:32:12 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:32:12 --> Controller Class Initialized
INFO - 2018-04-09 06:32:12 --> Model Class Initialized
INFO - 2018-04-09 06:32:12 --> Config Class Initialized
INFO - 2018-04-09 06:32:12 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:32:12 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:32:12 --> Utf8 Class Initialized
INFO - 2018-04-09 06:32:12 --> URI Class Initialized
INFO - 2018-04-09 06:32:12 --> Router Class Initialized
INFO - 2018-04-09 06:32:12 --> Output Class Initialized
INFO - 2018-04-09 06:32:12 --> Security Class Initialized
DEBUG - 2018-04-09 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:32:12 --> Input Class Initialized
INFO - 2018-04-09 06:32:12 --> Language Class Initialized
INFO - 2018-04-09 06:32:12 --> Loader Class Initialized
INFO - 2018-04-09 06:32:12 --> Helper loaded: url_helper
INFO - 2018-04-09 06:32:12 --> Helper loaded: file_helper
INFO - 2018-04-09 06:32:12 --> Helper loaded: date_helper
INFO - 2018-04-09 06:32:12 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:32:12 --> Controller Class Initialized
INFO - 2018-04-09 06:32:12 --> Model Class Initialized
INFO - 2018-04-09 06:32:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:32:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:32:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:32:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:32:12 --> Final output sent to browser
DEBUG - 2018-04-09 06:32:12 --> Total execution time: 0.3402
INFO - 2018-04-09 06:41:29 --> Config Class Initialized
INFO - 2018-04-09 06:41:29 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:41:29 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:41:29 --> Utf8 Class Initialized
INFO - 2018-04-09 06:41:29 --> URI Class Initialized
INFO - 2018-04-09 06:41:29 --> Router Class Initialized
INFO - 2018-04-09 06:41:29 --> Output Class Initialized
INFO - 2018-04-09 06:41:29 --> Security Class Initialized
DEBUG - 2018-04-09 06:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:41:29 --> Input Class Initialized
INFO - 2018-04-09 06:41:29 --> Language Class Initialized
INFO - 2018-04-09 06:41:29 --> Loader Class Initialized
INFO - 2018-04-09 06:41:29 --> Helper loaded: url_helper
INFO - 2018-04-09 06:41:29 --> Helper loaded: file_helper
INFO - 2018-04-09 06:41:29 --> Helper loaded: date_helper
INFO - 2018-04-09 06:41:29 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:41:29 --> Controller Class Initialized
INFO - 2018-04-09 06:41:29 --> Model Class Initialized
INFO - 2018-04-09 06:41:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-09 06:41:29 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file G:\xampp\htdocs\codeigniter\application\views\user\user.php 21
INFO - 2018-04-09 06:41:44 --> Config Class Initialized
INFO - 2018-04-09 06:41:44 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:41:44 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:41:44 --> Utf8 Class Initialized
INFO - 2018-04-09 06:41:44 --> URI Class Initialized
INFO - 2018-04-09 06:41:44 --> Router Class Initialized
INFO - 2018-04-09 06:41:44 --> Output Class Initialized
INFO - 2018-04-09 06:41:44 --> Security Class Initialized
DEBUG - 2018-04-09 06:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:41:44 --> Input Class Initialized
INFO - 2018-04-09 06:41:44 --> Language Class Initialized
INFO - 2018-04-09 06:41:44 --> Loader Class Initialized
INFO - 2018-04-09 06:41:44 --> Helper loaded: url_helper
INFO - 2018-04-09 06:41:44 --> Helper loaded: file_helper
INFO - 2018-04-09 06:41:44 --> Helper loaded: date_helper
INFO - 2018-04-09 06:41:44 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:41:44 --> Controller Class Initialized
INFO - 2018-04-09 06:41:44 --> Model Class Initialized
INFO - 2018-04-09 06:41:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:41:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:41:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:41:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:41:45 --> Final output sent to browser
DEBUG - 2018-04-09 06:41:45 --> Total execution time: 0.3441
INFO - 2018-04-09 06:41:47 --> Config Class Initialized
INFO - 2018-04-09 06:41:48 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:41:48 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:41:48 --> Utf8 Class Initialized
INFO - 2018-04-09 06:41:48 --> URI Class Initialized
INFO - 2018-04-09 06:41:48 --> Router Class Initialized
INFO - 2018-04-09 06:41:48 --> Output Class Initialized
INFO - 2018-04-09 06:41:48 --> Security Class Initialized
DEBUG - 2018-04-09 06:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:41:48 --> Input Class Initialized
INFO - 2018-04-09 06:41:48 --> Language Class Initialized
INFO - 2018-04-09 06:41:48 --> Loader Class Initialized
INFO - 2018-04-09 06:41:48 --> Helper loaded: url_helper
INFO - 2018-04-09 06:41:48 --> Helper loaded: file_helper
INFO - 2018-04-09 06:41:48 --> Helper loaded: date_helper
INFO - 2018-04-09 06:41:48 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:41:48 --> Controller Class Initialized
INFO - 2018-04-09 06:41:48 --> Model Class Initialized
INFO - 2018-04-09 06:41:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:41:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:41:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:41:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:41:48 --> Final output sent to browser
DEBUG - 2018-04-09 06:41:48 --> Total execution time: 0.3452
INFO - 2018-04-09 06:42:05 --> Config Class Initialized
INFO - 2018-04-09 06:42:05 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:42:05 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:42:05 --> Utf8 Class Initialized
INFO - 2018-04-09 06:42:05 --> URI Class Initialized
INFO - 2018-04-09 06:42:05 --> Router Class Initialized
INFO - 2018-04-09 06:42:05 --> Output Class Initialized
INFO - 2018-04-09 06:42:05 --> Security Class Initialized
DEBUG - 2018-04-09 06:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:42:05 --> Input Class Initialized
INFO - 2018-04-09 06:42:05 --> Language Class Initialized
INFO - 2018-04-09 06:42:05 --> Loader Class Initialized
INFO - 2018-04-09 06:42:05 --> Helper loaded: url_helper
INFO - 2018-04-09 06:42:05 --> Helper loaded: file_helper
INFO - 2018-04-09 06:42:05 --> Helper loaded: date_helper
INFO - 2018-04-09 06:42:05 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:42:05 --> Controller Class Initialized
INFO - 2018-04-09 06:42:05 --> Model Class Initialized
INFO - 2018-04-09 06:42:05 --> Config Class Initialized
INFO - 2018-04-09 06:42:05 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:42:05 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:42:05 --> Utf8 Class Initialized
INFO - 2018-04-09 06:42:05 --> URI Class Initialized
INFO - 2018-04-09 06:42:06 --> Router Class Initialized
INFO - 2018-04-09 06:42:06 --> Output Class Initialized
INFO - 2018-04-09 06:42:06 --> Security Class Initialized
DEBUG - 2018-04-09 06:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:42:06 --> Input Class Initialized
INFO - 2018-04-09 06:42:06 --> Language Class Initialized
INFO - 2018-04-09 06:42:06 --> Loader Class Initialized
INFO - 2018-04-09 06:42:06 --> Helper loaded: url_helper
INFO - 2018-04-09 06:42:06 --> Helper loaded: file_helper
INFO - 2018-04-09 06:42:06 --> Helper loaded: date_helper
INFO - 2018-04-09 06:42:06 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:42:06 --> Controller Class Initialized
INFO - 2018-04-09 06:42:06 --> Model Class Initialized
INFO - 2018-04-09 06:42:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:42:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:42:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:42:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:42:06 --> Final output sent to browser
DEBUG - 2018-04-09 06:42:06 --> Total execution time: 0.3610
INFO - 2018-04-09 06:44:19 --> Config Class Initialized
INFO - 2018-04-09 06:44:19 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:44:19 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:44:19 --> Utf8 Class Initialized
INFO - 2018-04-09 06:44:19 --> URI Class Initialized
INFO - 2018-04-09 06:44:19 --> Router Class Initialized
INFO - 2018-04-09 06:44:19 --> Output Class Initialized
INFO - 2018-04-09 06:44:19 --> Security Class Initialized
DEBUG - 2018-04-09 06:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:44:19 --> Input Class Initialized
INFO - 2018-04-09 06:44:19 --> Language Class Initialized
INFO - 2018-04-09 06:44:19 --> Loader Class Initialized
INFO - 2018-04-09 06:44:19 --> Helper loaded: url_helper
INFO - 2018-04-09 06:44:19 --> Helper loaded: file_helper
INFO - 2018-04-09 06:44:19 --> Helper loaded: date_helper
INFO - 2018-04-09 06:44:19 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:44:20 --> Controller Class Initialized
INFO - 2018-04-09 06:44:20 --> Model Class Initialized
INFO - 2018-04-09 06:44:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:44:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:44:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:44:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:44:20 --> Final output sent to browser
DEBUG - 2018-04-09 06:44:20 --> Total execution time: 0.3561
INFO - 2018-04-09 06:45:08 --> Config Class Initialized
INFO - 2018-04-09 06:45:08 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:45:08 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:45:09 --> Utf8 Class Initialized
INFO - 2018-04-09 06:45:09 --> URI Class Initialized
INFO - 2018-04-09 06:45:09 --> Router Class Initialized
INFO - 2018-04-09 06:45:09 --> Output Class Initialized
INFO - 2018-04-09 06:45:09 --> Security Class Initialized
DEBUG - 2018-04-09 06:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:45:09 --> Input Class Initialized
INFO - 2018-04-09 06:45:09 --> Language Class Initialized
INFO - 2018-04-09 06:45:09 --> Loader Class Initialized
INFO - 2018-04-09 06:45:09 --> Helper loaded: url_helper
INFO - 2018-04-09 06:45:09 --> Helper loaded: file_helper
INFO - 2018-04-09 06:45:09 --> Helper loaded: date_helper
INFO - 2018-04-09 06:45:09 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:45:09 --> Controller Class Initialized
INFO - 2018-04-09 06:45:09 --> Model Class Initialized
INFO - 2018-04-09 06:45:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:45:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:45:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:45:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:45:09 --> Final output sent to browser
DEBUG - 2018-04-09 06:45:09 --> Total execution time: 0.3462
INFO - 2018-04-09 06:50:26 --> Config Class Initialized
INFO - 2018-04-09 06:50:26 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:50:26 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:50:26 --> Utf8 Class Initialized
INFO - 2018-04-09 06:50:26 --> URI Class Initialized
INFO - 2018-04-09 06:50:26 --> Router Class Initialized
INFO - 2018-04-09 06:50:26 --> Output Class Initialized
INFO - 2018-04-09 06:50:26 --> Security Class Initialized
DEBUG - 2018-04-09 06:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:50:26 --> Input Class Initialized
INFO - 2018-04-09 06:50:26 --> Language Class Initialized
INFO - 2018-04-09 06:50:26 --> Loader Class Initialized
INFO - 2018-04-09 06:50:26 --> Helper loaded: url_helper
INFO - 2018-04-09 06:50:26 --> Helper loaded: file_helper
INFO - 2018-04-09 06:50:26 --> Helper loaded: date_helper
INFO - 2018-04-09 06:50:26 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:50:26 --> Controller Class Initialized
INFO - 2018-04-09 06:50:26 --> Model Class Initialized
INFO - 2018-04-09 06:50:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-09 06:50:26 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file G:\xampp\htdocs\codeigniter\application\views\user\user.php 62
INFO - 2018-04-09 06:51:49 --> Config Class Initialized
INFO - 2018-04-09 06:51:49 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:51:49 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:51:49 --> Utf8 Class Initialized
INFO - 2018-04-09 06:51:49 --> URI Class Initialized
INFO - 2018-04-09 06:51:49 --> Router Class Initialized
INFO - 2018-04-09 06:51:49 --> Output Class Initialized
INFO - 2018-04-09 06:51:49 --> Security Class Initialized
DEBUG - 2018-04-09 06:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:51:49 --> Input Class Initialized
INFO - 2018-04-09 06:51:49 --> Language Class Initialized
INFO - 2018-04-09 06:51:49 --> Loader Class Initialized
INFO - 2018-04-09 06:51:49 --> Helper loaded: url_helper
INFO - 2018-04-09 06:51:49 --> Helper loaded: file_helper
INFO - 2018-04-09 06:51:49 --> Helper loaded: date_helper
INFO - 2018-04-09 06:51:49 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:51:49 --> Controller Class Initialized
INFO - 2018-04-09 06:51:49 --> Model Class Initialized
INFO - 2018-04-09 06:51:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-09 06:51:49 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
INFO - 2018-04-09 06:52:19 --> Config Class Initialized
INFO - 2018-04-09 06:52:19 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:52:19 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:52:19 --> Utf8 Class Initialized
INFO - 2018-04-09 06:52:19 --> URI Class Initialized
INFO - 2018-04-09 06:52:19 --> Router Class Initialized
INFO - 2018-04-09 06:52:19 --> Output Class Initialized
INFO - 2018-04-09 06:52:19 --> Security Class Initialized
DEBUG - 2018-04-09 06:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:52:19 --> Input Class Initialized
INFO - 2018-04-09 06:52:19 --> Language Class Initialized
INFO - 2018-04-09 06:52:19 --> Loader Class Initialized
INFO - 2018-04-09 06:52:19 --> Helper loaded: url_helper
INFO - 2018-04-09 06:52:19 --> Helper loaded: file_helper
INFO - 2018-04-09 06:52:19 --> Helper loaded: date_helper
INFO - 2018-04-09 06:52:19 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:52:19 --> Controller Class Initialized
INFO - 2018-04-09 06:52:19 --> Model Class Initialized
INFO - 2018-04-09 06:52:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-09 06:52:19 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) G:\xampp\htdocs\codeigniter\application\views\user\user.php 13
INFO - 2018-04-09 06:52:44 --> Config Class Initialized
INFO - 2018-04-09 06:52:44 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:52:44 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:52:44 --> Utf8 Class Initialized
INFO - 2018-04-09 06:52:44 --> URI Class Initialized
INFO - 2018-04-09 06:52:44 --> Router Class Initialized
INFO - 2018-04-09 06:52:44 --> Output Class Initialized
INFO - 2018-04-09 06:52:44 --> Security Class Initialized
DEBUG - 2018-04-09 06:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:52:44 --> Input Class Initialized
INFO - 2018-04-09 06:52:44 --> Language Class Initialized
INFO - 2018-04-09 06:52:44 --> Loader Class Initialized
INFO - 2018-04-09 06:52:44 --> Helper loaded: url_helper
INFO - 2018-04-09 06:52:44 --> Helper loaded: file_helper
INFO - 2018-04-09 06:52:44 --> Helper loaded: date_helper
INFO - 2018-04-09 06:52:44 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:52:44 --> Controller Class Initialized
INFO - 2018-04-09 06:52:44 --> Model Class Initialized
INFO - 2018-04-09 06:52:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:52:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:52:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:52:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:52:44 --> Final output sent to browser
DEBUG - 2018-04-09 06:52:44 --> Total execution time: 0.3972
INFO - 2018-04-09 06:52:47 --> Config Class Initialized
INFO - 2018-04-09 06:52:47 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:52:47 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:52:47 --> Utf8 Class Initialized
INFO - 2018-04-09 06:52:47 --> URI Class Initialized
INFO - 2018-04-09 06:52:47 --> Router Class Initialized
INFO - 2018-04-09 06:52:47 --> Output Class Initialized
INFO - 2018-04-09 06:52:47 --> Security Class Initialized
DEBUG - 2018-04-09 06:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:52:47 --> Input Class Initialized
INFO - 2018-04-09 06:52:47 --> Language Class Initialized
INFO - 2018-04-09 06:52:47 --> Loader Class Initialized
INFO - 2018-04-09 06:52:47 --> Helper loaded: url_helper
INFO - 2018-04-09 06:52:47 --> Helper loaded: file_helper
INFO - 2018-04-09 06:52:47 --> Helper loaded: date_helper
INFO - 2018-04-09 06:52:47 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:52:47 --> Controller Class Initialized
INFO - 2018-04-09 06:52:47 --> Model Class Initialized
INFO - 2018-04-09 06:52:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:52:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-09 06:52:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:52:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:52:47 --> Final output sent to browser
DEBUG - 2018-04-09 06:52:47 --> Total execution time: 0.3515
INFO - 2018-04-09 06:52:55 --> Config Class Initialized
INFO - 2018-04-09 06:52:55 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:52:55 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:52:55 --> Utf8 Class Initialized
INFO - 2018-04-09 06:52:55 --> URI Class Initialized
INFO - 2018-04-09 06:52:56 --> Router Class Initialized
INFO - 2018-04-09 06:52:56 --> Output Class Initialized
INFO - 2018-04-09 06:52:56 --> Security Class Initialized
DEBUG - 2018-04-09 06:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:52:56 --> Input Class Initialized
INFO - 2018-04-09 06:52:56 --> Language Class Initialized
INFO - 2018-04-09 06:52:56 --> Loader Class Initialized
INFO - 2018-04-09 06:52:56 --> Helper loaded: url_helper
INFO - 2018-04-09 06:52:56 --> Helper loaded: file_helper
INFO - 2018-04-09 06:52:56 --> Helper loaded: date_helper
INFO - 2018-04-09 06:52:56 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:52:56 --> Controller Class Initialized
INFO - 2018-04-09 06:52:56 --> Model Class Initialized
INFO - 2018-04-09 06:52:56 --> Config Class Initialized
INFO - 2018-04-09 06:52:56 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:52:56 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:52:56 --> Utf8 Class Initialized
INFO - 2018-04-09 06:52:56 --> URI Class Initialized
INFO - 2018-04-09 06:52:56 --> Router Class Initialized
INFO - 2018-04-09 06:52:56 --> Output Class Initialized
INFO - 2018-04-09 06:52:56 --> Security Class Initialized
DEBUG - 2018-04-09 06:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:52:56 --> Input Class Initialized
INFO - 2018-04-09 06:52:56 --> Language Class Initialized
INFO - 2018-04-09 06:52:56 --> Loader Class Initialized
INFO - 2018-04-09 06:52:56 --> Helper loaded: url_helper
INFO - 2018-04-09 06:52:56 --> Helper loaded: file_helper
INFO - 2018-04-09 06:52:56 --> Helper loaded: date_helper
INFO - 2018-04-09 06:52:56 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:52:56 --> Controller Class Initialized
INFO - 2018-04-09 06:52:56 --> Model Class Initialized
INFO - 2018-04-09 06:52:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:52:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:52:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:52:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:52:56 --> Final output sent to browser
DEBUG - 2018-04-09 06:52:56 --> Total execution time: 0.3544
INFO - 2018-04-09 06:53:13 --> Config Class Initialized
INFO - 2018-04-09 06:53:13 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:53:14 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:53:14 --> Utf8 Class Initialized
INFO - 2018-04-09 06:53:14 --> URI Class Initialized
INFO - 2018-04-09 06:53:14 --> Router Class Initialized
INFO - 2018-04-09 06:53:14 --> Output Class Initialized
INFO - 2018-04-09 06:53:14 --> Security Class Initialized
DEBUG - 2018-04-09 06:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:53:14 --> Input Class Initialized
INFO - 2018-04-09 06:53:14 --> Language Class Initialized
INFO - 2018-04-09 06:53:14 --> Loader Class Initialized
INFO - 2018-04-09 06:53:14 --> Helper loaded: url_helper
INFO - 2018-04-09 06:53:14 --> Helper loaded: file_helper
INFO - 2018-04-09 06:53:14 --> Helper loaded: date_helper
INFO - 2018-04-09 06:53:14 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:53:14 --> Controller Class Initialized
INFO - 2018-04-09 06:53:14 --> Model Class Initialized
INFO - 2018-04-09 06:53:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:53:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:53:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:53:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:53:14 --> Final output sent to browser
DEBUG - 2018-04-09 06:53:14 --> Total execution time: 0.4055
INFO - 2018-04-09 06:53:45 --> Config Class Initialized
INFO - 2018-04-09 06:53:45 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:53:45 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:53:45 --> Utf8 Class Initialized
INFO - 2018-04-09 06:53:45 --> URI Class Initialized
INFO - 2018-04-09 06:53:45 --> Router Class Initialized
INFO - 2018-04-09 06:53:45 --> Output Class Initialized
INFO - 2018-04-09 06:53:45 --> Security Class Initialized
DEBUG - 2018-04-09 06:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:53:46 --> Input Class Initialized
INFO - 2018-04-09 06:53:46 --> Language Class Initialized
INFO - 2018-04-09 06:53:46 --> Loader Class Initialized
INFO - 2018-04-09 06:53:46 --> Helper loaded: url_helper
INFO - 2018-04-09 06:53:46 --> Helper loaded: file_helper
INFO - 2018-04-09 06:53:46 --> Helper loaded: date_helper
INFO - 2018-04-09 06:53:46 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:53:46 --> Controller Class Initialized
DEBUG - 2018-04-09 06:53:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-09 06:53:46 --> Config Class Initialized
INFO - 2018-04-09 06:53:46 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:53:46 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:53:46 --> Utf8 Class Initialized
INFO - 2018-04-09 06:53:46 --> URI Class Initialized
INFO - 2018-04-09 06:53:46 --> Router Class Initialized
INFO - 2018-04-09 06:53:46 --> Output Class Initialized
INFO - 2018-04-09 06:53:46 --> Security Class Initialized
DEBUG - 2018-04-09 06:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:53:46 --> Input Class Initialized
INFO - 2018-04-09 06:53:46 --> Language Class Initialized
INFO - 2018-04-09 06:53:46 --> Loader Class Initialized
INFO - 2018-04-09 06:53:46 --> Helper loaded: url_helper
INFO - 2018-04-09 06:53:46 --> Helper loaded: file_helper
INFO - 2018-04-09 06:53:46 --> Helper loaded: date_helper
INFO - 2018-04-09 06:53:46 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:53:46 --> Controller Class Initialized
INFO - 2018-04-09 06:53:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-09 06:53:46 --> Final output sent to browser
DEBUG - 2018-04-09 06:53:46 --> Total execution time: 0.3046
INFO - 2018-04-09 06:54:20 --> Config Class Initialized
INFO - 2018-04-09 06:54:20 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:54:20 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:54:20 --> Utf8 Class Initialized
INFO - 2018-04-09 06:54:20 --> URI Class Initialized
INFO - 2018-04-09 06:54:20 --> Router Class Initialized
INFO - 2018-04-09 06:54:21 --> Output Class Initialized
INFO - 2018-04-09 06:54:21 --> Security Class Initialized
DEBUG - 2018-04-09 06:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:54:21 --> Input Class Initialized
INFO - 2018-04-09 06:54:21 --> Language Class Initialized
INFO - 2018-04-09 06:54:21 --> Loader Class Initialized
INFO - 2018-04-09 06:54:21 --> Helper loaded: url_helper
INFO - 2018-04-09 06:54:21 --> Helper loaded: file_helper
INFO - 2018-04-09 06:54:21 --> Helper loaded: date_helper
INFO - 2018-04-09 06:54:21 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:54:21 --> Controller Class Initialized
INFO - 2018-04-09 06:54:21 --> Model Class Initialized
INFO - 2018-04-09 06:54:21 --> Final output sent to browser
DEBUG - 2018-04-09 06:54:21 --> Total execution time: 0.3170
INFO - 2018-04-09 06:54:21 --> Config Class Initialized
INFO - 2018-04-09 06:54:21 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:54:21 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:54:21 --> Utf8 Class Initialized
INFO - 2018-04-09 06:54:21 --> URI Class Initialized
INFO - 2018-04-09 06:54:21 --> Router Class Initialized
INFO - 2018-04-09 06:54:21 --> Output Class Initialized
INFO - 2018-04-09 06:54:21 --> Security Class Initialized
DEBUG - 2018-04-09 06:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:54:21 --> Input Class Initialized
INFO - 2018-04-09 06:54:21 --> Language Class Initialized
INFO - 2018-04-09 06:54:21 --> Loader Class Initialized
INFO - 2018-04-09 06:54:21 --> Helper loaded: url_helper
INFO - 2018-04-09 06:54:21 --> Helper loaded: file_helper
INFO - 2018-04-09 06:54:21 --> Helper loaded: date_helper
INFO - 2018-04-09 06:54:21 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:54:21 --> Controller Class Initialized
INFO - 2018-04-09 06:54:21 --> Model Class Initialized
INFO - 2018-04-09 06:54:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-09 06:54:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-09 06:54:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-09 06:54:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-09 06:54:21 --> Final output sent to browser
DEBUG - 2018-04-09 06:54:21 --> Total execution time: 0.3525
INFO - 2018-04-09 06:56:53 --> Config Class Initialized
INFO - 2018-04-09 06:56:53 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:56:53 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:56:53 --> Utf8 Class Initialized
INFO - 2018-04-09 06:56:53 --> URI Class Initialized
INFO - 2018-04-09 06:56:53 --> Router Class Initialized
INFO - 2018-04-09 06:56:53 --> Output Class Initialized
INFO - 2018-04-09 06:56:53 --> Security Class Initialized
DEBUG - 2018-04-09 06:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:56:53 --> Input Class Initialized
INFO - 2018-04-09 06:56:53 --> Language Class Initialized
INFO - 2018-04-09 06:56:53 --> Loader Class Initialized
INFO - 2018-04-09 06:56:53 --> Helper loaded: url_helper
INFO - 2018-04-09 06:56:53 --> Helper loaded: file_helper
INFO - 2018-04-09 06:56:53 --> Helper loaded: date_helper
INFO - 2018-04-09 06:56:53 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:56:53 --> Controller Class Initialized
DEBUG - 2018-04-09 06:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-09 06:56:53 --> Config Class Initialized
INFO - 2018-04-09 06:56:53 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:56:53 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:56:53 --> Utf8 Class Initialized
INFO - 2018-04-09 06:56:53 --> URI Class Initialized
INFO - 2018-04-09 06:56:53 --> Router Class Initialized
INFO - 2018-04-09 06:56:53 --> Output Class Initialized
INFO - 2018-04-09 06:56:53 --> Security Class Initialized
DEBUG - 2018-04-09 06:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:56:53 --> Input Class Initialized
INFO - 2018-04-09 06:56:53 --> Language Class Initialized
INFO - 2018-04-09 06:56:53 --> Loader Class Initialized
INFO - 2018-04-09 06:56:53 --> Helper loaded: url_helper
INFO - 2018-04-09 06:56:53 --> Helper loaded: file_helper
INFO - 2018-04-09 06:56:53 --> Helper loaded: date_helper
INFO - 2018-04-09 06:56:53 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:56:54 --> Controller Class Initialized
INFO - 2018-04-09 06:56:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-09 06:56:54 --> Final output sent to browser
DEBUG - 2018-04-09 06:56:54 --> Total execution time: 0.3094
INFO - 2018-04-09 06:57:24 --> Config Class Initialized
INFO - 2018-04-09 06:57:24 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:57:24 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:57:24 --> Utf8 Class Initialized
INFO - 2018-04-09 06:57:24 --> URI Class Initialized
INFO - 2018-04-09 06:57:24 --> Router Class Initialized
INFO - 2018-04-09 06:57:24 --> Output Class Initialized
INFO - 2018-04-09 06:57:24 --> Security Class Initialized
DEBUG - 2018-04-09 06:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:57:24 --> Input Class Initialized
INFO - 2018-04-09 06:57:24 --> Language Class Initialized
INFO - 2018-04-09 06:57:24 --> Loader Class Initialized
INFO - 2018-04-09 06:57:24 --> Helper loaded: url_helper
INFO - 2018-04-09 06:57:24 --> Helper loaded: file_helper
INFO - 2018-04-09 06:57:24 --> Helper loaded: date_helper
INFO - 2018-04-09 06:57:24 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:57:25 --> Controller Class Initialized
INFO - 2018-04-09 06:57:25 --> Model Class Initialized
INFO - 2018-04-09 06:57:25 --> Final output sent to browser
DEBUG - 2018-04-09 06:57:25 --> Total execution time: 0.3133
INFO - 2018-04-09 06:57:25 --> Config Class Initialized
INFO - 2018-04-09 06:57:25 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:57:25 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:57:25 --> Utf8 Class Initialized
INFO - 2018-04-09 06:57:25 --> URI Class Initialized
INFO - 2018-04-09 06:57:25 --> Router Class Initialized
INFO - 2018-04-09 06:57:25 --> Output Class Initialized
INFO - 2018-04-09 06:57:25 --> Security Class Initialized
DEBUG - 2018-04-09 06:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:57:25 --> Input Class Initialized
INFO - 2018-04-09 06:57:25 --> Language Class Initialized
INFO - 2018-04-09 06:57:25 --> Loader Class Initialized
INFO - 2018-04-09 06:57:25 --> Helper loaded: url_helper
INFO - 2018-04-09 06:57:25 --> Helper loaded: file_helper
INFO - 2018-04-09 06:57:25 --> Helper loaded: date_helper
INFO - 2018-04-09 06:57:25 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:57:25 --> Controller Class Initialized
INFO - 2018-04-09 06:57:25 --> Final output sent to browser
DEBUG - 2018-04-09 06:57:25 --> Total execution time: 0.2887
INFO - 2018-04-09 06:57:53 --> Config Class Initialized
INFO - 2018-04-09 06:57:53 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:57:53 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:57:53 --> Utf8 Class Initialized
INFO - 2018-04-09 06:57:53 --> URI Class Initialized
INFO - 2018-04-09 06:57:53 --> Router Class Initialized
INFO - 2018-04-09 06:57:53 --> Output Class Initialized
INFO - 2018-04-09 06:57:53 --> Security Class Initialized
DEBUG - 2018-04-09 06:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:57:53 --> Input Class Initialized
INFO - 2018-04-09 06:57:53 --> Language Class Initialized
INFO - 2018-04-09 06:57:53 --> Loader Class Initialized
INFO - 2018-04-09 06:57:53 --> Helper loaded: url_helper
INFO - 2018-04-09 06:57:53 --> Helper loaded: file_helper
INFO - 2018-04-09 06:57:53 --> Helper loaded: date_helper
INFO - 2018-04-09 06:57:53 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:57:53 --> Controller Class Initialized
INFO - 2018-04-09 06:59:26 --> Config Class Initialized
INFO - 2018-04-09 06:59:26 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:59:26 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:59:26 --> Utf8 Class Initialized
INFO - 2018-04-09 06:59:26 --> URI Class Initialized
INFO - 2018-04-09 06:59:26 --> Router Class Initialized
INFO - 2018-04-09 06:59:26 --> Output Class Initialized
INFO - 2018-04-09 06:59:26 --> Security Class Initialized
DEBUG - 2018-04-09 06:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:59:26 --> Input Class Initialized
INFO - 2018-04-09 06:59:26 --> Language Class Initialized
INFO - 2018-04-09 06:59:26 --> Loader Class Initialized
INFO - 2018-04-09 06:59:26 --> Helper loaded: url_helper
INFO - 2018-04-09 06:59:26 --> Helper loaded: file_helper
INFO - 2018-04-09 06:59:26 --> Helper loaded: date_helper
INFO - 2018-04-09 06:59:26 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:59:26 --> Controller Class Initialized
INFO - 2018-04-09 06:59:26 --> Config Class Initialized
INFO - 2018-04-09 06:59:26 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:59:26 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:59:26 --> Utf8 Class Initialized
INFO - 2018-04-09 06:59:26 --> URI Class Initialized
INFO - 2018-04-09 06:59:26 --> Router Class Initialized
INFO - 2018-04-09 06:59:26 --> Output Class Initialized
INFO - 2018-04-09 06:59:26 --> Security Class Initialized
DEBUG - 2018-04-09 06:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:59:26 --> Input Class Initialized
INFO - 2018-04-09 06:59:26 --> Language Class Initialized
INFO - 2018-04-09 06:59:26 --> Loader Class Initialized
INFO - 2018-04-09 06:59:26 --> Helper loaded: url_helper
INFO - 2018-04-09 06:59:26 --> Helper loaded: file_helper
INFO - 2018-04-09 06:59:26 --> Helper loaded: date_helper
INFO - 2018-04-09 06:59:26 --> Database Driver Class Initialized
DEBUG - 2018-04-09 06:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 06:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 06:59:26 --> Controller Class Initialized
INFO - 2018-04-09 06:59:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-09 06:59:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-09 06:59:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-09 06:59:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-09 06:59:27 --> Final output sent to browser
DEBUG - 2018-04-09 06:59:27 --> Total execution time: 0.4762
INFO - 2018-04-09 06:59:27 --> Config Class Initialized
INFO - 2018-04-09 06:59:27 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:59:27 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:59:27 --> Utf8 Class Initialized
INFO - 2018-04-09 06:59:27 --> URI Class Initialized
INFO - 2018-04-09 06:59:27 --> Router Class Initialized
INFO - 2018-04-09 06:59:27 --> Output Class Initialized
INFO - 2018-04-09 06:59:27 --> Security Class Initialized
DEBUG - 2018-04-09 06:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:59:27 --> Input Class Initialized
INFO - 2018-04-09 06:59:27 --> Language Class Initialized
ERROR - 2018-04-09 06:59:27 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-09 06:59:27 --> Config Class Initialized
INFO - 2018-04-09 06:59:27 --> Hooks Class Initialized
DEBUG - 2018-04-09 06:59:27 --> UTF-8 Support Enabled
INFO - 2018-04-09 06:59:27 --> Utf8 Class Initialized
INFO - 2018-04-09 06:59:27 --> URI Class Initialized
INFO - 2018-04-09 06:59:27 --> Router Class Initialized
INFO - 2018-04-09 06:59:27 --> Output Class Initialized
INFO - 2018-04-09 06:59:27 --> Security Class Initialized
DEBUG - 2018-04-09 06:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 06:59:27 --> Input Class Initialized
INFO - 2018-04-09 06:59:27 --> Language Class Initialized
ERROR - 2018-04-09 06:59:27 --> 404 Page Not Found: Downloadpng/index
INFO - 2018-04-09 07:20:43 --> Config Class Initialized
INFO - 2018-04-09 07:20:43 --> Hooks Class Initialized
DEBUG - 2018-04-09 07:20:43 --> UTF-8 Support Enabled
INFO - 2018-04-09 07:20:43 --> Utf8 Class Initialized
INFO - 2018-04-09 07:20:43 --> URI Class Initialized
INFO - 2018-04-09 07:20:43 --> Router Class Initialized
INFO - 2018-04-09 07:20:43 --> Output Class Initialized
INFO - 2018-04-09 07:20:43 --> Security Class Initialized
DEBUG - 2018-04-09 07:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 07:20:43 --> Input Class Initialized
INFO - 2018-04-09 07:20:43 --> Language Class Initialized
INFO - 2018-04-09 07:20:43 --> Loader Class Initialized
INFO - 2018-04-09 07:20:43 --> Helper loaded: url_helper
INFO - 2018-04-09 07:20:43 --> Helper loaded: file_helper
INFO - 2018-04-09 07:20:43 --> Helper loaded: date_helper
INFO - 2018-04-09 07:20:43 --> Database Driver Class Initialized
DEBUG - 2018-04-09 07:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 07:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 07:20:43 --> Controller Class Initialized
INFO - 2018-04-09 07:20:43 --> Model Class Initialized
INFO - 2018-04-09 07:20:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-09 07:20:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-09 07:20:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-09 07:20:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-09 07:20:43 --> Final output sent to browser
DEBUG - 2018-04-09 07:20:43 --> Total execution time: 0.3825
INFO - 2018-04-09 07:20:43 --> Config Class Initialized
INFO - 2018-04-09 07:20:43 --> Hooks Class Initialized
DEBUG - 2018-04-09 07:20:44 --> UTF-8 Support Enabled
INFO - 2018-04-09 07:20:44 --> Utf8 Class Initialized
INFO - 2018-04-09 07:20:44 --> URI Class Initialized
INFO - 2018-04-09 07:20:44 --> Router Class Initialized
INFO - 2018-04-09 07:20:44 --> Output Class Initialized
INFO - 2018-04-09 07:20:44 --> Security Class Initialized
DEBUG - 2018-04-09 07:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 07:20:44 --> Input Class Initialized
INFO - 2018-04-09 07:20:44 --> Language Class Initialized
ERROR - 2018-04-09 07:20:44 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-09 07:20:44 --> Config Class Initialized
INFO - 2018-04-09 07:20:44 --> Hooks Class Initialized
DEBUG - 2018-04-09 07:20:44 --> UTF-8 Support Enabled
INFO - 2018-04-09 07:20:44 --> Utf8 Class Initialized
INFO - 2018-04-09 07:20:44 --> URI Class Initialized
INFO - 2018-04-09 07:20:44 --> Router Class Initialized
INFO - 2018-04-09 07:20:44 --> Output Class Initialized
INFO - 2018-04-09 07:20:44 --> Security Class Initialized
DEBUG - 2018-04-09 07:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 07:20:44 --> Input Class Initialized
INFO - 2018-04-09 07:20:44 --> Language Class Initialized
ERROR - 2018-04-09 07:20:44 --> 404 Page Not Found: Downloadpng/index
INFO - 2018-04-09 07:20:51 --> Config Class Initialized
INFO - 2018-04-09 07:20:51 --> Hooks Class Initialized
DEBUG - 2018-04-09 07:20:51 --> UTF-8 Support Enabled
INFO - 2018-04-09 07:20:51 --> Utf8 Class Initialized
INFO - 2018-04-09 07:20:51 --> URI Class Initialized
INFO - 2018-04-09 07:20:51 --> Router Class Initialized
INFO - 2018-04-09 07:20:51 --> Output Class Initialized
INFO - 2018-04-09 07:20:51 --> Security Class Initialized
DEBUG - 2018-04-09 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 07:20:51 --> Input Class Initialized
INFO - 2018-04-09 07:20:51 --> Language Class Initialized
ERROR - 2018-04-09 07:20:51 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-09 16:42:45 --> Config Class Initialized
INFO - 2018-04-09 16:42:45 --> Hooks Class Initialized
DEBUG - 2018-04-09 16:42:46 --> UTF-8 Support Enabled
INFO - 2018-04-09 16:42:46 --> Utf8 Class Initialized
INFO - 2018-04-09 16:42:46 --> URI Class Initialized
INFO - 2018-04-09 16:42:46 --> Router Class Initialized
INFO - 2018-04-09 16:42:46 --> Output Class Initialized
INFO - 2018-04-09 16:42:46 --> Security Class Initialized
DEBUG - 2018-04-09 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 16:42:46 --> Input Class Initialized
INFO - 2018-04-09 16:42:46 --> Language Class Initialized
INFO - 2018-04-09 16:42:46 --> Loader Class Initialized
INFO - 2018-04-09 16:42:46 --> Helper loaded: url_helper
INFO - 2018-04-09 16:42:46 --> Helper loaded: file_helper
INFO - 2018-04-09 16:42:46 --> Helper loaded: date_helper
INFO - 2018-04-09 16:42:46 --> Database Driver Class Initialized
DEBUG - 2018-04-09 16:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 16:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 16:42:47 --> Controller Class Initialized
INFO - 2018-04-09 16:44:04 --> Config Class Initialized
INFO - 2018-04-09 16:44:04 --> Hooks Class Initialized
DEBUG - 2018-04-09 16:44:04 --> UTF-8 Support Enabled
INFO - 2018-04-09 16:44:04 --> Utf8 Class Initialized
INFO - 2018-04-09 16:44:04 --> URI Class Initialized
INFO - 2018-04-09 16:44:04 --> Router Class Initialized
INFO - 2018-04-09 16:44:04 --> Output Class Initialized
INFO - 2018-04-09 16:44:04 --> Security Class Initialized
DEBUG - 2018-04-09 16:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 16:44:04 --> Input Class Initialized
INFO - 2018-04-09 16:44:04 --> Language Class Initialized
INFO - 2018-04-09 16:44:04 --> Loader Class Initialized
INFO - 2018-04-09 16:44:04 --> Helper loaded: url_helper
INFO - 2018-04-09 16:44:04 --> Helper loaded: file_helper
INFO - 2018-04-09 16:44:04 --> Helper loaded: date_helper
INFO - 2018-04-09 16:44:04 --> Database Driver Class Initialized
DEBUG - 2018-04-09 16:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 16:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 16:44:04 --> Controller Class Initialized
INFO - 2018-04-09 16:44:51 --> Config Class Initialized
INFO - 2018-04-09 16:44:51 --> Hooks Class Initialized
DEBUG - 2018-04-09 16:44:51 --> UTF-8 Support Enabled
INFO - 2018-04-09 16:44:51 --> Utf8 Class Initialized
INFO - 2018-04-09 16:44:51 --> URI Class Initialized
INFO - 2018-04-09 16:44:51 --> Router Class Initialized
INFO - 2018-04-09 16:44:51 --> Output Class Initialized
INFO - 2018-04-09 16:44:51 --> Security Class Initialized
DEBUG - 2018-04-09 16:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 16:44:51 --> Input Class Initialized
INFO - 2018-04-09 16:44:51 --> Language Class Initialized
INFO - 2018-04-09 16:44:51 --> Loader Class Initialized
INFO - 2018-04-09 16:44:51 --> Helper loaded: url_helper
INFO - 2018-04-09 16:44:51 --> Helper loaded: file_helper
INFO - 2018-04-09 16:44:51 --> Helper loaded: date_helper
INFO - 2018-04-09 16:44:51 --> Database Driver Class Initialized
DEBUG - 2018-04-09 16:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 16:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 16:44:51 --> Controller Class Initialized
INFO - 2018-04-09 16:44:54 --> Config Class Initialized
INFO - 2018-04-09 16:44:54 --> Hooks Class Initialized
DEBUG - 2018-04-09 16:44:54 --> UTF-8 Support Enabled
INFO - 2018-04-09 16:44:54 --> Utf8 Class Initialized
INFO - 2018-04-09 16:44:54 --> URI Class Initialized
INFO - 2018-04-09 16:44:54 --> Router Class Initialized
INFO - 2018-04-09 16:44:54 --> Output Class Initialized
INFO - 2018-04-09 16:44:54 --> Security Class Initialized
DEBUG - 2018-04-09 16:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 16:44:54 --> Input Class Initialized
INFO - 2018-04-09 16:44:54 --> Language Class Initialized
INFO - 2018-04-09 16:44:54 --> Loader Class Initialized
INFO - 2018-04-09 16:44:54 --> Helper loaded: url_helper
INFO - 2018-04-09 16:44:54 --> Helper loaded: file_helper
INFO - 2018-04-09 16:44:54 --> Helper loaded: date_helper
INFO - 2018-04-09 16:44:54 --> Database Driver Class Initialized
DEBUG - 2018-04-09 16:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 16:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 16:44:54 --> Controller Class Initialized
INFO - 2018-04-09 16:44:57 --> Config Class Initialized
INFO - 2018-04-09 16:44:57 --> Hooks Class Initialized
DEBUG - 2018-04-09 16:44:57 --> UTF-8 Support Enabled
INFO - 2018-04-09 16:44:57 --> Utf8 Class Initialized
INFO - 2018-04-09 16:44:57 --> URI Class Initialized
INFO - 2018-04-09 16:44:57 --> Router Class Initialized
INFO - 2018-04-09 16:44:57 --> Output Class Initialized
INFO - 2018-04-09 16:44:57 --> Security Class Initialized
DEBUG - 2018-04-09 16:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 16:44:57 --> Input Class Initialized
INFO - 2018-04-09 16:44:57 --> Language Class Initialized
INFO - 2018-04-09 16:44:57 --> Loader Class Initialized
INFO - 2018-04-09 16:44:57 --> Helper loaded: url_helper
INFO - 2018-04-09 16:44:57 --> Helper loaded: file_helper
INFO - 2018-04-09 16:44:57 --> Helper loaded: date_helper
INFO - 2018-04-09 16:44:57 --> Database Driver Class Initialized
DEBUG - 2018-04-09 16:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 16:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 16:44:57 --> Controller Class Initialized
INFO - 2018-04-09 16:45:02 --> Config Class Initialized
INFO - 2018-04-09 16:45:02 --> Hooks Class Initialized
DEBUG - 2018-04-09 16:45:02 --> UTF-8 Support Enabled
INFO - 2018-04-09 16:45:02 --> Utf8 Class Initialized
INFO - 2018-04-09 16:45:02 --> URI Class Initialized
DEBUG - 2018-04-09 16:45:02 --> No URI present. Default controller set.
INFO - 2018-04-09 16:45:02 --> Router Class Initialized
INFO - 2018-04-09 16:45:02 --> Output Class Initialized
INFO - 2018-04-09 16:45:02 --> Security Class Initialized
DEBUG - 2018-04-09 16:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 16:45:02 --> Input Class Initialized
INFO - 2018-04-09 16:45:02 --> Language Class Initialized
INFO - 2018-04-09 16:45:02 --> Loader Class Initialized
INFO - 2018-04-09 16:45:02 --> Helper loaded: url_helper
INFO - 2018-04-09 16:45:02 --> Helper loaded: file_helper
INFO - 2018-04-09 16:45:02 --> Helper loaded: date_helper
INFO - 2018-04-09 16:45:02 --> Database Driver Class Initialized
DEBUG - 2018-04-09 16:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 16:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 16:45:02 --> Controller Class Initialized
INFO - 2018-04-09 16:45:02 --> Config Class Initialized
INFO - 2018-04-09 16:45:02 --> Hooks Class Initialized
DEBUG - 2018-04-09 16:45:02 --> UTF-8 Support Enabled
INFO - 2018-04-09 16:45:02 --> Utf8 Class Initialized
INFO - 2018-04-09 16:45:02 --> URI Class Initialized
INFO - 2018-04-09 16:45:03 --> Router Class Initialized
INFO - 2018-04-09 16:45:03 --> Output Class Initialized
INFO - 2018-04-09 16:45:03 --> Security Class Initialized
DEBUG - 2018-04-09 16:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 16:45:03 --> Input Class Initialized
INFO - 2018-04-09 16:45:03 --> Language Class Initialized
INFO - 2018-04-09 16:45:03 --> Loader Class Initialized
INFO - 2018-04-09 16:45:03 --> Helper loaded: url_helper
INFO - 2018-04-09 16:45:03 --> Helper loaded: file_helper
INFO - 2018-04-09 16:45:03 --> Helper loaded: date_helper
INFO - 2018-04-09 16:45:03 --> Database Driver Class Initialized
DEBUG - 2018-04-09 16:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 16:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 16:45:03 --> Controller Class Initialized
INFO - 2018-04-09 16:45:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-09 16:45:03 --> Final output sent to browser
DEBUG - 2018-04-09 16:45:03 --> Total execution time: 0.5643
INFO - 2018-04-09 16:45:06 --> Config Class Initialized
INFO - 2018-04-09 16:45:06 --> Hooks Class Initialized
DEBUG - 2018-04-09 16:45:06 --> UTF-8 Support Enabled
INFO - 2018-04-09 16:45:06 --> Utf8 Class Initialized
INFO - 2018-04-09 16:45:06 --> URI Class Initialized
INFO - 2018-04-09 16:45:06 --> Router Class Initialized
INFO - 2018-04-09 16:45:06 --> Output Class Initialized
INFO - 2018-04-09 16:45:06 --> Security Class Initialized
DEBUG - 2018-04-09 16:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-09 16:45:06 --> Input Class Initialized
INFO - 2018-04-09 16:45:06 --> Language Class Initialized
INFO - 2018-04-09 16:45:06 --> Loader Class Initialized
INFO - 2018-04-09 16:45:06 --> Helper loaded: url_helper
INFO - 2018-04-09 16:45:06 --> Helper loaded: file_helper
INFO - 2018-04-09 16:45:06 --> Helper loaded: date_helper
INFO - 2018-04-09 16:45:06 --> Database Driver Class Initialized
DEBUG - 2018-04-09 16:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-09 16:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-09 16:45:06 --> Controller Class Initialized
