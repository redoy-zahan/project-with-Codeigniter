<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-02 02:24:38 --> Config Class Initialized
INFO - 2018-04-02 02:24:39 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:24:39 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:24:39 --> Utf8 Class Initialized
INFO - 2018-04-02 02:24:39 --> URI Class Initialized
DEBUG - 2018-04-02 02:24:39 --> No URI present. Default controller set.
INFO - 2018-04-02 02:24:39 --> Router Class Initialized
INFO - 2018-04-02 02:24:39 --> Output Class Initialized
INFO - 2018-04-02 02:24:39 --> Security Class Initialized
DEBUG - 2018-04-02 02:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:24:39 --> Input Class Initialized
INFO - 2018-04-02 02:24:39 --> Language Class Initialized
INFO - 2018-04-02 02:24:39 --> Loader Class Initialized
INFO - 2018-04-02 02:24:39 --> Helper loaded: url_helper
INFO - 2018-04-02 02:24:39 --> Helper loaded: file_helper
INFO - 2018-04-02 02:24:39 --> Helper loaded: date_helper
INFO - 2018-04-02 02:24:39 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:24:40 --> Controller Class Initialized
INFO - 2018-04-02 02:24:40 --> Config Class Initialized
INFO - 2018-04-02 02:24:40 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:24:40 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:24:40 --> Utf8 Class Initialized
INFO - 2018-04-02 02:24:40 --> URI Class Initialized
INFO - 2018-04-02 02:24:40 --> Router Class Initialized
INFO - 2018-04-02 02:24:40 --> Output Class Initialized
INFO - 2018-04-02 02:24:40 --> Security Class Initialized
DEBUG - 2018-04-02 02:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:24:40 --> Input Class Initialized
INFO - 2018-04-02 02:24:40 --> Language Class Initialized
INFO - 2018-04-02 02:24:40 --> Loader Class Initialized
INFO - 2018-04-02 02:24:40 --> Helper loaded: url_helper
INFO - 2018-04-02 02:24:40 --> Helper loaded: file_helper
INFO - 2018-04-02 02:24:40 --> Helper loaded: date_helper
INFO - 2018-04-02 02:24:40 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:24:40 --> Controller Class Initialized
INFO - 2018-04-02 02:24:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 02:24:40 --> Final output sent to browser
DEBUG - 2018-04-02 02:24:40 --> Total execution time: 0.2428
INFO - 2018-04-02 02:24:42 --> Config Class Initialized
INFO - 2018-04-02 02:24:42 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:24:42 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:24:42 --> Utf8 Class Initialized
INFO - 2018-04-02 02:24:42 --> URI Class Initialized
DEBUG - 2018-04-02 02:24:42 --> No URI present. Default controller set.
INFO - 2018-04-02 02:24:42 --> Router Class Initialized
INFO - 2018-04-02 02:24:42 --> Output Class Initialized
INFO - 2018-04-02 02:24:42 --> Security Class Initialized
DEBUG - 2018-04-02 02:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:24:42 --> Input Class Initialized
INFO - 2018-04-02 02:24:42 --> Language Class Initialized
INFO - 2018-04-02 02:24:42 --> Loader Class Initialized
INFO - 2018-04-02 02:24:42 --> Helper loaded: url_helper
INFO - 2018-04-02 02:24:42 --> Helper loaded: file_helper
INFO - 2018-04-02 02:24:42 --> Helper loaded: date_helper
INFO - 2018-04-02 02:24:42 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:24:42 --> Controller Class Initialized
INFO - 2018-04-02 02:24:42 --> Config Class Initialized
INFO - 2018-04-02 02:24:42 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:24:43 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:24:43 --> Utf8 Class Initialized
INFO - 2018-04-02 02:24:43 --> URI Class Initialized
INFO - 2018-04-02 02:24:43 --> Router Class Initialized
INFO - 2018-04-02 02:24:43 --> Output Class Initialized
INFO - 2018-04-02 02:24:43 --> Security Class Initialized
DEBUG - 2018-04-02 02:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:24:43 --> Input Class Initialized
INFO - 2018-04-02 02:24:43 --> Language Class Initialized
INFO - 2018-04-02 02:24:43 --> Loader Class Initialized
INFO - 2018-04-02 02:24:43 --> Helper loaded: url_helper
INFO - 2018-04-02 02:24:43 --> Helper loaded: file_helper
INFO - 2018-04-02 02:24:43 --> Helper loaded: date_helper
INFO - 2018-04-02 02:24:43 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:24:43 --> Controller Class Initialized
INFO - 2018-04-02 02:24:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 02:24:43 --> Final output sent to browser
DEBUG - 2018-04-02 02:24:43 --> Total execution time: 0.2126
INFO - 2018-04-02 02:25:57 --> Config Class Initialized
INFO - 2018-04-02 02:25:57 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:25:57 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:25:57 --> Utf8 Class Initialized
INFO - 2018-04-02 02:25:57 --> URI Class Initialized
INFO - 2018-04-02 02:25:57 --> Router Class Initialized
INFO - 2018-04-02 02:25:57 --> Output Class Initialized
INFO - 2018-04-02 02:25:57 --> Security Class Initialized
DEBUG - 2018-04-02 02:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:25:57 --> Input Class Initialized
INFO - 2018-04-02 02:25:57 --> Language Class Initialized
INFO - 2018-04-02 02:25:57 --> Loader Class Initialized
INFO - 2018-04-02 02:25:57 --> Helper loaded: url_helper
INFO - 2018-04-02 02:25:57 --> Helper loaded: file_helper
INFO - 2018-04-02 02:25:57 --> Helper loaded: date_helper
INFO - 2018-04-02 02:25:57 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:25:57 --> Controller Class Initialized
INFO - 2018-04-02 02:25:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 02:25:57 --> Final output sent to browser
DEBUG - 2018-04-02 02:25:57 --> Total execution time: 0.3008
INFO - 2018-04-02 02:26:00 --> Config Class Initialized
INFO - 2018-04-02 02:26:00 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:26:00 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:26:00 --> Utf8 Class Initialized
INFO - 2018-04-02 02:26:00 --> URI Class Initialized
INFO - 2018-04-02 02:26:00 --> Router Class Initialized
INFO - 2018-04-02 02:26:00 --> Output Class Initialized
INFO - 2018-04-02 02:26:00 --> Security Class Initialized
DEBUG - 2018-04-02 02:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:26:00 --> Input Class Initialized
INFO - 2018-04-02 02:26:00 --> Language Class Initialized
ERROR - 2018-04-02 02:26:00 --> 404 Page Not Found: Auth_Controller/registration.php
INFO - 2018-04-02 02:26:02 --> Config Class Initialized
INFO - 2018-04-02 02:26:02 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:26:02 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:26:02 --> Utf8 Class Initialized
INFO - 2018-04-02 02:26:02 --> URI Class Initialized
INFO - 2018-04-02 02:26:02 --> Router Class Initialized
INFO - 2018-04-02 02:26:02 --> Output Class Initialized
INFO - 2018-04-02 02:26:02 --> Security Class Initialized
DEBUG - 2018-04-02 02:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:26:02 --> Input Class Initialized
INFO - 2018-04-02 02:26:02 --> Language Class Initialized
INFO - 2018-04-02 02:26:02 --> Loader Class Initialized
INFO - 2018-04-02 02:26:02 --> Helper loaded: url_helper
INFO - 2018-04-02 02:26:02 --> Helper loaded: file_helper
INFO - 2018-04-02 02:26:02 --> Helper loaded: date_helper
INFO - 2018-04-02 02:26:02 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:26:02 --> Controller Class Initialized
INFO - 2018-04-02 02:26:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 02:26:02 --> Final output sent to browser
DEBUG - 2018-04-02 02:26:02 --> Total execution time: 0.2253
INFO - 2018-04-02 02:29:12 --> Config Class Initialized
INFO - 2018-04-02 02:29:12 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:29:12 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:29:12 --> Utf8 Class Initialized
INFO - 2018-04-02 02:29:12 --> URI Class Initialized
INFO - 2018-04-02 02:29:12 --> Router Class Initialized
INFO - 2018-04-02 02:29:12 --> Output Class Initialized
INFO - 2018-04-02 02:29:12 --> Security Class Initialized
DEBUG - 2018-04-02 02:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:29:12 --> Input Class Initialized
INFO - 2018-04-02 02:29:12 --> Language Class Initialized
ERROR - 2018-04-02 02:29:12 --> 404 Page Not Found: Auth_Controller/registration.php
INFO - 2018-04-02 02:29:22 --> Config Class Initialized
INFO - 2018-04-02 02:29:22 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:29:22 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:29:22 --> Utf8 Class Initialized
INFO - 2018-04-02 02:29:22 --> URI Class Initialized
DEBUG - 2018-04-02 02:29:22 --> No URI present. Default controller set.
INFO - 2018-04-02 02:29:22 --> Router Class Initialized
INFO - 2018-04-02 02:29:23 --> Output Class Initialized
INFO - 2018-04-02 02:29:23 --> Security Class Initialized
DEBUG - 2018-04-02 02:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:29:23 --> Input Class Initialized
INFO - 2018-04-02 02:29:23 --> Language Class Initialized
INFO - 2018-04-02 02:29:23 --> Loader Class Initialized
INFO - 2018-04-02 02:29:23 --> Helper loaded: url_helper
INFO - 2018-04-02 02:29:23 --> Helper loaded: file_helper
INFO - 2018-04-02 02:29:23 --> Helper loaded: date_helper
INFO - 2018-04-02 02:29:23 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:29:23 --> Controller Class Initialized
INFO - 2018-04-02 02:29:23 --> Config Class Initialized
INFO - 2018-04-02 02:29:23 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:29:23 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:29:23 --> Utf8 Class Initialized
INFO - 2018-04-02 02:29:23 --> URI Class Initialized
INFO - 2018-04-02 02:29:23 --> Router Class Initialized
INFO - 2018-04-02 02:29:23 --> Output Class Initialized
INFO - 2018-04-02 02:29:23 --> Security Class Initialized
DEBUG - 2018-04-02 02:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:29:23 --> Input Class Initialized
INFO - 2018-04-02 02:29:23 --> Language Class Initialized
INFO - 2018-04-02 02:29:23 --> Loader Class Initialized
INFO - 2018-04-02 02:29:23 --> Helper loaded: url_helper
INFO - 2018-04-02 02:29:23 --> Helper loaded: file_helper
INFO - 2018-04-02 02:29:23 --> Helper loaded: date_helper
INFO - 2018-04-02 02:29:23 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:29:23 --> Controller Class Initialized
INFO - 2018-04-02 02:29:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 02:29:23 --> Final output sent to browser
DEBUG - 2018-04-02 02:29:23 --> Total execution time: 0.2038
INFO - 2018-04-02 02:29:27 --> Config Class Initialized
INFO - 2018-04-02 02:29:27 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:29:27 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:29:27 --> Utf8 Class Initialized
INFO - 2018-04-02 02:29:27 --> URI Class Initialized
DEBUG - 2018-04-02 02:29:27 --> No URI present. Default controller set.
INFO - 2018-04-02 02:29:27 --> Router Class Initialized
INFO - 2018-04-02 02:29:27 --> Output Class Initialized
INFO - 2018-04-02 02:29:27 --> Security Class Initialized
DEBUG - 2018-04-02 02:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:29:28 --> Input Class Initialized
INFO - 2018-04-02 02:29:28 --> Language Class Initialized
INFO - 2018-04-02 02:29:28 --> Loader Class Initialized
INFO - 2018-04-02 02:29:28 --> Helper loaded: url_helper
INFO - 2018-04-02 02:29:28 --> Helper loaded: file_helper
INFO - 2018-04-02 02:29:28 --> Helper loaded: date_helper
INFO - 2018-04-02 02:29:28 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:29:28 --> Controller Class Initialized
INFO - 2018-04-02 02:29:28 --> Config Class Initialized
INFO - 2018-04-02 02:29:28 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:29:28 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:29:28 --> Utf8 Class Initialized
INFO - 2018-04-02 02:29:28 --> URI Class Initialized
INFO - 2018-04-02 02:29:28 --> Router Class Initialized
INFO - 2018-04-02 02:29:28 --> Output Class Initialized
INFO - 2018-04-02 02:29:28 --> Security Class Initialized
DEBUG - 2018-04-02 02:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:29:28 --> Input Class Initialized
INFO - 2018-04-02 02:29:28 --> Language Class Initialized
INFO - 2018-04-02 02:29:28 --> Loader Class Initialized
INFO - 2018-04-02 02:29:28 --> Helper loaded: url_helper
INFO - 2018-04-02 02:29:28 --> Helper loaded: file_helper
INFO - 2018-04-02 02:29:28 --> Helper loaded: date_helper
INFO - 2018-04-02 02:29:28 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:29:28 --> Controller Class Initialized
INFO - 2018-04-02 02:29:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 02:29:28 --> Final output sent to browser
DEBUG - 2018-04-02 02:29:28 --> Total execution time: 0.2139
INFO - 2018-04-02 02:29:35 --> Config Class Initialized
INFO - 2018-04-02 02:29:35 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:29:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:29:35 --> Utf8 Class Initialized
INFO - 2018-04-02 02:29:36 --> URI Class Initialized
DEBUG - 2018-04-02 02:29:36 --> No URI present. Default controller set.
INFO - 2018-04-02 02:29:36 --> Router Class Initialized
INFO - 2018-04-02 02:29:36 --> Output Class Initialized
INFO - 2018-04-02 02:29:36 --> Security Class Initialized
DEBUG - 2018-04-02 02:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:29:36 --> Input Class Initialized
INFO - 2018-04-02 02:29:36 --> Language Class Initialized
INFO - 2018-04-02 02:29:36 --> Loader Class Initialized
INFO - 2018-04-02 02:29:36 --> Helper loaded: url_helper
INFO - 2018-04-02 02:29:36 --> Helper loaded: file_helper
INFO - 2018-04-02 02:29:36 --> Helper loaded: date_helper
INFO - 2018-04-02 02:29:36 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:29:36 --> Controller Class Initialized
INFO - 2018-04-02 02:29:36 --> Config Class Initialized
INFO - 2018-04-02 02:29:36 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:29:36 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:29:36 --> Utf8 Class Initialized
INFO - 2018-04-02 02:29:36 --> URI Class Initialized
INFO - 2018-04-02 02:29:36 --> Router Class Initialized
INFO - 2018-04-02 02:29:36 --> Output Class Initialized
INFO - 2018-04-02 02:29:36 --> Security Class Initialized
DEBUG - 2018-04-02 02:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:29:36 --> Input Class Initialized
INFO - 2018-04-02 02:29:36 --> Language Class Initialized
INFO - 2018-04-02 02:29:36 --> Loader Class Initialized
INFO - 2018-04-02 02:29:36 --> Helper loaded: url_helper
INFO - 2018-04-02 02:29:36 --> Helper loaded: file_helper
INFO - 2018-04-02 02:29:36 --> Helper loaded: date_helper
INFO - 2018-04-02 02:29:36 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:29:36 --> Controller Class Initialized
INFO - 2018-04-02 02:29:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 02:29:36 --> Final output sent to browser
DEBUG - 2018-04-02 02:29:36 --> Total execution time: 0.2200
INFO - 2018-04-02 02:30:26 --> Config Class Initialized
INFO - 2018-04-02 02:30:26 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:30:26 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:30:26 --> Utf8 Class Initialized
INFO - 2018-04-02 02:30:26 --> URI Class Initialized
DEBUG - 2018-04-02 02:30:26 --> No URI present. Default controller set.
INFO - 2018-04-02 02:30:26 --> Router Class Initialized
INFO - 2018-04-02 02:30:26 --> Output Class Initialized
INFO - 2018-04-02 02:30:26 --> Security Class Initialized
DEBUG - 2018-04-02 02:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:30:26 --> Input Class Initialized
INFO - 2018-04-02 02:30:26 --> Language Class Initialized
INFO - 2018-04-02 02:30:26 --> Loader Class Initialized
INFO - 2018-04-02 02:30:26 --> Helper loaded: url_helper
INFO - 2018-04-02 02:30:26 --> Helper loaded: file_helper
INFO - 2018-04-02 02:30:26 --> Helper loaded: date_helper
INFO - 2018-04-02 02:30:26 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:30:26 --> Controller Class Initialized
INFO - 2018-04-02 02:30:26 --> Config Class Initialized
INFO - 2018-04-02 02:30:26 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:30:26 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:30:26 --> Utf8 Class Initialized
INFO - 2018-04-02 02:30:26 --> URI Class Initialized
INFO - 2018-04-02 02:30:26 --> Router Class Initialized
INFO - 2018-04-02 02:30:26 --> Output Class Initialized
INFO - 2018-04-02 02:30:26 --> Security Class Initialized
DEBUG - 2018-04-02 02:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:30:26 --> Input Class Initialized
INFO - 2018-04-02 02:30:26 --> Language Class Initialized
INFO - 2018-04-02 02:30:26 --> Loader Class Initialized
INFO - 2018-04-02 02:30:26 --> Helper loaded: url_helper
INFO - 2018-04-02 02:30:26 --> Helper loaded: file_helper
INFO - 2018-04-02 02:30:26 --> Helper loaded: date_helper
INFO - 2018-04-02 02:30:26 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:30:26 --> Controller Class Initialized
INFO - 2018-04-02 02:30:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 02:30:26 --> Final output sent to browser
DEBUG - 2018-04-02 02:30:26 --> Total execution time: 0.2331
INFO - 2018-04-02 02:30:35 --> Config Class Initialized
INFO - 2018-04-02 02:30:35 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:30:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:30:35 --> Utf8 Class Initialized
INFO - 2018-04-02 02:30:35 --> URI Class Initialized
DEBUG - 2018-04-02 02:30:35 --> No URI present. Default controller set.
INFO - 2018-04-02 02:30:35 --> Router Class Initialized
INFO - 2018-04-02 02:30:35 --> Output Class Initialized
INFO - 2018-04-02 02:30:35 --> Security Class Initialized
DEBUG - 2018-04-02 02:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:30:35 --> Input Class Initialized
INFO - 2018-04-02 02:30:35 --> Language Class Initialized
INFO - 2018-04-02 02:30:35 --> Loader Class Initialized
INFO - 2018-04-02 02:30:35 --> Helper loaded: url_helper
INFO - 2018-04-02 02:30:35 --> Helper loaded: file_helper
INFO - 2018-04-02 02:30:35 --> Helper loaded: date_helper
INFO - 2018-04-02 02:30:35 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:30:35 --> Controller Class Initialized
INFO - 2018-04-02 02:30:35 --> Config Class Initialized
INFO - 2018-04-02 02:30:35 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:30:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:30:35 --> Utf8 Class Initialized
INFO - 2018-04-02 02:30:35 --> URI Class Initialized
INFO - 2018-04-02 02:30:35 --> Router Class Initialized
INFO - 2018-04-02 02:30:35 --> Output Class Initialized
INFO - 2018-04-02 02:30:35 --> Security Class Initialized
DEBUG - 2018-04-02 02:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:30:35 --> Input Class Initialized
INFO - 2018-04-02 02:30:35 --> Language Class Initialized
INFO - 2018-04-02 02:30:35 --> Loader Class Initialized
INFO - 2018-04-02 02:30:35 --> Helper loaded: url_helper
INFO - 2018-04-02 02:30:35 --> Helper loaded: file_helper
INFO - 2018-04-02 02:30:35 --> Helper loaded: date_helper
INFO - 2018-04-02 02:30:35 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:30:35 --> Controller Class Initialized
INFO - 2018-04-02 02:30:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 02:30:35 --> Final output sent to browser
DEBUG - 2018-04-02 02:30:35 --> Total execution time: 0.2099
INFO - 2018-04-02 02:30:45 --> Config Class Initialized
INFO - 2018-04-02 02:30:45 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:30:45 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:30:45 --> Utf8 Class Initialized
INFO - 2018-04-02 02:30:45 --> URI Class Initialized
INFO - 2018-04-02 02:30:45 --> Router Class Initialized
INFO - 2018-04-02 02:30:45 --> Output Class Initialized
INFO - 2018-04-02 02:30:45 --> Security Class Initialized
DEBUG - 2018-04-02 02:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:30:45 --> Input Class Initialized
INFO - 2018-04-02 02:30:45 --> Language Class Initialized
ERROR - 2018-04-02 02:30:45 --> 404 Page Not Found: Registrationphp/index
INFO - 2018-04-02 02:42:19 --> Config Class Initialized
INFO - 2018-04-02 02:42:19 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:42:19 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:42:19 --> Utf8 Class Initialized
INFO - 2018-04-02 02:42:19 --> URI Class Initialized
DEBUG - 2018-04-02 02:42:19 --> No URI present. Default controller set.
INFO - 2018-04-02 02:42:19 --> Router Class Initialized
INFO - 2018-04-02 02:42:19 --> Output Class Initialized
INFO - 2018-04-02 02:42:19 --> Security Class Initialized
DEBUG - 2018-04-02 02:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:42:19 --> Input Class Initialized
INFO - 2018-04-02 02:42:19 --> Language Class Initialized
INFO - 2018-04-02 02:42:19 --> Loader Class Initialized
INFO - 2018-04-02 02:42:19 --> Helper loaded: url_helper
INFO - 2018-04-02 02:42:19 --> Helper loaded: file_helper
INFO - 2018-04-02 02:42:19 --> Helper loaded: date_helper
INFO - 2018-04-02 02:42:20 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:42:20 --> Controller Class Initialized
INFO - 2018-04-02 02:42:20 --> Config Class Initialized
INFO - 2018-04-02 02:42:20 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:42:20 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:42:20 --> Utf8 Class Initialized
INFO - 2018-04-02 02:42:20 --> URI Class Initialized
INFO - 2018-04-02 02:42:20 --> Router Class Initialized
INFO - 2018-04-02 02:42:20 --> Output Class Initialized
INFO - 2018-04-02 02:42:20 --> Security Class Initialized
DEBUG - 2018-04-02 02:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:42:20 --> Input Class Initialized
INFO - 2018-04-02 02:42:20 --> Language Class Initialized
INFO - 2018-04-02 02:42:20 --> Loader Class Initialized
INFO - 2018-04-02 02:42:20 --> Helper loaded: url_helper
INFO - 2018-04-02 02:42:20 --> Helper loaded: file_helper
INFO - 2018-04-02 02:42:20 --> Helper loaded: date_helper
INFO - 2018-04-02 02:42:20 --> Database Driver Class Initialized
DEBUG - 2018-04-02 02:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 02:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 02:42:20 --> Controller Class Initialized
INFO - 2018-04-02 02:42:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 02:42:20 --> Final output sent to browser
DEBUG - 2018-04-02 02:42:20 --> Total execution time: 0.2252
INFO - 2018-04-02 02:42:25 --> Config Class Initialized
INFO - 2018-04-02 02:42:25 --> Hooks Class Initialized
DEBUG - 2018-04-02 02:42:25 --> UTF-8 Support Enabled
INFO - 2018-04-02 02:42:25 --> Utf8 Class Initialized
INFO - 2018-04-02 02:42:25 --> URI Class Initialized
INFO - 2018-04-02 02:42:25 --> Router Class Initialized
INFO - 2018-04-02 02:42:25 --> Output Class Initialized
INFO - 2018-04-02 02:42:25 --> Security Class Initialized
DEBUG - 2018-04-02 02:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 02:42:26 --> Input Class Initialized
INFO - 2018-04-02 02:42:26 --> Language Class Initialized
ERROR - 2018-04-02 02:42:26 --> 404 Page Not Found: Auth_Controller/registration.php
INFO - 2018-04-02 04:32:29 --> Config Class Initialized
INFO - 2018-04-02 04:32:29 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:32:29 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:32:29 --> Utf8 Class Initialized
INFO - 2018-04-02 04:32:29 --> URI Class Initialized
DEBUG - 2018-04-02 04:32:29 --> No URI present. Default controller set.
INFO - 2018-04-02 04:32:29 --> Router Class Initialized
INFO - 2018-04-02 04:32:29 --> Output Class Initialized
INFO - 2018-04-02 04:32:29 --> Security Class Initialized
DEBUG - 2018-04-02 04:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:32:29 --> Input Class Initialized
INFO - 2018-04-02 04:32:29 --> Language Class Initialized
INFO - 2018-04-02 04:32:29 --> Loader Class Initialized
INFO - 2018-04-02 04:32:29 --> Helper loaded: url_helper
INFO - 2018-04-02 04:32:29 --> Helper loaded: file_helper
INFO - 2018-04-02 04:32:29 --> Helper loaded: date_helper
INFO - 2018-04-02 04:32:29 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:32:29 --> Controller Class Initialized
INFO - 2018-04-02 04:32:29 --> Config Class Initialized
INFO - 2018-04-02 04:32:29 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:32:29 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:32:29 --> Utf8 Class Initialized
INFO - 2018-04-02 04:32:29 --> URI Class Initialized
INFO - 2018-04-02 04:32:29 --> Router Class Initialized
INFO - 2018-04-02 04:32:29 --> Output Class Initialized
INFO - 2018-04-02 04:32:29 --> Security Class Initialized
DEBUG - 2018-04-02 04:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:32:29 --> Input Class Initialized
INFO - 2018-04-02 04:32:29 --> Language Class Initialized
INFO - 2018-04-02 04:32:29 --> Loader Class Initialized
INFO - 2018-04-02 04:32:29 --> Helper loaded: url_helper
INFO - 2018-04-02 04:32:29 --> Helper loaded: file_helper
INFO - 2018-04-02 04:32:29 --> Helper loaded: date_helper
INFO - 2018-04-02 04:32:29 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:32:29 --> Controller Class Initialized
INFO - 2018-04-02 04:32:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 04:32:29 --> Final output sent to browser
DEBUG - 2018-04-02 04:32:29 --> Total execution time: 0.2280
INFO - 2018-04-02 04:32:32 --> Config Class Initialized
INFO - 2018-04-02 04:32:32 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:32:32 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:32:32 --> Utf8 Class Initialized
INFO - 2018-04-02 04:32:32 --> URI Class Initialized
INFO - 2018-04-02 04:32:32 --> Router Class Initialized
INFO - 2018-04-02 04:32:32 --> Output Class Initialized
INFO - 2018-04-02 04:32:32 --> Security Class Initialized
DEBUG - 2018-04-02 04:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:32:32 --> Input Class Initialized
INFO - 2018-04-02 04:32:32 --> Language Class Initialized
ERROR - 2018-04-02 04:32:32 --> 404 Page Not Found: Auth_Controller/Register
INFO - 2018-04-02 04:33:21 --> Config Class Initialized
INFO - 2018-04-02 04:33:21 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:33:21 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:33:21 --> Utf8 Class Initialized
INFO - 2018-04-02 04:33:21 --> URI Class Initialized
INFO - 2018-04-02 04:33:21 --> Router Class Initialized
INFO - 2018-04-02 04:33:21 --> Output Class Initialized
INFO - 2018-04-02 04:33:21 --> Security Class Initialized
DEBUG - 2018-04-02 04:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:33:21 --> Input Class Initialized
INFO - 2018-04-02 04:33:21 --> Language Class Initialized
INFO - 2018-04-02 04:33:21 --> Loader Class Initialized
INFO - 2018-04-02 04:33:21 --> Helper loaded: url_helper
INFO - 2018-04-02 04:33:21 --> Helper loaded: file_helper
INFO - 2018-04-02 04:33:21 --> Helper loaded: date_helper
INFO - 2018-04-02 04:33:21 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:33:21 --> Controller Class Initialized
INFO - 2018-04-02 04:33:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 04:33:21 --> Final output sent to browser
DEBUG - 2018-04-02 04:33:21 --> Total execution time: 0.2428
INFO - 2018-04-02 04:33:23 --> Config Class Initialized
INFO - 2018-04-02 04:33:23 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:33:23 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:33:23 --> Utf8 Class Initialized
INFO - 2018-04-02 04:33:23 --> URI Class Initialized
INFO - 2018-04-02 04:33:23 --> Router Class Initialized
INFO - 2018-04-02 04:33:23 --> Output Class Initialized
INFO - 2018-04-02 04:33:23 --> Security Class Initialized
DEBUG - 2018-04-02 04:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:33:23 --> Input Class Initialized
INFO - 2018-04-02 04:33:23 --> Language Class Initialized
INFO - 2018-04-02 04:33:23 --> Loader Class Initialized
INFO - 2018-04-02 04:33:23 --> Helper loaded: url_helper
INFO - 2018-04-02 04:33:23 --> Helper loaded: file_helper
INFO - 2018-04-02 04:33:23 --> Helper loaded: date_helper
INFO - 2018-04-02 04:33:23 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:33:23 --> Controller Class Initialized
INFO - 2018-04-02 04:33:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 04:33:23 --> Final output sent to browser
DEBUG - 2018-04-02 04:33:23 --> Total execution time: 0.2824
INFO - 2018-04-02 04:33:27 --> Config Class Initialized
INFO - 2018-04-02 04:33:27 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:33:27 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:33:27 --> Utf8 Class Initialized
INFO - 2018-04-02 04:33:27 --> URI Class Initialized
INFO - 2018-04-02 04:33:27 --> Router Class Initialized
INFO - 2018-04-02 04:33:27 --> Output Class Initialized
INFO - 2018-04-02 04:33:27 --> Security Class Initialized
DEBUG - 2018-04-02 04:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:33:28 --> Input Class Initialized
INFO - 2018-04-02 04:33:28 --> Language Class Initialized
INFO - 2018-04-02 04:33:28 --> Loader Class Initialized
INFO - 2018-04-02 04:33:28 --> Helper loaded: url_helper
INFO - 2018-04-02 04:33:28 --> Helper loaded: file_helper
INFO - 2018-04-02 04:33:28 --> Helper loaded: date_helper
INFO - 2018-04-02 04:33:28 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:33:28 --> Controller Class Initialized
INFO - 2018-04-02 04:33:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 04:33:28 --> Final output sent to browser
DEBUG - 2018-04-02 04:33:28 --> Total execution time: 0.2468
INFO - 2018-04-02 04:33:29 --> Config Class Initialized
INFO - 2018-04-02 04:33:29 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:33:29 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:33:29 --> Utf8 Class Initialized
INFO - 2018-04-02 04:33:29 --> URI Class Initialized
INFO - 2018-04-02 04:33:29 --> Router Class Initialized
INFO - 2018-04-02 04:33:29 --> Output Class Initialized
INFO - 2018-04-02 04:33:29 --> Security Class Initialized
DEBUG - 2018-04-02 04:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:33:29 --> Input Class Initialized
INFO - 2018-04-02 04:33:29 --> Language Class Initialized
INFO - 2018-04-02 04:33:29 --> Loader Class Initialized
INFO - 2018-04-02 04:33:29 --> Helper loaded: url_helper
INFO - 2018-04-02 04:33:29 --> Helper loaded: file_helper
INFO - 2018-04-02 04:33:29 --> Helper loaded: date_helper
INFO - 2018-04-02 04:33:29 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:33:29 --> Controller Class Initialized
INFO - 2018-04-02 04:33:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 04:33:29 --> Final output sent to browser
DEBUG - 2018-04-02 04:33:29 --> Total execution time: 0.2834
INFO - 2018-04-02 04:33:30 --> Config Class Initialized
INFO - 2018-04-02 04:33:30 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:33:30 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:33:30 --> Utf8 Class Initialized
INFO - 2018-04-02 04:33:30 --> URI Class Initialized
INFO - 2018-04-02 04:33:30 --> Router Class Initialized
INFO - 2018-04-02 04:33:30 --> Output Class Initialized
INFO - 2018-04-02 04:33:30 --> Security Class Initialized
DEBUG - 2018-04-02 04:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:33:30 --> Input Class Initialized
INFO - 2018-04-02 04:33:30 --> Language Class Initialized
INFO - 2018-04-02 04:33:30 --> Loader Class Initialized
INFO - 2018-04-02 04:33:30 --> Helper loaded: url_helper
INFO - 2018-04-02 04:33:30 --> Helper loaded: file_helper
INFO - 2018-04-02 04:33:30 --> Helper loaded: date_helper
INFO - 2018-04-02 04:33:30 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:33:30 --> Controller Class Initialized
INFO - 2018-04-02 04:33:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 04:33:30 --> Final output sent to browser
DEBUG - 2018-04-02 04:33:30 --> Total execution time: 0.2558
INFO - 2018-04-02 04:33:31 --> Config Class Initialized
INFO - 2018-04-02 04:33:31 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:33:31 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:33:31 --> Utf8 Class Initialized
INFO - 2018-04-02 04:33:31 --> URI Class Initialized
INFO - 2018-04-02 04:33:31 --> Router Class Initialized
INFO - 2018-04-02 04:33:31 --> Output Class Initialized
INFO - 2018-04-02 04:33:31 --> Security Class Initialized
DEBUG - 2018-04-02 04:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:33:31 --> Input Class Initialized
INFO - 2018-04-02 04:33:31 --> Language Class Initialized
INFO - 2018-04-02 04:33:31 --> Loader Class Initialized
INFO - 2018-04-02 04:33:31 --> Helper loaded: url_helper
INFO - 2018-04-02 04:33:31 --> Helper loaded: file_helper
INFO - 2018-04-02 04:33:31 --> Helper loaded: date_helper
INFO - 2018-04-02 04:33:31 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:33:31 --> Controller Class Initialized
INFO - 2018-04-02 04:33:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 04:33:31 --> Final output sent to browser
DEBUG - 2018-04-02 04:33:31 --> Total execution time: 0.2514
INFO - 2018-04-02 04:33:34 --> Config Class Initialized
INFO - 2018-04-02 04:33:34 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:33:34 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:33:34 --> Utf8 Class Initialized
INFO - 2018-04-02 04:33:34 --> URI Class Initialized
INFO - 2018-04-02 04:33:34 --> Router Class Initialized
INFO - 2018-04-02 04:33:34 --> Output Class Initialized
INFO - 2018-04-02 04:33:34 --> Security Class Initialized
DEBUG - 2018-04-02 04:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:33:34 --> Input Class Initialized
INFO - 2018-04-02 04:33:34 --> Language Class Initialized
INFO - 2018-04-02 04:33:34 --> Loader Class Initialized
INFO - 2018-04-02 04:33:34 --> Helper loaded: url_helper
INFO - 2018-04-02 04:33:34 --> Helper loaded: file_helper
INFO - 2018-04-02 04:33:34 --> Helper loaded: date_helper
INFO - 2018-04-02 04:33:34 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:33:34 --> Controller Class Initialized
INFO - 2018-04-02 04:33:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 04:33:34 --> Final output sent to browser
DEBUG - 2018-04-02 04:33:34 --> Total execution time: 0.2484
INFO - 2018-04-02 04:33:48 --> Config Class Initialized
INFO - 2018-04-02 04:33:48 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:33:48 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:33:48 --> Utf8 Class Initialized
INFO - 2018-04-02 04:33:48 --> URI Class Initialized
INFO - 2018-04-02 04:33:48 --> Router Class Initialized
INFO - 2018-04-02 04:33:48 --> Output Class Initialized
INFO - 2018-04-02 04:33:48 --> Security Class Initialized
DEBUG - 2018-04-02 04:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:33:48 --> Input Class Initialized
INFO - 2018-04-02 04:33:48 --> Language Class Initialized
INFO - 2018-04-02 04:33:48 --> Loader Class Initialized
INFO - 2018-04-02 04:33:48 --> Helper loaded: url_helper
INFO - 2018-04-02 04:33:48 --> Helper loaded: file_helper
INFO - 2018-04-02 04:33:48 --> Helper loaded: date_helper
INFO - 2018-04-02 04:33:48 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:33:48 --> Controller Class Initialized
INFO - 2018-04-02 04:33:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 04:33:48 --> Final output sent to browser
DEBUG - 2018-04-02 04:33:48 --> Total execution time: 0.2539
INFO - 2018-04-02 04:33:50 --> Config Class Initialized
INFO - 2018-04-02 04:33:50 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:33:50 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:33:50 --> Utf8 Class Initialized
INFO - 2018-04-02 04:33:50 --> URI Class Initialized
INFO - 2018-04-02 04:33:50 --> Router Class Initialized
INFO - 2018-04-02 04:33:50 --> Output Class Initialized
INFO - 2018-04-02 04:33:50 --> Security Class Initialized
DEBUG - 2018-04-02 04:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:33:50 --> Input Class Initialized
INFO - 2018-04-02 04:33:50 --> Language Class Initialized
ERROR - 2018-04-02 04:33:50 --> Severity: Error --> Class 'CI_Controler' not found G:\xampp\htdocs\codeigniter\application\controllers\Register.php 2
INFO - 2018-04-02 04:34:21 --> Config Class Initialized
INFO - 2018-04-02 04:34:21 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:34:21 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:34:21 --> Utf8 Class Initialized
INFO - 2018-04-02 04:34:21 --> URI Class Initialized
INFO - 2018-04-02 04:34:21 --> Router Class Initialized
INFO - 2018-04-02 04:34:21 --> Output Class Initialized
INFO - 2018-04-02 04:34:21 --> Security Class Initialized
DEBUG - 2018-04-02 04:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:34:21 --> Input Class Initialized
INFO - 2018-04-02 04:34:21 --> Language Class Initialized
INFO - 2018-04-02 04:34:21 --> Loader Class Initialized
INFO - 2018-04-02 04:34:21 --> Helper loaded: url_helper
INFO - 2018-04-02 04:34:21 --> Helper loaded: file_helper
INFO - 2018-04-02 04:34:21 --> Helper loaded: date_helper
INFO - 2018-04-02 04:34:21 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:34:21 --> Controller Class Initialized
INFO - 2018-04-02 04:34:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:34:22 --> Final output sent to browser
DEBUG - 2018-04-02 04:34:22 --> Total execution time: 0.2539
INFO - 2018-04-02 04:34:22 --> Config Class Initialized
INFO - 2018-04-02 04:34:22 --> Config Class Initialized
INFO - 2018-04-02 04:34:22 --> Hooks Class Initialized
INFO - 2018-04-02 04:34:22 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:34:22 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 04:34:22 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:34:22 --> Utf8 Class Initialized
INFO - 2018-04-02 04:34:22 --> Utf8 Class Initialized
INFO - 2018-04-02 04:34:22 --> URI Class Initialized
INFO - 2018-04-02 04:34:22 --> URI Class Initialized
INFO - 2018-04-02 04:34:22 --> Router Class Initialized
INFO - 2018-04-02 04:34:22 --> Router Class Initialized
INFO - 2018-04-02 04:34:22 --> Output Class Initialized
INFO - 2018-04-02 04:34:22 --> Output Class Initialized
INFO - 2018-04-02 04:34:22 --> Security Class Initialized
INFO - 2018-04-02 04:34:22 --> Security Class Initialized
DEBUG - 2018-04-02 04:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 04:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:34:22 --> Input Class Initialized
INFO - 2018-04-02 04:34:22 --> Input Class Initialized
INFO - 2018-04-02 04:34:22 --> Language Class Initialized
INFO - 2018-04-02 04:34:22 --> Language Class Initialized
ERROR - 2018-04-02 04:34:22 --> 404 Page Not Found: Register/css
ERROR - 2018-04-02 04:34:22 --> 404 Page Not Found: Register/css
INFO - 2018-04-02 04:39:53 --> Config Class Initialized
INFO - 2018-04-02 04:39:53 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:39:53 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:39:53 --> Utf8 Class Initialized
INFO - 2018-04-02 04:39:53 --> URI Class Initialized
INFO - 2018-04-02 04:39:53 --> Router Class Initialized
INFO - 2018-04-02 04:39:53 --> Output Class Initialized
INFO - 2018-04-02 04:39:53 --> Security Class Initialized
DEBUG - 2018-04-02 04:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:39:53 --> Input Class Initialized
INFO - 2018-04-02 04:39:53 --> Language Class Initialized
ERROR - 2018-04-02 04:39:53 --> Severity: Error --> Class 'Student_Cotroller' not found G:\xampp\htdocs\codeigniter\application\controllers\Register.php 2
INFO - 2018-04-02 04:40:32 --> Config Class Initialized
INFO - 2018-04-02 04:40:32 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:40:32 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:40:32 --> Utf8 Class Initialized
INFO - 2018-04-02 04:40:32 --> URI Class Initialized
INFO - 2018-04-02 04:40:32 --> Router Class Initialized
INFO - 2018-04-02 04:40:32 --> Output Class Initialized
INFO - 2018-04-02 04:40:32 --> Security Class Initialized
DEBUG - 2018-04-02 04:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:40:32 --> Input Class Initialized
INFO - 2018-04-02 04:40:32 --> Language Class Initialized
INFO - 2018-04-02 04:40:32 --> Loader Class Initialized
INFO - 2018-04-02 04:40:32 --> Helper loaded: url_helper
INFO - 2018-04-02 04:40:32 --> Helper loaded: file_helper
INFO - 2018-04-02 04:40:32 --> Helper loaded: date_helper
INFO - 2018-04-02 04:40:32 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:40:32 --> Controller Class Initialized
INFO - 2018-04-02 04:40:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-02 04:41:11 --> Config Class Initialized
INFO - 2018-04-02 04:41:11 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:41:11 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:41:12 --> Utf8 Class Initialized
INFO - 2018-04-02 04:41:12 --> URI Class Initialized
INFO - 2018-04-02 04:41:12 --> Router Class Initialized
INFO - 2018-04-02 04:41:12 --> Output Class Initialized
INFO - 2018-04-02 04:41:12 --> Security Class Initialized
DEBUG - 2018-04-02 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:41:12 --> Input Class Initialized
INFO - 2018-04-02 04:41:12 --> Language Class Initialized
INFO - 2018-04-02 04:41:12 --> Loader Class Initialized
INFO - 2018-04-02 04:41:12 --> Helper loaded: url_helper
INFO - 2018-04-02 04:41:12 --> Helper loaded: file_helper
INFO - 2018-04-02 04:41:12 --> Helper loaded: date_helper
INFO - 2018-04-02 04:41:12 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:41:12 --> Controller Class Initialized
INFO - 2018-04-02 04:41:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-02 04:41:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:41:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-02 04:41:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-02 04:41:12 --> Final output sent to browser
DEBUG - 2018-04-02 04:41:12 --> Total execution time: 0.3718
INFO - 2018-04-02 04:41:52 --> Config Class Initialized
INFO - 2018-04-02 04:41:52 --> Config Class Initialized
INFO - 2018-04-02 04:41:52 --> Config Class Initialized
INFO - 2018-04-02 04:41:52 --> Hooks Class Initialized
INFO - 2018-04-02 04:41:52 --> Hooks Class Initialized
INFO - 2018-04-02 04:41:52 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:41:52 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 04:41:52 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 04:41:52 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:41:52 --> Utf8 Class Initialized
INFO - 2018-04-02 04:41:52 --> Utf8 Class Initialized
INFO - 2018-04-02 04:41:52 --> Utf8 Class Initialized
INFO - 2018-04-02 04:41:52 --> URI Class Initialized
INFO - 2018-04-02 04:41:52 --> URI Class Initialized
INFO - 2018-04-02 04:41:52 --> URI Class Initialized
INFO - 2018-04-02 04:41:52 --> Router Class Initialized
INFO - 2018-04-02 04:41:52 --> Router Class Initialized
INFO - 2018-04-02 04:41:52 --> Router Class Initialized
INFO - 2018-04-02 04:41:52 --> Output Class Initialized
INFO - 2018-04-02 04:41:52 --> Output Class Initialized
INFO - 2018-04-02 04:41:52 --> Output Class Initialized
INFO - 2018-04-02 04:41:52 --> Security Class Initialized
INFO - 2018-04-02 04:41:52 --> Security Class Initialized
INFO - 2018-04-02 04:41:52 --> Security Class Initialized
DEBUG - 2018-04-02 04:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 04:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 04:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:41:52 --> Input Class Initialized
INFO - 2018-04-02 04:41:52 --> Input Class Initialized
INFO - 2018-04-02 04:41:52 --> Input Class Initialized
INFO - 2018-04-02 04:41:52 --> Language Class Initialized
INFO - 2018-04-02 04:41:52 --> Language Class Initialized
INFO - 2018-04-02 04:41:52 --> Language Class Initialized
ERROR - 2018-04-02 04:41:52 --> 404 Page Not Found: Assets/css
ERROR - 2018-04-02 04:41:52 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-02 04:41:52 --> 404 Page Not Found: Assets/js
INFO - 2018-04-02 04:43:05 --> Config Class Initialized
INFO - 2018-04-02 04:43:05 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:43:05 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:43:05 --> Utf8 Class Initialized
INFO - 2018-04-02 04:43:05 --> URI Class Initialized
INFO - 2018-04-02 04:43:05 --> Router Class Initialized
INFO - 2018-04-02 04:43:05 --> Output Class Initialized
INFO - 2018-04-02 04:43:05 --> Security Class Initialized
DEBUG - 2018-04-02 04:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:43:05 --> Input Class Initialized
INFO - 2018-04-02 04:43:05 --> Language Class Initialized
INFO - 2018-04-02 04:43:05 --> Loader Class Initialized
INFO - 2018-04-02 04:43:05 --> Helper loaded: url_helper
INFO - 2018-04-02 04:43:05 --> Helper loaded: file_helper
INFO - 2018-04-02 04:43:05 --> Helper loaded: date_helper
INFO - 2018-04-02 04:43:05 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:43:05 --> Controller Class Initialized
INFO - 2018-04-02 04:43:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-02 04:43:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:43:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-02 04:43:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-02 04:43:05 --> Final output sent to browser
DEBUG - 2018-04-02 04:43:05 --> Total execution time: 0.3772
INFO - 2018-04-02 04:43:08 --> Config Class Initialized
INFO - 2018-04-02 04:43:08 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:43:08 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:43:08 --> Utf8 Class Initialized
INFO - 2018-04-02 04:43:09 --> URI Class Initialized
INFO - 2018-04-02 04:43:09 --> Router Class Initialized
INFO - 2018-04-02 04:43:09 --> Output Class Initialized
INFO - 2018-04-02 04:43:09 --> Security Class Initialized
DEBUG - 2018-04-02 04:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:43:09 --> Input Class Initialized
INFO - 2018-04-02 04:43:09 --> Language Class Initialized
INFO - 2018-04-02 04:43:09 --> Loader Class Initialized
INFO - 2018-04-02 04:43:09 --> Helper loaded: url_helper
INFO - 2018-04-02 04:43:09 --> Helper loaded: file_helper
INFO - 2018-04-02 04:43:09 --> Helper loaded: date_helper
INFO - 2018-04-02 04:43:09 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:43:09 --> Controller Class Initialized
INFO - 2018-04-02 04:43:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-02 04:43:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:43:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-02 04:43:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-02 04:43:09 --> Final output sent to browser
DEBUG - 2018-04-02 04:43:09 --> Total execution time: 0.4915
INFO - 2018-04-02 04:43:50 --> Config Class Initialized
INFO - 2018-04-02 04:43:50 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:43:50 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:43:50 --> Utf8 Class Initialized
INFO - 2018-04-02 04:43:50 --> URI Class Initialized
INFO - 2018-04-02 04:43:50 --> Router Class Initialized
INFO - 2018-04-02 04:43:50 --> Output Class Initialized
INFO - 2018-04-02 04:43:50 --> Security Class Initialized
DEBUG - 2018-04-02 04:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:43:50 --> Input Class Initialized
INFO - 2018-04-02 04:43:50 --> Language Class Initialized
INFO - 2018-04-02 04:43:50 --> Loader Class Initialized
INFO - 2018-04-02 04:43:50 --> Helper loaded: url_helper
INFO - 2018-04-02 04:43:50 --> Helper loaded: file_helper
INFO - 2018-04-02 04:43:50 --> Helper loaded: date_helper
INFO - 2018-04-02 04:43:50 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:43:50 --> Controller Class Initialized
INFO - 2018-04-02 04:43:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-02 04:43:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:43:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-02 04:43:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-02 04:43:50 --> Final output sent to browser
INFO - 2018-04-02 04:43:50 --> Config Class Initialized
INFO - 2018-04-02 04:43:50 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:43:50 --> Total execution time: 0.3580
DEBUG - 2018-04-02 04:43:50 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:43:50 --> Utf8 Class Initialized
INFO - 2018-04-02 04:43:50 --> URI Class Initialized
INFO - 2018-04-02 04:43:50 --> Router Class Initialized
INFO - 2018-04-02 04:43:50 --> Output Class Initialized
INFO - 2018-04-02 04:43:50 --> Security Class Initialized
DEBUG - 2018-04-02 04:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:43:50 --> Input Class Initialized
INFO - 2018-04-02 04:43:50 --> Language Class Initialized
INFO - 2018-04-02 04:43:50 --> Loader Class Initialized
INFO - 2018-04-02 04:43:50 --> Helper loaded: url_helper
INFO - 2018-04-02 04:43:50 --> Helper loaded: file_helper
INFO - 2018-04-02 04:43:50 --> Helper loaded: date_helper
INFO - 2018-04-02 04:43:50 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:43:50 --> Controller Class Initialized
INFO - 2018-04-02 04:43:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-02 04:43:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:43:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-02 04:43:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-02 04:43:50 --> Final output sent to browser
DEBUG - 2018-04-02 04:43:50 --> Total execution time: 0.2854
INFO - 2018-04-02 04:43:50 --> Config Class Initialized
INFO - 2018-04-02 04:43:50 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:43:50 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:43:50 --> Utf8 Class Initialized
INFO - 2018-04-02 04:43:50 --> URI Class Initialized
INFO - 2018-04-02 04:43:50 --> Router Class Initialized
INFO - 2018-04-02 04:43:51 --> Output Class Initialized
INFO - 2018-04-02 04:43:51 --> Security Class Initialized
DEBUG - 2018-04-02 04:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:43:51 --> Input Class Initialized
INFO - 2018-04-02 04:43:51 --> Language Class Initialized
INFO - 2018-04-02 04:43:51 --> Loader Class Initialized
INFO - 2018-04-02 04:43:51 --> Helper loaded: url_helper
INFO - 2018-04-02 04:43:51 --> Helper loaded: file_helper
INFO - 2018-04-02 04:43:51 --> Helper loaded: date_helper
INFO - 2018-04-02 04:43:51 --> Config Class Initialized
INFO - 2018-04-02 04:43:51 --> Hooks Class Initialized
INFO - 2018-04-02 04:43:51 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:43:51 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 04:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:43:51 --> Utf8 Class Initialized
INFO - 2018-04-02 04:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:43:51 --> Controller Class Initialized
INFO - 2018-04-02 04:43:51 --> URI Class Initialized
INFO - 2018-04-02 04:43:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-02 04:43:51 --> Router Class Initialized
INFO - 2018-04-02 04:43:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:43:51 --> Output Class Initialized
INFO - 2018-04-02 04:43:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-02 04:43:51 --> Security Class Initialized
INFO - 2018-04-02 04:43:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
DEBUG - 2018-04-02 04:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:43:51 --> Input Class Initialized
INFO - 2018-04-02 04:43:51 --> Final output sent to browser
DEBUG - 2018-04-02 04:43:51 --> Total execution time: 0.4161
INFO - 2018-04-02 04:43:51 --> Language Class Initialized
INFO - 2018-04-02 04:43:51 --> Loader Class Initialized
INFO - 2018-04-02 04:43:51 --> Helper loaded: url_helper
INFO - 2018-04-02 04:43:51 --> Helper loaded: file_helper
INFO - 2018-04-02 04:43:51 --> Helper loaded: date_helper
INFO - 2018-04-02 04:43:51 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:43:51 --> Controller Class Initialized
INFO - 2018-04-02 04:43:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-02 04:43:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:43:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-02 04:43:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-02 04:43:51 --> Final output sent to browser
DEBUG - 2018-04-02 04:43:51 --> Total execution time: 0.2994
INFO - 2018-04-02 04:44:21 --> Config Class Initialized
INFO - 2018-04-02 04:44:21 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:44:21 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:44:21 --> Utf8 Class Initialized
INFO - 2018-04-02 04:44:21 --> URI Class Initialized
INFO - 2018-04-02 04:44:21 --> Router Class Initialized
INFO - 2018-04-02 04:44:21 --> Output Class Initialized
INFO - 2018-04-02 04:44:21 --> Security Class Initialized
DEBUG - 2018-04-02 04:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:44:22 --> Input Class Initialized
INFO - 2018-04-02 04:44:22 --> Language Class Initialized
INFO - 2018-04-02 04:44:22 --> Loader Class Initialized
INFO - 2018-04-02 04:44:22 --> Helper loaded: url_helper
INFO - 2018-04-02 04:44:22 --> Helper loaded: file_helper
INFO - 2018-04-02 04:44:22 --> Helper loaded: date_helper
INFO - 2018-04-02 04:44:22 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:44:22 --> Controller Class Initialized
INFO - 2018-04-02 04:44:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-02 04:44:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:44:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-02 04:44:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-02 04:44:22 --> Final output sent to browser
DEBUG - 2018-04-02 04:44:22 --> Total execution time: 0.3256
INFO - 2018-04-02 04:47:31 --> Config Class Initialized
INFO - 2018-04-02 04:47:31 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:47:31 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:47:31 --> Utf8 Class Initialized
INFO - 2018-04-02 04:47:31 --> URI Class Initialized
INFO - 2018-04-02 04:47:31 --> Router Class Initialized
INFO - 2018-04-02 04:47:31 --> Output Class Initialized
INFO - 2018-04-02 04:47:31 --> Security Class Initialized
DEBUG - 2018-04-02 04:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:47:31 --> Input Class Initialized
INFO - 2018-04-02 04:47:31 --> Language Class Initialized
INFO - 2018-04-02 04:47:31 --> Loader Class Initialized
INFO - 2018-04-02 04:47:31 --> Helper loaded: url_helper
INFO - 2018-04-02 04:47:31 --> Helper loaded: file_helper
INFO - 2018-04-02 04:47:31 --> Helper loaded: date_helper
INFO - 2018-04-02 04:47:31 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:47:31 --> Controller Class Initialized
INFO - 2018-04-02 04:47:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:47:31 --> Final output sent to browser
DEBUG - 2018-04-02 04:47:31 --> Total execution time: 0.2866
INFO - 2018-04-02 04:47:31 --> Config Class Initialized
INFO - 2018-04-02 04:47:31 --> Config Class Initialized
INFO - 2018-04-02 04:47:31 --> Hooks Class Initialized
INFO - 2018-04-02 04:47:31 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:47:31 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 04:47:31 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:47:31 --> Utf8 Class Initialized
INFO - 2018-04-02 04:47:31 --> Utf8 Class Initialized
INFO - 2018-04-02 04:47:31 --> URI Class Initialized
INFO - 2018-04-02 04:47:31 --> URI Class Initialized
INFO - 2018-04-02 04:47:31 --> Router Class Initialized
INFO - 2018-04-02 04:47:31 --> Router Class Initialized
INFO - 2018-04-02 04:47:31 --> Output Class Initialized
INFO - 2018-04-02 04:47:31 --> Output Class Initialized
INFO - 2018-04-02 04:47:31 --> Security Class Initialized
INFO - 2018-04-02 04:47:31 --> Security Class Initialized
DEBUG - 2018-04-02 04:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 04:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:47:31 --> Input Class Initialized
INFO - 2018-04-02 04:47:31 --> Input Class Initialized
INFO - 2018-04-02 04:47:31 --> Language Class Initialized
INFO - 2018-04-02 04:47:31 --> Language Class Initialized
ERROR - 2018-04-02 04:47:31 --> 404 Page Not Found: Register/css
ERROR - 2018-04-02 04:47:31 --> 404 Page Not Found: Register/css
INFO - 2018-04-02 04:49:59 --> Config Class Initialized
INFO - 2018-04-02 04:49:59 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:49:59 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:49:59 --> Utf8 Class Initialized
INFO - 2018-04-02 04:49:59 --> URI Class Initialized
INFO - 2018-04-02 04:49:59 --> Router Class Initialized
INFO - 2018-04-02 04:49:59 --> Output Class Initialized
INFO - 2018-04-02 04:49:59 --> Security Class Initialized
DEBUG - 2018-04-02 04:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:49:59 --> Input Class Initialized
INFO - 2018-04-02 04:49:59 --> Language Class Initialized
INFO - 2018-04-02 04:49:59 --> Loader Class Initialized
INFO - 2018-04-02 04:49:59 --> Helper loaded: url_helper
INFO - 2018-04-02 04:49:59 --> Helper loaded: file_helper
INFO - 2018-04-02 04:49:59 --> Helper loaded: date_helper
INFO - 2018-04-02 04:49:59 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:49:59 --> Controller Class Initialized
INFO - 2018-04-02 04:49:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:49:59 --> Final output sent to browser
DEBUG - 2018-04-02 04:49:59 --> Total execution time: 0.4106
INFO - 2018-04-02 04:50:07 --> Config Class Initialized
INFO - 2018-04-02 04:50:07 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:50:07 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:50:08 --> Utf8 Class Initialized
INFO - 2018-04-02 04:50:08 --> URI Class Initialized
INFO - 2018-04-02 04:50:08 --> Router Class Initialized
INFO - 2018-04-02 04:50:08 --> Output Class Initialized
INFO - 2018-04-02 04:50:08 --> Security Class Initialized
DEBUG - 2018-04-02 04:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:50:08 --> Input Class Initialized
INFO - 2018-04-02 04:50:08 --> Language Class Initialized
ERROR - 2018-04-02 04:50:08 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 04:51:12 --> Config Class Initialized
INFO - 2018-04-02 04:51:12 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:51:12 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:51:12 --> Utf8 Class Initialized
INFO - 2018-04-02 04:51:12 --> URI Class Initialized
INFO - 2018-04-02 04:51:12 --> Router Class Initialized
INFO - 2018-04-02 04:51:12 --> Output Class Initialized
INFO - 2018-04-02 04:51:12 --> Security Class Initialized
DEBUG - 2018-04-02 04:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:51:12 --> Input Class Initialized
INFO - 2018-04-02 04:51:12 --> Language Class Initialized
INFO - 2018-04-02 04:51:12 --> Loader Class Initialized
INFO - 2018-04-02 04:51:12 --> Helper loaded: url_helper
INFO - 2018-04-02 04:51:12 --> Helper loaded: file_helper
INFO - 2018-04-02 04:51:12 --> Helper loaded: date_helper
INFO - 2018-04-02 04:51:12 --> Database Driver Class Initialized
DEBUG - 2018-04-02 04:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 04:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 04:51:12 --> Controller Class Initialized
INFO - 2018-04-02 04:51:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 04:51:12 --> Final output sent to browser
DEBUG - 2018-04-02 04:51:12 --> Total execution time: 0.3617
INFO - 2018-04-02 04:51:13 --> Config Class Initialized
INFO - 2018-04-02 04:51:13 --> Hooks Class Initialized
DEBUG - 2018-04-02 04:51:13 --> UTF-8 Support Enabled
INFO - 2018-04-02 04:51:13 --> Utf8 Class Initialized
INFO - 2018-04-02 04:51:13 --> URI Class Initialized
INFO - 2018-04-02 04:51:13 --> Router Class Initialized
INFO - 2018-04-02 04:51:13 --> Output Class Initialized
INFO - 2018-04-02 04:51:13 --> Security Class Initialized
DEBUG - 2018-04-02 04:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 04:51:13 --> Input Class Initialized
INFO - 2018-04-02 04:51:13 --> Language Class Initialized
ERROR - 2018-04-02 04:51:13 --> 404 Page Not Found: Assets/css
INFO - 2018-04-02 05:00:16 --> Config Class Initialized
INFO - 2018-04-02 05:00:16 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:00:16 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:00:16 --> Utf8 Class Initialized
INFO - 2018-04-02 05:00:17 --> URI Class Initialized
INFO - 2018-04-02 05:00:17 --> Router Class Initialized
INFO - 2018-04-02 05:00:17 --> Output Class Initialized
INFO - 2018-04-02 05:00:17 --> Security Class Initialized
DEBUG - 2018-04-02 05:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:00:17 --> Input Class Initialized
INFO - 2018-04-02 05:00:17 --> Language Class Initialized
ERROR - 2018-04-02 05:00:17 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) G:\xampp\htdocs\codeigniter\application\controllers\Register.php 11
INFO - 2018-04-02 05:00:35 --> Config Class Initialized
INFO - 2018-04-02 05:00:35 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:00:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:00:35 --> Utf8 Class Initialized
INFO - 2018-04-02 05:00:35 --> URI Class Initialized
INFO - 2018-04-02 05:00:35 --> Router Class Initialized
INFO - 2018-04-02 05:00:35 --> Output Class Initialized
INFO - 2018-04-02 05:00:35 --> Security Class Initialized
DEBUG - 2018-04-02 05:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:00:35 --> Input Class Initialized
INFO - 2018-04-02 05:00:35 --> Language Class Initialized
ERROR - 2018-04-02 05:00:35 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) G:\xampp\htdocs\codeigniter\application\controllers\Register.php 11
INFO - 2018-04-02 05:00:39 --> Config Class Initialized
INFO - 2018-04-02 05:00:39 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:00:39 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:00:39 --> Utf8 Class Initialized
INFO - 2018-04-02 05:00:39 --> URI Class Initialized
INFO - 2018-04-02 05:00:39 --> Router Class Initialized
INFO - 2018-04-02 05:00:39 --> Output Class Initialized
INFO - 2018-04-02 05:00:39 --> Security Class Initialized
DEBUG - 2018-04-02 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:00:39 --> Input Class Initialized
INFO - 2018-04-02 05:00:39 --> Language Class Initialized
ERROR - 2018-04-02 05:00:39 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) G:\xampp\htdocs\codeigniter\application\controllers\Register.php 11
INFO - 2018-04-02 05:01:13 --> Config Class Initialized
INFO - 2018-04-02 05:01:13 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:01:13 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:01:13 --> Utf8 Class Initialized
INFO - 2018-04-02 05:01:13 --> URI Class Initialized
INFO - 2018-04-02 05:01:13 --> Router Class Initialized
INFO - 2018-04-02 05:01:13 --> Output Class Initialized
INFO - 2018-04-02 05:01:13 --> Security Class Initialized
DEBUG - 2018-04-02 05:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:01:13 --> Input Class Initialized
INFO - 2018-04-02 05:01:13 --> Language Class Initialized
ERROR - 2018-04-02 05:01:13 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) G:\xampp\htdocs\codeigniter\application\controllers\Register.php 11
INFO - 2018-04-02 05:01:46 --> Config Class Initialized
INFO - 2018-04-02 05:01:46 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:01:46 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:01:46 --> Utf8 Class Initialized
INFO - 2018-04-02 05:01:46 --> URI Class Initialized
INFO - 2018-04-02 05:01:46 --> Router Class Initialized
INFO - 2018-04-02 05:01:46 --> Output Class Initialized
INFO - 2018-04-02 05:01:46 --> Security Class Initialized
DEBUG - 2018-04-02 05:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:01:46 --> Input Class Initialized
INFO - 2018-04-02 05:01:46 --> Language Class Initialized
INFO - 2018-04-02 05:01:46 --> Loader Class Initialized
INFO - 2018-04-02 05:01:46 --> Helper loaded: url_helper
INFO - 2018-04-02 05:01:46 --> Helper loaded: file_helper
INFO - 2018-04-02 05:01:46 --> Helper loaded: date_helper
INFO - 2018-04-02 05:01:46 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:01:46 --> Controller Class Initialized
INFO - 2018-04-02 05:01:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 05:01:46 --> Final output sent to browser
DEBUG - 2018-04-02 05:01:46 --> Total execution time: 0.2869
INFO - 2018-04-02 05:01:48 --> Config Class Initialized
INFO - 2018-04-02 05:01:48 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:01:48 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:01:48 --> Utf8 Class Initialized
INFO - 2018-04-02 05:01:48 --> URI Class Initialized
INFO - 2018-04-02 05:01:48 --> Router Class Initialized
INFO - 2018-04-02 05:01:48 --> Output Class Initialized
INFO - 2018-04-02 05:01:48 --> Security Class Initialized
DEBUG - 2018-04-02 05:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:01:48 --> Input Class Initialized
INFO - 2018-04-02 05:01:49 --> Language Class Initialized
ERROR - 2018-04-02 05:01:49 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) G:\xampp\htdocs\codeigniter\application\controllers\Register.php 11
INFO - 2018-04-02 05:02:31 --> Config Class Initialized
INFO - 2018-04-02 05:02:31 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:02:31 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:02:32 --> Utf8 Class Initialized
INFO - 2018-04-02 05:02:32 --> URI Class Initialized
INFO - 2018-04-02 05:02:32 --> Router Class Initialized
INFO - 2018-04-02 05:02:32 --> Output Class Initialized
INFO - 2018-04-02 05:02:32 --> Security Class Initialized
DEBUG - 2018-04-02 05:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:02:32 --> Input Class Initialized
INFO - 2018-04-02 05:02:32 --> Language Class Initialized
INFO - 2018-04-02 05:02:32 --> Loader Class Initialized
INFO - 2018-04-02 05:02:32 --> Helper loaded: url_helper
INFO - 2018-04-02 05:02:32 --> Helper loaded: file_helper
INFO - 2018-04-02 05:02:32 --> Helper loaded: date_helper
INFO - 2018-04-02 05:02:32 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:02:32 --> Controller Class Initialized
INFO - 2018-04-02 05:02:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:02:32 --> Final output sent to browser
DEBUG - 2018-04-02 05:02:32 --> Total execution time: 0.3031
INFO - 2018-04-02 05:02:53 --> Config Class Initialized
INFO - 2018-04-02 05:02:53 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:02:53 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:02:53 --> Utf8 Class Initialized
INFO - 2018-04-02 05:02:53 --> URI Class Initialized
INFO - 2018-04-02 05:02:53 --> Router Class Initialized
INFO - 2018-04-02 05:02:53 --> Output Class Initialized
INFO - 2018-04-02 05:02:53 --> Security Class Initialized
DEBUG - 2018-04-02 05:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:02:53 --> Input Class Initialized
INFO - 2018-04-02 05:02:53 --> Language Class Initialized
ERROR - 2018-04-02 05:02:53 --> 404 Page Not Found: Register/Register
INFO - 2018-04-02 05:03:40 --> Config Class Initialized
INFO - 2018-04-02 05:03:40 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:03:40 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:03:40 --> Utf8 Class Initialized
INFO - 2018-04-02 05:03:40 --> URI Class Initialized
INFO - 2018-04-02 05:03:40 --> Router Class Initialized
INFO - 2018-04-02 05:03:40 --> Output Class Initialized
INFO - 2018-04-02 05:03:40 --> Security Class Initialized
DEBUG - 2018-04-02 05:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:03:40 --> Input Class Initialized
INFO - 2018-04-02 05:03:40 --> Language Class Initialized
INFO - 2018-04-02 05:03:40 --> Loader Class Initialized
INFO - 2018-04-02 05:03:40 --> Helper loaded: url_helper
INFO - 2018-04-02 05:03:40 --> Helper loaded: file_helper
INFO - 2018-04-02 05:03:40 --> Helper loaded: date_helper
INFO - 2018-04-02 05:03:40 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:03:40 --> Controller Class Initialized
INFO - 2018-04-02 05:03:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:03:40 --> Final output sent to browser
DEBUG - 2018-04-02 05:03:40 --> Total execution time: 0.3072
INFO - 2018-04-02 05:04:14 --> Config Class Initialized
INFO - 2018-04-02 05:04:14 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:04:14 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:04:14 --> Utf8 Class Initialized
INFO - 2018-04-02 05:04:14 --> URI Class Initialized
INFO - 2018-04-02 05:04:14 --> Router Class Initialized
INFO - 2018-04-02 05:04:14 --> Output Class Initialized
INFO - 2018-04-02 05:04:14 --> Security Class Initialized
DEBUG - 2018-04-02 05:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:04:14 --> Input Class Initialized
INFO - 2018-04-02 05:04:14 --> Language Class Initialized
INFO - 2018-04-02 05:04:14 --> Loader Class Initialized
INFO - 2018-04-02 05:04:14 --> Helper loaded: url_helper
INFO - 2018-04-02 05:04:14 --> Helper loaded: file_helper
INFO - 2018-04-02 05:04:14 --> Helper loaded: date_helper
INFO - 2018-04-02 05:04:14 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:04:14 --> Controller Class Initialized
INFO - 2018-04-02 05:04:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:04:14 --> Final output sent to browser
DEBUG - 2018-04-02 05:04:14 --> Total execution time: 0.2825
INFO - 2018-04-02 05:05:35 --> Config Class Initialized
INFO - 2018-04-02 05:05:35 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:05:35 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:05:35 --> Utf8 Class Initialized
INFO - 2018-04-02 05:05:35 --> URI Class Initialized
INFO - 2018-04-02 05:05:35 --> Router Class Initialized
INFO - 2018-04-02 05:05:35 --> Output Class Initialized
INFO - 2018-04-02 05:05:35 --> Security Class Initialized
DEBUG - 2018-04-02 05:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:05:35 --> Input Class Initialized
INFO - 2018-04-02 05:05:35 --> Language Class Initialized
INFO - 2018-04-02 05:05:35 --> Loader Class Initialized
INFO - 2018-04-02 05:05:35 --> Helper loaded: url_helper
INFO - 2018-04-02 05:05:35 --> Helper loaded: file_helper
INFO - 2018-04-02 05:05:35 --> Helper loaded: date_helper
INFO - 2018-04-02 05:05:35 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:05:35 --> Controller Class Initialized
INFO - 2018-04-02 05:05:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:05:35 --> Final output sent to browser
DEBUG - 2018-04-02 05:05:35 --> Total execution time: 0.3261
INFO - 2018-04-02 05:06:03 --> Config Class Initialized
INFO - 2018-04-02 05:06:03 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:06:03 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:06:03 --> Utf8 Class Initialized
INFO - 2018-04-02 05:06:03 --> URI Class Initialized
INFO - 2018-04-02 05:06:03 --> Router Class Initialized
INFO - 2018-04-02 05:06:03 --> Output Class Initialized
INFO - 2018-04-02 05:06:03 --> Security Class Initialized
DEBUG - 2018-04-02 05:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:06:03 --> Input Class Initialized
INFO - 2018-04-02 05:06:03 --> Language Class Initialized
INFO - 2018-04-02 05:06:03 --> Loader Class Initialized
INFO - 2018-04-02 05:06:03 --> Helper loaded: url_helper
INFO - 2018-04-02 05:06:03 --> Helper loaded: file_helper
INFO - 2018-04-02 05:06:03 --> Helper loaded: date_helper
INFO - 2018-04-02 05:06:04 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:06:04 --> Controller Class Initialized
INFO - 2018-04-02 05:06:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:06:04 --> Final output sent to browser
DEBUG - 2018-04-02 05:06:04 --> Total execution time: 0.2938
INFO - 2018-04-02 05:06:42 --> Config Class Initialized
INFO - 2018-04-02 05:06:42 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:06:42 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:06:42 --> Utf8 Class Initialized
INFO - 2018-04-02 05:06:42 --> URI Class Initialized
INFO - 2018-04-02 05:06:42 --> Router Class Initialized
INFO - 2018-04-02 05:06:42 --> Output Class Initialized
INFO - 2018-04-02 05:06:42 --> Security Class Initialized
DEBUG - 2018-04-02 05:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:06:42 --> Input Class Initialized
INFO - 2018-04-02 05:06:42 --> Language Class Initialized
INFO - 2018-04-02 05:06:42 --> Loader Class Initialized
INFO - 2018-04-02 05:06:42 --> Helper loaded: url_helper
INFO - 2018-04-02 05:06:42 --> Helper loaded: file_helper
INFO - 2018-04-02 05:06:43 --> Helper loaded: date_helper
INFO - 2018-04-02 05:06:43 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:06:43 --> Controller Class Initialized
INFO - 2018-04-02 05:06:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:06:43 --> Final output sent to browser
DEBUG - 2018-04-02 05:06:43 --> Total execution time: 0.3111
INFO - 2018-04-02 05:08:14 --> Config Class Initialized
INFO - 2018-04-02 05:08:14 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:08:14 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:08:14 --> Utf8 Class Initialized
INFO - 2018-04-02 05:08:14 --> URI Class Initialized
INFO - 2018-04-02 05:08:14 --> Router Class Initialized
INFO - 2018-04-02 05:08:14 --> Output Class Initialized
INFO - 2018-04-02 05:08:14 --> Security Class Initialized
DEBUG - 2018-04-02 05:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:08:14 --> Input Class Initialized
INFO - 2018-04-02 05:08:14 --> Language Class Initialized
INFO - 2018-04-02 05:08:15 --> Loader Class Initialized
INFO - 2018-04-02 05:08:15 --> Helper loaded: url_helper
INFO - 2018-04-02 05:08:15 --> Helper loaded: file_helper
INFO - 2018-04-02 05:08:15 --> Helper loaded: date_helper
INFO - 2018-04-02 05:08:15 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:08:15 --> Controller Class Initialized
INFO - 2018-04-02 05:08:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:08:15 --> Final output sent to browser
DEBUG - 2018-04-02 05:08:15 --> Total execution time: 0.3181
INFO - 2018-04-02 05:08:16 --> Config Class Initialized
INFO - 2018-04-02 05:08:16 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:08:16 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:08:16 --> Utf8 Class Initialized
INFO - 2018-04-02 05:08:16 --> URI Class Initialized
INFO - 2018-04-02 05:08:16 --> Router Class Initialized
INFO - 2018-04-02 05:08:16 --> Output Class Initialized
INFO - 2018-04-02 05:08:16 --> Security Class Initialized
DEBUG - 2018-04-02 05:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:08:16 --> Input Class Initialized
INFO - 2018-04-02 05:08:16 --> Language Class Initialized
INFO - 2018-04-02 05:08:16 --> Loader Class Initialized
INFO - 2018-04-02 05:08:16 --> Helper loaded: url_helper
INFO - 2018-04-02 05:08:16 --> Helper loaded: file_helper
INFO - 2018-04-02 05:08:16 --> Helper loaded: date_helper
INFO - 2018-04-02 05:08:16 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:08:16 --> Controller Class Initialized
INFO - 2018-04-02 05:08:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:08:16 --> Final output sent to browser
DEBUG - 2018-04-02 05:08:16 --> Total execution time: 0.3581
INFO - 2018-04-02 05:08:21 --> Config Class Initialized
INFO - 2018-04-02 05:08:21 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:08:21 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:08:21 --> Utf8 Class Initialized
INFO - 2018-04-02 05:08:21 --> URI Class Initialized
INFO - 2018-04-02 05:08:21 --> Router Class Initialized
INFO - 2018-04-02 05:08:21 --> Output Class Initialized
INFO - 2018-04-02 05:08:21 --> Security Class Initialized
DEBUG - 2018-04-02 05:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:08:21 --> Input Class Initialized
INFO - 2018-04-02 05:08:21 --> Language Class Initialized
INFO - 2018-04-02 05:08:21 --> Loader Class Initialized
INFO - 2018-04-02 05:08:21 --> Helper loaded: url_helper
INFO - 2018-04-02 05:08:21 --> Helper loaded: file_helper
INFO - 2018-04-02 05:08:21 --> Helper loaded: date_helper
INFO - 2018-04-02 05:08:21 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:08:21 --> Controller Class Initialized
INFO - 2018-04-02 05:08:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:08:21 --> Final output sent to browser
DEBUG - 2018-04-02 05:08:21 --> Total execution time: 0.2927
INFO - 2018-04-02 05:08:26 --> Config Class Initialized
INFO - 2018-04-02 05:08:26 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:08:26 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:08:26 --> Utf8 Class Initialized
INFO - 2018-04-02 05:08:26 --> URI Class Initialized
INFO - 2018-04-02 05:08:26 --> Router Class Initialized
INFO - 2018-04-02 05:08:26 --> Output Class Initialized
INFO - 2018-04-02 05:08:26 --> Security Class Initialized
DEBUG - 2018-04-02 05:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:08:26 --> Input Class Initialized
INFO - 2018-04-02 05:08:26 --> Language Class Initialized
INFO - 2018-04-02 05:08:26 --> Loader Class Initialized
INFO - 2018-04-02 05:08:26 --> Helper loaded: url_helper
INFO - 2018-04-02 05:08:26 --> Helper loaded: file_helper
INFO - 2018-04-02 05:08:26 --> Helper loaded: date_helper
INFO - 2018-04-02 05:08:26 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:08:26 --> Controller Class Initialized
INFO - 2018-04-02 05:08:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:08:26 --> Final output sent to browser
DEBUG - 2018-04-02 05:08:26 --> Total execution time: 0.2917
INFO - 2018-04-02 05:08:46 --> Config Class Initialized
INFO - 2018-04-02 05:08:46 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:08:46 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:08:46 --> Utf8 Class Initialized
INFO - 2018-04-02 05:08:46 --> URI Class Initialized
INFO - 2018-04-02 05:08:46 --> Router Class Initialized
INFO - 2018-04-02 05:08:46 --> Output Class Initialized
INFO - 2018-04-02 05:08:46 --> Security Class Initialized
DEBUG - 2018-04-02 05:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:08:46 --> Input Class Initialized
INFO - 2018-04-02 05:08:46 --> Language Class Initialized
INFO - 2018-04-02 05:08:46 --> Loader Class Initialized
INFO - 2018-04-02 05:08:46 --> Helper loaded: url_helper
INFO - 2018-04-02 05:08:46 --> Helper loaded: file_helper
INFO - 2018-04-02 05:08:46 --> Helper loaded: date_helper
INFO - 2018-04-02 05:08:46 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:08:46 --> Controller Class Initialized
INFO - 2018-04-02 05:08:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:08:46 --> Final output sent to browser
DEBUG - 2018-04-02 05:08:46 --> Total execution time: 0.3175
INFO - 2018-04-02 05:08:49 --> Config Class Initialized
INFO - 2018-04-02 05:08:49 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:08:49 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:08:49 --> Utf8 Class Initialized
INFO - 2018-04-02 05:08:49 --> URI Class Initialized
INFO - 2018-04-02 05:08:49 --> Router Class Initialized
INFO - 2018-04-02 05:08:49 --> Output Class Initialized
INFO - 2018-04-02 05:08:49 --> Security Class Initialized
DEBUG - 2018-04-02 05:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:08:49 --> Input Class Initialized
INFO - 2018-04-02 05:08:49 --> Language Class Initialized
INFO - 2018-04-02 05:08:49 --> Loader Class Initialized
INFO - 2018-04-02 05:08:49 --> Helper loaded: url_helper
INFO - 2018-04-02 05:08:49 --> Helper loaded: file_helper
INFO - 2018-04-02 05:08:49 --> Helper loaded: date_helper
INFO - 2018-04-02 05:08:49 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:08:49 --> Controller Class Initialized
INFO - 2018-04-02 05:29:34 --> Config Class Initialized
INFO - 2018-04-02 05:29:34 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:29:34 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:29:34 --> Utf8 Class Initialized
INFO - 2018-04-02 05:29:34 --> URI Class Initialized
INFO - 2018-04-02 05:29:34 --> Router Class Initialized
INFO - 2018-04-02 05:29:34 --> Output Class Initialized
INFO - 2018-04-02 05:29:34 --> Security Class Initialized
DEBUG - 2018-04-02 05:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:29:34 --> Input Class Initialized
INFO - 2018-04-02 05:29:34 --> Language Class Initialized
INFO - 2018-04-02 05:29:34 --> Loader Class Initialized
INFO - 2018-04-02 05:29:34 --> Helper loaded: url_helper
INFO - 2018-04-02 05:29:34 --> Helper loaded: file_helper
INFO - 2018-04-02 05:29:34 --> Helper loaded: date_helper
INFO - 2018-04-02 05:29:34 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:29:34 --> Controller Class Initialized
INFO - 2018-04-02 05:29:34 --> Final output sent to browser
DEBUG - 2018-04-02 05:29:34 --> Total execution time: 0.2959
INFO - 2018-04-02 05:29:41 --> Config Class Initialized
INFO - 2018-04-02 05:29:41 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:29:41 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:29:41 --> Utf8 Class Initialized
INFO - 2018-04-02 05:29:41 --> URI Class Initialized
INFO - 2018-04-02 05:29:41 --> Router Class Initialized
INFO - 2018-04-02 05:29:41 --> Output Class Initialized
INFO - 2018-04-02 05:29:41 --> Security Class Initialized
DEBUG - 2018-04-02 05:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:29:42 --> Input Class Initialized
INFO - 2018-04-02 05:29:42 --> Language Class Initialized
INFO - 2018-04-02 05:29:42 --> Loader Class Initialized
INFO - 2018-04-02 05:29:42 --> Helper loaded: url_helper
INFO - 2018-04-02 05:29:42 --> Helper loaded: file_helper
INFO - 2018-04-02 05:29:42 --> Helper loaded: date_helper
INFO - 2018-04-02 05:29:42 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:29:42 --> Controller Class Initialized
INFO - 2018-04-02 05:29:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:29:42 --> Final output sent to browser
DEBUG - 2018-04-02 05:29:42 --> Total execution time: 0.2960
INFO - 2018-04-02 05:29:45 --> Config Class Initialized
INFO - 2018-04-02 05:29:45 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:29:45 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:29:45 --> Utf8 Class Initialized
INFO - 2018-04-02 05:29:45 --> URI Class Initialized
INFO - 2018-04-02 05:29:45 --> Router Class Initialized
INFO - 2018-04-02 05:29:45 --> Output Class Initialized
INFO - 2018-04-02 05:29:45 --> Security Class Initialized
DEBUG - 2018-04-02 05:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:29:45 --> Input Class Initialized
INFO - 2018-04-02 05:29:45 --> Language Class Initialized
INFO - 2018-04-02 05:29:45 --> Loader Class Initialized
INFO - 2018-04-02 05:29:45 --> Helper loaded: url_helper
INFO - 2018-04-02 05:29:45 --> Helper loaded: file_helper
INFO - 2018-04-02 05:29:45 --> Helper loaded: date_helper
INFO - 2018-04-02 05:29:45 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:29:45 --> Controller Class Initialized
INFO - 2018-04-02 05:29:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:29:45 --> Final output sent to browser
DEBUG - 2018-04-02 05:29:45 --> Total execution time: 0.3704
INFO - 2018-04-02 05:30:09 --> Config Class Initialized
INFO - 2018-04-02 05:30:10 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:30:10 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:30:10 --> Utf8 Class Initialized
INFO - 2018-04-02 05:30:10 --> URI Class Initialized
INFO - 2018-04-02 05:30:10 --> Router Class Initialized
INFO - 2018-04-02 05:30:10 --> Output Class Initialized
INFO - 2018-04-02 05:30:10 --> Security Class Initialized
DEBUG - 2018-04-02 05:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:30:10 --> Input Class Initialized
INFO - 2018-04-02 05:30:10 --> Language Class Initialized
INFO - 2018-04-02 05:30:10 --> Loader Class Initialized
INFO - 2018-04-02 05:30:10 --> Helper loaded: url_helper
INFO - 2018-04-02 05:30:10 --> Helper loaded: file_helper
INFO - 2018-04-02 05:30:10 --> Helper loaded: date_helper
INFO - 2018-04-02 05:30:10 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:30:10 --> Controller Class Initialized
INFO - 2018-04-02 05:30:39 --> Config Class Initialized
INFO - 2018-04-02 05:30:40 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:30:40 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:30:40 --> Utf8 Class Initialized
INFO - 2018-04-02 05:30:40 --> URI Class Initialized
INFO - 2018-04-02 05:30:40 --> Router Class Initialized
INFO - 2018-04-02 05:30:40 --> Output Class Initialized
INFO - 2018-04-02 05:30:40 --> Security Class Initialized
DEBUG - 2018-04-02 05:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:30:40 --> Input Class Initialized
INFO - 2018-04-02 05:30:40 --> Language Class Initialized
INFO - 2018-04-02 05:30:40 --> Loader Class Initialized
INFO - 2018-04-02 05:30:40 --> Helper loaded: url_helper
INFO - 2018-04-02 05:30:40 --> Helper loaded: file_helper
INFO - 2018-04-02 05:30:40 --> Helper loaded: date_helper
INFO - 2018-04-02 05:30:40 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:30:41 --> Controller Class Initialized
INFO - 2018-04-02 05:30:41 --> Final output sent to browser
DEBUG - 2018-04-02 05:30:41 --> Total execution time: 1.2091
INFO - 2018-04-02 05:30:41 --> Config Class Initialized
INFO - 2018-04-02 05:30:41 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:30:41 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:30:41 --> Utf8 Class Initialized
INFO - 2018-04-02 05:30:41 --> URI Class Initialized
INFO - 2018-04-02 05:30:41 --> Router Class Initialized
INFO - 2018-04-02 05:30:41 --> Output Class Initialized
INFO - 2018-04-02 05:30:41 --> Security Class Initialized
DEBUG - 2018-04-02 05:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:30:41 --> Input Class Initialized
INFO - 2018-04-02 05:30:41 --> Language Class Initialized
INFO - 2018-04-02 05:30:41 --> Loader Class Initialized
INFO - 2018-04-02 05:30:41 --> Helper loaded: url_helper
INFO - 2018-04-02 05:30:41 --> Helper loaded: file_helper
INFO - 2018-04-02 05:30:41 --> Helper loaded: date_helper
INFO - 2018-04-02 05:30:41 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:30:41 --> Controller Class Initialized
INFO - 2018-04-02 05:30:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:30:41 --> Final output sent to browser
DEBUG - 2018-04-02 05:30:41 --> Total execution time: 0.3694
INFO - 2018-04-02 05:30:45 --> Config Class Initialized
INFO - 2018-04-02 05:30:45 --> Config Class Initialized
INFO - 2018-04-02 05:30:45 --> Hooks Class Initialized
INFO - 2018-04-02 05:30:45 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:30:45 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 05:30:45 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:30:45 --> Utf8 Class Initialized
INFO - 2018-04-02 05:30:45 --> Utf8 Class Initialized
INFO - 2018-04-02 05:30:46 --> URI Class Initialized
INFO - 2018-04-02 05:30:46 --> URI Class Initialized
INFO - 2018-04-02 05:30:46 --> Router Class Initialized
INFO - 2018-04-02 05:30:46 --> Router Class Initialized
INFO - 2018-04-02 05:30:46 --> Output Class Initialized
INFO - 2018-04-02 05:30:46 --> Output Class Initialized
INFO - 2018-04-02 05:30:46 --> Security Class Initialized
INFO - 2018-04-02 05:30:46 --> Security Class Initialized
DEBUG - 2018-04-02 05:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 05:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:30:46 --> Input Class Initialized
INFO - 2018-04-02 05:30:46 --> Input Class Initialized
INFO - 2018-04-02 05:30:46 --> Language Class Initialized
INFO - 2018-04-02 05:30:46 --> Language Class Initialized
INFO - 2018-04-02 05:30:46 --> Loader Class Initialized
INFO - 2018-04-02 05:30:46 --> Loader Class Initialized
INFO - 2018-04-02 05:30:46 --> Helper loaded: url_helper
INFO - 2018-04-02 05:30:46 --> Helper loaded: url_helper
INFO - 2018-04-02 05:30:46 --> Helper loaded: file_helper
INFO - 2018-04-02 05:30:46 --> Helper loaded: file_helper
INFO - 2018-04-02 05:30:46 --> Helper loaded: date_helper
INFO - 2018-04-02 05:30:46 --> Helper loaded: date_helper
INFO - 2018-04-02 05:30:46 --> Database Driver Class Initialized
INFO - 2018-04-02 05:30:46 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-04-02 05:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:30:46 --> Controller Class Initialized
INFO - 2018-04-02 05:30:46 --> Model Class Initialized
ERROR - 2018-04-02 05:30:47 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `user` (`name`, `email`, `phone`, `user_name`, `dob`, `weight`, `blood_group`, `country`, `gender`) VALUES ('redoy', 'redoy@gmail.com', '01776836632', 'redoy', '2018-04-14', '45', 'A-', 'Bangladesh', 'Female')
INFO - 2018-04-02 05:30:47 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-02 05:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:30:47 --> Controller Class Initialized
INFO - 2018-04-02 05:30:47 --> Model Class Initialized
ERROR - 2018-04-02 05:30:47 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `user` (`name`, `email`, `phone`, `user_name`, `dob`, `weight`, `blood_group`, `country`, `gender`) VALUES ('redoy', 'redoy@gmail.com', '01776836632', 'redoy', '2018-04-14', '45', 'A-', 'Bangladesh', 'Female')
INFO - 2018-04-02 05:30:47 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-02 05:41:37 --> Config Class Initialized
INFO - 2018-04-02 05:41:37 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:41:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:41:37 --> Utf8 Class Initialized
INFO - 2018-04-02 05:41:37 --> URI Class Initialized
INFO - 2018-04-02 05:41:37 --> Router Class Initialized
INFO - 2018-04-02 05:41:37 --> Output Class Initialized
INFO - 2018-04-02 05:41:37 --> Security Class Initialized
DEBUG - 2018-04-02 05:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:41:37 --> Input Class Initialized
INFO - 2018-04-02 05:41:37 --> Language Class Initialized
INFO - 2018-04-02 05:41:37 --> Loader Class Initialized
INFO - 2018-04-02 05:41:37 --> Helper loaded: url_helper
INFO - 2018-04-02 05:41:37 --> Helper loaded: file_helper
INFO - 2018-04-02 05:41:37 --> Helper loaded: date_helper
INFO - 2018-04-02 05:41:37 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:41:37 --> Controller Class Initialized
INFO - 2018-04-02 05:41:37 --> Final output sent to browser
DEBUG - 2018-04-02 05:41:37 --> Total execution time: 0.3467
INFO - 2018-04-02 05:41:43 --> Config Class Initialized
INFO - 2018-04-02 05:41:43 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:41:43 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:41:43 --> Utf8 Class Initialized
INFO - 2018-04-02 05:41:43 --> URI Class Initialized
INFO - 2018-04-02 05:41:43 --> Router Class Initialized
INFO - 2018-04-02 05:41:43 --> Output Class Initialized
INFO - 2018-04-02 05:41:43 --> Security Class Initialized
DEBUG - 2018-04-02 05:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:41:43 --> Input Class Initialized
INFO - 2018-04-02 05:41:43 --> Language Class Initialized
INFO - 2018-04-02 05:41:43 --> Loader Class Initialized
INFO - 2018-04-02 05:41:43 --> Helper loaded: url_helper
INFO - 2018-04-02 05:41:43 --> Helper loaded: file_helper
INFO - 2018-04-02 05:41:43 --> Helper loaded: date_helper
INFO - 2018-04-02 05:41:44 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:41:44 --> Controller Class Initialized
INFO - 2018-04-02 05:41:44 --> Final output sent to browser
DEBUG - 2018-04-02 05:41:44 --> Total execution time: 0.2735
INFO - 2018-04-02 05:41:45 --> Config Class Initialized
INFO - 2018-04-02 05:41:45 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:41:45 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:41:45 --> Utf8 Class Initialized
INFO - 2018-04-02 05:41:45 --> URI Class Initialized
INFO - 2018-04-02 05:41:45 --> Router Class Initialized
INFO - 2018-04-02 05:41:45 --> Output Class Initialized
INFO - 2018-04-02 05:41:46 --> Security Class Initialized
DEBUG - 2018-04-02 05:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:41:46 --> Input Class Initialized
INFO - 2018-04-02 05:41:46 --> Language Class Initialized
INFO - 2018-04-02 05:41:46 --> Loader Class Initialized
INFO - 2018-04-02 05:41:46 --> Helper loaded: url_helper
INFO - 2018-04-02 05:41:46 --> Helper loaded: file_helper
INFO - 2018-04-02 05:41:46 --> Helper loaded: date_helper
INFO - 2018-04-02 05:41:46 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:41:46 --> Controller Class Initialized
INFO - 2018-04-02 05:41:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:41:46 --> Final output sent to browser
DEBUG - 2018-04-02 05:41:46 --> Total execution time: 0.3700
INFO - 2018-04-02 05:41:48 --> Config Class Initialized
INFO - 2018-04-02 05:41:48 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:41:48 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:41:48 --> Utf8 Class Initialized
INFO - 2018-04-02 05:41:48 --> URI Class Initialized
INFO - 2018-04-02 05:41:48 --> Router Class Initialized
INFO - 2018-04-02 05:41:48 --> Output Class Initialized
INFO - 2018-04-02 05:41:48 --> Security Class Initialized
DEBUG - 2018-04-02 05:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:41:48 --> Input Class Initialized
INFO - 2018-04-02 05:41:48 --> Language Class Initialized
INFO - 2018-04-02 05:41:48 --> Loader Class Initialized
INFO - 2018-04-02 05:41:48 --> Helper loaded: url_helper
INFO - 2018-04-02 05:41:48 --> Helper loaded: file_helper
INFO - 2018-04-02 05:41:48 --> Helper loaded: date_helper
INFO - 2018-04-02 05:41:48 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:41:48 --> Controller Class Initialized
INFO - 2018-04-02 05:41:48 --> Model Class Initialized
INFO - 2018-04-02 05:41:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 05:41:49 --> Final output sent to browser
DEBUG - 2018-04-02 05:41:49 --> Total execution time: 0.5070
INFO - 2018-04-02 05:42:11 --> Config Class Initialized
INFO - 2018-04-02 05:42:11 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:42:11 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:42:11 --> Utf8 Class Initialized
INFO - 2018-04-02 05:42:11 --> URI Class Initialized
INFO - 2018-04-02 05:42:11 --> Router Class Initialized
INFO - 2018-04-02 05:42:11 --> Output Class Initialized
INFO - 2018-04-02 05:42:11 --> Security Class Initialized
DEBUG - 2018-04-02 05:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:42:11 --> Input Class Initialized
INFO - 2018-04-02 05:42:11 --> Language Class Initialized
INFO - 2018-04-02 05:42:11 --> Loader Class Initialized
INFO - 2018-04-02 05:42:11 --> Helper loaded: url_helper
INFO - 2018-04-02 05:42:11 --> Helper loaded: file_helper
INFO - 2018-04-02 05:42:11 --> Helper loaded: date_helper
INFO - 2018-04-02 05:42:11 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:42:12 --> Controller Class Initialized
INFO - 2018-04-02 05:42:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:42:12 --> Final output sent to browser
DEBUG - 2018-04-02 05:42:12 --> Total execution time: 0.2925
INFO - 2018-04-02 05:42:52 --> Config Class Initialized
INFO - 2018-04-02 05:42:52 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:42:52 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:42:52 --> Utf8 Class Initialized
INFO - 2018-04-02 05:42:52 --> URI Class Initialized
INFO - 2018-04-02 05:42:52 --> Router Class Initialized
INFO - 2018-04-02 05:42:52 --> Output Class Initialized
INFO - 2018-04-02 05:42:52 --> Security Class Initialized
DEBUG - 2018-04-02 05:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:42:52 --> Input Class Initialized
INFO - 2018-04-02 05:42:52 --> Language Class Initialized
INFO - 2018-04-02 05:42:52 --> Loader Class Initialized
INFO - 2018-04-02 05:42:52 --> Helper loaded: url_helper
INFO - 2018-04-02 05:42:52 --> Helper loaded: file_helper
INFO - 2018-04-02 05:42:52 --> Helper loaded: date_helper
INFO - 2018-04-02 05:42:52 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:42:52 --> Controller Class Initialized
INFO - 2018-04-02 05:42:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:42:52 --> Final output sent to browser
DEBUG - 2018-04-02 05:42:52 --> Total execution time: 0.3767
INFO - 2018-04-02 05:43:19 --> Config Class Initialized
INFO - 2018-04-02 05:43:19 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:43:19 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:43:19 --> Utf8 Class Initialized
INFO - 2018-04-02 05:43:19 --> URI Class Initialized
INFO - 2018-04-02 05:43:19 --> Router Class Initialized
INFO - 2018-04-02 05:43:19 --> Output Class Initialized
INFO - 2018-04-02 05:43:19 --> Security Class Initialized
DEBUG - 2018-04-02 05:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:43:19 --> Input Class Initialized
INFO - 2018-04-02 05:43:19 --> Language Class Initialized
INFO - 2018-04-02 05:43:19 --> Loader Class Initialized
INFO - 2018-04-02 05:43:19 --> Helper loaded: url_helper
INFO - 2018-04-02 05:43:19 --> Helper loaded: file_helper
INFO - 2018-04-02 05:43:19 --> Helper loaded: date_helper
INFO - 2018-04-02 05:43:19 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:43:19 --> Controller Class Initialized
INFO - 2018-04-02 05:43:19 --> Model Class Initialized
INFO - 2018-04-02 05:43:49 --> Config Class Initialized
INFO - 2018-04-02 05:43:49 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:43:49 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:43:49 --> Utf8 Class Initialized
INFO - 2018-04-02 05:43:49 --> URI Class Initialized
INFO - 2018-04-02 05:43:49 --> Router Class Initialized
INFO - 2018-04-02 05:43:49 --> Output Class Initialized
INFO - 2018-04-02 05:43:49 --> Security Class Initialized
DEBUG - 2018-04-02 05:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:43:49 --> Input Class Initialized
INFO - 2018-04-02 05:43:49 --> Language Class Initialized
INFO - 2018-04-02 05:43:49 --> Loader Class Initialized
INFO - 2018-04-02 05:43:49 --> Helper loaded: url_helper
INFO - 2018-04-02 05:43:49 --> Helper loaded: file_helper
INFO - 2018-04-02 05:43:49 --> Helper loaded: date_helper
INFO - 2018-04-02 05:43:49 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:43:49 --> Controller Class Initialized
INFO - 2018-04-02 05:43:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:43:49 --> Final output sent to browser
DEBUG - 2018-04-02 05:43:49 --> Total execution time: 0.3031
INFO - 2018-04-02 05:43:52 --> Config Class Initialized
INFO - 2018-04-02 05:43:52 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:43:52 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:43:52 --> Utf8 Class Initialized
INFO - 2018-04-02 05:43:52 --> URI Class Initialized
INFO - 2018-04-02 05:43:52 --> Router Class Initialized
INFO - 2018-04-02 05:43:52 --> Output Class Initialized
INFO - 2018-04-02 05:43:52 --> Security Class Initialized
DEBUG - 2018-04-02 05:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:43:52 --> Input Class Initialized
INFO - 2018-04-02 05:43:52 --> Language Class Initialized
INFO - 2018-04-02 05:43:52 --> Loader Class Initialized
INFO - 2018-04-02 05:43:52 --> Helper loaded: url_helper
INFO - 2018-04-02 05:43:52 --> Helper loaded: file_helper
INFO - 2018-04-02 05:43:53 --> Helper loaded: date_helper
INFO - 2018-04-02 05:43:53 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:43:53 --> Controller Class Initialized
INFO - 2018-04-02 05:43:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:43:53 --> Final output sent to browser
DEBUG - 2018-04-02 05:43:53 --> Total execution time: 0.3443
INFO - 2018-04-02 05:44:02 --> Config Class Initialized
INFO - 2018-04-02 05:44:02 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:44:02 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:44:02 --> Utf8 Class Initialized
INFO - 2018-04-02 05:44:02 --> URI Class Initialized
INFO - 2018-04-02 05:44:02 --> Router Class Initialized
INFO - 2018-04-02 05:44:02 --> Output Class Initialized
INFO - 2018-04-02 05:44:02 --> Security Class Initialized
DEBUG - 2018-04-02 05:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:44:02 --> Input Class Initialized
INFO - 2018-04-02 05:44:02 --> Language Class Initialized
INFO - 2018-04-02 05:44:02 --> Loader Class Initialized
INFO - 2018-04-02 05:44:02 --> Helper loaded: url_helper
INFO - 2018-04-02 05:44:02 --> Helper loaded: file_helper
INFO - 2018-04-02 05:44:02 --> Helper loaded: date_helper
INFO - 2018-04-02 05:44:02 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:44:02 --> Controller Class Initialized
INFO - 2018-04-02 05:44:02 --> Final output sent to browser
DEBUG - 2018-04-02 05:44:02 --> Total execution time: 0.2928
INFO - 2018-04-02 05:44:03 --> Config Class Initialized
INFO - 2018-04-02 05:44:03 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:44:03 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:44:03 --> Utf8 Class Initialized
INFO - 2018-04-02 05:44:03 --> URI Class Initialized
INFO - 2018-04-02 05:44:03 --> Router Class Initialized
INFO - 2018-04-02 05:44:03 --> Output Class Initialized
INFO - 2018-04-02 05:44:03 --> Security Class Initialized
DEBUG - 2018-04-02 05:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:44:03 --> Input Class Initialized
INFO - 2018-04-02 05:44:03 --> Language Class Initialized
INFO - 2018-04-02 05:44:03 --> Loader Class Initialized
INFO - 2018-04-02 05:44:03 --> Helper loaded: url_helper
INFO - 2018-04-02 05:44:03 --> Helper loaded: file_helper
INFO - 2018-04-02 05:44:03 --> Helper loaded: date_helper
INFO - 2018-04-02 05:44:03 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:44:03 --> Controller Class Initialized
INFO - 2018-04-02 05:44:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:44:03 --> Final output sent to browser
DEBUG - 2018-04-02 05:44:03 --> Total execution time: 0.3305
INFO - 2018-04-02 05:44:06 --> Config Class Initialized
INFO - 2018-04-02 05:44:06 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:44:06 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:44:06 --> Utf8 Class Initialized
INFO - 2018-04-02 05:44:06 --> URI Class Initialized
INFO - 2018-04-02 05:44:06 --> Router Class Initialized
INFO - 2018-04-02 05:44:06 --> Output Class Initialized
INFO - 2018-04-02 05:44:06 --> Security Class Initialized
DEBUG - 2018-04-02 05:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:44:06 --> Input Class Initialized
INFO - 2018-04-02 05:44:06 --> Language Class Initialized
INFO - 2018-04-02 05:44:06 --> Loader Class Initialized
INFO - 2018-04-02 05:44:06 --> Helper loaded: url_helper
INFO - 2018-04-02 05:44:06 --> Helper loaded: file_helper
INFO - 2018-04-02 05:44:06 --> Helper loaded: date_helper
INFO - 2018-04-02 05:44:06 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:44:06 --> Controller Class Initialized
INFO - 2018-04-02 05:44:06 --> Model Class Initialized
INFO - 2018-04-02 05:44:32 --> Config Class Initialized
INFO - 2018-04-02 05:44:32 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:44:32 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:44:32 --> Utf8 Class Initialized
INFO - 2018-04-02 05:44:32 --> URI Class Initialized
INFO - 2018-04-02 05:44:32 --> Router Class Initialized
INFO - 2018-04-02 05:44:33 --> Output Class Initialized
INFO - 2018-04-02 05:44:33 --> Security Class Initialized
DEBUG - 2018-04-02 05:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:44:33 --> Input Class Initialized
INFO - 2018-04-02 05:44:33 --> Language Class Initialized
INFO - 2018-04-02 05:44:33 --> Loader Class Initialized
INFO - 2018-04-02 05:44:33 --> Helper loaded: url_helper
INFO - 2018-04-02 05:44:33 --> Helper loaded: file_helper
INFO - 2018-04-02 05:44:33 --> Helper loaded: date_helper
INFO - 2018-04-02 05:44:33 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:44:33 --> Controller Class Initialized
INFO - 2018-04-02 05:44:33 --> Model Class Initialized
INFO - 2018-04-02 05:44:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 05:44:33 --> Final output sent to browser
DEBUG - 2018-04-02 05:44:33 --> Total execution time: 0.4421
INFO - 2018-04-02 05:44:56 --> Config Class Initialized
INFO - 2018-04-02 05:44:56 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:44:56 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:44:56 --> Utf8 Class Initialized
INFO - 2018-04-02 05:44:56 --> URI Class Initialized
INFO - 2018-04-02 05:44:56 --> Router Class Initialized
INFO - 2018-04-02 05:44:56 --> Output Class Initialized
INFO - 2018-04-02 05:44:56 --> Security Class Initialized
DEBUG - 2018-04-02 05:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:44:56 --> Input Class Initialized
INFO - 2018-04-02 05:44:56 --> Language Class Initialized
INFO - 2018-04-02 05:44:57 --> Loader Class Initialized
INFO - 2018-04-02 05:44:57 --> Helper loaded: url_helper
INFO - 2018-04-02 05:44:57 --> Helper loaded: file_helper
INFO - 2018-04-02 05:44:57 --> Helper loaded: date_helper
INFO - 2018-04-02 05:44:57 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:44:57 --> Controller Class Initialized
INFO - 2018-04-02 05:44:57 --> Model Class Initialized
ERROR - 2018-04-02 05:44:57 --> Severity: Notice --> Undefined property: stdClass::$user_name G:\xampp\htdocs\codeigniter\application\controllers\Auth_Controller.php 50
INFO - 2018-04-02 05:44:57 --> Final output sent to browser
DEBUG - 2018-04-02 05:44:57 --> Total execution time: 0.4632
INFO - 2018-04-02 05:44:57 --> Config Class Initialized
INFO - 2018-04-02 05:44:57 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:44:57 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:44:57 --> Utf8 Class Initialized
INFO - 2018-04-02 05:44:57 --> URI Class Initialized
INFO - 2018-04-02 05:44:57 --> Router Class Initialized
INFO - 2018-04-02 05:44:57 --> Output Class Initialized
INFO - 2018-04-02 05:44:57 --> Security Class Initialized
DEBUG - 2018-04-02 05:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:44:57 --> Input Class Initialized
INFO - 2018-04-02 05:44:57 --> Language Class Initialized
INFO - 2018-04-02 05:44:57 --> Loader Class Initialized
INFO - 2018-04-02 05:44:57 --> Helper loaded: url_helper
INFO - 2018-04-02 05:44:57 --> Helper loaded: file_helper
INFO - 2018-04-02 05:44:57 --> Helper loaded: date_helper
INFO - 2018-04-02 05:44:57 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:44:57 --> Controller Class Initialized
INFO - 2018-04-02 05:44:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 05:44:58 --> Final output sent to browser
DEBUG - 2018-04-02 05:44:58 --> Total execution time: 0.7226
INFO - 2018-04-02 05:55:29 --> Config Class Initialized
INFO - 2018-04-02 05:55:29 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:55:29 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:55:29 --> Utf8 Class Initialized
INFO - 2018-04-02 05:55:29 --> URI Class Initialized
INFO - 2018-04-02 05:55:29 --> Router Class Initialized
INFO - 2018-04-02 05:55:29 --> Output Class Initialized
INFO - 2018-04-02 05:55:29 --> Security Class Initialized
DEBUG - 2018-04-02 05:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:55:29 --> Input Class Initialized
INFO - 2018-04-02 05:55:29 --> Language Class Initialized
INFO - 2018-04-02 05:55:29 --> Loader Class Initialized
INFO - 2018-04-02 05:55:29 --> Helper loaded: url_helper
INFO - 2018-04-02 05:55:29 --> Helper loaded: file_helper
INFO - 2018-04-02 05:55:29 --> Helper loaded: date_helper
INFO - 2018-04-02 05:55:29 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:55:29 --> Controller Class Initialized
INFO - 2018-04-02 05:55:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 05:55:29 --> Final output sent to browser
DEBUG - 2018-04-02 05:55:29 --> Total execution time: 0.3448
INFO - 2018-04-02 05:55:33 --> Config Class Initialized
INFO - 2018-04-02 05:55:33 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:55:33 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:55:33 --> Utf8 Class Initialized
INFO - 2018-04-02 05:55:33 --> URI Class Initialized
INFO - 2018-04-02 05:55:33 --> Router Class Initialized
INFO - 2018-04-02 05:55:33 --> Output Class Initialized
INFO - 2018-04-02 05:55:33 --> Security Class Initialized
DEBUG - 2018-04-02 05:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:55:33 --> Input Class Initialized
INFO - 2018-04-02 05:55:33 --> Language Class Initialized
INFO - 2018-04-02 05:55:33 --> Loader Class Initialized
INFO - 2018-04-02 05:55:33 --> Helper loaded: url_helper
INFO - 2018-04-02 05:55:33 --> Helper loaded: file_helper
INFO - 2018-04-02 05:55:33 --> Helper loaded: date_helper
INFO - 2018-04-02 05:55:33 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:55:33 --> Controller Class Initialized
INFO - 2018-04-02 05:55:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 05:55:34 --> Final output sent to browser
DEBUG - 2018-04-02 05:55:34 --> Total execution time: 0.3035
INFO - 2018-04-02 05:55:36 --> Config Class Initialized
INFO - 2018-04-02 05:55:36 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:55:36 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:55:36 --> Utf8 Class Initialized
INFO - 2018-04-02 05:55:36 --> URI Class Initialized
INFO - 2018-04-02 05:55:37 --> Router Class Initialized
INFO - 2018-04-02 05:55:37 --> Output Class Initialized
INFO - 2018-04-02 05:55:37 --> Security Class Initialized
DEBUG - 2018-04-02 05:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:55:37 --> Input Class Initialized
INFO - 2018-04-02 05:55:37 --> Language Class Initialized
INFO - 2018-04-02 05:55:37 --> Loader Class Initialized
INFO - 2018-04-02 05:55:37 --> Helper loaded: url_helper
INFO - 2018-04-02 05:55:37 --> Helper loaded: file_helper
INFO - 2018-04-02 05:55:37 --> Helper loaded: date_helper
INFO - 2018-04-02 05:55:37 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:55:37 --> Controller Class Initialized
INFO - 2018-04-02 05:55:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 05:55:37 --> Final output sent to browser
DEBUG - 2018-04-02 05:55:37 --> Total execution time: 0.3258
INFO - 2018-04-02 05:55:50 --> Config Class Initialized
INFO - 2018-04-02 05:55:50 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:55:50 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:55:50 --> Utf8 Class Initialized
INFO - 2018-04-02 05:55:50 --> URI Class Initialized
INFO - 2018-04-02 05:55:50 --> Router Class Initialized
INFO - 2018-04-02 05:55:50 --> Output Class Initialized
INFO - 2018-04-02 05:55:50 --> Security Class Initialized
DEBUG - 2018-04-02 05:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:55:50 --> Input Class Initialized
INFO - 2018-04-02 05:55:50 --> Language Class Initialized
INFO - 2018-04-02 05:55:50 --> Loader Class Initialized
INFO - 2018-04-02 05:55:50 --> Helper loaded: url_helper
INFO - 2018-04-02 05:55:50 --> Helper loaded: file_helper
INFO - 2018-04-02 05:55:50 --> Helper loaded: date_helper
INFO - 2018-04-02 05:55:50 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:55:50 --> Controller Class Initialized
INFO - 2018-04-02 05:55:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-02 05:55:50 --> Final output sent to browser
DEBUG - 2018-04-02 05:55:50 --> Total execution time: 0.3680
INFO - 2018-04-02 05:55:50 --> Config Class Initialized
INFO - 2018-04-02 05:55:50 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:55:50 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:55:50 --> Utf8 Class Initialized
INFO - 2018-04-02 05:55:50 --> URI Class Initialized
INFO - 2018-04-02 05:55:50 --> Router Class Initialized
INFO - 2018-04-02 05:55:50 --> Output Class Initialized
INFO - 2018-04-02 05:55:50 --> Security Class Initialized
DEBUG - 2018-04-02 05:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:55:51 --> Input Class Initialized
INFO - 2018-04-02 05:55:51 --> Language Class Initialized
ERROR - 2018-04-02 05:55:51 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-02 05:55:51 --> Config Class Initialized
INFO - 2018-04-02 05:55:51 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:55:51 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:55:51 --> Utf8 Class Initialized
INFO - 2018-04-02 05:55:51 --> URI Class Initialized
INFO - 2018-04-02 05:55:51 --> Router Class Initialized
INFO - 2018-04-02 05:55:51 --> Output Class Initialized
INFO - 2018-04-02 05:55:51 --> Security Class Initialized
DEBUG - 2018-04-02 05:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:55:51 --> Input Class Initialized
INFO - 2018-04-02 05:55:51 --> Language Class Initialized
ERROR - 2018-04-02 05:55:51 --> 404 Page Not Found: Downloadpng/index
INFO - 2018-04-02 05:56:54 --> Config Class Initialized
INFO - 2018-04-02 05:56:54 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:56:54 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:56:54 --> Utf8 Class Initialized
INFO - 2018-04-02 05:56:54 --> URI Class Initialized
INFO - 2018-04-02 05:56:54 --> Router Class Initialized
INFO - 2018-04-02 05:56:54 --> Output Class Initialized
INFO - 2018-04-02 05:56:54 --> Security Class Initialized
DEBUG - 2018-04-02 05:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:56:54 --> Input Class Initialized
INFO - 2018-04-02 05:56:54 --> Language Class Initialized
INFO - 2018-04-02 05:56:54 --> Loader Class Initialized
INFO - 2018-04-02 05:56:54 --> Helper loaded: url_helper
INFO - 2018-04-02 05:56:54 --> Helper loaded: file_helper
INFO - 2018-04-02 05:56:54 --> Helper loaded: date_helper
INFO - 2018-04-02 05:56:54 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:56:54 --> Controller Class Initialized
INFO - 2018-04-02 05:56:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:56:54 --> Final output sent to browser
DEBUG - 2018-04-02 05:56:54 --> Total execution time: 0.3551
INFO - 2018-04-02 05:56:59 --> Config Class Initialized
INFO - 2018-04-02 05:56:59 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:56:59 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:56:59 --> Utf8 Class Initialized
INFO - 2018-04-02 05:56:59 --> URI Class Initialized
INFO - 2018-04-02 05:56:59 --> Router Class Initialized
INFO - 2018-04-02 05:56:59 --> Output Class Initialized
INFO - 2018-04-02 05:56:59 --> Security Class Initialized
DEBUG - 2018-04-02 05:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:56:59 --> Input Class Initialized
INFO - 2018-04-02 05:56:59 --> Language Class Initialized
INFO - 2018-04-02 05:56:59 --> Loader Class Initialized
INFO - 2018-04-02 05:56:59 --> Helper loaded: url_helper
INFO - 2018-04-02 05:56:59 --> Helper loaded: file_helper
INFO - 2018-04-02 05:56:59 --> Helper loaded: date_helper
INFO - 2018-04-02 05:56:59 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:56:59 --> Controller Class Initialized
INFO - 2018-04-02 05:56:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 05:57:00 --> Final output sent to browser
DEBUG - 2018-04-02 05:57:00 --> Total execution time: 0.3686
INFO - 2018-04-02 05:57:01 --> Config Class Initialized
INFO - 2018-04-02 05:57:01 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:57:01 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:57:01 --> Utf8 Class Initialized
INFO - 2018-04-02 05:57:01 --> URI Class Initialized
INFO - 2018-04-02 05:57:01 --> Router Class Initialized
INFO - 2018-04-02 05:57:01 --> Output Class Initialized
INFO - 2018-04-02 05:57:01 --> Security Class Initialized
DEBUG - 2018-04-02 05:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:57:01 --> Input Class Initialized
INFO - 2018-04-02 05:57:01 --> Language Class Initialized
INFO - 2018-04-02 05:57:01 --> Loader Class Initialized
INFO - 2018-04-02 05:57:01 --> Helper loaded: url_helper
INFO - 2018-04-02 05:57:01 --> Helper loaded: file_helper
INFO - 2018-04-02 05:57:01 --> Helper loaded: date_helper
INFO - 2018-04-02 05:57:01 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:57:01 --> Controller Class Initialized
INFO - 2018-04-02 05:57:01 --> Model Class Initialized
ERROR - 2018-04-02 05:57:01 --> Query error: Column 'gender' cannot be null - Invalid query: INSERT INTO `user` (`user_type`, `name`, `email`, `gender`, `blood_group`, `phone`, `dob`, `weight`, `country`) VALUES (2, 'ogin', '', NULL, 'select group', '', '', '', 'select')
INFO - 2018-04-02 05:57:01 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-02 05:57:05 --> Config Class Initialized
INFO - 2018-04-02 05:57:05 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:57:05 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:57:05 --> Utf8 Class Initialized
INFO - 2018-04-02 05:57:05 --> URI Class Initialized
DEBUG - 2018-04-02 05:57:05 --> No URI present. Default controller set.
INFO - 2018-04-02 05:57:05 --> Router Class Initialized
INFO - 2018-04-02 05:57:05 --> Output Class Initialized
INFO - 2018-04-02 05:57:05 --> Security Class Initialized
DEBUG - 2018-04-02 05:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:57:05 --> Input Class Initialized
INFO - 2018-04-02 05:57:05 --> Language Class Initialized
INFO - 2018-04-02 05:57:05 --> Loader Class Initialized
INFO - 2018-04-02 05:57:05 --> Helper loaded: url_helper
INFO - 2018-04-02 05:57:05 --> Helper loaded: file_helper
INFO - 2018-04-02 05:57:05 --> Helper loaded: date_helper
INFO - 2018-04-02 05:57:05 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:57:05 --> Controller Class Initialized
INFO - 2018-04-02 05:57:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-02 05:57:05 --> Final output sent to browser
DEBUG - 2018-04-02 05:57:05 --> Total execution time: 0.5421
INFO - 2018-04-02 05:57:05 --> Config Class Initialized
INFO - 2018-04-02 05:57:05 --> Config Class Initialized
INFO - 2018-04-02 05:57:05 --> Hooks Class Initialized
INFO - 2018-04-02 05:57:05 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:57:05 --> UTF-8 Support Enabled
DEBUG - 2018-04-02 05:57:05 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:57:05 --> Utf8 Class Initialized
INFO - 2018-04-02 05:57:05 --> Utf8 Class Initialized
INFO - 2018-04-02 05:57:05 --> URI Class Initialized
INFO - 2018-04-02 05:57:05 --> URI Class Initialized
INFO - 2018-04-02 05:57:05 --> Router Class Initialized
INFO - 2018-04-02 05:57:05 --> Router Class Initialized
INFO - 2018-04-02 05:57:05 --> Output Class Initialized
INFO - 2018-04-02 05:57:05 --> Output Class Initialized
INFO - 2018-04-02 05:57:05 --> Security Class Initialized
INFO - 2018-04-02 05:57:05 --> Security Class Initialized
DEBUG - 2018-04-02 05:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-02 05:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:57:05 --> Input Class Initialized
INFO - 2018-04-02 05:57:05 --> Input Class Initialized
INFO - 2018-04-02 05:57:06 --> Language Class Initialized
INFO - 2018-04-02 05:57:06 --> Language Class Initialized
ERROR - 2018-04-02 05:57:06 --> 404 Page Not Found: Css/bootstrap.min.css
ERROR - 2018-04-02 05:57:06 --> 404 Page Not Found: Downloadpng/index
INFO - 2018-04-02 05:57:09 --> Config Class Initialized
INFO - 2018-04-02 05:57:09 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:57:09 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:57:09 --> Utf8 Class Initialized
INFO - 2018-04-02 05:57:09 --> URI Class Initialized
INFO - 2018-04-02 05:57:09 --> Router Class Initialized
INFO - 2018-04-02 05:57:09 --> Output Class Initialized
INFO - 2018-04-02 05:57:09 --> Security Class Initialized
DEBUG - 2018-04-02 05:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:57:09 --> Input Class Initialized
INFO - 2018-04-02 05:57:09 --> Language Class Initialized
ERROR - 2018-04-02 05:57:09 --> 404 Page Not Found: Edithtml/index
INFO - 2018-04-02 05:57:11 --> Config Class Initialized
INFO - 2018-04-02 05:57:11 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:57:11 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:57:11 --> Utf8 Class Initialized
INFO - 2018-04-02 05:57:11 --> URI Class Initialized
DEBUG - 2018-04-02 05:57:11 --> No URI present. Default controller set.
INFO - 2018-04-02 05:57:11 --> Router Class Initialized
INFO - 2018-04-02 05:57:11 --> Output Class Initialized
INFO - 2018-04-02 05:57:11 --> Security Class Initialized
DEBUG - 2018-04-02 05:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:57:11 --> Input Class Initialized
INFO - 2018-04-02 05:57:11 --> Language Class Initialized
INFO - 2018-04-02 05:57:11 --> Loader Class Initialized
INFO - 2018-04-02 05:57:11 --> Helper loaded: url_helper
INFO - 2018-04-02 05:57:11 --> Helper loaded: file_helper
INFO - 2018-04-02 05:57:11 --> Helper loaded: date_helper
INFO - 2018-04-02 05:57:11 --> Database Driver Class Initialized
DEBUG - 2018-04-02 05:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 05:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 05:57:11 --> Controller Class Initialized
INFO - 2018-04-02 05:57:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-02 05:57:11 --> Final output sent to browser
DEBUG - 2018-04-02 05:57:11 --> Total execution time: 0.4099
INFO - 2018-04-02 05:57:11 --> Config Class Initialized
INFO - 2018-04-02 05:57:11 --> Hooks Class Initialized
DEBUG - 2018-04-02 05:57:11 --> UTF-8 Support Enabled
INFO - 2018-04-02 05:57:11 --> Utf8 Class Initialized
INFO - 2018-04-02 05:57:11 --> URI Class Initialized
INFO - 2018-04-02 05:57:11 --> Router Class Initialized
INFO - 2018-04-02 05:57:11 --> Output Class Initialized
INFO - 2018-04-02 05:57:11 --> Security Class Initialized
DEBUG - 2018-04-02 05:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 05:57:11 --> Input Class Initialized
INFO - 2018-04-02 05:57:11 --> Language Class Initialized
ERROR - 2018-04-02 05:57:11 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-02 20:31:40 --> Config Class Initialized
INFO - 2018-04-02 20:31:41 --> Hooks Class Initialized
DEBUG - 2018-04-02 20:31:41 --> UTF-8 Support Enabled
INFO - 2018-04-02 20:31:41 --> Utf8 Class Initialized
INFO - 2018-04-02 20:31:41 --> URI Class Initialized
DEBUG - 2018-04-02 20:31:41 --> No URI present. Default controller set.
INFO - 2018-04-02 20:31:41 --> Router Class Initialized
INFO - 2018-04-02 20:31:41 --> Output Class Initialized
INFO - 2018-04-02 20:31:41 --> Security Class Initialized
DEBUG - 2018-04-02 20:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 20:31:41 --> Input Class Initialized
INFO - 2018-04-02 20:31:41 --> Language Class Initialized
INFO - 2018-04-02 20:31:41 --> Loader Class Initialized
INFO - 2018-04-02 20:31:42 --> Helper loaded: url_helper
INFO - 2018-04-02 20:31:42 --> Helper loaded: file_helper
INFO - 2018-04-02 20:31:42 --> Helper loaded: date_helper
INFO - 2018-04-02 20:31:42 --> Database Driver Class Initialized
DEBUG - 2018-04-02 20:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 20:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 20:31:43 --> Controller Class Initialized
INFO - 2018-04-02 20:31:43 --> Config Class Initialized
INFO - 2018-04-02 20:31:43 --> Hooks Class Initialized
DEBUG - 2018-04-02 20:31:43 --> UTF-8 Support Enabled
INFO - 2018-04-02 20:31:43 --> Utf8 Class Initialized
INFO - 2018-04-02 20:31:43 --> URI Class Initialized
INFO - 2018-04-02 20:31:43 --> Router Class Initialized
INFO - 2018-04-02 20:31:43 --> Output Class Initialized
INFO - 2018-04-02 20:31:43 --> Security Class Initialized
DEBUG - 2018-04-02 20:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 20:31:43 --> Input Class Initialized
INFO - 2018-04-02 20:31:43 --> Language Class Initialized
INFO - 2018-04-02 20:31:43 --> Loader Class Initialized
INFO - 2018-04-02 20:31:43 --> Helper loaded: url_helper
INFO - 2018-04-02 20:31:43 --> Helper loaded: file_helper
INFO - 2018-04-02 20:31:43 --> Helper loaded: date_helper
INFO - 2018-04-02 20:31:43 --> Database Driver Class Initialized
DEBUG - 2018-04-02 20:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 20:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 20:31:43 --> Controller Class Initialized
INFO - 2018-04-02 20:31:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 20:31:43 --> Final output sent to browser
DEBUG - 2018-04-02 20:31:43 --> Total execution time: 0.5812
INFO - 2018-04-02 20:32:14 --> Config Class Initialized
INFO - 2018-04-02 20:32:14 --> Hooks Class Initialized
DEBUG - 2018-04-02 20:32:14 --> UTF-8 Support Enabled
INFO - 2018-04-02 20:32:14 --> Utf8 Class Initialized
INFO - 2018-04-02 20:32:14 --> URI Class Initialized
INFO - 2018-04-02 20:32:14 --> Router Class Initialized
INFO - 2018-04-02 20:32:14 --> Output Class Initialized
INFO - 2018-04-02 20:32:14 --> Security Class Initialized
DEBUG - 2018-04-02 20:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 20:32:14 --> Input Class Initialized
INFO - 2018-04-02 20:32:14 --> Language Class Initialized
INFO - 2018-04-02 20:32:14 --> Loader Class Initialized
INFO - 2018-04-02 20:32:14 --> Helper loaded: url_helper
INFO - 2018-04-02 20:32:14 --> Helper loaded: file_helper
INFO - 2018-04-02 20:32:14 --> Helper loaded: date_helper
INFO - 2018-04-02 20:32:14 --> Database Driver Class Initialized
DEBUG - 2018-04-02 20:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 20:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 20:32:14 --> Controller Class Initialized
INFO - 2018-04-02 20:32:14 --> Model Class Initialized
ERROR - 2018-04-02 20:32:15 --> Severity: Notice --> Undefined property: stdClass::$user_name G:\xampp\htdocs\codeigniter\application\controllers\Auth_Controller.php 50
INFO - 2018-04-02 20:32:15 --> Final output sent to browser
DEBUG - 2018-04-02 20:32:15 --> Total execution time: 0.6740
INFO - 2018-04-02 20:32:15 --> Config Class Initialized
INFO - 2018-04-02 20:32:15 --> Hooks Class Initialized
DEBUG - 2018-04-02 20:32:15 --> UTF-8 Support Enabled
INFO - 2018-04-02 20:32:15 --> Utf8 Class Initialized
INFO - 2018-04-02 20:32:15 --> URI Class Initialized
INFO - 2018-04-02 20:32:15 --> Router Class Initialized
INFO - 2018-04-02 20:32:15 --> Output Class Initialized
INFO - 2018-04-02 20:32:15 --> Security Class Initialized
DEBUG - 2018-04-02 20:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 20:32:15 --> Input Class Initialized
INFO - 2018-04-02 20:32:15 --> Language Class Initialized
INFO - 2018-04-02 20:32:15 --> Loader Class Initialized
INFO - 2018-04-02 20:32:15 --> Helper loaded: url_helper
INFO - 2018-04-02 20:32:15 --> Helper loaded: file_helper
INFO - 2018-04-02 20:32:15 --> Helper loaded: date_helper
INFO - 2018-04-02 20:32:15 --> Database Driver Class Initialized
DEBUG - 2018-04-02 20:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 20:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 20:32:15 --> Controller Class Initialized
INFO - 2018-04-02 20:32:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 20:32:15 --> Final output sent to browser
DEBUG - 2018-04-02 20:32:15 --> Total execution time: 0.3519
INFO - 2018-04-02 21:10:56 --> Config Class Initialized
INFO - 2018-04-02 21:10:56 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:10:56 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:10:56 --> Utf8 Class Initialized
INFO - 2018-04-02 21:10:56 --> URI Class Initialized
INFO - 2018-04-02 21:10:56 --> Router Class Initialized
INFO - 2018-04-02 21:10:56 --> Output Class Initialized
INFO - 2018-04-02 21:10:56 --> Security Class Initialized
DEBUG - 2018-04-02 21:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:10:56 --> Input Class Initialized
INFO - 2018-04-02 21:10:56 --> Language Class Initialized
INFO - 2018-04-02 21:10:56 --> Loader Class Initialized
INFO - 2018-04-02 21:10:56 --> Helper loaded: url_helper
INFO - 2018-04-02 21:10:56 --> Helper loaded: file_helper
INFO - 2018-04-02 21:10:56 --> Helper loaded: date_helper
INFO - 2018-04-02 21:10:56 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:10:56 --> Controller Class Initialized
INFO - 2018-04-02 21:10:56 --> Config Class Initialized
INFO - 2018-04-02 21:10:56 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:10:56 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:10:56 --> Utf8 Class Initialized
INFO - 2018-04-02 21:10:56 --> URI Class Initialized
INFO - 2018-04-02 21:10:56 --> Router Class Initialized
INFO - 2018-04-02 21:10:57 --> Output Class Initialized
INFO - 2018-04-02 21:10:57 --> Security Class Initialized
DEBUG - 2018-04-02 21:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:10:57 --> Input Class Initialized
INFO - 2018-04-02 21:10:57 --> Language Class Initialized
INFO - 2018-04-02 21:10:57 --> Loader Class Initialized
INFO - 2018-04-02 21:10:57 --> Helper loaded: url_helper
INFO - 2018-04-02 21:10:57 --> Helper loaded: file_helper
INFO - 2018-04-02 21:10:57 --> Helper loaded: date_helper
INFO - 2018-04-02 21:10:57 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:10:57 --> Controller Class Initialized
INFO - 2018-04-02 21:10:58 --> Config Class Initialized
INFO - 2018-04-02 21:10:58 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:10:59 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:10:59 --> Utf8 Class Initialized
INFO - 2018-04-02 21:10:59 --> URI Class Initialized
INFO - 2018-04-02 21:10:59 --> Router Class Initialized
INFO - 2018-04-02 21:10:59 --> Output Class Initialized
INFO - 2018-04-02 21:10:59 --> Security Class Initialized
DEBUG - 2018-04-02 21:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:10:59 --> Input Class Initialized
INFO - 2018-04-02 21:10:59 --> Language Class Initialized
INFO - 2018-04-02 21:10:59 --> Loader Class Initialized
INFO - 2018-04-02 21:10:59 --> Helper loaded: url_helper
INFO - 2018-04-02 21:10:59 --> Helper loaded: file_helper
INFO - 2018-04-02 21:10:59 --> Helper loaded: date_helper
INFO - 2018-04-02 21:10:59 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:10:59 --> Controller Class Initialized
INFO - 2018-04-02 21:11:02 --> Config Class Initialized
INFO - 2018-04-02 21:11:02 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:11:02 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:11:02 --> Utf8 Class Initialized
INFO - 2018-04-02 21:11:02 --> URI Class Initialized
INFO - 2018-04-02 21:11:02 --> Router Class Initialized
INFO - 2018-04-02 21:11:02 --> Output Class Initialized
INFO - 2018-04-02 21:11:02 --> Security Class Initialized
DEBUG - 2018-04-02 21:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:11:02 --> Input Class Initialized
INFO - 2018-04-02 21:11:02 --> Language Class Initialized
INFO - 2018-04-02 21:11:02 --> Loader Class Initialized
INFO - 2018-04-02 21:11:02 --> Helper loaded: url_helper
INFO - 2018-04-02 21:11:02 --> Helper loaded: file_helper
INFO - 2018-04-02 21:11:02 --> Helper loaded: date_helper
INFO - 2018-04-02 21:11:02 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:11:02 --> Controller Class Initialized
INFO - 2018-04-02 21:11:09 --> Config Class Initialized
INFO - 2018-04-02 21:11:09 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:11:09 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:11:09 --> Utf8 Class Initialized
INFO - 2018-04-02 21:11:09 --> URI Class Initialized
DEBUG - 2018-04-02 21:11:09 --> No URI present. Default controller set.
INFO - 2018-04-02 21:11:09 --> Router Class Initialized
INFO - 2018-04-02 21:11:09 --> Output Class Initialized
INFO - 2018-04-02 21:11:09 --> Security Class Initialized
DEBUG - 2018-04-02 21:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:11:09 --> Input Class Initialized
INFO - 2018-04-02 21:11:10 --> Language Class Initialized
INFO - 2018-04-02 21:11:10 --> Loader Class Initialized
INFO - 2018-04-02 21:11:10 --> Helper loaded: url_helper
INFO - 2018-04-02 21:11:10 --> Helper loaded: file_helper
INFO - 2018-04-02 21:11:10 --> Helper loaded: date_helper
INFO - 2018-04-02 21:11:10 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:11:10 --> Controller Class Initialized
INFO - 2018-04-02 21:11:16 --> Config Class Initialized
INFO - 2018-04-02 21:11:16 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:11:16 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:11:16 --> Utf8 Class Initialized
INFO - 2018-04-02 21:11:16 --> URI Class Initialized
DEBUG - 2018-04-02 21:11:16 --> No URI present. Default controller set.
INFO - 2018-04-02 21:11:16 --> Router Class Initialized
INFO - 2018-04-02 21:11:16 --> Output Class Initialized
INFO - 2018-04-02 21:11:16 --> Security Class Initialized
DEBUG - 2018-04-02 21:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:11:16 --> Input Class Initialized
INFO - 2018-04-02 21:11:16 --> Language Class Initialized
INFO - 2018-04-02 21:11:16 --> Loader Class Initialized
INFO - 2018-04-02 21:11:16 --> Helper loaded: url_helper
INFO - 2018-04-02 21:11:16 --> Helper loaded: file_helper
INFO - 2018-04-02 21:11:16 --> Helper loaded: date_helper
INFO - 2018-04-02 21:11:16 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:11:16 --> Controller Class Initialized
INFO - 2018-04-02 21:11:16 --> Config Class Initialized
INFO - 2018-04-02 21:11:16 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:11:16 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:11:16 --> Utf8 Class Initialized
INFO - 2018-04-02 21:11:16 --> URI Class Initialized
DEBUG - 2018-04-02 21:11:16 --> No URI present. Default controller set.
INFO - 2018-04-02 21:11:16 --> Router Class Initialized
INFO - 2018-04-02 21:11:16 --> Output Class Initialized
INFO - 2018-04-02 21:11:16 --> Security Class Initialized
DEBUG - 2018-04-02 21:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:11:16 --> Input Class Initialized
INFO - 2018-04-02 21:11:16 --> Language Class Initialized
INFO - 2018-04-02 21:11:16 --> Loader Class Initialized
INFO - 2018-04-02 21:11:16 --> Helper loaded: url_helper
INFO - 2018-04-02 21:11:16 --> Helper loaded: file_helper
INFO - 2018-04-02 21:11:16 --> Helper loaded: date_helper
INFO - 2018-04-02 21:11:16 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:11:17 --> Controller Class Initialized
INFO - 2018-04-02 21:11:19 --> Config Class Initialized
INFO - 2018-04-02 21:11:19 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:11:19 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:11:19 --> Utf8 Class Initialized
INFO - 2018-04-02 21:11:19 --> URI Class Initialized
DEBUG - 2018-04-02 21:11:19 --> No URI present. Default controller set.
INFO - 2018-04-02 21:11:19 --> Router Class Initialized
INFO - 2018-04-02 21:11:19 --> Output Class Initialized
INFO - 2018-04-02 21:11:19 --> Security Class Initialized
DEBUG - 2018-04-02 21:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:11:19 --> Input Class Initialized
INFO - 2018-04-02 21:11:19 --> Language Class Initialized
INFO - 2018-04-02 21:11:19 --> Loader Class Initialized
INFO - 2018-04-02 21:11:19 --> Helper loaded: url_helper
INFO - 2018-04-02 21:11:19 --> Helper loaded: file_helper
INFO - 2018-04-02 21:11:19 --> Helper loaded: date_helper
INFO - 2018-04-02 21:11:19 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:11:19 --> Controller Class Initialized
INFO - 2018-04-02 21:11:21 --> Config Class Initialized
INFO - 2018-04-02 21:11:21 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:11:21 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:11:21 --> Utf8 Class Initialized
INFO - 2018-04-02 21:11:21 --> URI Class Initialized
DEBUG - 2018-04-02 21:11:21 --> No URI present. Default controller set.
INFO - 2018-04-02 21:11:21 --> Router Class Initialized
INFO - 2018-04-02 21:11:21 --> Output Class Initialized
INFO - 2018-04-02 21:11:21 --> Security Class Initialized
DEBUG - 2018-04-02 21:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:11:21 --> Input Class Initialized
INFO - 2018-04-02 21:11:21 --> Language Class Initialized
INFO - 2018-04-02 21:11:21 --> Loader Class Initialized
INFO - 2018-04-02 21:11:21 --> Helper loaded: url_helper
INFO - 2018-04-02 21:11:21 --> Helper loaded: file_helper
INFO - 2018-04-02 21:11:21 --> Helper loaded: date_helper
INFO - 2018-04-02 21:11:21 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:11:21 --> Controller Class Initialized
INFO - 2018-04-02 21:11:27 --> Config Class Initialized
INFO - 2018-04-02 21:11:27 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:11:27 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:11:27 --> Utf8 Class Initialized
INFO - 2018-04-02 21:11:27 --> URI Class Initialized
DEBUG - 2018-04-02 21:11:27 --> No URI present. Default controller set.
INFO - 2018-04-02 21:11:27 --> Router Class Initialized
INFO - 2018-04-02 21:11:27 --> Output Class Initialized
INFO - 2018-04-02 21:11:27 --> Security Class Initialized
DEBUG - 2018-04-02 21:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:11:27 --> Input Class Initialized
INFO - 2018-04-02 21:11:27 --> Language Class Initialized
INFO - 2018-04-02 21:11:27 --> Loader Class Initialized
INFO - 2018-04-02 21:11:27 --> Helper loaded: url_helper
INFO - 2018-04-02 21:11:27 --> Helper loaded: file_helper
INFO - 2018-04-02 21:11:27 --> Helper loaded: date_helper
INFO - 2018-04-02 21:11:27 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:11:28 --> Controller Class Initialized
INFO - 2018-04-02 21:11:56 --> Config Class Initialized
INFO - 2018-04-02 21:11:56 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:11:56 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:11:56 --> Utf8 Class Initialized
INFO - 2018-04-02 21:11:56 --> URI Class Initialized
DEBUG - 2018-04-02 21:11:56 --> No URI present. Default controller set.
INFO - 2018-04-02 21:11:56 --> Router Class Initialized
INFO - 2018-04-02 21:11:56 --> Output Class Initialized
INFO - 2018-04-02 21:11:56 --> Security Class Initialized
DEBUG - 2018-04-02 21:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:11:56 --> Input Class Initialized
INFO - 2018-04-02 21:11:56 --> Language Class Initialized
INFO - 2018-04-02 21:11:56 --> Loader Class Initialized
INFO - 2018-04-02 21:11:56 --> Helper loaded: url_helper
INFO - 2018-04-02 21:11:56 --> Helper loaded: file_helper
INFO - 2018-04-02 21:11:56 --> Helper loaded: date_helper
INFO - 2018-04-02 21:11:56 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:11:56 --> Controller Class Initialized
INFO - 2018-04-02 21:11:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 21:11:56 --> Final output sent to browser
DEBUG - 2018-04-02 21:11:56 --> Total execution time: 0.3200
INFO - 2018-04-02 21:12:03 --> Config Class Initialized
INFO - 2018-04-02 21:12:03 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:12:03 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:12:03 --> Utf8 Class Initialized
INFO - 2018-04-02 21:12:03 --> URI Class Initialized
DEBUG - 2018-04-02 21:12:03 --> No URI present. Default controller set.
INFO - 2018-04-02 21:12:03 --> Router Class Initialized
INFO - 2018-04-02 21:12:03 --> Output Class Initialized
INFO - 2018-04-02 21:12:03 --> Security Class Initialized
DEBUG - 2018-04-02 21:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:12:03 --> Input Class Initialized
INFO - 2018-04-02 21:12:03 --> Language Class Initialized
INFO - 2018-04-02 21:12:03 --> Loader Class Initialized
INFO - 2018-04-02 21:12:03 --> Helper loaded: url_helper
INFO - 2018-04-02 21:12:03 --> Helper loaded: file_helper
INFO - 2018-04-02 21:12:03 --> Helper loaded: date_helper
INFO - 2018-04-02 21:12:03 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:12:03 --> Controller Class Initialized
INFO - 2018-04-02 21:12:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 21:12:03 --> Final output sent to browser
DEBUG - 2018-04-02 21:12:03 --> Total execution time: 0.3241
INFO - 2018-04-02 21:12:11 --> Config Class Initialized
INFO - 2018-04-02 21:12:11 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:12:11 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:12:11 --> Utf8 Class Initialized
INFO - 2018-04-02 21:12:11 --> URI Class Initialized
DEBUG - 2018-04-02 21:12:11 --> No URI present. Default controller set.
INFO - 2018-04-02 21:12:11 --> Router Class Initialized
INFO - 2018-04-02 21:12:11 --> Output Class Initialized
INFO - 2018-04-02 21:12:11 --> Security Class Initialized
DEBUG - 2018-04-02 21:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:12:11 --> Input Class Initialized
INFO - 2018-04-02 21:12:11 --> Language Class Initialized
INFO - 2018-04-02 21:12:11 --> Loader Class Initialized
INFO - 2018-04-02 21:12:11 --> Helper loaded: url_helper
INFO - 2018-04-02 21:12:11 --> Helper loaded: file_helper
INFO - 2018-04-02 21:12:11 --> Helper loaded: date_helper
INFO - 2018-04-02 21:12:11 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:12:11 --> Controller Class Initialized
INFO - 2018-04-02 21:12:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 21:12:11 --> Final output sent to browser
DEBUG - 2018-04-02 21:12:11 --> Total execution time: 0.3811
INFO - 2018-04-02 21:12:14 --> Config Class Initialized
INFO - 2018-04-02 21:12:14 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:12:14 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:12:14 --> Utf8 Class Initialized
INFO - 2018-04-02 21:12:14 --> URI Class Initialized
INFO - 2018-04-02 21:12:14 --> Router Class Initialized
INFO - 2018-04-02 21:12:14 --> Output Class Initialized
INFO - 2018-04-02 21:12:14 --> Security Class Initialized
DEBUG - 2018-04-02 21:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:12:14 --> Input Class Initialized
INFO - 2018-04-02 21:12:14 --> Language Class Initialized
ERROR - 2018-04-02 21:12:14 --> 404 Page Not Found: User/regPage
INFO - 2018-04-02 21:12:17 --> Config Class Initialized
INFO - 2018-04-02 21:12:17 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:12:18 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:12:18 --> Utf8 Class Initialized
INFO - 2018-04-02 21:12:18 --> URI Class Initialized
INFO - 2018-04-02 21:12:18 --> Router Class Initialized
INFO - 2018-04-02 21:12:18 --> Output Class Initialized
INFO - 2018-04-02 21:12:18 --> Security Class Initialized
DEBUG - 2018-04-02 21:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:12:18 --> Input Class Initialized
INFO - 2018-04-02 21:12:18 --> Language Class Initialized
ERROR - 2018-04-02 21:12:18 --> 404 Page Not Found: User/regPage
INFO - 2018-04-02 21:12:21 --> Config Class Initialized
INFO - 2018-04-02 21:12:21 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:12:21 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:12:21 --> Utf8 Class Initialized
INFO - 2018-04-02 21:12:21 --> URI Class Initialized
INFO - 2018-04-02 21:12:21 --> Router Class Initialized
INFO - 2018-04-02 21:12:21 --> Output Class Initialized
INFO - 2018-04-02 21:12:21 --> Security Class Initialized
DEBUG - 2018-04-02 21:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:12:21 --> Input Class Initialized
INFO - 2018-04-02 21:12:21 --> Language Class Initialized
ERROR - 2018-04-02 21:12:21 --> 404 Page Not Found: User/regPage
INFO - 2018-04-02 21:13:04 --> Config Class Initialized
INFO - 2018-04-02 21:13:04 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:13:04 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:13:04 --> Utf8 Class Initialized
INFO - 2018-04-02 21:13:04 --> URI Class Initialized
INFO - 2018-04-02 21:13:05 --> Router Class Initialized
INFO - 2018-04-02 21:13:05 --> Output Class Initialized
INFO - 2018-04-02 21:13:05 --> Security Class Initialized
DEBUG - 2018-04-02 21:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:13:05 --> Input Class Initialized
INFO - 2018-04-02 21:13:05 --> Language Class Initialized
ERROR - 2018-04-02 21:13:05 --> 404 Page Not Found: Login/index
INFO - 2018-04-02 21:14:24 --> Config Class Initialized
INFO - 2018-04-02 21:14:24 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:14:24 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:14:24 --> Utf8 Class Initialized
INFO - 2018-04-02 21:14:24 --> URI Class Initialized
INFO - 2018-04-02 21:14:24 --> Router Class Initialized
INFO - 2018-04-02 21:14:24 --> Output Class Initialized
INFO - 2018-04-02 21:14:24 --> Security Class Initialized
DEBUG - 2018-04-02 21:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:14:24 --> Input Class Initialized
INFO - 2018-04-02 21:14:24 --> Language Class Initialized
INFO - 2018-04-02 21:14:24 --> Loader Class Initialized
INFO - 2018-04-02 21:14:24 --> Helper loaded: url_helper
INFO - 2018-04-02 21:14:24 --> Helper loaded: file_helper
INFO - 2018-04-02 21:14:24 --> Helper loaded: date_helper
INFO - 2018-04-02 21:14:24 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:14:24 --> Controller Class Initialized
INFO - 2018-04-02 21:14:24 --> Model Class Initialized
INFO - 2018-04-02 21:14:36 --> Config Class Initialized
INFO - 2018-04-02 21:14:36 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:14:36 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:14:36 --> Utf8 Class Initialized
INFO - 2018-04-02 21:14:36 --> URI Class Initialized
DEBUG - 2018-04-02 21:14:36 --> No URI present. Default controller set.
INFO - 2018-04-02 21:14:36 --> Router Class Initialized
INFO - 2018-04-02 21:14:36 --> Output Class Initialized
INFO - 2018-04-02 21:14:36 --> Security Class Initialized
DEBUG - 2018-04-02 21:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:14:36 --> Input Class Initialized
INFO - 2018-04-02 21:14:36 --> Language Class Initialized
INFO - 2018-04-02 21:14:36 --> Loader Class Initialized
INFO - 2018-04-02 21:14:36 --> Helper loaded: url_helper
INFO - 2018-04-02 21:14:36 --> Helper loaded: file_helper
INFO - 2018-04-02 21:14:36 --> Helper loaded: date_helper
INFO - 2018-04-02 21:14:36 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:14:36 --> Controller Class Initialized
INFO - 2018-04-02 21:14:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 21:14:36 --> Final output sent to browser
DEBUG - 2018-04-02 21:14:36 --> Total execution time: 0.3754
INFO - 2018-04-02 21:14:47 --> Config Class Initialized
INFO - 2018-04-02 21:14:47 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:14:47 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:14:47 --> Utf8 Class Initialized
INFO - 2018-04-02 21:14:48 --> URI Class Initialized
DEBUG - 2018-04-02 21:14:48 --> No URI present. Default controller set.
INFO - 2018-04-02 21:14:48 --> Router Class Initialized
INFO - 2018-04-02 21:14:48 --> Output Class Initialized
INFO - 2018-04-02 21:14:48 --> Security Class Initialized
DEBUG - 2018-04-02 21:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:14:48 --> Input Class Initialized
INFO - 2018-04-02 21:14:48 --> Language Class Initialized
INFO - 2018-04-02 21:14:48 --> Loader Class Initialized
INFO - 2018-04-02 21:14:48 --> Helper loaded: url_helper
INFO - 2018-04-02 21:14:48 --> Helper loaded: file_helper
INFO - 2018-04-02 21:14:48 --> Helper loaded: date_helper
INFO - 2018-04-02 21:14:48 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:14:48 --> Controller Class Initialized
INFO - 2018-04-02 21:14:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 21:14:48 --> Final output sent to browser
DEBUG - 2018-04-02 21:14:48 --> Total execution time: 0.3849
INFO - 2018-04-02 21:14:51 --> Config Class Initialized
INFO - 2018-04-02 21:14:51 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:14:51 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:14:51 --> Utf8 Class Initialized
INFO - 2018-04-02 21:14:51 --> URI Class Initialized
INFO - 2018-04-02 21:14:51 --> Router Class Initialized
INFO - 2018-04-02 21:14:51 --> Output Class Initialized
INFO - 2018-04-02 21:14:51 --> Security Class Initialized
DEBUG - 2018-04-02 21:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:14:51 --> Input Class Initialized
INFO - 2018-04-02 21:14:51 --> Language Class Initialized
INFO - 2018-04-02 21:14:51 --> Loader Class Initialized
INFO - 2018-04-02 21:14:51 --> Helper loaded: url_helper
INFO - 2018-04-02 21:14:51 --> Helper loaded: file_helper
INFO - 2018-04-02 21:14:51 --> Helper loaded: date_helper
INFO - 2018-04-02 21:14:51 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:14:51 --> Controller Class Initialized
DEBUG - 2018-04-02 21:14:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-02 21:14:51 --> Config Class Initialized
INFO - 2018-04-02 21:14:51 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:14:51 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:14:51 --> Utf8 Class Initialized
INFO - 2018-04-02 21:14:51 --> URI Class Initialized
INFO - 2018-04-02 21:14:51 --> Router Class Initialized
INFO - 2018-04-02 21:14:51 --> Output Class Initialized
INFO - 2018-04-02 21:14:51 --> Security Class Initialized
DEBUG - 2018-04-02 21:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:14:51 --> Input Class Initialized
INFO - 2018-04-02 21:14:51 --> Language Class Initialized
INFO - 2018-04-02 21:14:51 --> Loader Class Initialized
INFO - 2018-04-02 21:14:51 --> Helper loaded: url_helper
INFO - 2018-04-02 21:14:51 --> Helper loaded: file_helper
INFO - 2018-04-02 21:14:51 --> Helper loaded: date_helper
INFO - 2018-04-02 21:14:52 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:14:52 --> Controller Class Initialized
INFO - 2018-04-02 21:14:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 21:14:52 --> Final output sent to browser
DEBUG - 2018-04-02 21:14:52 --> Total execution time: 0.2963
INFO - 2018-04-02 21:15:13 --> Config Class Initialized
INFO - 2018-04-02 21:15:13 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:15:13 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:15:13 --> Utf8 Class Initialized
INFO - 2018-04-02 21:15:13 --> URI Class Initialized
INFO - 2018-04-02 21:15:13 --> Router Class Initialized
INFO - 2018-04-02 21:15:13 --> Output Class Initialized
INFO - 2018-04-02 21:15:13 --> Security Class Initialized
DEBUG - 2018-04-02 21:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:15:13 --> Input Class Initialized
INFO - 2018-04-02 21:15:13 --> Language Class Initialized
INFO - 2018-04-02 21:15:13 --> Loader Class Initialized
INFO - 2018-04-02 21:15:13 --> Helper loaded: url_helper
INFO - 2018-04-02 21:15:13 --> Helper loaded: file_helper
INFO - 2018-04-02 21:15:13 --> Helper loaded: date_helper
INFO - 2018-04-02 21:15:13 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:15:13 --> Controller Class Initialized
INFO - 2018-04-02 21:15:13 --> Model Class Initialized
ERROR - 2018-04-02 21:15:13 --> Severity: Notice --> Undefined property: stdClass::$user_name G:\xampp\htdocs\codeigniter\application\controllers\Auth_Controller.php 50
INFO - 2018-04-02 21:15:13 --> Final output sent to browser
DEBUG - 2018-04-02 21:15:13 --> Total execution time: 0.3229
INFO - 2018-04-02 21:15:13 --> Config Class Initialized
INFO - 2018-04-02 21:15:13 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:15:13 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:15:13 --> Utf8 Class Initialized
INFO - 2018-04-02 21:15:13 --> URI Class Initialized
INFO - 2018-04-02 21:15:13 --> Router Class Initialized
INFO - 2018-04-02 21:15:13 --> Output Class Initialized
INFO - 2018-04-02 21:15:13 --> Security Class Initialized
DEBUG - 2018-04-02 21:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:15:13 --> Input Class Initialized
INFO - 2018-04-02 21:15:13 --> Language Class Initialized
INFO - 2018-04-02 21:15:13 --> Loader Class Initialized
INFO - 2018-04-02 21:15:13 --> Helper loaded: url_helper
INFO - 2018-04-02 21:15:13 --> Helper loaded: file_helper
INFO - 2018-04-02 21:15:13 --> Helper loaded: date_helper
INFO - 2018-04-02 21:15:13 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:15:13 --> Controller Class Initialized
INFO - 2018-04-02 21:15:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 21:15:13 --> Final output sent to browser
DEBUG - 2018-04-02 21:15:13 --> Total execution time: 0.3053
INFO - 2018-04-02 21:15:20 --> Config Class Initialized
INFO - 2018-04-02 21:15:20 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:15:20 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:15:20 --> Utf8 Class Initialized
INFO - 2018-04-02 21:15:20 --> URI Class Initialized
INFO - 2018-04-02 21:15:20 --> Router Class Initialized
INFO - 2018-04-02 21:15:20 --> Output Class Initialized
INFO - 2018-04-02 21:15:20 --> Security Class Initialized
DEBUG - 2018-04-02 21:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:15:20 --> Input Class Initialized
INFO - 2018-04-02 21:15:20 --> Language Class Initialized
INFO - 2018-04-02 21:15:20 --> Loader Class Initialized
INFO - 2018-04-02 21:15:20 --> Helper loaded: url_helper
INFO - 2018-04-02 21:15:21 --> Helper loaded: file_helper
INFO - 2018-04-02 21:15:21 --> Helper loaded: date_helper
INFO - 2018-04-02 21:15:21 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:15:21 --> Controller Class Initialized
INFO - 2018-04-02 21:15:21 --> Config Class Initialized
INFO - 2018-04-02 21:15:21 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:15:21 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:15:21 --> Utf8 Class Initialized
INFO - 2018-04-02 21:15:21 --> URI Class Initialized
INFO - 2018-04-02 21:15:21 --> Router Class Initialized
INFO - 2018-04-02 21:15:21 --> Output Class Initialized
INFO - 2018-04-02 21:15:21 --> Security Class Initialized
DEBUG - 2018-04-02 21:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:15:21 --> Input Class Initialized
INFO - 2018-04-02 21:15:21 --> Language Class Initialized
INFO - 2018-04-02 21:15:21 --> Loader Class Initialized
INFO - 2018-04-02 21:15:21 --> Helper loaded: url_helper
INFO - 2018-04-02 21:15:21 --> Helper loaded: file_helper
INFO - 2018-04-02 21:15:21 --> Helper loaded: date_helper
INFO - 2018-04-02 21:15:21 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:15:21 --> Controller Class Initialized
INFO - 2018-04-02 21:15:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-02 21:15:21 --> Final output sent to browser
DEBUG - 2018-04-02 21:15:21 --> Total execution time: 0.3128
INFO - 2018-04-02 21:15:24 --> Config Class Initialized
INFO - 2018-04-02 21:15:24 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:15:24 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:15:24 --> Utf8 Class Initialized
INFO - 2018-04-02 21:15:24 --> URI Class Initialized
INFO - 2018-04-02 21:15:24 --> Router Class Initialized
INFO - 2018-04-02 21:15:24 --> Output Class Initialized
INFO - 2018-04-02 21:15:24 --> Security Class Initialized
DEBUG - 2018-04-02 21:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:15:24 --> Input Class Initialized
INFO - 2018-04-02 21:15:24 --> Language Class Initialized
INFO - 2018-04-02 21:15:24 --> Loader Class Initialized
INFO - 2018-04-02 21:15:24 --> Helper loaded: url_helper
INFO - 2018-04-02 21:15:24 --> Helper loaded: file_helper
INFO - 2018-04-02 21:15:24 --> Helper loaded: date_helper
INFO - 2018-04-02 21:15:24 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:15:24 --> Controller Class Initialized
DEBUG - 2018-04-02 21:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-02 21:15:24 --> Config Class Initialized
INFO - 2018-04-02 21:15:24 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:15:24 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:15:24 --> Utf8 Class Initialized
INFO - 2018-04-02 21:15:24 --> URI Class Initialized
INFO - 2018-04-02 21:15:24 --> Router Class Initialized
INFO - 2018-04-02 21:15:24 --> Output Class Initialized
INFO - 2018-04-02 21:15:24 --> Security Class Initialized
DEBUG - 2018-04-02 21:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:15:24 --> Input Class Initialized
INFO - 2018-04-02 21:15:24 --> Language Class Initialized
INFO - 2018-04-02 21:15:24 --> Loader Class Initialized
INFO - 2018-04-02 21:15:24 --> Helper loaded: url_helper
INFO - 2018-04-02 21:15:24 --> Helper loaded: file_helper
INFO - 2018-04-02 21:15:24 --> Helper loaded: date_helper
INFO - 2018-04-02 21:15:24 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:15:24 --> Controller Class Initialized
INFO - 2018-04-02 21:15:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 21:15:24 --> Final output sent to browser
DEBUG - 2018-04-02 21:15:24 --> Total execution time: 0.3027
INFO - 2018-04-02 21:15:26 --> Config Class Initialized
INFO - 2018-04-02 21:15:26 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:15:26 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:15:26 --> Utf8 Class Initialized
INFO - 2018-04-02 21:15:26 --> URI Class Initialized
INFO - 2018-04-02 21:15:27 --> Router Class Initialized
INFO - 2018-04-02 21:15:27 --> Output Class Initialized
INFO - 2018-04-02 21:15:27 --> Security Class Initialized
DEBUG - 2018-04-02 21:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:15:27 --> Input Class Initialized
INFO - 2018-04-02 21:15:27 --> Language Class Initialized
INFO - 2018-04-02 21:15:27 --> Loader Class Initialized
INFO - 2018-04-02 21:15:27 --> Helper loaded: url_helper
INFO - 2018-04-02 21:15:27 --> Helper loaded: file_helper
INFO - 2018-04-02 21:15:27 --> Helper loaded: date_helper
INFO - 2018-04-02 21:15:27 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:15:27 --> Controller Class Initialized
INFO - 2018-04-02 21:15:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 21:15:27 --> Final output sent to browser
DEBUG - 2018-04-02 21:15:27 --> Total execution time: 0.3359
INFO - 2018-04-02 21:16:06 --> Config Class Initialized
INFO - 2018-04-02 21:16:06 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:16:06 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:16:06 --> Utf8 Class Initialized
INFO - 2018-04-02 21:16:06 --> URI Class Initialized
INFO - 2018-04-02 21:16:06 --> Router Class Initialized
INFO - 2018-04-02 21:16:06 --> Output Class Initialized
INFO - 2018-04-02 21:16:06 --> Security Class Initialized
DEBUG - 2018-04-02 21:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:16:06 --> Input Class Initialized
INFO - 2018-04-02 21:16:06 --> Language Class Initialized
INFO - 2018-04-02 21:16:06 --> Loader Class Initialized
INFO - 2018-04-02 21:16:06 --> Helper loaded: url_helper
INFO - 2018-04-02 21:16:06 --> Helper loaded: file_helper
INFO - 2018-04-02 21:16:06 --> Helper loaded: date_helper
INFO - 2018-04-02 21:16:06 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:16:06 --> Controller Class Initialized
INFO - 2018-04-02 21:16:06 --> Model Class Initialized
ERROR - 2018-04-02 21:16:06 --> Query error: Column 'gender' cannot be null - Invalid query: INSERT INTO `user` (`user_type`, `name`, `email`, `gender`, `blood_group`, `phone`, `dob`, `weight`, `country`) VALUES (2, 'redoy', 'redoy@gmail.com0', NULL, 'select group', '', '', '', 'select')
INFO - 2018-04-02 21:16:06 --> Language file loaded: language/english/db_lang.php
INFO - 2018-04-02 21:16:09 --> Config Class Initialized
INFO - 2018-04-02 21:16:09 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:16:09 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:16:09 --> Utf8 Class Initialized
INFO - 2018-04-02 21:16:09 --> URI Class Initialized
INFO - 2018-04-02 21:16:09 --> Router Class Initialized
INFO - 2018-04-02 21:16:09 --> Output Class Initialized
INFO - 2018-04-02 21:16:09 --> Security Class Initialized
DEBUG - 2018-04-02 21:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:16:09 --> Input Class Initialized
INFO - 2018-04-02 21:16:09 --> Language Class Initialized
INFO - 2018-04-02 21:16:09 --> Loader Class Initialized
INFO - 2018-04-02 21:16:09 --> Helper loaded: url_helper
INFO - 2018-04-02 21:16:09 --> Helper loaded: file_helper
INFO - 2018-04-02 21:16:10 --> Helper loaded: date_helper
INFO - 2018-04-02 21:16:10 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:16:10 --> Controller Class Initialized
INFO - 2018-04-02 21:16:10 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-02 21:16:10 --> Final output sent to browser
DEBUG - 2018-04-02 21:16:10 --> Total execution time: 0.3139
INFO - 2018-04-02 21:16:37 --> Config Class Initialized
INFO - 2018-04-02 21:16:37 --> Hooks Class Initialized
DEBUG - 2018-04-02 21:16:37 --> UTF-8 Support Enabled
INFO - 2018-04-02 21:16:37 --> Utf8 Class Initialized
INFO - 2018-04-02 21:16:37 --> URI Class Initialized
INFO - 2018-04-02 21:16:37 --> Router Class Initialized
INFO - 2018-04-02 21:16:37 --> Output Class Initialized
INFO - 2018-04-02 21:16:37 --> Security Class Initialized
DEBUG - 2018-04-02 21:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-02 21:16:37 --> Input Class Initialized
INFO - 2018-04-02 21:16:37 --> Language Class Initialized
INFO - 2018-04-02 21:16:37 --> Loader Class Initialized
INFO - 2018-04-02 21:16:37 --> Helper loaded: url_helper
INFO - 2018-04-02 21:16:37 --> Helper loaded: file_helper
INFO - 2018-04-02 21:16:37 --> Helper loaded: date_helper
INFO - 2018-04-02 21:16:37 --> Database Driver Class Initialized
DEBUG - 2018-04-02 21:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-02 21:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-02 21:16:37 --> Controller Class Initialized
INFO - 2018-04-02 21:16:37 --> Model Class Initialized
INFO - 2018-04-02 21:16:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-02 21:16:37 --> Final output sent to browser
DEBUG - 2018-04-02 21:16:37 --> Total execution time: 0.4598
