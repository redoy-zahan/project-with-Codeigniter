<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-12 06:06:10 --> Config Class Initialized
INFO - 2018-04-12 06:06:10 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:06:10 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:06:10 --> Utf8 Class Initialized
INFO - 2018-04-12 06:06:10 --> URI Class Initialized
DEBUG - 2018-04-12 06:06:10 --> No URI present. Default controller set.
INFO - 2018-04-12 06:06:10 --> Router Class Initialized
INFO - 2018-04-12 06:06:10 --> Output Class Initialized
INFO - 2018-04-12 06:06:10 --> Security Class Initialized
DEBUG - 2018-04-12 06:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:06:10 --> Input Class Initialized
INFO - 2018-04-12 06:06:10 --> Language Class Initialized
INFO - 2018-04-12 06:06:11 --> Loader Class Initialized
INFO - 2018-04-12 06:06:11 --> Helper loaded: url_helper
INFO - 2018-04-12 06:06:11 --> Helper loaded: file_helper
INFO - 2018-04-12 06:06:11 --> Helper loaded: date_helper
INFO - 2018-04-12 06:06:11 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:06:12 --> Controller Class Initialized
INFO - 2018-04-12 06:06:12 --> Config Class Initialized
INFO - 2018-04-12 06:06:12 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:06:12 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:06:12 --> Utf8 Class Initialized
INFO - 2018-04-12 06:06:12 --> URI Class Initialized
INFO - 2018-04-12 06:06:12 --> Router Class Initialized
INFO - 2018-04-12 06:06:12 --> Output Class Initialized
INFO - 2018-04-12 06:06:12 --> Security Class Initialized
DEBUG - 2018-04-12 06:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:06:12 --> Input Class Initialized
INFO - 2018-04-12 06:06:12 --> Language Class Initialized
INFO - 2018-04-12 06:06:12 --> Loader Class Initialized
INFO - 2018-04-12 06:06:12 --> Helper loaded: url_helper
INFO - 2018-04-12 06:06:12 --> Helper loaded: file_helper
INFO - 2018-04-12 06:06:12 --> Helper loaded: date_helper
INFO - 2018-04-12 06:06:12 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:06:12 --> Controller Class Initialized
INFO - 2018-04-12 06:06:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 06:06:13 --> Final output sent to browser
DEBUG - 2018-04-12 06:06:13 --> Total execution time: 0.6801
INFO - 2018-04-12 06:06:33 --> Config Class Initialized
INFO - 2018-04-12 06:06:33 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:06:33 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:06:33 --> Utf8 Class Initialized
INFO - 2018-04-12 06:06:33 --> URI Class Initialized
INFO - 2018-04-12 06:06:33 --> Router Class Initialized
INFO - 2018-04-12 06:06:33 --> Output Class Initialized
INFO - 2018-04-12 06:06:33 --> Security Class Initialized
DEBUG - 2018-04-12 06:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:06:33 --> Input Class Initialized
INFO - 2018-04-12 06:06:33 --> Language Class Initialized
INFO - 2018-04-12 06:06:33 --> Loader Class Initialized
INFO - 2018-04-12 06:06:33 --> Helper loaded: url_helper
INFO - 2018-04-12 06:06:33 --> Helper loaded: file_helper
INFO - 2018-04-12 06:06:33 --> Helper loaded: date_helper
INFO - 2018-04-12 06:06:33 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:06:33 --> Controller Class Initialized
INFO - 2018-04-12 06:06:34 --> Model Class Initialized
INFO - 2018-04-12 06:06:34 --> Final output sent to browser
DEBUG - 2018-04-12 06:06:34 --> Total execution time: 0.6833
INFO - 2018-04-12 06:06:34 --> Config Class Initialized
INFO - 2018-04-12 06:06:34 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:06:34 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:06:34 --> Utf8 Class Initialized
INFO - 2018-04-12 06:06:34 --> URI Class Initialized
INFO - 2018-04-12 06:06:34 --> Router Class Initialized
INFO - 2018-04-12 06:06:34 --> Output Class Initialized
INFO - 2018-04-12 06:06:34 --> Security Class Initialized
DEBUG - 2018-04-12 06:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:06:34 --> Input Class Initialized
INFO - 2018-04-12 06:06:34 --> Language Class Initialized
INFO - 2018-04-12 06:06:34 --> Loader Class Initialized
INFO - 2018-04-12 06:06:34 --> Helper loaded: url_helper
INFO - 2018-04-12 06:06:34 --> Helper loaded: file_helper
INFO - 2018-04-12 06:06:34 --> Helper loaded: date_helper
INFO - 2018-04-12 06:06:34 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:06:34 --> Controller Class Initialized
INFO - 2018-04-12 06:06:35 --> Model Class Initialized
INFO - 2018-04-12 06:06:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:06:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:06:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:06:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:06:35 --> Final output sent to browser
DEBUG - 2018-04-12 06:06:35 --> Total execution time: 0.9319
INFO - 2018-04-12 06:06:35 --> Config Class Initialized
INFO - 2018-04-12 06:06:35 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:06:35 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:06:35 --> Utf8 Class Initialized
INFO - 2018-04-12 06:06:35 --> URI Class Initialized
INFO - 2018-04-12 06:06:35 --> Router Class Initialized
INFO - 2018-04-12 06:06:35 --> Output Class Initialized
INFO - 2018-04-12 06:06:35 --> Security Class Initialized
DEBUG - 2018-04-12 06:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:06:35 --> Input Class Initialized
INFO - 2018-04-12 06:06:35 --> Language Class Initialized
ERROR - 2018-04-12 06:06:35 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:06:36 --> Config Class Initialized
INFO - 2018-04-12 06:06:36 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:06:36 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:06:36 --> Utf8 Class Initialized
INFO - 2018-04-12 06:06:36 --> URI Class Initialized
INFO - 2018-04-12 06:06:36 --> Router Class Initialized
INFO - 2018-04-12 06:06:36 --> Output Class Initialized
INFO - 2018-04-12 06:06:36 --> Security Class Initialized
DEBUG - 2018-04-12 06:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:06:36 --> Input Class Initialized
INFO - 2018-04-12 06:06:36 --> Language Class Initialized
ERROR - 2018-04-12 06:06:36 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:06:36 --> Config Class Initialized
INFO - 2018-04-12 06:06:36 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:06:36 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:06:36 --> Utf8 Class Initialized
INFO - 2018-04-12 06:06:36 --> URI Class Initialized
INFO - 2018-04-12 06:06:36 --> Router Class Initialized
INFO - 2018-04-12 06:06:36 --> Output Class Initialized
INFO - 2018-04-12 06:06:36 --> Security Class Initialized
DEBUG - 2018-04-12 06:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:06:36 --> Input Class Initialized
INFO - 2018-04-12 06:06:36 --> Language Class Initialized
ERROR - 2018-04-12 06:06:36 --> 404 Page Not Found: Assets/img
INFO - 2018-04-12 06:07:55 --> Config Class Initialized
INFO - 2018-04-12 06:07:55 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:07:55 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:07:55 --> Utf8 Class Initialized
INFO - 2018-04-12 06:07:55 --> URI Class Initialized
INFO - 2018-04-12 06:07:55 --> Router Class Initialized
INFO - 2018-04-12 06:07:55 --> Output Class Initialized
INFO - 2018-04-12 06:07:55 --> Security Class Initialized
DEBUG - 2018-04-12 06:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:07:55 --> Input Class Initialized
INFO - 2018-04-12 06:07:55 --> Language Class Initialized
INFO - 2018-04-12 06:07:55 --> Loader Class Initialized
INFO - 2018-04-12 06:07:55 --> Helper loaded: url_helper
INFO - 2018-04-12 06:07:55 --> Helper loaded: file_helper
INFO - 2018-04-12 06:07:55 --> Helper loaded: date_helper
INFO - 2018-04-12 06:07:55 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:07:55 --> Controller Class Initialized
INFO - 2018-04-12 06:07:55 --> Model Class Initialized
INFO - 2018-04-12 06:07:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:07:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:07:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:07:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:07:55 --> Final output sent to browser
DEBUG - 2018-04-12 06:07:55 --> Total execution time: 0.2749
INFO - 2018-04-12 06:07:55 --> Config Class Initialized
INFO - 2018-04-12 06:07:55 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:07:55 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:07:55 --> Utf8 Class Initialized
INFO - 2018-04-12 06:07:55 --> URI Class Initialized
INFO - 2018-04-12 06:07:55 --> Router Class Initialized
INFO - 2018-04-12 06:07:56 --> Output Class Initialized
INFO - 2018-04-12 06:07:56 --> Security Class Initialized
DEBUG - 2018-04-12 06:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:07:56 --> Input Class Initialized
INFO - 2018-04-12 06:07:56 --> Language Class Initialized
ERROR - 2018-04-12 06:07:56 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:08:36 --> Config Class Initialized
INFO - 2018-04-12 06:08:36 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:08:36 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:08:36 --> Utf8 Class Initialized
INFO - 2018-04-12 06:08:36 --> URI Class Initialized
INFO - 2018-04-12 06:08:36 --> Router Class Initialized
INFO - 2018-04-12 06:08:36 --> Output Class Initialized
INFO - 2018-04-12 06:08:36 --> Security Class Initialized
DEBUG - 2018-04-12 06:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:08:36 --> Input Class Initialized
INFO - 2018-04-12 06:08:36 --> Language Class Initialized
INFO - 2018-04-12 06:08:36 --> Loader Class Initialized
INFO - 2018-04-12 06:08:36 --> Helper loaded: url_helper
INFO - 2018-04-12 06:08:36 --> Helper loaded: file_helper
INFO - 2018-04-12 06:08:36 --> Helper loaded: date_helper
INFO - 2018-04-12 06:08:36 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:08:36 --> Controller Class Initialized
INFO - 2018-04-12 06:08:36 --> Model Class Initialized
INFO - 2018-04-12 06:08:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:08:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:08:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:08:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:08:36 --> Final output sent to browser
DEBUG - 2018-04-12 06:08:36 --> Total execution time: 0.2863
INFO - 2018-04-12 06:08:36 --> Config Class Initialized
INFO - 2018-04-12 06:08:36 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:08:36 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:08:37 --> Utf8 Class Initialized
INFO - 2018-04-12 06:08:37 --> URI Class Initialized
INFO - 2018-04-12 06:08:37 --> Router Class Initialized
INFO - 2018-04-12 06:08:37 --> Output Class Initialized
INFO - 2018-04-12 06:08:37 --> Security Class Initialized
DEBUG - 2018-04-12 06:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:08:37 --> Input Class Initialized
INFO - 2018-04-12 06:08:37 --> Language Class Initialized
ERROR - 2018-04-12 06:08:37 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:09:16 --> Config Class Initialized
INFO - 2018-04-12 06:09:16 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:09:16 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:09:16 --> Utf8 Class Initialized
INFO - 2018-04-12 06:09:16 --> URI Class Initialized
INFO - 2018-04-12 06:09:16 --> Router Class Initialized
INFO - 2018-04-12 06:09:16 --> Output Class Initialized
INFO - 2018-04-12 06:09:16 --> Security Class Initialized
DEBUG - 2018-04-12 06:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:09:16 --> Input Class Initialized
INFO - 2018-04-12 06:09:16 --> Language Class Initialized
INFO - 2018-04-12 06:09:16 --> Loader Class Initialized
INFO - 2018-04-12 06:09:16 --> Helper loaded: url_helper
INFO - 2018-04-12 06:09:16 --> Helper loaded: file_helper
INFO - 2018-04-12 06:09:16 --> Helper loaded: date_helper
INFO - 2018-04-12 06:09:16 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:09:16 --> Controller Class Initialized
INFO - 2018-04-12 06:09:16 --> Model Class Initialized
INFO - 2018-04-12 06:09:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:09:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:09:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:09:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:09:16 --> Final output sent to browser
DEBUG - 2018-04-12 06:09:16 --> Total execution time: 0.2858
INFO - 2018-04-12 06:09:16 --> Config Class Initialized
INFO - 2018-04-12 06:09:16 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:09:16 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:09:16 --> Utf8 Class Initialized
INFO - 2018-04-12 06:09:16 --> URI Class Initialized
INFO - 2018-04-12 06:09:16 --> Router Class Initialized
INFO - 2018-04-12 06:09:16 --> Output Class Initialized
INFO - 2018-04-12 06:09:16 --> Security Class Initialized
DEBUG - 2018-04-12 06:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:09:16 --> Input Class Initialized
INFO - 2018-04-12 06:09:16 --> Language Class Initialized
ERROR - 2018-04-12 06:09:16 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:09:54 --> Config Class Initialized
INFO - 2018-04-12 06:09:54 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:09:54 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:09:54 --> Utf8 Class Initialized
INFO - 2018-04-12 06:09:54 --> URI Class Initialized
INFO - 2018-04-12 06:09:54 --> Router Class Initialized
INFO - 2018-04-12 06:09:54 --> Output Class Initialized
INFO - 2018-04-12 06:09:54 --> Security Class Initialized
DEBUG - 2018-04-12 06:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:09:54 --> Input Class Initialized
INFO - 2018-04-12 06:09:54 --> Language Class Initialized
INFO - 2018-04-12 06:09:54 --> Loader Class Initialized
INFO - 2018-04-12 06:09:54 --> Helper loaded: url_helper
INFO - 2018-04-12 06:09:54 --> Helper loaded: file_helper
INFO - 2018-04-12 06:09:54 --> Helper loaded: date_helper
INFO - 2018-04-12 06:09:54 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:09:54 --> Controller Class Initialized
INFO - 2018-04-12 06:09:54 --> Final output sent to browser
DEBUG - 2018-04-12 06:09:54 --> Total execution time: 0.2293
INFO - 2018-04-12 06:09:58 --> Config Class Initialized
INFO - 2018-04-12 06:09:58 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:09:58 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:09:58 --> Utf8 Class Initialized
INFO - 2018-04-12 06:09:58 --> URI Class Initialized
INFO - 2018-04-12 06:09:58 --> Router Class Initialized
INFO - 2018-04-12 06:09:58 --> Output Class Initialized
INFO - 2018-04-12 06:09:58 --> Security Class Initialized
DEBUG - 2018-04-12 06:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:09:58 --> Input Class Initialized
INFO - 2018-04-12 06:09:58 --> Language Class Initialized
INFO - 2018-04-12 06:09:58 --> Loader Class Initialized
INFO - 2018-04-12 06:09:58 --> Helper loaded: url_helper
INFO - 2018-04-12 06:09:58 --> Helper loaded: file_helper
INFO - 2018-04-12 06:09:58 --> Helper loaded: date_helper
INFO - 2018-04-12 06:09:58 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:09:58 --> Controller Class Initialized
INFO - 2018-04-12 06:09:58 --> Model Class Initialized
INFO - 2018-04-12 06:09:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:09:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:09:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:09:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:09:58 --> Final output sent to browser
DEBUG - 2018-04-12 06:09:58 --> Total execution time: 0.2852
INFO - 2018-04-12 06:10:39 --> Config Class Initialized
INFO - 2018-04-12 06:10:39 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:10:39 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:10:39 --> Utf8 Class Initialized
INFO - 2018-04-12 06:10:39 --> URI Class Initialized
INFO - 2018-04-12 06:10:39 --> Router Class Initialized
INFO - 2018-04-12 06:10:39 --> Output Class Initialized
INFO - 2018-04-12 06:10:39 --> Security Class Initialized
DEBUG - 2018-04-12 06:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:10:39 --> Input Class Initialized
INFO - 2018-04-12 06:10:39 --> Language Class Initialized
INFO - 2018-04-12 06:10:39 --> Loader Class Initialized
INFO - 2018-04-12 06:10:39 --> Helper loaded: url_helper
INFO - 2018-04-12 06:10:39 --> Helper loaded: file_helper
INFO - 2018-04-12 06:10:39 --> Helper loaded: date_helper
INFO - 2018-04-12 06:10:39 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:10:39 --> Controller Class Initialized
INFO - 2018-04-12 06:10:39 --> Model Class Initialized
INFO - 2018-04-12 06:10:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:10:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:10:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:10:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:10:39 --> Final output sent to browser
DEBUG - 2018-04-12 06:10:40 --> Total execution time: 0.5293
INFO - 2018-04-12 06:10:40 --> Config Class Initialized
INFO - 2018-04-12 06:10:40 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:10:40 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:10:40 --> Utf8 Class Initialized
INFO - 2018-04-12 06:10:40 --> URI Class Initialized
INFO - 2018-04-12 06:10:40 --> Router Class Initialized
INFO - 2018-04-12 06:10:40 --> Output Class Initialized
INFO - 2018-04-12 06:10:40 --> Security Class Initialized
DEBUG - 2018-04-12 06:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:10:40 --> Input Class Initialized
INFO - 2018-04-12 06:10:40 --> Language Class Initialized
ERROR - 2018-04-12 06:10:40 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:11:04 --> Config Class Initialized
INFO - 2018-04-12 06:11:04 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:11:04 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:11:04 --> Utf8 Class Initialized
INFO - 2018-04-12 06:11:04 --> URI Class Initialized
INFO - 2018-04-12 06:11:04 --> Router Class Initialized
INFO - 2018-04-12 06:11:04 --> Output Class Initialized
INFO - 2018-04-12 06:11:04 --> Security Class Initialized
DEBUG - 2018-04-12 06:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:11:04 --> Input Class Initialized
INFO - 2018-04-12 06:11:04 --> Language Class Initialized
INFO - 2018-04-12 06:11:04 --> Loader Class Initialized
INFO - 2018-04-12 06:11:04 --> Helper loaded: url_helper
INFO - 2018-04-12 06:11:04 --> Helper loaded: file_helper
INFO - 2018-04-12 06:11:04 --> Helper loaded: date_helper
INFO - 2018-04-12 06:11:04 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:11:04 --> Controller Class Initialized
INFO - 2018-04-12 06:11:04 --> Model Class Initialized
INFO - 2018-04-12 06:11:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:11:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:11:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:11:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:11:04 --> Final output sent to browser
DEBUG - 2018-04-12 06:11:04 --> Total execution time: 0.2902
INFO - 2018-04-12 06:11:04 --> Config Class Initialized
INFO - 2018-04-12 06:11:04 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:11:04 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:11:04 --> Utf8 Class Initialized
INFO - 2018-04-12 06:11:04 --> URI Class Initialized
INFO - 2018-04-12 06:11:04 --> Router Class Initialized
INFO - 2018-04-12 06:11:05 --> Output Class Initialized
INFO - 2018-04-12 06:11:05 --> Security Class Initialized
DEBUG - 2018-04-12 06:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:11:05 --> Input Class Initialized
INFO - 2018-04-12 06:11:05 --> Language Class Initialized
ERROR - 2018-04-12 06:11:05 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:12:22 --> Config Class Initialized
INFO - 2018-04-12 06:12:22 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:12:22 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:12:22 --> Utf8 Class Initialized
INFO - 2018-04-12 06:12:22 --> URI Class Initialized
INFO - 2018-04-12 06:12:22 --> Router Class Initialized
INFO - 2018-04-12 06:12:22 --> Output Class Initialized
INFO - 2018-04-12 06:12:22 --> Security Class Initialized
DEBUG - 2018-04-12 06:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:12:22 --> Input Class Initialized
INFO - 2018-04-12 06:12:22 --> Language Class Initialized
INFO - 2018-04-12 06:12:22 --> Loader Class Initialized
INFO - 2018-04-12 06:12:22 --> Helper loaded: url_helper
INFO - 2018-04-12 06:12:22 --> Helper loaded: file_helper
INFO - 2018-04-12 06:12:22 --> Helper loaded: date_helper
INFO - 2018-04-12 06:12:22 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:12:22 --> Controller Class Initialized
INFO - 2018-04-12 06:12:22 --> Final output sent to browser
DEBUG - 2018-04-12 06:12:22 --> Total execution time: 0.2346
INFO - 2018-04-12 06:16:54 --> Config Class Initialized
INFO - 2018-04-12 06:16:54 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:16:54 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:16:54 --> Utf8 Class Initialized
INFO - 2018-04-12 06:16:54 --> URI Class Initialized
INFO - 2018-04-12 06:16:54 --> Router Class Initialized
INFO - 2018-04-12 06:16:54 --> Output Class Initialized
INFO - 2018-04-12 06:16:54 --> Security Class Initialized
DEBUG - 2018-04-12 06:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:16:54 --> Input Class Initialized
INFO - 2018-04-12 06:16:54 --> Language Class Initialized
INFO - 2018-04-12 06:16:54 --> Loader Class Initialized
INFO - 2018-04-12 06:16:54 --> Helper loaded: url_helper
INFO - 2018-04-12 06:16:54 --> Helper loaded: file_helper
INFO - 2018-04-12 06:16:54 --> Helper loaded: date_helper
INFO - 2018-04-12 06:16:54 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:16:54 --> Controller Class Initialized
INFO - 2018-04-12 06:16:54 --> Final output sent to browser
DEBUG - 2018-04-12 06:16:54 --> Total execution time: 0.3094
INFO - 2018-04-12 06:17:28 --> Config Class Initialized
INFO - 2018-04-12 06:17:28 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:17:28 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:17:28 --> Utf8 Class Initialized
INFO - 2018-04-12 06:17:28 --> URI Class Initialized
INFO - 2018-04-12 06:17:28 --> Router Class Initialized
INFO - 2018-04-12 06:17:28 --> Output Class Initialized
INFO - 2018-04-12 06:17:28 --> Security Class Initialized
DEBUG - 2018-04-12 06:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:17:28 --> Input Class Initialized
INFO - 2018-04-12 06:17:28 --> Language Class Initialized
INFO - 2018-04-12 06:17:28 --> Loader Class Initialized
INFO - 2018-04-12 06:17:28 --> Helper loaded: url_helper
INFO - 2018-04-12 06:17:28 --> Helper loaded: file_helper
INFO - 2018-04-12 06:17:28 --> Helper loaded: date_helper
INFO - 2018-04-12 06:17:28 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:17:28 --> Controller Class Initialized
INFO - 2018-04-12 06:34:29 --> Config Class Initialized
INFO - 2018-04-12 06:34:29 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:34:29 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:34:29 --> Utf8 Class Initialized
INFO - 2018-04-12 06:34:29 --> URI Class Initialized
INFO - 2018-04-12 06:34:29 --> Router Class Initialized
INFO - 2018-04-12 06:34:29 --> Output Class Initialized
INFO - 2018-04-12 06:34:29 --> Security Class Initialized
DEBUG - 2018-04-12 06:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:34:29 --> Input Class Initialized
INFO - 2018-04-12 06:34:29 --> Language Class Initialized
INFO - 2018-04-12 06:34:29 --> Loader Class Initialized
INFO - 2018-04-12 06:34:29 --> Helper loaded: url_helper
INFO - 2018-04-12 06:34:29 --> Helper loaded: file_helper
INFO - 2018-04-12 06:34:29 --> Helper loaded: date_helper
INFO - 2018-04-12 06:34:29 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:34:29 --> Controller Class Initialized
INFO - 2018-04-12 06:34:29 --> Model Class Initialized
INFO - 2018-04-12 06:34:30 --> Config Class Initialized
INFO - 2018-04-12 06:34:30 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:34:30 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:34:30 --> Utf8 Class Initialized
INFO - 2018-04-12 06:34:30 --> URI Class Initialized
INFO - 2018-04-12 06:34:30 --> Router Class Initialized
INFO - 2018-04-12 06:34:30 --> Output Class Initialized
INFO - 2018-04-12 06:34:30 --> Security Class Initialized
DEBUG - 2018-04-12 06:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:34:30 --> Input Class Initialized
INFO - 2018-04-12 06:34:30 --> Language Class Initialized
INFO - 2018-04-12 06:34:30 --> Loader Class Initialized
INFO - 2018-04-12 06:34:30 --> Helper loaded: url_helper
INFO - 2018-04-12 06:34:30 --> Helper loaded: file_helper
INFO - 2018-04-12 06:34:30 --> Helper loaded: date_helper
INFO - 2018-04-12 06:34:30 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:34:30 --> Controller Class Initialized
INFO - 2018-04-12 06:34:30 --> Model Class Initialized
INFO - 2018-04-12 06:34:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:34:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:34:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:34:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:34:30 --> Final output sent to browser
DEBUG - 2018-04-12 06:34:30 --> Total execution time: 0.5843
INFO - 2018-04-12 06:34:30 --> Config Class Initialized
INFO - 2018-04-12 06:34:30 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:34:30 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:34:30 --> Utf8 Class Initialized
INFO - 2018-04-12 06:34:30 --> URI Class Initialized
INFO - 2018-04-12 06:34:30 --> Router Class Initialized
INFO - 2018-04-12 06:34:30 --> Output Class Initialized
INFO - 2018-04-12 06:34:30 --> Security Class Initialized
DEBUG - 2018-04-12 06:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:34:30 --> Input Class Initialized
INFO - 2018-04-12 06:34:30 --> Language Class Initialized
INFO - 2018-04-12 06:34:30 --> Loader Class Initialized
INFO - 2018-04-12 06:34:30 --> Helper loaded: url_helper
INFO - 2018-04-12 06:34:30 --> Helper loaded: file_helper
INFO - 2018-04-12 06:34:30 --> Helper loaded: date_helper
INFO - 2018-04-12 06:34:31 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:34:31 --> Controller Class Initialized
INFO - 2018-04-12 06:34:31 --> Model Class Initialized
INFO - 2018-04-12 06:34:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:34:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:34:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:34:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:34:31 --> Final output sent to browser
DEBUG - 2018-04-12 06:34:31 --> Total execution time: 0.3218
INFO - 2018-04-12 06:34:36 --> Config Class Initialized
INFO - 2018-04-12 06:34:36 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:34:36 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:34:36 --> Utf8 Class Initialized
INFO - 2018-04-12 06:34:36 --> URI Class Initialized
INFO - 2018-04-12 06:34:36 --> Router Class Initialized
INFO - 2018-04-12 06:34:36 --> Output Class Initialized
INFO - 2018-04-12 06:34:36 --> Security Class Initialized
DEBUG - 2018-04-12 06:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:34:36 --> Input Class Initialized
INFO - 2018-04-12 06:34:36 --> Language Class Initialized
INFO - 2018-04-12 06:34:36 --> Loader Class Initialized
INFO - 2018-04-12 06:34:36 --> Helper loaded: url_helper
INFO - 2018-04-12 06:34:36 --> Helper loaded: file_helper
INFO - 2018-04-12 06:34:36 --> Helper loaded: date_helper
INFO - 2018-04-12 06:34:36 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:34:36 --> Controller Class Initialized
INFO - 2018-04-12 06:34:36 --> Model Class Initialized
INFO - 2018-04-12 06:34:36 --> Config Class Initialized
INFO - 2018-04-12 06:34:36 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:34:36 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:34:36 --> Utf8 Class Initialized
INFO - 2018-04-12 06:34:36 --> URI Class Initialized
INFO - 2018-04-12 06:34:36 --> Router Class Initialized
INFO - 2018-04-12 06:34:36 --> Output Class Initialized
INFO - 2018-04-12 06:34:36 --> Security Class Initialized
DEBUG - 2018-04-12 06:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:34:36 --> Input Class Initialized
INFO - 2018-04-12 06:34:36 --> Language Class Initialized
INFO - 2018-04-12 06:34:36 --> Loader Class Initialized
INFO - 2018-04-12 06:34:36 --> Helper loaded: url_helper
INFO - 2018-04-12 06:34:36 --> Helper loaded: file_helper
INFO - 2018-04-12 06:34:36 --> Helper loaded: date_helper
INFO - 2018-04-12 06:34:36 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:34:36 --> Controller Class Initialized
INFO - 2018-04-12 06:34:36 --> Model Class Initialized
INFO - 2018-04-12 06:34:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:34:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:34:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:34:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:34:37 --> Final output sent to browser
DEBUG - 2018-04-12 06:34:37 --> Total execution time: 0.5348
INFO - 2018-04-12 06:34:37 --> Config Class Initialized
INFO - 2018-04-12 06:34:37 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:34:37 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:34:37 --> Utf8 Class Initialized
INFO - 2018-04-12 06:34:37 --> URI Class Initialized
INFO - 2018-04-12 06:34:37 --> Router Class Initialized
INFO - 2018-04-12 06:34:37 --> Output Class Initialized
INFO - 2018-04-12 06:34:37 --> Security Class Initialized
DEBUG - 2018-04-12 06:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:34:37 --> Input Class Initialized
INFO - 2018-04-12 06:34:37 --> Language Class Initialized
INFO - 2018-04-12 06:34:37 --> Loader Class Initialized
INFO - 2018-04-12 06:34:37 --> Helper loaded: url_helper
INFO - 2018-04-12 06:34:37 --> Helper loaded: file_helper
INFO - 2018-04-12 06:34:37 --> Helper loaded: date_helper
INFO - 2018-04-12 06:34:37 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:34:37 --> Controller Class Initialized
INFO - 2018-04-12 06:34:37 --> Model Class Initialized
INFO - 2018-04-12 06:34:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:34:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:34:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:34:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:34:37 --> Final output sent to browser
DEBUG - 2018-04-12 06:34:37 --> Total execution time: 0.2949
INFO - 2018-04-12 06:38:13 --> Config Class Initialized
INFO - 2018-04-12 06:38:13 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:38:13 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:38:13 --> Utf8 Class Initialized
INFO - 2018-04-12 06:38:13 --> URI Class Initialized
INFO - 2018-04-12 06:38:13 --> Router Class Initialized
INFO - 2018-04-12 06:38:13 --> Output Class Initialized
INFO - 2018-04-12 06:38:13 --> Security Class Initialized
DEBUG - 2018-04-12 06:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:38:13 --> Input Class Initialized
INFO - 2018-04-12 06:38:13 --> Language Class Initialized
INFO - 2018-04-12 06:38:13 --> Loader Class Initialized
INFO - 2018-04-12 06:38:13 --> Helper loaded: url_helper
INFO - 2018-04-12 06:38:13 --> Helper loaded: file_helper
INFO - 2018-04-12 06:38:13 --> Helper loaded: date_helper
INFO - 2018-04-12 06:38:13 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:38:13 --> Controller Class Initialized
INFO - 2018-04-12 06:38:13 --> Model Class Initialized
INFO - 2018-04-12 06:38:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:38:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:38:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:38:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:38:13 --> Final output sent to browser
DEBUG - 2018-04-12 06:38:13 --> Total execution time: 0.3989
INFO - 2018-04-12 06:38:13 --> Config Class Initialized
INFO - 2018-04-12 06:38:13 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:38:13 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:38:13 --> Utf8 Class Initialized
INFO - 2018-04-12 06:38:13 --> URI Class Initialized
INFO - 2018-04-12 06:38:13 --> Router Class Initialized
INFO - 2018-04-12 06:38:13 --> Output Class Initialized
INFO - 2018-04-12 06:38:13 --> Security Class Initialized
DEBUG - 2018-04-12 06:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:38:13 --> Input Class Initialized
INFO - 2018-04-12 06:38:13 --> Language Class Initialized
INFO - 2018-04-12 06:38:13 --> Loader Class Initialized
INFO - 2018-04-12 06:38:13 --> Helper loaded: url_helper
INFO - 2018-04-12 06:38:13 --> Helper loaded: file_helper
INFO - 2018-04-12 06:38:13 --> Helper loaded: date_helper
INFO - 2018-04-12 06:38:13 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:38:13 --> Controller Class Initialized
INFO - 2018-04-12 06:38:13 --> Model Class Initialized
INFO - 2018-04-12 06:38:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:38:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:38:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:38:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:38:13 --> Final output sent to browser
DEBUG - 2018-04-12 06:38:13 --> Total execution time: 0.2937
INFO - 2018-04-12 06:38:19 --> Config Class Initialized
INFO - 2018-04-12 06:38:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:38:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:38:19 --> Utf8 Class Initialized
INFO - 2018-04-12 06:38:19 --> URI Class Initialized
INFO - 2018-04-12 06:38:19 --> Router Class Initialized
INFO - 2018-04-12 06:38:19 --> Output Class Initialized
INFO - 2018-04-12 06:38:19 --> Security Class Initialized
DEBUG - 2018-04-12 06:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:38:19 --> Input Class Initialized
INFO - 2018-04-12 06:38:19 --> Language Class Initialized
INFO - 2018-04-12 06:38:19 --> Loader Class Initialized
INFO - 2018-04-12 06:38:19 --> Helper loaded: url_helper
INFO - 2018-04-12 06:38:19 --> Helper loaded: file_helper
INFO - 2018-04-12 06:38:19 --> Helper loaded: date_helper
INFO - 2018-04-12 06:38:19 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:38:19 --> Controller Class Initialized
INFO - 2018-04-12 06:38:19 --> Model Class Initialized
INFO - 2018-04-12 06:38:19 --> Config Class Initialized
INFO - 2018-04-12 06:38:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:38:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:38:19 --> Utf8 Class Initialized
INFO - 2018-04-12 06:38:19 --> URI Class Initialized
INFO - 2018-04-12 06:38:19 --> Router Class Initialized
INFO - 2018-04-12 06:38:19 --> Output Class Initialized
INFO - 2018-04-12 06:38:19 --> Security Class Initialized
DEBUG - 2018-04-12 06:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:38:19 --> Input Class Initialized
INFO - 2018-04-12 06:38:19 --> Language Class Initialized
INFO - 2018-04-12 06:38:19 --> Loader Class Initialized
INFO - 2018-04-12 06:38:19 --> Helper loaded: url_helper
INFO - 2018-04-12 06:38:19 --> Helper loaded: file_helper
INFO - 2018-04-12 06:38:19 --> Helper loaded: date_helper
INFO - 2018-04-12 06:38:19 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:38:20 --> Controller Class Initialized
INFO - 2018-04-12 06:38:20 --> Model Class Initialized
INFO - 2018-04-12 06:38:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:38:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:38:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:38:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:38:20 --> Final output sent to browser
DEBUG - 2018-04-12 06:38:20 --> Total execution time: 0.6537
INFO - 2018-04-12 06:38:20 --> Config Class Initialized
INFO - 2018-04-12 06:38:20 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:38:20 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:38:20 --> Utf8 Class Initialized
INFO - 2018-04-12 06:38:20 --> URI Class Initialized
INFO - 2018-04-12 06:38:20 --> Router Class Initialized
INFO - 2018-04-12 06:38:20 --> Output Class Initialized
INFO - 2018-04-12 06:38:20 --> Security Class Initialized
DEBUG - 2018-04-12 06:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:38:20 --> Input Class Initialized
INFO - 2018-04-12 06:38:20 --> Language Class Initialized
ERROR - 2018-04-12 06:38:20 --> 404 Page Not Found: Welcome/css
INFO - 2018-04-12 06:39:40 --> Config Class Initialized
INFO - 2018-04-12 06:39:40 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:39:40 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:39:40 --> Utf8 Class Initialized
INFO - 2018-04-12 06:39:40 --> URI Class Initialized
INFO - 2018-04-12 06:39:40 --> Router Class Initialized
INFO - 2018-04-12 06:39:40 --> Output Class Initialized
INFO - 2018-04-12 06:39:40 --> Security Class Initialized
DEBUG - 2018-04-12 06:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:39:40 --> Input Class Initialized
INFO - 2018-04-12 06:39:40 --> Language Class Initialized
INFO - 2018-04-12 06:39:40 --> Loader Class Initialized
INFO - 2018-04-12 06:39:40 --> Helper loaded: url_helper
INFO - 2018-04-12 06:39:40 --> Helper loaded: file_helper
INFO - 2018-04-12 06:39:40 --> Helper loaded: date_helper
INFO - 2018-04-12 06:39:40 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:39:40 --> Controller Class Initialized
INFO - 2018-04-12 06:39:40 --> Model Class Initialized
INFO - 2018-04-12 06:39:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:39:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:39:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:39:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:39:40 --> Final output sent to browser
DEBUG - 2018-04-12 06:39:40 --> Total execution time: 0.3138
INFO - 2018-04-12 06:39:40 --> Config Class Initialized
INFO - 2018-04-12 06:39:40 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:39:40 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:39:40 --> Utf8 Class Initialized
INFO - 2018-04-12 06:39:40 --> URI Class Initialized
INFO - 2018-04-12 06:39:40 --> Router Class Initialized
INFO - 2018-04-12 06:39:41 --> Output Class Initialized
INFO - 2018-04-12 06:39:41 --> Security Class Initialized
DEBUG - 2018-04-12 06:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:39:41 --> Input Class Initialized
INFO - 2018-04-12 06:39:41 --> Language Class Initialized
ERROR - 2018-04-12 06:39:41 --> 404 Page Not Found: Welcome/css
INFO - 2018-04-12 06:39:44 --> Config Class Initialized
INFO - 2018-04-12 06:39:44 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:39:44 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:39:44 --> Utf8 Class Initialized
INFO - 2018-04-12 06:39:44 --> URI Class Initialized
INFO - 2018-04-12 06:39:44 --> Router Class Initialized
INFO - 2018-04-12 06:39:44 --> Output Class Initialized
INFO - 2018-04-12 06:39:44 --> Security Class Initialized
DEBUG - 2018-04-12 06:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:39:44 --> Input Class Initialized
INFO - 2018-04-12 06:39:44 --> Language Class Initialized
INFO - 2018-04-12 06:39:44 --> Loader Class Initialized
INFO - 2018-04-12 06:39:44 --> Helper loaded: url_helper
INFO - 2018-04-12 06:39:44 --> Helper loaded: file_helper
INFO - 2018-04-12 06:39:44 --> Helper loaded: date_helper
INFO - 2018-04-12 06:39:44 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:39:44 --> Controller Class Initialized
INFO - 2018-04-12 06:39:44 --> Model Class Initialized
INFO - 2018-04-12 06:39:45 --> Config Class Initialized
INFO - 2018-04-12 06:39:45 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:39:45 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:39:45 --> Utf8 Class Initialized
INFO - 2018-04-12 06:39:45 --> URI Class Initialized
INFO - 2018-04-12 06:39:45 --> Router Class Initialized
INFO - 2018-04-12 06:39:45 --> Output Class Initialized
INFO - 2018-04-12 06:39:45 --> Security Class Initialized
DEBUG - 2018-04-12 06:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:39:45 --> Input Class Initialized
INFO - 2018-04-12 06:39:45 --> Language Class Initialized
INFO - 2018-04-12 06:39:45 --> Loader Class Initialized
INFO - 2018-04-12 06:39:45 --> Helper loaded: url_helper
INFO - 2018-04-12 06:39:45 --> Helper loaded: file_helper
INFO - 2018-04-12 06:39:45 --> Helper loaded: date_helper
INFO - 2018-04-12 06:39:45 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:39:45 --> Controller Class Initialized
INFO - 2018-04-12 06:39:45 --> Model Class Initialized
INFO - 2018-04-12 06:39:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:39:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:39:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:39:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:39:45 --> Final output sent to browser
DEBUG - 2018-04-12 06:39:45 --> Total execution time: 0.4774
INFO - 2018-04-12 06:39:45 --> Config Class Initialized
INFO - 2018-04-12 06:39:45 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:39:45 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:39:45 --> Utf8 Class Initialized
INFO - 2018-04-12 06:39:45 --> URI Class Initialized
INFO - 2018-04-12 06:39:45 --> Router Class Initialized
INFO - 2018-04-12 06:39:45 --> Output Class Initialized
INFO - 2018-04-12 06:39:45 --> Security Class Initialized
DEBUG - 2018-04-12 06:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:39:45 --> Input Class Initialized
INFO - 2018-04-12 06:39:45 --> Language Class Initialized
ERROR - 2018-04-12 06:39:45 --> 404 Page Not Found: Welcome/css
INFO - 2018-04-12 06:42:01 --> Config Class Initialized
INFO - 2018-04-12 06:42:01 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:42:01 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:42:01 --> Utf8 Class Initialized
INFO - 2018-04-12 06:42:01 --> URI Class Initialized
INFO - 2018-04-12 06:42:01 --> Router Class Initialized
INFO - 2018-04-12 06:42:01 --> Output Class Initialized
INFO - 2018-04-12 06:42:01 --> Security Class Initialized
DEBUG - 2018-04-12 06:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:42:01 --> Input Class Initialized
INFO - 2018-04-12 06:42:01 --> Language Class Initialized
INFO - 2018-04-12 06:42:01 --> Loader Class Initialized
INFO - 2018-04-12 06:42:01 --> Helper loaded: url_helper
INFO - 2018-04-12 06:42:01 --> Helper loaded: file_helper
INFO - 2018-04-12 06:42:01 --> Helper loaded: date_helper
INFO - 2018-04-12 06:42:01 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:42:01 --> Controller Class Initialized
INFO - 2018-04-12 06:42:01 --> Model Class Initialized
INFO - 2018-04-12 06:42:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:42:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:42:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:42:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:42:01 --> Final output sent to browser
DEBUG - 2018-04-12 06:42:01 --> Total execution time: 0.3096
INFO - 2018-04-12 06:42:02 --> Config Class Initialized
INFO - 2018-04-12 06:42:02 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:42:02 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:42:02 --> Utf8 Class Initialized
INFO - 2018-04-12 06:42:02 --> URI Class Initialized
INFO - 2018-04-12 06:42:02 --> Router Class Initialized
INFO - 2018-04-12 06:42:02 --> Output Class Initialized
INFO - 2018-04-12 06:42:02 --> Security Class Initialized
DEBUG - 2018-04-12 06:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:42:02 --> Input Class Initialized
INFO - 2018-04-12 06:42:02 --> Language Class Initialized
ERROR - 2018-04-12 06:42:02 --> 404 Page Not Found: Welcome/css
INFO - 2018-04-12 06:42:35 --> Config Class Initialized
INFO - 2018-04-12 06:42:35 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:42:35 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:42:35 --> Utf8 Class Initialized
INFO - 2018-04-12 06:42:35 --> URI Class Initialized
INFO - 2018-04-12 06:42:35 --> Router Class Initialized
INFO - 2018-04-12 06:42:35 --> Output Class Initialized
INFO - 2018-04-12 06:42:35 --> Security Class Initialized
DEBUG - 2018-04-12 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:42:35 --> Input Class Initialized
INFO - 2018-04-12 06:42:35 --> Language Class Initialized
INFO - 2018-04-12 06:42:35 --> Loader Class Initialized
INFO - 2018-04-12 06:42:35 --> Helper loaded: url_helper
INFO - 2018-04-12 06:42:35 --> Helper loaded: file_helper
INFO - 2018-04-12 06:42:35 --> Helper loaded: date_helper
INFO - 2018-04-12 06:42:35 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:42:35 --> Controller Class Initialized
INFO - 2018-04-12 06:42:35 --> Model Class Initialized
INFO - 2018-04-12 06:42:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:42:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:42:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:42:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:42:35 --> Final output sent to browser
DEBUG - 2018-04-12 06:42:35 --> Total execution time: 0.5585
INFO - 2018-04-12 06:42:35 --> Config Class Initialized
INFO - 2018-04-12 06:42:35 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:42:35 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:42:35 --> Utf8 Class Initialized
INFO - 2018-04-12 06:42:35 --> URI Class Initialized
INFO - 2018-04-12 06:42:35 --> Router Class Initialized
INFO - 2018-04-12 06:42:35 --> Output Class Initialized
INFO - 2018-04-12 06:42:35 --> Security Class Initialized
DEBUG - 2018-04-12 06:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:42:35 --> Input Class Initialized
INFO - 2018-04-12 06:42:35 --> Language Class Initialized
ERROR - 2018-04-12 06:42:35 --> 404 Page Not Found: Welcome/css
INFO - 2018-04-12 06:44:04 --> Config Class Initialized
INFO - 2018-04-12 06:44:05 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:44:05 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:44:05 --> Utf8 Class Initialized
INFO - 2018-04-12 06:44:05 --> URI Class Initialized
INFO - 2018-04-12 06:44:05 --> Router Class Initialized
INFO - 2018-04-12 06:44:05 --> Output Class Initialized
INFO - 2018-04-12 06:44:05 --> Security Class Initialized
DEBUG - 2018-04-12 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:44:05 --> Input Class Initialized
INFO - 2018-04-12 06:44:05 --> Language Class Initialized
INFO - 2018-04-12 06:44:05 --> Loader Class Initialized
INFO - 2018-04-12 06:44:05 --> Helper loaded: url_helper
INFO - 2018-04-12 06:44:05 --> Helper loaded: file_helper
INFO - 2018-04-12 06:44:05 --> Helper loaded: date_helper
INFO - 2018-04-12 06:44:05 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:44:05 --> Controller Class Initialized
INFO - 2018-04-12 06:44:05 --> Model Class Initialized
INFO - 2018-04-12 06:44:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:44:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:44:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:44:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:44:05 --> Final output sent to browser
DEBUG - 2018-04-12 06:44:05 --> Total execution time: 0.5502
INFO - 2018-04-12 06:44:05 --> Config Class Initialized
INFO - 2018-04-12 06:44:05 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:44:05 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:44:05 --> Utf8 Class Initialized
INFO - 2018-04-12 06:44:05 --> URI Class Initialized
INFO - 2018-04-12 06:44:05 --> Router Class Initialized
INFO - 2018-04-12 06:44:05 --> Output Class Initialized
INFO - 2018-04-12 06:44:05 --> Security Class Initialized
DEBUG - 2018-04-12 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:44:05 --> Input Class Initialized
INFO - 2018-04-12 06:44:05 --> Language Class Initialized
ERROR - 2018-04-12 06:44:05 --> 404 Page Not Found: Welcome/css
INFO - 2018-04-12 06:44:26 --> Config Class Initialized
INFO - 2018-04-12 06:44:26 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:44:26 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:44:26 --> Utf8 Class Initialized
INFO - 2018-04-12 06:44:26 --> URI Class Initialized
INFO - 2018-04-12 06:44:26 --> Router Class Initialized
INFO - 2018-04-12 06:44:26 --> Output Class Initialized
INFO - 2018-04-12 06:44:26 --> Security Class Initialized
DEBUG - 2018-04-12 06:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:44:26 --> Input Class Initialized
INFO - 2018-04-12 06:44:26 --> Language Class Initialized
INFO - 2018-04-12 06:44:26 --> Loader Class Initialized
INFO - 2018-04-12 06:44:26 --> Helper loaded: url_helper
INFO - 2018-04-12 06:44:26 --> Helper loaded: file_helper
INFO - 2018-04-12 06:44:26 --> Helper loaded: date_helper
INFO - 2018-04-12 06:44:26 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:44:26 --> Controller Class Initialized
INFO - 2018-04-12 06:44:26 --> Model Class Initialized
INFO - 2018-04-12 06:44:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:44:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:44:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:44:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:44:26 --> Final output sent to browser
DEBUG - 2018-04-12 06:44:26 --> Total execution time: 0.3106
INFO - 2018-04-12 06:44:26 --> Config Class Initialized
INFO - 2018-04-12 06:44:26 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:44:26 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:44:26 --> Utf8 Class Initialized
INFO - 2018-04-12 06:44:26 --> URI Class Initialized
INFO - 2018-04-12 06:44:26 --> Router Class Initialized
INFO - 2018-04-12 06:44:26 --> Output Class Initialized
INFO - 2018-04-12 06:44:26 --> Security Class Initialized
DEBUG - 2018-04-12 06:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:44:26 --> Input Class Initialized
INFO - 2018-04-12 06:44:26 --> Language Class Initialized
ERROR - 2018-04-12 06:44:26 --> 404 Page Not Found: Welcome/css
INFO - 2018-04-12 06:44:29 --> Config Class Initialized
INFO - 2018-04-12 06:44:29 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:44:29 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:44:29 --> Utf8 Class Initialized
INFO - 2018-04-12 06:44:29 --> URI Class Initialized
INFO - 2018-04-12 06:44:29 --> Router Class Initialized
INFO - 2018-04-12 06:44:29 --> Output Class Initialized
INFO - 2018-04-12 06:44:29 --> Security Class Initialized
DEBUG - 2018-04-12 06:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:44:29 --> Input Class Initialized
INFO - 2018-04-12 06:44:29 --> Language Class Initialized
INFO - 2018-04-12 06:44:29 --> Loader Class Initialized
INFO - 2018-04-12 06:44:29 --> Helper loaded: url_helper
INFO - 2018-04-12 06:44:29 --> Helper loaded: file_helper
INFO - 2018-04-12 06:44:29 --> Helper loaded: date_helper
INFO - 2018-04-12 06:44:29 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:44:29 --> Controller Class Initialized
DEBUG - 2018-04-12 06:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-12 06:44:29 --> Config Class Initialized
INFO - 2018-04-12 06:44:29 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:44:29 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:44:29 --> Utf8 Class Initialized
INFO - 2018-04-12 06:44:29 --> URI Class Initialized
INFO - 2018-04-12 06:44:30 --> Router Class Initialized
INFO - 2018-04-12 06:44:30 --> Output Class Initialized
INFO - 2018-04-12 06:44:30 --> Security Class Initialized
DEBUG - 2018-04-12 06:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:44:30 --> Input Class Initialized
INFO - 2018-04-12 06:44:30 --> Language Class Initialized
INFO - 2018-04-12 06:44:30 --> Loader Class Initialized
INFO - 2018-04-12 06:44:30 --> Helper loaded: url_helper
INFO - 2018-04-12 06:44:30 --> Helper loaded: file_helper
INFO - 2018-04-12 06:44:30 --> Helper loaded: date_helper
INFO - 2018-04-12 06:44:30 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:44:30 --> Controller Class Initialized
INFO - 2018-04-12 06:44:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 06:44:30 --> Final output sent to browser
DEBUG - 2018-04-12 06:44:30 --> Total execution time: 0.2555
INFO - 2018-04-12 06:44:49 --> Config Class Initialized
INFO - 2018-04-12 06:44:49 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:44:49 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:44:49 --> Utf8 Class Initialized
INFO - 2018-04-12 06:44:49 --> URI Class Initialized
INFO - 2018-04-12 06:44:49 --> Router Class Initialized
INFO - 2018-04-12 06:44:49 --> Output Class Initialized
INFO - 2018-04-12 06:44:49 --> Security Class Initialized
DEBUG - 2018-04-12 06:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:44:49 --> Input Class Initialized
INFO - 2018-04-12 06:44:49 --> Language Class Initialized
INFO - 2018-04-12 06:44:49 --> Loader Class Initialized
INFO - 2018-04-12 06:44:50 --> Helper loaded: url_helper
INFO - 2018-04-12 06:44:50 --> Helper loaded: file_helper
INFO - 2018-04-12 06:44:50 --> Helper loaded: date_helper
INFO - 2018-04-12 06:44:50 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:44:50 --> Controller Class Initialized
INFO - 2018-04-12 06:44:50 --> Model Class Initialized
INFO - 2018-04-12 06:44:50 --> Final output sent to browser
DEBUG - 2018-04-12 06:44:50 --> Total execution time: 0.2655
INFO - 2018-04-12 06:44:50 --> Config Class Initialized
INFO - 2018-04-12 06:44:50 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:44:50 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:44:50 --> Utf8 Class Initialized
INFO - 2018-04-12 06:44:50 --> URI Class Initialized
INFO - 2018-04-12 06:44:50 --> Router Class Initialized
INFO - 2018-04-12 06:44:50 --> Output Class Initialized
INFO - 2018-04-12 06:44:50 --> Security Class Initialized
DEBUG - 2018-04-12 06:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:44:50 --> Input Class Initialized
INFO - 2018-04-12 06:44:50 --> Language Class Initialized
INFO - 2018-04-12 06:44:50 --> Loader Class Initialized
INFO - 2018-04-12 06:44:50 --> Helper loaded: url_helper
INFO - 2018-04-12 06:44:50 --> Helper loaded: file_helper
INFO - 2018-04-12 06:44:50 --> Helper loaded: date_helper
INFO - 2018-04-12 06:44:50 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:44:50 --> Controller Class Initialized
INFO - 2018-04-12 06:44:50 --> Model Class Initialized
INFO - 2018-04-12 06:44:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:44:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:44:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:44:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:44:50 --> Final output sent to browser
DEBUG - 2018-04-12 06:44:50 --> Total execution time: 0.2985
INFO - 2018-04-12 06:44:50 --> Config Class Initialized
INFO - 2018-04-12 06:44:50 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:44:50 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:44:50 --> Utf8 Class Initialized
INFO - 2018-04-12 06:44:50 --> URI Class Initialized
INFO - 2018-04-12 06:44:50 --> Router Class Initialized
INFO - 2018-04-12 06:44:50 --> Output Class Initialized
INFO - 2018-04-12 06:44:50 --> Security Class Initialized
DEBUG - 2018-04-12 06:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:44:50 --> Input Class Initialized
INFO - 2018-04-12 06:44:50 --> Language Class Initialized
ERROR - 2018-04-12 06:44:50 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:46:30 --> Config Class Initialized
INFO - 2018-04-12 06:46:30 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:46:30 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:46:30 --> Utf8 Class Initialized
INFO - 2018-04-12 06:46:30 --> URI Class Initialized
INFO - 2018-04-12 06:46:30 --> Router Class Initialized
INFO - 2018-04-12 06:46:30 --> Output Class Initialized
INFO - 2018-04-12 06:46:30 --> Security Class Initialized
DEBUG - 2018-04-12 06:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:46:30 --> Input Class Initialized
INFO - 2018-04-12 06:46:30 --> Language Class Initialized
INFO - 2018-04-12 06:46:30 --> Loader Class Initialized
INFO - 2018-04-12 06:46:30 --> Helper loaded: url_helper
INFO - 2018-04-12 06:46:30 --> Helper loaded: file_helper
INFO - 2018-04-12 06:46:30 --> Helper loaded: date_helper
INFO - 2018-04-12 06:46:30 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:46:30 --> Controller Class Initialized
INFO - 2018-04-12 06:46:30 --> Model Class Initialized
INFO - 2018-04-12 06:46:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:46:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:46:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:46:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:46:30 --> Final output sent to browser
DEBUG - 2018-04-12 06:46:30 --> Total execution time: 0.6936
INFO - 2018-04-12 06:46:30 --> Config Class Initialized
INFO - 2018-04-12 06:46:30 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:46:30 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:46:30 --> Utf8 Class Initialized
INFO - 2018-04-12 06:46:30 --> URI Class Initialized
INFO - 2018-04-12 06:46:30 --> Router Class Initialized
INFO - 2018-04-12 06:46:30 --> Output Class Initialized
INFO - 2018-04-12 06:46:30 --> Security Class Initialized
DEBUG - 2018-04-12 06:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:46:31 --> Input Class Initialized
INFO - 2018-04-12 06:46:31 --> Language Class Initialized
ERROR - 2018-04-12 06:46:31 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:51:37 --> Config Class Initialized
INFO - 2018-04-12 06:51:37 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:51:37 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:51:37 --> Utf8 Class Initialized
INFO - 2018-04-12 06:51:37 --> URI Class Initialized
INFO - 2018-04-12 06:51:37 --> Router Class Initialized
INFO - 2018-04-12 06:51:37 --> Output Class Initialized
INFO - 2018-04-12 06:51:37 --> Security Class Initialized
DEBUG - 2018-04-12 06:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:51:37 --> Input Class Initialized
INFO - 2018-04-12 06:51:37 --> Language Class Initialized
INFO - 2018-04-12 06:51:37 --> Loader Class Initialized
INFO - 2018-04-12 06:51:37 --> Helper loaded: url_helper
INFO - 2018-04-12 06:51:37 --> Helper loaded: file_helper
INFO - 2018-04-12 06:51:37 --> Helper loaded: date_helper
INFO - 2018-04-12 06:51:37 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:51:37 --> Controller Class Initialized
INFO - 2018-04-12 06:51:37 --> Model Class Initialized
INFO - 2018-04-12 06:51:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:51:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:51:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:51:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:51:37 --> Final output sent to browser
DEBUG - 2018-04-12 06:51:37 --> Total execution time: 0.3452
INFO - 2018-04-12 06:51:37 --> Config Class Initialized
INFO - 2018-04-12 06:51:37 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:51:37 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:51:37 --> Utf8 Class Initialized
INFO - 2018-04-12 06:51:37 --> URI Class Initialized
INFO - 2018-04-12 06:51:37 --> Router Class Initialized
INFO - 2018-04-12 06:51:37 --> Output Class Initialized
INFO - 2018-04-12 06:51:37 --> Security Class Initialized
DEBUG - 2018-04-12 06:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:51:37 --> Input Class Initialized
INFO - 2018-04-12 06:51:37 --> Language Class Initialized
ERROR - 2018-04-12 06:51:37 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:51:42 --> Config Class Initialized
INFO - 2018-04-12 06:51:42 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:51:42 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:51:42 --> Utf8 Class Initialized
INFO - 2018-04-12 06:51:42 --> URI Class Initialized
INFO - 2018-04-12 06:51:42 --> Router Class Initialized
INFO - 2018-04-12 06:51:42 --> Output Class Initialized
INFO - 2018-04-12 06:51:42 --> Security Class Initialized
DEBUG - 2018-04-12 06:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:51:42 --> Input Class Initialized
INFO - 2018-04-12 06:51:42 --> Language Class Initialized
INFO - 2018-04-12 06:51:42 --> Loader Class Initialized
INFO - 2018-04-12 06:51:42 --> Helper loaded: url_helper
INFO - 2018-04-12 06:51:42 --> Helper loaded: file_helper
INFO - 2018-04-12 06:51:42 --> Helper loaded: date_helper
INFO - 2018-04-12 06:51:42 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:51:42 --> Controller Class Initialized
INFO - 2018-04-12 06:51:42 --> Model Class Initialized
INFO - 2018-04-12 06:51:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:51:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:51:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:51:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:51:42 --> Final output sent to browser
DEBUG - 2018-04-12 06:51:42 --> Total execution time: 0.3811
INFO - 2018-04-12 06:51:48 --> Config Class Initialized
INFO - 2018-04-12 06:51:48 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:51:48 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:51:48 --> Utf8 Class Initialized
INFO - 2018-04-12 06:51:48 --> URI Class Initialized
INFO - 2018-04-12 06:51:48 --> Router Class Initialized
INFO - 2018-04-12 06:51:48 --> Output Class Initialized
INFO - 2018-04-12 06:51:48 --> Security Class Initialized
DEBUG - 2018-04-12 06:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:51:48 --> Input Class Initialized
INFO - 2018-04-12 06:51:48 --> Language Class Initialized
ERROR - 2018-04-12 06:51:48 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:51:48 --> Config Class Initialized
INFO - 2018-04-12 06:51:49 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:51:49 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:51:49 --> Utf8 Class Initialized
INFO - 2018-04-12 06:51:49 --> URI Class Initialized
INFO - 2018-04-12 06:51:49 --> Router Class Initialized
INFO - 2018-04-12 06:51:49 --> Output Class Initialized
INFO - 2018-04-12 06:51:49 --> Security Class Initialized
DEBUG - 2018-04-12 06:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:51:49 --> Input Class Initialized
INFO - 2018-04-12 06:51:49 --> Language Class Initialized
ERROR - 2018-04-12 06:51:49 --> 404 Page Not Found: Assets/css
INFO - 2018-04-12 06:53:31 --> Config Class Initialized
INFO - 2018-04-12 06:53:31 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:53:32 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:53:32 --> Utf8 Class Initialized
INFO - 2018-04-12 06:53:32 --> URI Class Initialized
INFO - 2018-04-12 06:53:32 --> Router Class Initialized
INFO - 2018-04-12 06:53:32 --> Output Class Initialized
INFO - 2018-04-12 06:53:32 --> Security Class Initialized
DEBUG - 2018-04-12 06:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:53:32 --> Input Class Initialized
INFO - 2018-04-12 06:53:32 --> Language Class Initialized
INFO - 2018-04-12 06:53:32 --> Loader Class Initialized
INFO - 2018-04-12 06:53:32 --> Helper loaded: url_helper
INFO - 2018-04-12 06:53:32 --> Helper loaded: file_helper
INFO - 2018-04-12 06:53:32 --> Helper loaded: date_helper
INFO - 2018-04-12 06:53:32 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:53:32 --> Controller Class Initialized
INFO - 2018-04-12 06:53:32 --> Model Class Initialized
INFO - 2018-04-12 06:53:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:53:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:53:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:53:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:53:32 --> Final output sent to browser
DEBUG - 2018-04-12 06:53:32 --> Total execution time: 0.7844
INFO - 2018-04-12 06:53:32 --> Config Class Initialized
INFO - 2018-04-12 06:53:32 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:53:32 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:53:32 --> Utf8 Class Initialized
INFO - 2018-04-12 06:53:32 --> URI Class Initialized
INFO - 2018-04-12 06:53:32 --> Router Class Initialized
INFO - 2018-04-12 06:53:32 --> Config Class Initialized
INFO - 2018-04-12 06:53:32 --> Output Class Initialized
INFO - 2018-04-12 06:53:32 --> Hooks Class Initialized
INFO - 2018-04-12 06:53:32 --> Security Class Initialized
DEBUG - 2018-04-12 06:53:32 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:53:32 --> Utf8 Class Initialized
DEBUG - 2018-04-12 06:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:53:32 --> Input Class Initialized
INFO - 2018-04-12 06:53:33 --> URI Class Initialized
INFO - 2018-04-12 06:53:33 --> Language Class Initialized
INFO - 2018-04-12 06:53:33 --> Router Class Initialized
ERROR - 2018-04-12 06:53:33 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:53:33 --> Output Class Initialized
INFO - 2018-04-12 06:53:33 --> Security Class Initialized
DEBUG - 2018-04-12 06:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:53:33 --> Input Class Initialized
INFO - 2018-04-12 06:53:33 --> Language Class Initialized
ERROR - 2018-04-12 06:53:33 --> 404 Page Not Found: Assets/css
INFO - 2018-04-12 06:53:33 --> Config Class Initialized
INFO - 2018-04-12 06:53:33 --> Config Class Initialized
INFO - 2018-04-12 06:53:33 --> Hooks Class Initialized
INFO - 2018-04-12 06:53:33 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:53:33 --> UTF-8 Support Enabled
DEBUG - 2018-04-12 06:53:33 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:53:33 --> Utf8 Class Initialized
INFO - 2018-04-12 06:53:33 --> Utf8 Class Initialized
INFO - 2018-04-12 06:53:33 --> URI Class Initialized
INFO - 2018-04-12 06:53:33 --> URI Class Initialized
INFO - 2018-04-12 06:53:33 --> Router Class Initialized
INFO - 2018-04-12 06:53:33 --> Router Class Initialized
INFO - 2018-04-12 06:53:33 --> Output Class Initialized
INFO - 2018-04-12 06:53:33 --> Output Class Initialized
INFO - 2018-04-12 06:53:33 --> Security Class Initialized
INFO - 2018-04-12 06:53:33 --> Security Class Initialized
DEBUG - 2018-04-12 06:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-12 06:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:53:33 --> Input Class Initialized
INFO - 2018-04-12 06:53:33 --> Input Class Initialized
INFO - 2018-04-12 06:53:33 --> Language Class Initialized
INFO - 2018-04-12 06:53:33 --> Language Class Initialized
ERROR - 2018-04-12 06:53:33 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-12 06:53:33 --> 404 Page Not Found: Assets/js
INFO - 2018-04-12 06:54:34 --> Config Class Initialized
INFO - 2018-04-12 06:54:34 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:54:34 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:54:34 --> Utf8 Class Initialized
INFO - 2018-04-12 06:54:34 --> URI Class Initialized
INFO - 2018-04-12 06:54:34 --> Router Class Initialized
INFO - 2018-04-12 06:54:34 --> Output Class Initialized
INFO - 2018-04-12 06:54:34 --> Security Class Initialized
DEBUG - 2018-04-12 06:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:54:34 --> Input Class Initialized
INFO - 2018-04-12 06:54:34 --> Language Class Initialized
INFO - 2018-04-12 06:54:34 --> Loader Class Initialized
INFO - 2018-04-12 06:54:34 --> Helper loaded: url_helper
INFO - 2018-04-12 06:54:34 --> Helper loaded: file_helper
INFO - 2018-04-12 06:54:34 --> Helper loaded: date_helper
INFO - 2018-04-12 06:54:34 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:54:34 --> Controller Class Initialized
INFO - 2018-04-12 06:54:34 --> Model Class Initialized
INFO - 2018-04-12 06:54:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:54:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:54:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:54:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:54:35 --> Final output sent to browser
DEBUG - 2018-04-12 06:54:35 --> Total execution time: 0.4336
INFO - 2018-04-12 06:54:35 --> Config Class Initialized
INFO - 2018-04-12 06:54:35 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:54:35 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:54:35 --> Utf8 Class Initialized
INFO - 2018-04-12 06:54:35 --> URI Class Initialized
INFO - 2018-04-12 06:54:35 --> Router Class Initialized
INFO - 2018-04-12 06:54:35 --> Output Class Initialized
INFO - 2018-04-12 06:54:35 --> Config Class Initialized
INFO - 2018-04-12 06:54:35 --> Hooks Class Initialized
INFO - 2018-04-12 06:54:35 --> Security Class Initialized
DEBUG - 2018-04-12 06:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-12 06:54:35 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:54:35 --> Input Class Initialized
INFO - 2018-04-12 06:54:35 --> Utf8 Class Initialized
INFO - 2018-04-12 06:54:35 --> Language Class Initialized
INFO - 2018-04-12 06:54:35 --> URI Class Initialized
ERROR - 2018-04-12 06:54:35 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:54:35 --> Router Class Initialized
INFO - 2018-04-12 06:54:35 --> Output Class Initialized
INFO - 2018-04-12 06:54:35 --> Security Class Initialized
DEBUG - 2018-04-12 06:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:54:35 --> Input Class Initialized
INFO - 2018-04-12 06:54:35 --> Language Class Initialized
ERROR - 2018-04-12 06:54:35 --> 404 Page Not Found: Assets/css
INFO - 2018-04-12 06:54:35 --> Config Class Initialized
INFO - 2018-04-12 06:54:35 --> Config Class Initialized
INFO - 2018-04-12 06:54:35 --> Hooks Class Initialized
INFO - 2018-04-12 06:54:35 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:54:35 --> UTF-8 Support Enabled
DEBUG - 2018-04-12 06:54:35 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:54:35 --> Utf8 Class Initialized
INFO - 2018-04-12 06:54:35 --> Utf8 Class Initialized
INFO - 2018-04-12 06:54:35 --> URI Class Initialized
INFO - 2018-04-12 06:54:35 --> URI Class Initialized
INFO - 2018-04-12 06:54:35 --> Router Class Initialized
INFO - 2018-04-12 06:54:35 --> Router Class Initialized
INFO - 2018-04-12 06:54:35 --> Output Class Initialized
INFO - 2018-04-12 06:54:35 --> Output Class Initialized
INFO - 2018-04-12 06:54:35 --> Security Class Initialized
INFO - 2018-04-12 06:54:35 --> Security Class Initialized
DEBUG - 2018-04-12 06:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-12 06:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:54:35 --> Input Class Initialized
INFO - 2018-04-12 06:54:35 --> Input Class Initialized
INFO - 2018-04-12 06:54:35 --> Language Class Initialized
INFO - 2018-04-12 06:54:35 --> Language Class Initialized
ERROR - 2018-04-12 06:54:35 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-12 06:54:35 --> 404 Page Not Found: Assets/js
INFO - 2018-04-12 06:56:03 --> Config Class Initialized
INFO - 2018-04-12 06:56:03 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:56:03 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:56:03 --> Utf8 Class Initialized
INFO - 2018-04-12 06:56:03 --> URI Class Initialized
INFO - 2018-04-12 06:56:03 --> Router Class Initialized
INFO - 2018-04-12 06:56:03 --> Output Class Initialized
INFO - 2018-04-12 06:56:03 --> Security Class Initialized
DEBUG - 2018-04-12 06:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:56:03 --> Input Class Initialized
INFO - 2018-04-12 06:56:03 --> Language Class Initialized
INFO - 2018-04-12 06:56:03 --> Loader Class Initialized
INFO - 2018-04-12 06:56:03 --> Helper loaded: url_helper
INFO - 2018-04-12 06:56:03 --> Helper loaded: file_helper
INFO - 2018-04-12 06:56:03 --> Helper loaded: date_helper
INFO - 2018-04-12 06:56:03 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:56:03 --> Controller Class Initialized
INFO - 2018-04-12 06:56:03 --> Model Class Initialized
INFO - 2018-04-12 06:56:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:56:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:56:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:56:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:56:03 --> Final output sent to browser
DEBUG - 2018-04-12 06:56:03 --> Total execution time: 0.5904
INFO - 2018-04-12 06:56:03 --> Config Class Initialized
INFO - 2018-04-12 06:56:03 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:56:03 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:56:03 --> Utf8 Class Initialized
INFO - 2018-04-12 06:56:03 --> URI Class Initialized
INFO - 2018-04-12 06:56:03 --> Router Class Initialized
INFO - 2018-04-12 06:56:03 --> Output Class Initialized
INFO - 2018-04-12 06:56:03 --> Security Class Initialized
DEBUG - 2018-04-12 06:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:56:03 --> Input Class Initialized
INFO - 2018-04-12 06:56:03 --> Language Class Initialized
ERROR - 2018-04-12 06:56:03 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:56:52 --> Config Class Initialized
INFO - 2018-04-12 06:56:52 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:56:52 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:56:52 --> Utf8 Class Initialized
INFO - 2018-04-12 06:56:52 --> URI Class Initialized
DEBUG - 2018-04-12 06:56:52 --> No URI present. Default controller set.
INFO - 2018-04-12 06:56:52 --> Router Class Initialized
INFO - 2018-04-12 06:56:52 --> Output Class Initialized
INFO - 2018-04-12 06:56:52 --> Security Class Initialized
DEBUG - 2018-04-12 06:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:56:52 --> Input Class Initialized
INFO - 2018-04-12 06:56:52 --> Language Class Initialized
INFO - 2018-04-12 06:56:52 --> Loader Class Initialized
INFO - 2018-04-12 06:56:52 --> Helper loaded: url_helper
INFO - 2018-04-12 06:56:52 --> Helper loaded: file_helper
INFO - 2018-04-12 06:56:52 --> Helper loaded: date_helper
INFO - 2018-04-12 06:56:52 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:56:52 --> Controller Class Initialized
INFO - 2018-04-12 06:56:52 --> Model Class Initialized
INFO - 2018-04-12 06:56:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 06:56:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 06:56:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 06:56:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 06:56:52 --> Final output sent to browser
DEBUG - 2018-04-12 06:56:52 --> Total execution time: 0.3386
INFO - 2018-04-12 06:56:52 --> Config Class Initialized
INFO - 2018-04-12 06:56:52 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:56:52 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:56:52 --> Utf8 Class Initialized
INFO - 2018-04-12 06:56:52 --> URI Class Initialized
INFO - 2018-04-12 06:56:52 --> Router Class Initialized
INFO - 2018-04-12 06:56:52 --> Output Class Initialized
INFO - 2018-04-12 06:56:52 --> Security Class Initialized
DEBUG - 2018-04-12 06:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:56:52 --> Input Class Initialized
INFO - 2018-04-12 06:56:52 --> Language Class Initialized
ERROR - 2018-04-12 06:56:52 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 06:56:58 --> Config Class Initialized
INFO - 2018-04-12 06:56:58 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:56:58 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:56:58 --> Utf8 Class Initialized
INFO - 2018-04-12 06:56:58 --> URI Class Initialized
INFO - 2018-04-12 06:56:58 --> Router Class Initialized
INFO - 2018-04-12 06:56:58 --> Output Class Initialized
INFO - 2018-04-12 06:56:58 --> Security Class Initialized
DEBUG - 2018-04-12 06:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:56:58 --> Input Class Initialized
INFO - 2018-04-12 06:56:58 --> Language Class Initialized
INFO - 2018-04-12 06:56:58 --> Loader Class Initialized
INFO - 2018-04-12 06:56:58 --> Helper loaded: url_helper
INFO - 2018-04-12 06:56:58 --> Helper loaded: file_helper
INFO - 2018-04-12 06:56:58 --> Helper loaded: date_helper
INFO - 2018-04-12 06:56:58 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:56:58 --> Controller Class Initialized
DEBUG - 2018-04-12 06:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-12 06:56:58 --> Config Class Initialized
INFO - 2018-04-12 06:56:58 --> Hooks Class Initialized
DEBUG - 2018-04-12 06:56:58 --> UTF-8 Support Enabled
INFO - 2018-04-12 06:56:58 --> Utf8 Class Initialized
INFO - 2018-04-12 06:56:58 --> URI Class Initialized
INFO - 2018-04-12 06:56:58 --> Router Class Initialized
INFO - 2018-04-12 06:56:58 --> Output Class Initialized
INFO - 2018-04-12 06:56:58 --> Security Class Initialized
DEBUG - 2018-04-12 06:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 06:56:58 --> Input Class Initialized
INFO - 2018-04-12 06:56:58 --> Language Class Initialized
INFO - 2018-04-12 06:56:58 --> Loader Class Initialized
INFO - 2018-04-12 06:56:58 --> Helper loaded: url_helper
INFO - 2018-04-12 06:56:58 --> Helper loaded: file_helper
INFO - 2018-04-12 06:56:58 --> Helper loaded: date_helper
INFO - 2018-04-12 06:56:58 --> Database Driver Class Initialized
DEBUG - 2018-04-12 06:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 06:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 06:56:58 --> Controller Class Initialized
INFO - 2018-04-12 06:56:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 06:56:58 --> Final output sent to browser
DEBUG - 2018-04-12 06:56:58 --> Total execution time: 0.2619
INFO - 2018-04-12 10:08:51 --> Config Class Initialized
INFO - 2018-04-12 10:08:51 --> Hooks Class Initialized
DEBUG - 2018-04-12 10:08:51 --> UTF-8 Support Enabled
INFO - 2018-04-12 10:08:51 --> Utf8 Class Initialized
INFO - 2018-04-12 10:08:51 --> URI Class Initialized
DEBUG - 2018-04-12 10:08:51 --> No URI present. Default controller set.
INFO - 2018-04-12 10:08:51 --> Router Class Initialized
INFO - 2018-04-12 10:08:51 --> Output Class Initialized
INFO - 2018-04-12 10:08:51 --> Security Class Initialized
DEBUG - 2018-04-12 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 10:08:51 --> Input Class Initialized
INFO - 2018-04-12 10:08:51 --> Language Class Initialized
INFO - 2018-04-12 10:08:51 --> Loader Class Initialized
INFO - 2018-04-12 10:08:51 --> Helper loaded: url_helper
INFO - 2018-04-12 10:08:51 --> Helper loaded: file_helper
INFO - 2018-04-12 10:08:51 --> Helper loaded: date_helper
INFO - 2018-04-12 10:08:51 --> Database Driver Class Initialized
DEBUG - 2018-04-12 10:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 10:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 10:08:51 --> Controller Class Initialized
INFO - 2018-04-12 10:08:51 --> Config Class Initialized
INFO - 2018-04-12 10:08:51 --> Hooks Class Initialized
DEBUG - 2018-04-12 10:08:51 --> UTF-8 Support Enabled
INFO - 2018-04-12 10:08:51 --> Utf8 Class Initialized
INFO - 2018-04-12 10:08:51 --> URI Class Initialized
INFO - 2018-04-12 10:08:51 --> Router Class Initialized
INFO - 2018-04-12 10:08:51 --> Output Class Initialized
INFO - 2018-04-12 10:08:51 --> Security Class Initialized
DEBUG - 2018-04-12 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 10:08:51 --> Input Class Initialized
INFO - 2018-04-12 10:08:51 --> Language Class Initialized
INFO - 2018-04-12 10:08:51 --> Loader Class Initialized
INFO - 2018-04-12 10:08:51 --> Helper loaded: url_helper
INFO - 2018-04-12 10:08:51 --> Helper loaded: file_helper
INFO - 2018-04-12 10:08:51 --> Helper loaded: date_helper
INFO - 2018-04-12 10:08:51 --> Database Driver Class Initialized
DEBUG - 2018-04-12 10:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 10:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 10:08:51 --> Controller Class Initialized
INFO - 2018-04-12 10:08:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 10:08:51 --> Final output sent to browser
DEBUG - 2018-04-12 10:08:51 --> Total execution time: 0.2845
INFO - 2018-04-12 10:09:01 --> Config Class Initialized
INFO - 2018-04-12 10:09:01 --> Hooks Class Initialized
DEBUG - 2018-04-12 10:09:01 --> UTF-8 Support Enabled
INFO - 2018-04-12 10:09:01 --> Utf8 Class Initialized
INFO - 2018-04-12 10:09:01 --> URI Class Initialized
INFO - 2018-04-12 10:09:02 --> Router Class Initialized
INFO - 2018-04-12 10:09:02 --> Output Class Initialized
INFO - 2018-04-12 10:09:02 --> Security Class Initialized
DEBUG - 2018-04-12 10:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 10:09:02 --> Input Class Initialized
INFO - 2018-04-12 10:09:02 --> Language Class Initialized
INFO - 2018-04-12 10:09:02 --> Loader Class Initialized
INFO - 2018-04-12 10:09:02 --> Helper loaded: url_helper
INFO - 2018-04-12 10:09:02 --> Helper loaded: file_helper
INFO - 2018-04-12 10:09:02 --> Helper loaded: date_helper
INFO - 2018-04-12 10:09:02 --> Database Driver Class Initialized
DEBUG - 2018-04-12 10:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 10:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 10:09:02 --> Controller Class Initialized
INFO - 2018-04-12 10:09:02 --> Model Class Initialized
INFO - 2018-04-12 10:09:02 --> Final output sent to browser
DEBUG - 2018-04-12 10:09:02 --> Total execution time: 0.3061
INFO - 2018-04-12 10:09:02 --> Config Class Initialized
INFO - 2018-04-12 10:09:02 --> Hooks Class Initialized
DEBUG - 2018-04-12 10:09:02 --> UTF-8 Support Enabled
INFO - 2018-04-12 10:09:02 --> Utf8 Class Initialized
INFO - 2018-04-12 10:09:02 --> URI Class Initialized
INFO - 2018-04-12 10:09:02 --> Router Class Initialized
INFO - 2018-04-12 10:09:02 --> Output Class Initialized
INFO - 2018-04-12 10:09:02 --> Security Class Initialized
DEBUG - 2018-04-12 10:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 10:09:02 --> Input Class Initialized
INFO - 2018-04-12 10:09:02 --> Language Class Initialized
INFO - 2018-04-12 10:09:02 --> Loader Class Initialized
INFO - 2018-04-12 10:09:02 --> Helper loaded: url_helper
INFO - 2018-04-12 10:09:02 --> Helper loaded: file_helper
INFO - 2018-04-12 10:09:02 --> Helper loaded: date_helper
INFO - 2018-04-12 10:09:02 --> Database Driver Class Initialized
DEBUG - 2018-04-12 10:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 10:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 10:09:02 --> Controller Class Initialized
INFO - 2018-04-12 10:09:02 --> Model Class Initialized
INFO - 2018-04-12 10:09:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 10:09:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 10:09:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 10:09:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 10:09:02 --> Final output sent to browser
DEBUG - 2018-04-12 10:09:02 --> Total execution time: 0.3491
INFO - 2018-04-12 10:09:02 --> Config Class Initialized
INFO - 2018-04-12 10:09:02 --> Hooks Class Initialized
DEBUG - 2018-04-12 10:09:02 --> UTF-8 Support Enabled
INFO - 2018-04-12 10:09:02 --> Utf8 Class Initialized
INFO - 2018-04-12 10:09:02 --> URI Class Initialized
INFO - 2018-04-12 10:09:02 --> Router Class Initialized
INFO - 2018-04-12 10:09:02 --> Output Class Initialized
INFO - 2018-04-12 10:09:02 --> Security Class Initialized
DEBUG - 2018-04-12 10:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 10:09:02 --> Input Class Initialized
INFO - 2018-04-12 10:09:02 --> Language Class Initialized
ERROR - 2018-04-12 10:09:03 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 10:09:03 --> Config Class Initialized
INFO - 2018-04-12 10:09:03 --> Hooks Class Initialized
DEBUG - 2018-04-12 10:09:03 --> UTF-8 Support Enabled
INFO - 2018-04-12 10:09:03 --> Utf8 Class Initialized
INFO - 2018-04-12 10:09:03 --> URI Class Initialized
INFO - 2018-04-12 10:09:03 --> Router Class Initialized
INFO - 2018-04-12 10:09:03 --> Output Class Initialized
INFO - 2018-04-12 10:09:03 --> Security Class Initialized
DEBUG - 2018-04-12 10:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 10:09:03 --> Input Class Initialized
INFO - 2018-04-12 10:09:03 --> Language Class Initialized
ERROR - 2018-04-12 10:09:03 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 21:17:20 --> Config Class Initialized
INFO - 2018-04-12 21:17:21 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:17:21 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:17:21 --> Utf8 Class Initialized
INFO - 2018-04-12 21:17:21 --> URI Class Initialized
DEBUG - 2018-04-12 21:17:21 --> No URI present. Default controller set.
INFO - 2018-04-12 21:17:21 --> Router Class Initialized
INFO - 2018-04-12 21:17:21 --> Output Class Initialized
INFO - 2018-04-12 21:17:21 --> Security Class Initialized
DEBUG - 2018-04-12 21:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:17:21 --> Input Class Initialized
INFO - 2018-04-12 21:17:22 --> Language Class Initialized
INFO - 2018-04-12 21:17:22 --> Loader Class Initialized
INFO - 2018-04-12 21:17:22 --> Helper loaded: url_helper
INFO - 2018-04-12 21:17:23 --> Helper loaded: file_helper
INFO - 2018-04-12 21:17:23 --> Helper loaded: date_helper
INFO - 2018-04-12 21:17:23 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:17:23 --> Controller Class Initialized
INFO - 2018-04-12 21:17:23 --> Config Class Initialized
INFO - 2018-04-12 21:17:23 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:17:23 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:17:23 --> Utf8 Class Initialized
INFO - 2018-04-12 21:17:23 --> URI Class Initialized
INFO - 2018-04-12 21:17:23 --> Router Class Initialized
INFO - 2018-04-12 21:17:23 --> Output Class Initialized
INFO - 2018-04-12 21:17:23 --> Security Class Initialized
DEBUG - 2018-04-12 21:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:17:23 --> Input Class Initialized
INFO - 2018-04-12 21:17:23 --> Language Class Initialized
INFO - 2018-04-12 21:17:23 --> Loader Class Initialized
INFO - 2018-04-12 21:17:24 --> Helper loaded: url_helper
INFO - 2018-04-12 21:17:24 --> Helper loaded: file_helper
INFO - 2018-04-12 21:17:24 --> Helper loaded: date_helper
INFO - 2018-04-12 21:17:24 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:17:24 --> Controller Class Initialized
INFO - 2018-04-12 21:17:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 21:17:24 --> Final output sent to browser
DEBUG - 2018-04-12 21:17:24 --> Total execution time: 0.6964
INFO - 2018-04-12 21:17:41 --> Config Class Initialized
INFO - 2018-04-12 21:17:41 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:17:41 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:17:41 --> Utf8 Class Initialized
INFO - 2018-04-12 21:17:41 --> URI Class Initialized
INFO - 2018-04-12 21:17:41 --> Router Class Initialized
INFO - 2018-04-12 21:17:41 --> Output Class Initialized
INFO - 2018-04-12 21:17:41 --> Security Class Initialized
DEBUG - 2018-04-12 21:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:17:41 --> Input Class Initialized
INFO - 2018-04-12 21:17:41 --> Language Class Initialized
INFO - 2018-04-12 21:17:41 --> Loader Class Initialized
INFO - 2018-04-12 21:17:41 --> Helper loaded: url_helper
INFO - 2018-04-12 21:17:41 --> Helper loaded: file_helper
INFO - 2018-04-12 21:17:41 --> Helper loaded: date_helper
INFO - 2018-04-12 21:17:41 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:17:41 --> Controller Class Initialized
INFO - 2018-04-12 21:17:41 --> Model Class Initialized
INFO - 2018-04-12 21:17:41 --> Final output sent to browser
DEBUG - 2018-04-12 21:17:41 --> Total execution time: 0.6528
INFO - 2018-04-12 21:17:41 --> Config Class Initialized
INFO - 2018-04-12 21:17:41 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:17:42 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:17:42 --> Utf8 Class Initialized
INFO - 2018-04-12 21:17:42 --> URI Class Initialized
INFO - 2018-04-12 21:17:42 --> Router Class Initialized
INFO - 2018-04-12 21:17:42 --> Output Class Initialized
INFO - 2018-04-12 21:17:42 --> Security Class Initialized
DEBUG - 2018-04-12 21:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:17:42 --> Input Class Initialized
INFO - 2018-04-12 21:17:42 --> Language Class Initialized
INFO - 2018-04-12 21:17:42 --> Loader Class Initialized
INFO - 2018-04-12 21:17:42 --> Helper loaded: url_helper
INFO - 2018-04-12 21:17:42 --> Helper loaded: file_helper
INFO - 2018-04-12 21:17:42 --> Helper loaded: date_helper
INFO - 2018-04-12 21:17:42 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:17:42 --> Controller Class Initialized
INFO - 2018-04-12 21:17:42 --> Model Class Initialized
INFO - 2018-04-12 21:17:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 21:17:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 21:17:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 21:17:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 21:17:42 --> Final output sent to browser
DEBUG - 2018-04-12 21:17:42 --> Total execution time: 0.7486
INFO - 2018-04-12 21:17:42 --> Config Class Initialized
INFO - 2018-04-12 21:17:42 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:17:42 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:17:42 --> Utf8 Class Initialized
INFO - 2018-04-12 21:17:42 --> URI Class Initialized
INFO - 2018-04-12 21:17:42 --> Router Class Initialized
INFO - 2018-04-12 21:17:42 --> Output Class Initialized
INFO - 2018-04-12 21:17:42 --> Security Class Initialized
DEBUG - 2018-04-12 21:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:17:42 --> Input Class Initialized
INFO - 2018-04-12 21:17:42 --> Language Class Initialized
ERROR - 2018-04-12 21:17:43 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 21:17:43 --> Config Class Initialized
INFO - 2018-04-12 21:17:43 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:17:43 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:17:43 --> Utf8 Class Initialized
INFO - 2018-04-12 21:17:43 --> URI Class Initialized
INFO - 2018-04-12 21:17:43 --> Router Class Initialized
INFO - 2018-04-12 21:17:43 --> Output Class Initialized
INFO - 2018-04-12 21:17:43 --> Security Class Initialized
DEBUG - 2018-04-12 21:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:17:43 --> Input Class Initialized
INFO - 2018-04-12 21:17:43 --> Language Class Initialized
ERROR - 2018-04-12 21:17:43 --> 404 Page Not Found: Assets/img
INFO - 2018-04-12 21:17:54 --> Config Class Initialized
INFO - 2018-04-12 21:17:54 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:17:54 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:17:54 --> Utf8 Class Initialized
INFO - 2018-04-12 21:17:54 --> URI Class Initialized
INFO - 2018-04-12 21:17:54 --> Router Class Initialized
INFO - 2018-04-12 21:17:54 --> Output Class Initialized
INFO - 2018-04-12 21:17:54 --> Security Class Initialized
DEBUG - 2018-04-12 21:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:17:55 --> Input Class Initialized
INFO - 2018-04-12 21:17:55 --> Language Class Initialized
INFO - 2018-04-12 21:17:55 --> Loader Class Initialized
INFO - 2018-04-12 21:17:55 --> Helper loaded: url_helper
INFO - 2018-04-12 21:17:55 --> Helper loaded: file_helper
INFO - 2018-04-12 21:17:55 --> Helper loaded: date_helper
INFO - 2018-04-12 21:17:55 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:17:55 --> Controller Class Initialized
INFO - 2018-04-12 21:17:55 --> Model Class Initialized
INFO - 2018-04-12 21:17:55 --> Config Class Initialized
INFO - 2018-04-12 21:17:55 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:17:55 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:17:55 --> Utf8 Class Initialized
INFO - 2018-04-12 21:17:55 --> URI Class Initialized
INFO - 2018-04-12 21:17:55 --> Router Class Initialized
INFO - 2018-04-12 21:17:55 --> Output Class Initialized
INFO - 2018-04-12 21:17:55 --> Security Class Initialized
DEBUG - 2018-04-12 21:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:17:55 --> Input Class Initialized
INFO - 2018-04-12 21:17:55 --> Language Class Initialized
INFO - 2018-04-12 21:17:55 --> Loader Class Initialized
INFO - 2018-04-12 21:17:55 --> Helper loaded: url_helper
INFO - 2018-04-12 21:17:55 --> Helper loaded: file_helper
INFO - 2018-04-12 21:17:55 --> Helper loaded: date_helper
INFO - 2018-04-12 21:17:55 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:17:55 --> Controller Class Initialized
INFO - 2018-04-12 21:17:55 --> Model Class Initialized
INFO - 2018-04-12 21:17:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 21:17:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 21:17:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 21:17:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 21:17:55 --> Final output sent to browser
DEBUG - 2018-04-12 21:17:55 --> Total execution time: 0.5491
INFO - 2018-04-12 21:17:56 --> Config Class Initialized
INFO - 2018-04-12 21:17:56 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:17:56 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:17:56 --> Utf8 Class Initialized
INFO - 2018-04-12 21:17:56 --> URI Class Initialized
INFO - 2018-04-12 21:17:56 --> Router Class Initialized
INFO - 2018-04-12 21:17:56 --> Output Class Initialized
INFO - 2018-04-12 21:17:56 --> Security Class Initialized
DEBUG - 2018-04-12 21:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:17:56 --> Input Class Initialized
INFO - 2018-04-12 21:17:56 --> Language Class Initialized
ERROR - 2018-04-12 21:17:56 --> 404 Page Not Found: Welcome/css
INFO - 2018-04-12 21:18:04 --> Config Class Initialized
INFO - 2018-04-12 21:18:04 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:18:04 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:18:04 --> Utf8 Class Initialized
INFO - 2018-04-12 21:18:04 --> URI Class Initialized
INFO - 2018-04-12 21:18:04 --> Router Class Initialized
INFO - 2018-04-12 21:18:04 --> Output Class Initialized
INFO - 2018-04-12 21:18:04 --> Security Class Initialized
DEBUG - 2018-04-12 21:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:18:04 --> Input Class Initialized
INFO - 2018-04-12 21:18:04 --> Language Class Initialized
INFO - 2018-04-12 21:18:04 --> Loader Class Initialized
INFO - 2018-04-12 21:18:04 --> Helper loaded: url_helper
INFO - 2018-04-12 21:18:04 --> Helper loaded: file_helper
INFO - 2018-04-12 21:18:04 --> Helper loaded: date_helper
INFO - 2018-04-12 21:18:04 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:18:04 --> Controller Class Initialized
INFO - 2018-04-12 21:18:04 --> Model Class Initialized
INFO - 2018-04-12 21:18:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 21:18:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 21:18:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 21:18:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 21:18:04 --> Final output sent to browser
DEBUG - 2018-04-12 21:18:04 --> Total execution time: 0.3393
INFO - 2018-04-12 21:18:04 --> Config Class Initialized
INFO - 2018-04-12 21:18:04 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:18:04 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:18:04 --> Utf8 Class Initialized
INFO - 2018-04-12 21:18:04 --> URI Class Initialized
INFO - 2018-04-12 21:18:04 --> Router Class Initialized
INFO - 2018-04-12 21:18:04 --> Output Class Initialized
INFO - 2018-04-12 21:18:04 --> Security Class Initialized
DEBUG - 2018-04-12 21:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:18:04 --> Input Class Initialized
INFO - 2018-04-12 21:18:04 --> Language Class Initialized
ERROR - 2018-04-12 21:18:04 --> 404 Page Not Found: Welcome/css
INFO - 2018-04-12 21:18:08 --> Config Class Initialized
INFO - 2018-04-12 21:18:08 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:18:08 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:18:08 --> Utf8 Class Initialized
INFO - 2018-04-12 21:18:08 --> URI Class Initialized
INFO - 2018-04-12 21:18:08 --> Router Class Initialized
INFO - 2018-04-12 21:18:08 --> Output Class Initialized
INFO - 2018-04-12 21:18:08 --> Security Class Initialized
DEBUG - 2018-04-12 21:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:18:08 --> Input Class Initialized
INFO - 2018-04-12 21:18:08 --> Language Class Initialized
INFO - 2018-04-12 21:18:08 --> Loader Class Initialized
INFO - 2018-04-12 21:18:08 --> Helper loaded: url_helper
INFO - 2018-04-12 21:18:08 --> Helper loaded: file_helper
INFO - 2018-04-12 21:18:08 --> Helper loaded: date_helper
INFO - 2018-04-12 21:18:08 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:18:08 --> Controller Class Initialized
INFO - 2018-04-12 21:18:08 --> Model Class Initialized
INFO - 2018-04-12 21:18:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 21:18:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 21:18:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 21:18:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 21:18:08 --> Final output sent to browser
DEBUG - 2018-04-12 21:18:08 --> Total execution time: 0.3394
INFO - 2018-04-12 21:18:08 --> Config Class Initialized
INFO - 2018-04-12 21:18:08 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:18:08 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:18:08 --> Utf8 Class Initialized
INFO - 2018-04-12 21:18:08 --> URI Class Initialized
INFO - 2018-04-12 21:18:08 --> Router Class Initialized
INFO - 2018-04-12 21:18:08 --> Output Class Initialized
INFO - 2018-04-12 21:18:08 --> Security Class Initialized
DEBUG - 2018-04-12 21:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:18:08 --> Input Class Initialized
INFO - 2018-04-12 21:18:08 --> Language Class Initialized
ERROR - 2018-04-12 21:18:08 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 21:18:16 --> Config Class Initialized
INFO - 2018-04-12 21:18:16 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:18:16 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:18:16 --> Utf8 Class Initialized
INFO - 2018-04-12 21:18:16 --> URI Class Initialized
INFO - 2018-04-12 21:18:16 --> Router Class Initialized
INFO - 2018-04-12 21:18:16 --> Output Class Initialized
INFO - 2018-04-12 21:18:16 --> Security Class Initialized
DEBUG - 2018-04-12 21:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:18:16 --> Input Class Initialized
INFO - 2018-04-12 21:18:16 --> Language Class Initialized
INFO - 2018-04-12 21:18:16 --> Loader Class Initialized
INFO - 2018-04-12 21:18:16 --> Helper loaded: url_helper
INFO - 2018-04-12 21:18:16 --> Helper loaded: file_helper
INFO - 2018-04-12 21:18:16 --> Helper loaded: date_helper
INFO - 2018-04-12 21:18:16 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:18:16 --> Controller Class Initialized
DEBUG - 2018-04-12 21:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-12 21:18:17 --> Config Class Initialized
INFO - 2018-04-12 21:18:17 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:18:17 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:18:17 --> Utf8 Class Initialized
INFO - 2018-04-12 21:18:17 --> URI Class Initialized
INFO - 2018-04-12 21:18:17 --> Router Class Initialized
INFO - 2018-04-12 21:18:17 --> Output Class Initialized
INFO - 2018-04-12 21:18:17 --> Security Class Initialized
DEBUG - 2018-04-12 21:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:18:17 --> Input Class Initialized
INFO - 2018-04-12 21:18:17 --> Language Class Initialized
INFO - 2018-04-12 21:18:17 --> Loader Class Initialized
INFO - 2018-04-12 21:18:17 --> Helper loaded: url_helper
INFO - 2018-04-12 21:18:17 --> Helper loaded: file_helper
INFO - 2018-04-12 21:18:17 --> Helper loaded: date_helper
INFO - 2018-04-12 21:18:17 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:18:17 --> Controller Class Initialized
INFO - 2018-04-12 21:18:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 21:18:17 --> Final output sent to browser
DEBUG - 2018-04-12 21:18:17 --> Total execution time: 0.2903
INFO - 2018-04-12 21:19:24 --> Config Class Initialized
INFO - 2018-04-12 21:19:24 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:19:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:19:24 --> Utf8 Class Initialized
INFO - 2018-04-12 21:19:24 --> URI Class Initialized
INFO - 2018-04-12 21:19:24 --> Router Class Initialized
INFO - 2018-04-12 21:19:24 --> Output Class Initialized
INFO - 2018-04-12 21:19:24 --> Security Class Initialized
DEBUG - 2018-04-12 21:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:19:24 --> Input Class Initialized
INFO - 2018-04-12 21:19:24 --> Language Class Initialized
INFO - 2018-04-12 21:19:24 --> Loader Class Initialized
INFO - 2018-04-12 21:19:24 --> Helper loaded: url_helper
INFO - 2018-04-12 21:19:24 --> Helper loaded: file_helper
INFO - 2018-04-12 21:19:24 --> Helper loaded: date_helper
INFO - 2018-04-12 21:19:24 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:19:24 --> Controller Class Initialized
INFO - 2018-04-12 21:19:24 --> Model Class Initialized
INFO - 2018-04-12 21:19:25 --> Final output sent to browser
DEBUG - 2018-04-12 21:19:25 --> Total execution time: 0.5944
INFO - 2018-04-12 21:19:25 --> Config Class Initialized
INFO - 2018-04-12 21:19:25 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:19:25 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:19:25 --> Utf8 Class Initialized
INFO - 2018-04-12 21:19:25 --> URI Class Initialized
INFO - 2018-04-12 21:19:25 --> Router Class Initialized
INFO - 2018-04-12 21:19:25 --> Output Class Initialized
INFO - 2018-04-12 21:19:25 --> Security Class Initialized
DEBUG - 2018-04-12 21:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:19:25 --> Input Class Initialized
INFO - 2018-04-12 21:19:25 --> Language Class Initialized
INFO - 2018-04-12 21:19:25 --> Loader Class Initialized
INFO - 2018-04-12 21:19:25 --> Helper loaded: url_helper
INFO - 2018-04-12 21:19:25 --> Helper loaded: file_helper
INFO - 2018-04-12 21:19:25 --> Helper loaded: date_helper
INFO - 2018-04-12 21:19:25 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:19:25 --> Controller Class Initialized
INFO - 2018-04-12 21:19:25 --> Model Class Initialized
INFO - 2018-04-12 21:19:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 21:19:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 21:19:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 21:19:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 21:19:26 --> Final output sent to browser
DEBUG - 2018-04-12 21:19:26 --> Total execution time: 0.9606
INFO - 2018-04-12 21:19:28 --> Config Class Initialized
INFO - 2018-04-12 21:19:28 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:19:28 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:19:28 --> Utf8 Class Initialized
INFO - 2018-04-12 21:19:28 --> URI Class Initialized
INFO - 2018-04-12 21:19:28 --> Router Class Initialized
INFO - 2018-04-12 21:19:28 --> Output Class Initialized
INFO - 2018-04-12 21:19:28 --> Security Class Initialized
DEBUG - 2018-04-12 21:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:19:28 --> Input Class Initialized
INFO - 2018-04-12 21:19:28 --> Language Class Initialized
INFO - 2018-04-12 21:19:28 --> Loader Class Initialized
INFO - 2018-04-12 21:19:28 --> Helper loaded: url_helper
INFO - 2018-04-12 21:19:28 --> Helper loaded: file_helper
INFO - 2018-04-12 21:19:28 --> Helper loaded: date_helper
INFO - 2018-04-12 21:19:28 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:19:28 --> Controller Class Initialized
INFO - 2018-04-12 21:19:28 --> Model Class Initialized
INFO - 2018-04-12 21:19:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 21:19:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-12 21:19:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 21:19:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 21:19:28 --> Final output sent to browser
DEBUG - 2018-04-12 21:19:28 --> Total execution time: 0.4490
INFO - 2018-04-12 21:19:38 --> Config Class Initialized
INFO - 2018-04-12 21:19:38 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:19:38 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:19:38 --> Utf8 Class Initialized
INFO - 2018-04-12 21:19:38 --> URI Class Initialized
INFO - 2018-04-12 21:19:38 --> Router Class Initialized
INFO - 2018-04-12 21:19:38 --> Output Class Initialized
INFO - 2018-04-12 21:19:38 --> Security Class Initialized
DEBUG - 2018-04-12 21:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:19:38 --> Input Class Initialized
INFO - 2018-04-12 21:19:38 --> Language Class Initialized
INFO - 2018-04-12 21:19:39 --> Loader Class Initialized
INFO - 2018-04-12 21:19:39 --> Helper loaded: url_helper
INFO - 2018-04-12 21:19:39 --> Helper loaded: file_helper
INFO - 2018-04-12 21:19:39 --> Helper loaded: date_helper
INFO - 2018-04-12 21:19:39 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:19:39 --> Controller Class Initialized
INFO - 2018-04-12 21:19:39 --> Model Class Initialized
INFO - 2018-04-12 21:19:39 --> Config Class Initialized
INFO - 2018-04-12 21:19:39 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:19:39 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:19:39 --> Utf8 Class Initialized
INFO - 2018-04-12 21:19:39 --> URI Class Initialized
INFO - 2018-04-12 21:19:39 --> Router Class Initialized
INFO - 2018-04-12 21:19:39 --> Output Class Initialized
INFO - 2018-04-12 21:19:39 --> Security Class Initialized
DEBUG - 2018-04-12 21:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:19:39 --> Input Class Initialized
INFO - 2018-04-12 21:19:39 --> Language Class Initialized
INFO - 2018-04-12 21:19:39 --> Loader Class Initialized
INFO - 2018-04-12 21:19:39 --> Helper loaded: url_helper
INFO - 2018-04-12 21:19:39 --> Helper loaded: file_helper
INFO - 2018-04-12 21:19:39 --> Helper loaded: date_helper
INFO - 2018-04-12 21:19:39 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:19:39 --> Controller Class Initialized
INFO - 2018-04-12 21:19:39 --> Model Class Initialized
INFO - 2018-04-12 21:19:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 21:19:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 21:19:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 21:19:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 21:19:39 --> Final output sent to browser
DEBUG - 2018-04-12 21:19:39 --> Total execution time: 0.6125
INFO - 2018-04-12 21:20:24 --> Config Class Initialized
INFO - 2018-04-12 21:20:24 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:20:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:20:24 --> Utf8 Class Initialized
INFO - 2018-04-12 21:20:24 --> URI Class Initialized
INFO - 2018-04-12 21:20:24 --> Router Class Initialized
INFO - 2018-04-12 21:20:24 --> Output Class Initialized
INFO - 2018-04-12 21:20:24 --> Security Class Initialized
DEBUG - 2018-04-12 21:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:20:24 --> Input Class Initialized
INFO - 2018-04-12 21:20:24 --> Language Class Initialized
INFO - 2018-04-12 21:20:24 --> Loader Class Initialized
INFO - 2018-04-12 21:20:24 --> Helper loaded: url_helper
INFO - 2018-04-12 21:20:24 --> Helper loaded: file_helper
INFO - 2018-04-12 21:20:24 --> Helper loaded: date_helper
INFO - 2018-04-12 21:20:24 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:20:24 --> Controller Class Initialized
INFO - 2018-04-12 21:20:24 --> Model Class Initialized
INFO - 2018-04-12 21:20:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 21:20:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 21:20:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 21:20:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 21:20:24 --> Final output sent to browser
DEBUG - 2018-04-12 21:20:24 --> Total execution time: 0.3516
INFO - 2018-04-12 21:20:27 --> Config Class Initialized
INFO - 2018-04-12 21:20:27 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:20:27 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:20:27 --> Utf8 Class Initialized
INFO - 2018-04-12 21:20:27 --> URI Class Initialized
INFO - 2018-04-12 21:20:27 --> Router Class Initialized
INFO - 2018-04-12 21:20:27 --> Output Class Initialized
INFO - 2018-04-12 21:20:27 --> Security Class Initialized
DEBUG - 2018-04-12 21:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:20:27 --> Input Class Initialized
INFO - 2018-04-12 21:20:27 --> Language Class Initialized
INFO - 2018-04-12 21:20:27 --> Loader Class Initialized
INFO - 2018-04-12 21:20:27 --> Helper loaded: url_helper
INFO - 2018-04-12 21:20:27 --> Helper loaded: file_helper
INFO - 2018-04-12 21:20:27 --> Helper loaded: date_helper
INFO - 2018-04-12 21:20:27 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:20:27 --> Controller Class Initialized
INFO - 2018-04-12 21:20:27 --> Model Class Initialized
INFO - 2018-04-12 21:20:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 21:20:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-12 21:20:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 21:20:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 21:20:27 --> Final output sent to browser
DEBUG - 2018-04-12 21:20:27 --> Total execution time: 0.3484
INFO - 2018-04-12 21:20:37 --> Config Class Initialized
INFO - 2018-04-12 21:20:37 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:20:37 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:20:37 --> Utf8 Class Initialized
INFO - 2018-04-12 21:20:37 --> URI Class Initialized
INFO - 2018-04-12 21:20:37 --> Router Class Initialized
INFO - 2018-04-12 21:20:37 --> Output Class Initialized
INFO - 2018-04-12 21:20:37 --> Security Class Initialized
DEBUG - 2018-04-12 21:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:20:37 --> Input Class Initialized
INFO - 2018-04-12 21:20:37 --> Language Class Initialized
INFO - 2018-04-12 21:20:37 --> Loader Class Initialized
INFO - 2018-04-12 21:20:37 --> Helper loaded: url_helper
INFO - 2018-04-12 21:20:37 --> Helper loaded: file_helper
INFO - 2018-04-12 21:20:37 --> Helper loaded: date_helper
INFO - 2018-04-12 21:20:37 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:20:37 --> Controller Class Initialized
INFO - 2018-04-12 21:20:37 --> Model Class Initialized
INFO - 2018-04-12 21:20:37 --> Config Class Initialized
INFO - 2018-04-12 21:20:37 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:20:37 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:20:37 --> Utf8 Class Initialized
INFO - 2018-04-12 21:20:37 --> URI Class Initialized
INFO - 2018-04-12 21:20:37 --> Router Class Initialized
INFO - 2018-04-12 21:20:38 --> Output Class Initialized
INFO - 2018-04-12 21:20:38 --> Security Class Initialized
DEBUG - 2018-04-12 21:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:20:38 --> Input Class Initialized
INFO - 2018-04-12 21:20:38 --> Language Class Initialized
INFO - 2018-04-12 21:20:38 --> Loader Class Initialized
INFO - 2018-04-12 21:20:38 --> Helper loaded: url_helper
INFO - 2018-04-12 21:20:38 --> Helper loaded: file_helper
INFO - 2018-04-12 21:20:38 --> Helper loaded: date_helper
INFO - 2018-04-12 21:20:38 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:20:38 --> Controller Class Initialized
INFO - 2018-04-12 21:20:38 --> Model Class Initialized
INFO - 2018-04-12 21:20:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 21:20:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 21:20:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 21:20:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 21:20:38 --> Final output sent to browser
DEBUG - 2018-04-12 21:20:38 --> Total execution time: 0.5660
INFO - 2018-04-12 21:23:12 --> Config Class Initialized
INFO - 2018-04-12 21:23:12 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:23:12 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:23:12 --> Utf8 Class Initialized
INFO - 2018-04-12 21:23:12 --> URI Class Initialized
INFO - 2018-04-12 21:23:12 --> Router Class Initialized
INFO - 2018-04-12 21:23:12 --> Output Class Initialized
INFO - 2018-04-12 21:23:12 --> Security Class Initialized
DEBUG - 2018-04-12 21:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:23:12 --> Input Class Initialized
INFO - 2018-04-12 21:23:12 --> Language Class Initialized
INFO - 2018-04-12 21:23:12 --> Loader Class Initialized
INFO - 2018-04-12 21:23:12 --> Helper loaded: url_helper
INFO - 2018-04-12 21:23:12 --> Helper loaded: file_helper
INFO - 2018-04-12 21:23:12 --> Helper loaded: date_helper
INFO - 2018-04-12 21:23:13 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:23:13 --> Controller Class Initialized
INFO - 2018-04-12 21:23:13 --> Model Class Initialized
INFO - 2018-04-12 21:23:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 21:23:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 21:23:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 21:23:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 21:23:13 --> Final output sent to browser
DEBUG - 2018-04-12 21:23:13 --> Total execution time: 0.3572
INFO - 2018-04-12 21:23:15 --> Config Class Initialized
INFO - 2018-04-12 21:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:23:15 --> Utf8 Class Initialized
INFO - 2018-04-12 21:23:15 --> URI Class Initialized
INFO - 2018-04-12 21:23:15 --> Router Class Initialized
INFO - 2018-04-12 21:23:15 --> Output Class Initialized
INFO - 2018-04-12 21:23:15 --> Security Class Initialized
DEBUG - 2018-04-12 21:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:23:15 --> Input Class Initialized
INFO - 2018-04-12 21:23:15 --> Language Class Initialized
INFO - 2018-04-12 21:23:15 --> Loader Class Initialized
INFO - 2018-04-12 21:23:15 --> Helper loaded: url_helper
INFO - 2018-04-12 21:23:15 --> Helper loaded: file_helper
INFO - 2018-04-12 21:23:15 --> Helper loaded: date_helper
INFO - 2018-04-12 21:23:15 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:23:15 --> Controller Class Initialized
INFO - 2018-04-12 21:23:15 --> Model Class Initialized
INFO - 2018-04-12 21:23:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 21:23:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-12 21:23:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 21:23:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 21:23:15 --> Final output sent to browser
DEBUG - 2018-04-12 21:23:15 --> Total execution time: 0.3899
INFO - 2018-04-12 21:23:17 --> Config Class Initialized
INFO - 2018-04-12 21:23:17 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:23:18 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:23:18 --> Utf8 Class Initialized
INFO - 2018-04-12 21:23:18 --> URI Class Initialized
INFO - 2018-04-12 21:23:18 --> Router Class Initialized
INFO - 2018-04-12 21:23:18 --> Output Class Initialized
INFO - 2018-04-12 21:23:18 --> Security Class Initialized
DEBUG - 2018-04-12 21:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:23:18 --> Input Class Initialized
INFO - 2018-04-12 21:23:18 --> Language Class Initialized
INFO - 2018-04-12 21:23:18 --> Loader Class Initialized
INFO - 2018-04-12 21:23:18 --> Helper loaded: url_helper
INFO - 2018-04-12 21:23:18 --> Helper loaded: file_helper
INFO - 2018-04-12 21:23:18 --> Helper loaded: date_helper
INFO - 2018-04-12 21:23:18 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:23:18 --> Controller Class Initialized
INFO - 2018-04-12 21:23:18 --> Model Class Initialized
INFO - 2018-04-12 21:23:18 --> Config Class Initialized
INFO - 2018-04-12 21:23:18 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:23:18 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:23:18 --> Utf8 Class Initialized
INFO - 2018-04-12 21:23:18 --> URI Class Initialized
INFO - 2018-04-12 21:23:18 --> Router Class Initialized
INFO - 2018-04-12 21:23:18 --> Output Class Initialized
INFO - 2018-04-12 21:23:18 --> Security Class Initialized
DEBUG - 2018-04-12 21:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:23:18 --> Input Class Initialized
INFO - 2018-04-12 21:23:18 --> Language Class Initialized
INFO - 2018-04-12 21:23:18 --> Loader Class Initialized
INFO - 2018-04-12 21:23:18 --> Helper loaded: url_helper
INFO - 2018-04-12 21:23:18 --> Helper loaded: file_helper
INFO - 2018-04-12 21:23:18 --> Helper loaded: date_helper
INFO - 2018-04-12 21:23:18 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:23:18 --> Controller Class Initialized
INFO - 2018-04-12 21:23:18 --> Model Class Initialized
INFO - 2018-04-12 21:23:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 21:23:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 21:23:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 21:23:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 21:23:19 --> Final output sent to browser
DEBUG - 2018-04-12 21:23:19 --> Total execution time: 0.7211
INFO - 2018-04-12 21:26:59 --> Config Class Initialized
INFO - 2018-04-12 21:26:59 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:26:59 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:26:59 --> Utf8 Class Initialized
INFO - 2018-04-12 21:26:59 --> URI Class Initialized
INFO - 2018-04-12 21:26:59 --> Router Class Initialized
INFO - 2018-04-12 21:26:59 --> Output Class Initialized
INFO - 2018-04-12 21:26:59 --> Security Class Initialized
DEBUG - 2018-04-12 21:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:26:59 --> Input Class Initialized
INFO - 2018-04-12 21:26:59 --> Language Class Initialized
INFO - 2018-04-12 21:26:59 --> Loader Class Initialized
INFO - 2018-04-12 21:26:59 --> Helper loaded: url_helper
INFO - 2018-04-12 21:26:59 --> Helper loaded: file_helper
INFO - 2018-04-12 21:27:00 --> Helper loaded: date_helper
INFO - 2018-04-12 21:27:00 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:27:00 --> Controller Class Initialized
INFO - 2018-04-12 21:27:00 --> Model Class Initialized
INFO - 2018-04-12 21:27:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 21:27:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-12 21:27:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 21:27:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 21:27:00 --> Final output sent to browser
DEBUG - 2018-04-12 21:27:00 --> Total execution time: 0.8863
INFO - 2018-04-12 21:27:31 --> Config Class Initialized
INFO - 2018-04-12 21:27:31 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:27:31 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:27:31 --> Utf8 Class Initialized
INFO - 2018-04-12 21:27:31 --> URI Class Initialized
INFO - 2018-04-12 21:27:31 --> Router Class Initialized
INFO - 2018-04-12 21:27:31 --> Output Class Initialized
INFO - 2018-04-12 21:27:31 --> Security Class Initialized
DEBUG - 2018-04-12 21:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:27:31 --> Input Class Initialized
INFO - 2018-04-12 21:27:31 --> Language Class Initialized
INFO - 2018-04-12 21:27:31 --> Loader Class Initialized
INFO - 2018-04-12 21:27:31 --> Helper loaded: url_helper
INFO - 2018-04-12 21:27:31 --> Helper loaded: file_helper
INFO - 2018-04-12 21:27:31 --> Helper loaded: date_helper
INFO - 2018-04-12 21:27:31 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:27:31 --> Controller Class Initialized
DEBUG - 2018-04-12 21:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-12 21:27:31 --> Config Class Initialized
INFO - 2018-04-12 21:27:31 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:27:31 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:27:31 --> Utf8 Class Initialized
INFO - 2018-04-12 21:27:31 --> URI Class Initialized
INFO - 2018-04-12 21:27:31 --> Router Class Initialized
INFO - 2018-04-12 21:27:32 --> Output Class Initialized
INFO - 2018-04-12 21:27:32 --> Security Class Initialized
DEBUG - 2018-04-12 21:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:27:32 --> Input Class Initialized
INFO - 2018-04-12 21:27:32 --> Language Class Initialized
INFO - 2018-04-12 21:27:32 --> Loader Class Initialized
INFO - 2018-04-12 21:27:32 --> Helper loaded: url_helper
INFO - 2018-04-12 21:27:32 --> Helper loaded: file_helper
INFO - 2018-04-12 21:27:32 --> Helper loaded: date_helper
INFO - 2018-04-12 21:27:32 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:27:32 --> Controller Class Initialized
INFO - 2018-04-12 21:27:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 21:27:32 --> Final output sent to browser
DEBUG - 2018-04-12 21:27:32 --> Total execution time: 0.2937
INFO - 2018-04-12 21:27:44 --> Config Class Initialized
INFO - 2018-04-12 21:27:44 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:27:44 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:27:44 --> Utf8 Class Initialized
INFO - 2018-04-12 21:27:44 --> URI Class Initialized
INFO - 2018-04-12 21:27:44 --> Router Class Initialized
INFO - 2018-04-12 21:27:44 --> Output Class Initialized
INFO - 2018-04-12 21:27:44 --> Security Class Initialized
DEBUG - 2018-04-12 21:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:27:44 --> Input Class Initialized
INFO - 2018-04-12 21:27:44 --> Language Class Initialized
INFO - 2018-04-12 21:27:44 --> Loader Class Initialized
INFO - 2018-04-12 21:27:44 --> Helper loaded: url_helper
INFO - 2018-04-12 21:27:44 --> Helper loaded: file_helper
INFO - 2018-04-12 21:27:44 --> Helper loaded: date_helper
INFO - 2018-04-12 21:27:44 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:27:44 --> Controller Class Initialized
INFO - 2018-04-12 21:27:44 --> Model Class Initialized
INFO - 2018-04-12 21:27:44 --> Final output sent to browser
DEBUG - 2018-04-12 21:27:44 --> Total execution time: 0.3018
INFO - 2018-04-12 21:27:44 --> Config Class Initialized
INFO - 2018-04-12 21:27:44 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:27:44 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:27:44 --> Utf8 Class Initialized
INFO - 2018-04-12 21:27:44 --> URI Class Initialized
INFO - 2018-04-12 21:27:44 --> Router Class Initialized
INFO - 2018-04-12 21:27:44 --> Output Class Initialized
INFO - 2018-04-12 21:27:44 --> Security Class Initialized
DEBUG - 2018-04-12 21:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:27:44 --> Input Class Initialized
INFO - 2018-04-12 21:27:44 --> Language Class Initialized
INFO - 2018-04-12 21:27:44 --> Loader Class Initialized
INFO - 2018-04-12 21:27:44 --> Helper loaded: url_helper
INFO - 2018-04-12 21:27:44 --> Helper loaded: file_helper
INFO - 2018-04-12 21:27:44 --> Helper loaded: date_helper
INFO - 2018-04-12 21:27:44 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:27:44 --> Controller Class Initialized
INFO - 2018-04-12 21:27:44 --> Model Class Initialized
INFO - 2018-04-12 21:27:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 21:27:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 21:27:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 21:27:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 21:27:44 --> Final output sent to browser
DEBUG - 2018-04-12 21:27:44 --> Total execution time: 0.3423
INFO - 2018-04-12 21:27:44 --> Config Class Initialized
INFO - 2018-04-12 21:27:44 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:27:44 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:27:44 --> Utf8 Class Initialized
INFO - 2018-04-12 21:27:45 --> URI Class Initialized
INFO - 2018-04-12 21:27:45 --> Router Class Initialized
INFO - 2018-04-12 21:27:45 --> Output Class Initialized
INFO - 2018-04-12 21:27:45 --> Security Class Initialized
DEBUG - 2018-04-12 21:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:27:45 --> Input Class Initialized
INFO - 2018-04-12 21:27:45 --> Language Class Initialized
ERROR - 2018-04-12 21:27:45 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-12 21:28:00 --> Config Class Initialized
INFO - 2018-04-12 21:28:01 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:28:01 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:28:01 --> Utf8 Class Initialized
INFO - 2018-04-12 21:28:01 --> URI Class Initialized
INFO - 2018-04-12 21:28:01 --> Router Class Initialized
INFO - 2018-04-12 21:28:01 --> Output Class Initialized
INFO - 2018-04-12 21:28:01 --> Security Class Initialized
DEBUG - 2018-04-12 21:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:28:01 --> Input Class Initialized
INFO - 2018-04-12 21:28:01 --> Language Class Initialized
INFO - 2018-04-12 21:28:01 --> Loader Class Initialized
INFO - 2018-04-12 21:28:01 --> Helper loaded: url_helper
INFO - 2018-04-12 21:28:01 --> Helper loaded: file_helper
INFO - 2018-04-12 21:28:01 --> Helper loaded: date_helper
INFO - 2018-04-12 21:28:01 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:28:01 --> Controller Class Initialized
INFO - 2018-04-12 21:28:01 --> Model Class Initialized
INFO - 2018-04-12 21:28:01 --> Config Class Initialized
INFO - 2018-04-12 21:28:01 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:28:01 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:28:01 --> Utf8 Class Initialized
INFO - 2018-04-12 21:28:01 --> URI Class Initialized
INFO - 2018-04-12 21:28:01 --> Router Class Initialized
INFO - 2018-04-12 21:28:01 --> Output Class Initialized
INFO - 2018-04-12 21:28:01 --> Security Class Initialized
DEBUG - 2018-04-12 21:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:28:01 --> Input Class Initialized
INFO - 2018-04-12 21:28:01 --> Language Class Initialized
INFO - 2018-04-12 21:28:01 --> Loader Class Initialized
INFO - 2018-04-12 21:28:01 --> Helper loaded: url_helper
INFO - 2018-04-12 21:28:01 --> Helper loaded: file_helper
INFO - 2018-04-12 21:28:01 --> Helper loaded: date_helper
INFO - 2018-04-12 21:28:01 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:28:01 --> Controller Class Initialized
INFO - 2018-04-12 21:28:01 --> Model Class Initialized
INFO - 2018-04-12 21:28:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-12 21:28:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-12 21:28:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-12 21:28:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-12 21:28:01 --> Final output sent to browser
DEBUG - 2018-04-12 21:28:01 --> Total execution time: 0.5793
INFO - 2018-04-12 21:28:02 --> Config Class Initialized
INFO - 2018-04-12 21:28:02 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:28:02 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:28:02 --> Utf8 Class Initialized
INFO - 2018-04-12 21:28:02 --> URI Class Initialized
INFO - 2018-04-12 21:28:02 --> Router Class Initialized
INFO - 2018-04-12 21:28:02 --> Output Class Initialized
INFO - 2018-04-12 21:28:02 --> Security Class Initialized
DEBUG - 2018-04-12 21:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:28:02 --> Input Class Initialized
INFO - 2018-04-12 21:28:02 --> Language Class Initialized
ERROR - 2018-04-12 21:28:02 --> 404 Page Not Found: Welcome/css
INFO - 2018-04-12 21:28:23 --> Config Class Initialized
INFO - 2018-04-12 21:28:23 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:28:23 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:28:23 --> Utf8 Class Initialized
INFO - 2018-04-12 21:28:23 --> URI Class Initialized
INFO - 2018-04-12 21:28:23 --> Router Class Initialized
INFO - 2018-04-12 21:28:23 --> Output Class Initialized
INFO - 2018-04-12 21:28:23 --> Security Class Initialized
DEBUG - 2018-04-12 21:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:28:23 --> Input Class Initialized
INFO - 2018-04-12 21:28:23 --> Language Class Initialized
INFO - 2018-04-12 21:28:23 --> Loader Class Initialized
INFO - 2018-04-12 21:28:23 --> Helper loaded: url_helper
INFO - 2018-04-12 21:28:23 --> Helper loaded: file_helper
INFO - 2018-04-12 21:28:23 --> Helper loaded: date_helper
INFO - 2018-04-12 21:28:23 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:28:23 --> Controller Class Initialized
DEBUG - 2018-04-12 21:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-12 21:28:23 --> Config Class Initialized
INFO - 2018-04-12 21:28:23 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:28:23 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:28:23 --> Utf8 Class Initialized
INFO - 2018-04-12 21:28:23 --> URI Class Initialized
INFO - 2018-04-12 21:28:23 --> Router Class Initialized
INFO - 2018-04-12 21:28:23 --> Output Class Initialized
INFO - 2018-04-12 21:28:23 --> Security Class Initialized
DEBUG - 2018-04-12 21:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:28:23 --> Input Class Initialized
INFO - 2018-04-12 21:28:23 --> Language Class Initialized
INFO - 2018-04-12 21:28:23 --> Loader Class Initialized
INFO - 2018-04-12 21:28:23 --> Helper loaded: url_helper
INFO - 2018-04-12 21:28:23 --> Helper loaded: file_helper
INFO - 2018-04-12 21:28:23 --> Helper loaded: date_helper
INFO - 2018-04-12 21:28:23 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:28:23 --> Controller Class Initialized
INFO - 2018-04-12 21:28:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 21:28:23 --> Final output sent to browser
DEBUG - 2018-04-12 21:28:23 --> Total execution time: 0.2931
INFO - 2018-04-12 21:28:42 --> Config Class Initialized
INFO - 2018-04-12 21:28:42 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:28:42 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:28:43 --> Utf8 Class Initialized
INFO - 2018-04-12 21:28:43 --> URI Class Initialized
INFO - 2018-04-12 21:28:43 --> Router Class Initialized
INFO - 2018-04-12 21:28:43 --> Output Class Initialized
INFO - 2018-04-12 21:28:43 --> Security Class Initialized
DEBUG - 2018-04-12 21:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:28:43 --> Input Class Initialized
INFO - 2018-04-12 21:28:43 --> Language Class Initialized
INFO - 2018-04-12 21:28:43 --> Loader Class Initialized
INFO - 2018-04-12 21:28:43 --> Helper loaded: url_helper
INFO - 2018-04-12 21:28:43 --> Helper loaded: file_helper
INFO - 2018-04-12 21:28:43 --> Helper loaded: date_helper
INFO - 2018-04-12 21:28:43 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:28:43 --> Controller Class Initialized
INFO - 2018-04-12 21:28:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-12 21:28:43 --> Final output sent to browser
DEBUG - 2018-04-12 21:28:43 --> Total execution time: 0.6356
INFO - 2018-04-12 21:29:24 --> Config Class Initialized
INFO - 2018-04-12 21:29:24 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:29:24 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:29:24 --> Utf8 Class Initialized
INFO - 2018-04-12 21:29:24 --> URI Class Initialized
INFO - 2018-04-12 21:29:24 --> Router Class Initialized
INFO - 2018-04-12 21:29:24 --> Output Class Initialized
INFO - 2018-04-12 21:29:24 --> Security Class Initialized
DEBUG - 2018-04-12 21:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:29:24 --> Input Class Initialized
INFO - 2018-04-12 21:29:24 --> Language Class Initialized
INFO - 2018-04-12 21:29:24 --> Loader Class Initialized
INFO - 2018-04-12 21:29:24 --> Helper loaded: url_helper
INFO - 2018-04-12 21:29:24 --> Helper loaded: file_helper
INFO - 2018-04-12 21:29:24 --> Helper loaded: date_helper
INFO - 2018-04-12 21:29:24 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:29:24 --> Controller Class Initialized
INFO - 2018-04-12 21:29:24 --> Model Class Initialized
INFO - 2018-04-12 21:29:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 21:29:24 --> Final output sent to browser
DEBUG - 2018-04-12 21:29:24 --> Total execution time: 0.4346
INFO - 2018-04-12 21:30:03 --> Config Class Initialized
INFO - 2018-04-12 21:30:03 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:30:03 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:30:03 --> Utf8 Class Initialized
INFO - 2018-04-12 21:30:03 --> URI Class Initialized
INFO - 2018-04-12 21:30:03 --> Router Class Initialized
INFO - 2018-04-12 21:30:03 --> Output Class Initialized
INFO - 2018-04-12 21:30:03 --> Security Class Initialized
DEBUG - 2018-04-12 21:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:30:03 --> Input Class Initialized
INFO - 2018-04-12 21:30:03 --> Language Class Initialized
INFO - 2018-04-12 21:30:03 --> Loader Class Initialized
INFO - 2018-04-12 21:30:03 --> Helper loaded: url_helper
INFO - 2018-04-12 21:30:03 --> Helper loaded: file_helper
INFO - 2018-04-12 21:30:03 --> Helper loaded: date_helper
INFO - 2018-04-12 21:30:03 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:30:03 --> Controller Class Initialized
INFO - 2018-04-12 21:30:03 --> Model Class Initialized
INFO - 2018-04-12 21:30:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 21:30:03 --> Final output sent to browser
DEBUG - 2018-04-12 21:30:03 --> Total execution time: 0.4080
INFO - 2018-04-12 21:30:11 --> Config Class Initialized
INFO - 2018-04-12 21:30:11 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:30:11 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:30:11 --> Utf8 Class Initialized
INFO - 2018-04-12 21:30:11 --> URI Class Initialized
INFO - 2018-04-12 21:30:11 --> Router Class Initialized
INFO - 2018-04-12 21:30:11 --> Output Class Initialized
INFO - 2018-04-12 21:30:11 --> Security Class Initialized
DEBUG - 2018-04-12 21:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:30:11 --> Input Class Initialized
INFO - 2018-04-12 21:30:11 --> Language Class Initialized
INFO - 2018-04-12 21:30:11 --> Loader Class Initialized
INFO - 2018-04-12 21:30:11 --> Helper loaded: url_helper
INFO - 2018-04-12 21:30:11 --> Helper loaded: file_helper
INFO - 2018-04-12 21:30:11 --> Helper loaded: date_helper
INFO - 2018-04-12 21:30:11 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:30:11 --> Controller Class Initialized
INFO - 2018-04-12 21:30:11 --> Config Class Initialized
INFO - 2018-04-12 21:30:11 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:30:11 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:30:11 --> Utf8 Class Initialized
INFO - 2018-04-12 21:30:11 --> URI Class Initialized
INFO - 2018-04-12 21:30:11 --> Router Class Initialized
INFO - 2018-04-12 21:30:11 --> Output Class Initialized
INFO - 2018-04-12 21:30:11 --> Security Class Initialized
DEBUG - 2018-04-12 21:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:30:12 --> Input Class Initialized
INFO - 2018-04-12 21:30:12 --> Language Class Initialized
INFO - 2018-04-12 21:30:12 --> Loader Class Initialized
INFO - 2018-04-12 21:30:12 --> Helper loaded: url_helper
INFO - 2018-04-12 21:30:12 --> Helper loaded: file_helper
INFO - 2018-04-12 21:30:12 --> Helper loaded: date_helper
INFO - 2018-04-12 21:30:12 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:30:12 --> Controller Class Initialized
INFO - 2018-04-12 21:30:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 21:30:12 --> Final output sent to browser
DEBUG - 2018-04-12 21:30:12 --> Total execution time: 0.2989
INFO - 2018-04-12 21:30:25 --> Config Class Initialized
INFO - 2018-04-12 21:30:25 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:30:25 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:30:25 --> Utf8 Class Initialized
INFO - 2018-04-12 21:30:25 --> URI Class Initialized
INFO - 2018-04-12 21:30:25 --> Router Class Initialized
INFO - 2018-04-12 21:30:25 --> Output Class Initialized
INFO - 2018-04-12 21:30:25 --> Security Class Initialized
DEBUG - 2018-04-12 21:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:30:25 --> Input Class Initialized
INFO - 2018-04-12 21:30:25 --> Language Class Initialized
INFO - 2018-04-12 21:30:25 --> Loader Class Initialized
INFO - 2018-04-12 21:30:25 --> Helper loaded: url_helper
INFO - 2018-04-12 21:30:25 --> Helper loaded: file_helper
INFO - 2018-04-12 21:30:25 --> Helper loaded: date_helper
INFO - 2018-04-12 21:30:25 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:30:25 --> Controller Class Initialized
INFO - 2018-04-12 21:30:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-12 21:30:25 --> Final output sent to browser
DEBUG - 2018-04-12 21:30:25 --> Total execution time: 0.2917
INFO - 2018-04-12 21:32:12 --> Config Class Initialized
INFO - 2018-04-12 21:32:12 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:32:12 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:32:12 --> Utf8 Class Initialized
INFO - 2018-04-12 21:32:12 --> URI Class Initialized
INFO - 2018-04-12 21:32:12 --> Router Class Initialized
INFO - 2018-04-12 21:32:12 --> Output Class Initialized
INFO - 2018-04-12 21:32:12 --> Security Class Initialized
DEBUG - 2018-04-12 21:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:32:12 --> Input Class Initialized
INFO - 2018-04-12 21:32:12 --> Language Class Initialized
INFO - 2018-04-12 21:32:12 --> Loader Class Initialized
INFO - 2018-04-12 21:32:12 --> Helper loaded: url_helper
INFO - 2018-04-12 21:32:12 --> Helper loaded: file_helper
INFO - 2018-04-12 21:32:12 --> Helper loaded: date_helper
INFO - 2018-04-12 21:32:12 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:32:12 --> Controller Class Initialized
INFO - 2018-04-12 21:32:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-12 21:32:12 --> Final output sent to browser
DEBUG - 2018-04-12 21:32:12 --> Total execution time: 0.3073
INFO - 2018-04-12 21:32:31 --> Config Class Initialized
INFO - 2018-04-12 21:32:31 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:32:31 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:32:31 --> Utf8 Class Initialized
INFO - 2018-04-12 21:32:31 --> URI Class Initialized
INFO - 2018-04-12 21:32:32 --> Router Class Initialized
INFO - 2018-04-12 21:32:32 --> Output Class Initialized
INFO - 2018-04-12 21:32:32 --> Security Class Initialized
DEBUG - 2018-04-12 21:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:32:32 --> Input Class Initialized
INFO - 2018-04-12 21:32:32 --> Language Class Initialized
INFO - 2018-04-12 21:32:32 --> Loader Class Initialized
INFO - 2018-04-12 21:32:32 --> Helper loaded: url_helper
INFO - 2018-04-12 21:32:32 --> Helper loaded: file_helper
INFO - 2018-04-12 21:32:32 --> Helper loaded: date_helper
INFO - 2018-04-12 21:32:32 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:32:32 --> Controller Class Initialized
INFO - 2018-04-12 21:32:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-12 21:32:32 --> Final output sent to browser
DEBUG - 2018-04-12 21:32:32 --> Total execution time: 0.3353
INFO - 2018-04-12 21:32:47 --> Config Class Initialized
INFO - 2018-04-12 21:32:47 --> Hooks Class Initialized
DEBUG - 2018-04-12 21:32:47 --> UTF-8 Support Enabled
INFO - 2018-04-12 21:32:47 --> Utf8 Class Initialized
INFO - 2018-04-12 21:32:47 --> URI Class Initialized
INFO - 2018-04-12 21:32:47 --> Router Class Initialized
INFO - 2018-04-12 21:32:47 --> Output Class Initialized
INFO - 2018-04-12 21:32:47 --> Security Class Initialized
DEBUG - 2018-04-12 21:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 21:32:47 --> Input Class Initialized
INFO - 2018-04-12 21:32:47 --> Language Class Initialized
INFO - 2018-04-12 21:32:47 --> Loader Class Initialized
INFO - 2018-04-12 21:32:47 --> Helper loaded: url_helper
INFO - 2018-04-12 21:32:47 --> Helper loaded: file_helper
INFO - 2018-04-12 21:32:47 --> Helper loaded: date_helper
INFO - 2018-04-12 21:32:47 --> Database Driver Class Initialized
DEBUG - 2018-04-12 21:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 21:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 21:32:47 --> Controller Class Initialized
INFO - 2018-04-12 21:32:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-12 21:32:47 --> Final output sent to browser
DEBUG - 2018-04-12 21:32:47 --> Total execution time: 0.3156
INFO - 2018-04-12 22:10:11 --> Config Class Initialized
INFO - 2018-04-12 22:10:11 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:10:11 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:10:11 --> Utf8 Class Initialized
INFO - 2018-04-12 22:10:11 --> URI Class Initialized
INFO - 2018-04-12 22:10:11 --> Router Class Initialized
INFO - 2018-04-12 22:10:11 --> Output Class Initialized
INFO - 2018-04-12 22:10:11 --> Security Class Initialized
DEBUG - 2018-04-12 22:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:10:11 --> Input Class Initialized
INFO - 2018-04-12 22:10:11 --> Language Class Initialized
INFO - 2018-04-12 22:10:11 --> Loader Class Initialized
INFO - 2018-04-12 22:10:11 --> Helper loaded: url_helper
INFO - 2018-04-12 22:10:11 --> Helper loaded: file_helper
INFO - 2018-04-12 22:10:11 --> Helper loaded: date_helper
INFO - 2018-04-12 22:10:11 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:10:11 --> Controller Class Initialized
INFO - 2018-04-12 22:10:11 --> Model Class Initialized
INFO - 2018-04-12 22:10:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 22:10:11 --> Final output sent to browser
DEBUG - 2018-04-12 22:10:11 --> Total execution time: 0.4019
INFO - 2018-04-12 22:25:11 --> Config Class Initialized
INFO - 2018-04-12 22:25:11 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:25:11 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:25:11 --> Utf8 Class Initialized
INFO - 2018-04-12 22:25:11 --> URI Class Initialized
INFO - 2018-04-12 22:25:11 --> Router Class Initialized
INFO - 2018-04-12 22:25:11 --> Output Class Initialized
INFO - 2018-04-12 22:25:11 --> Security Class Initialized
DEBUG - 2018-04-12 22:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:25:11 --> Input Class Initialized
INFO - 2018-04-12 22:25:11 --> Language Class Initialized
INFO - 2018-04-12 22:25:11 --> Loader Class Initialized
INFO - 2018-04-12 22:25:11 --> Helper loaded: url_helper
INFO - 2018-04-12 22:25:11 --> Helper loaded: file_helper
INFO - 2018-04-12 22:25:11 --> Helper loaded: date_helper
INFO - 2018-04-12 22:25:11 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:25:11 --> Controller Class Initialized
INFO - 2018-04-12 22:25:11 --> Model Class Initialized
INFO - 2018-04-12 22:25:11 --> Final output sent to browser
DEBUG - 2018-04-12 22:25:11 --> Total execution time: 0.3479
INFO - 2018-04-12 22:25:11 --> Config Class Initialized
INFO - 2018-04-12 22:25:12 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:25:12 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:25:12 --> Utf8 Class Initialized
INFO - 2018-04-12 22:25:12 --> URI Class Initialized
INFO - 2018-04-12 22:25:12 --> Router Class Initialized
INFO - 2018-04-12 22:25:12 --> Output Class Initialized
INFO - 2018-04-12 22:25:12 --> Security Class Initialized
DEBUG - 2018-04-12 22:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:25:12 --> Input Class Initialized
INFO - 2018-04-12 22:25:12 --> Language Class Initialized
INFO - 2018-04-12 22:25:12 --> Loader Class Initialized
INFO - 2018-04-12 22:25:12 --> Helper loaded: url_helper
INFO - 2018-04-12 22:25:12 --> Helper loaded: file_helper
INFO - 2018-04-12 22:25:12 --> Helper loaded: date_helper
INFO - 2018-04-12 22:25:12 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:25:12 --> Controller Class Initialized
INFO - 2018-04-12 22:25:12 --> Model Class Initialized
INFO - 2018-04-12 22:25:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:25:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 22:25:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:25:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:25:12 --> Final output sent to browser
DEBUG - 2018-04-12 22:25:12 --> Total execution time: 0.4483
INFO - 2018-04-12 22:25:17 --> Config Class Initialized
INFO - 2018-04-12 22:25:17 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:25:17 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:25:17 --> Utf8 Class Initialized
INFO - 2018-04-12 22:25:17 --> URI Class Initialized
INFO - 2018-04-12 22:25:17 --> Router Class Initialized
INFO - 2018-04-12 22:25:17 --> Output Class Initialized
INFO - 2018-04-12 22:25:17 --> Security Class Initialized
DEBUG - 2018-04-12 22:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:25:17 --> Input Class Initialized
INFO - 2018-04-12 22:25:17 --> Language Class Initialized
INFO - 2018-04-12 22:25:17 --> Loader Class Initialized
INFO - 2018-04-12 22:25:17 --> Helper loaded: url_helper
INFO - 2018-04-12 22:25:17 --> Helper loaded: file_helper
INFO - 2018-04-12 22:25:17 --> Helper loaded: date_helper
INFO - 2018-04-12 22:25:17 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:25:17 --> Controller Class Initialized
INFO - 2018-04-12 22:25:17 --> Model Class Initialized
INFO - 2018-04-12 22:25:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:25:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-12 22:25:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:25:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:25:17 --> Final output sent to browser
DEBUG - 2018-04-12 22:25:17 --> Total execution time: 0.3603
INFO - 2018-04-12 22:25:28 --> Config Class Initialized
INFO - 2018-04-12 22:25:28 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:25:28 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:25:28 --> Utf8 Class Initialized
INFO - 2018-04-12 22:25:28 --> URI Class Initialized
INFO - 2018-04-12 22:25:28 --> Router Class Initialized
INFO - 2018-04-12 22:25:28 --> Output Class Initialized
INFO - 2018-04-12 22:25:28 --> Security Class Initialized
DEBUG - 2018-04-12 22:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:25:28 --> Input Class Initialized
INFO - 2018-04-12 22:25:28 --> Language Class Initialized
INFO - 2018-04-12 22:25:28 --> Loader Class Initialized
INFO - 2018-04-12 22:25:28 --> Helper loaded: url_helper
INFO - 2018-04-12 22:25:28 --> Helper loaded: file_helper
INFO - 2018-04-12 22:25:28 --> Helper loaded: date_helper
INFO - 2018-04-12 22:25:28 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:25:28 --> Controller Class Initialized
INFO - 2018-04-12 22:25:28 --> Model Class Initialized
INFO - 2018-04-12 22:25:28 --> Config Class Initialized
INFO - 2018-04-12 22:25:28 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:25:28 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:25:28 --> Utf8 Class Initialized
INFO - 2018-04-12 22:25:28 --> URI Class Initialized
INFO - 2018-04-12 22:25:28 --> Router Class Initialized
INFO - 2018-04-12 22:25:28 --> Output Class Initialized
INFO - 2018-04-12 22:25:28 --> Security Class Initialized
DEBUG - 2018-04-12 22:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:25:28 --> Input Class Initialized
INFO - 2018-04-12 22:25:28 --> Language Class Initialized
INFO - 2018-04-12 22:25:28 --> Loader Class Initialized
INFO - 2018-04-12 22:25:28 --> Helper loaded: url_helper
INFO - 2018-04-12 22:25:28 --> Helper loaded: file_helper
INFO - 2018-04-12 22:25:28 --> Helper loaded: date_helper
INFO - 2018-04-12 22:25:28 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:25:28 --> Controller Class Initialized
INFO - 2018-04-12 22:25:28 --> Model Class Initialized
INFO - 2018-04-12 22:25:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:25:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 22:25:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:25:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:25:28 --> Final output sent to browser
DEBUG - 2018-04-12 22:25:28 --> Total execution time: 0.3581
INFO - 2018-04-12 22:25:42 --> Config Class Initialized
INFO - 2018-04-12 22:25:42 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:25:42 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:25:42 --> Utf8 Class Initialized
INFO - 2018-04-12 22:25:42 --> URI Class Initialized
INFO - 2018-04-12 22:25:42 --> Router Class Initialized
INFO - 2018-04-12 22:25:42 --> Output Class Initialized
INFO - 2018-04-12 22:25:42 --> Security Class Initialized
DEBUG - 2018-04-12 22:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:25:42 --> Input Class Initialized
INFO - 2018-04-12 22:25:42 --> Language Class Initialized
INFO - 2018-04-12 22:25:43 --> Loader Class Initialized
INFO - 2018-04-12 22:25:43 --> Helper loaded: url_helper
INFO - 2018-04-12 22:25:43 --> Helper loaded: file_helper
INFO - 2018-04-12 22:25:43 --> Helper loaded: date_helper
INFO - 2018-04-12 22:25:43 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:25:43 --> Controller Class Initialized
INFO - 2018-04-12 22:25:43 --> Model Class Initialized
INFO - 2018-04-12 22:25:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:25:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-12 22:25:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:25:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:25:43 --> Final output sent to browser
DEBUG - 2018-04-12 22:25:43 --> Total execution time: 0.3672
INFO - 2018-04-12 22:29:53 --> Config Class Initialized
INFO - 2018-04-12 22:29:53 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:29:53 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:29:53 --> Utf8 Class Initialized
INFO - 2018-04-12 22:29:53 --> URI Class Initialized
INFO - 2018-04-12 22:29:53 --> Router Class Initialized
INFO - 2018-04-12 22:29:53 --> Output Class Initialized
INFO - 2018-04-12 22:29:53 --> Security Class Initialized
DEBUG - 2018-04-12 22:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:29:53 --> Input Class Initialized
INFO - 2018-04-12 22:29:53 --> Language Class Initialized
INFO - 2018-04-12 22:29:53 --> Loader Class Initialized
INFO - 2018-04-12 22:29:53 --> Helper loaded: url_helper
INFO - 2018-04-12 22:29:53 --> Helper loaded: file_helper
INFO - 2018-04-12 22:29:53 --> Helper loaded: date_helper
INFO - 2018-04-12 22:29:53 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:29:53 --> Controller Class Initialized
INFO - 2018-04-12 22:29:53 --> Model Class Initialized
INFO - 2018-04-12 22:29:53 --> Config Class Initialized
INFO - 2018-04-12 22:29:53 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:29:54 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:29:54 --> Utf8 Class Initialized
INFO - 2018-04-12 22:29:54 --> URI Class Initialized
INFO - 2018-04-12 22:29:54 --> Router Class Initialized
INFO - 2018-04-12 22:29:54 --> Output Class Initialized
INFO - 2018-04-12 22:29:54 --> Security Class Initialized
DEBUG - 2018-04-12 22:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:29:54 --> Input Class Initialized
INFO - 2018-04-12 22:29:54 --> Language Class Initialized
INFO - 2018-04-12 22:29:54 --> Loader Class Initialized
INFO - 2018-04-12 22:29:54 --> Helper loaded: url_helper
INFO - 2018-04-12 22:29:54 --> Helper loaded: file_helper
INFO - 2018-04-12 22:29:54 --> Helper loaded: date_helper
INFO - 2018-04-12 22:29:54 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:29:54 --> Controller Class Initialized
INFO - 2018-04-12 22:29:54 --> Model Class Initialized
INFO - 2018-04-12 22:29:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:29:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 22:29:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:29:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:29:54 --> Final output sent to browser
DEBUG - 2018-04-12 22:29:54 --> Total execution time: 0.3925
INFO - 2018-04-12 22:29:59 --> Config Class Initialized
INFO - 2018-04-12 22:29:59 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:29:59 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:29:59 --> Utf8 Class Initialized
INFO - 2018-04-12 22:29:59 --> URI Class Initialized
INFO - 2018-04-12 22:29:59 --> Router Class Initialized
INFO - 2018-04-12 22:29:59 --> Output Class Initialized
INFO - 2018-04-12 22:29:59 --> Security Class Initialized
DEBUG - 2018-04-12 22:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:29:59 --> Input Class Initialized
INFO - 2018-04-12 22:29:59 --> Language Class Initialized
INFO - 2018-04-12 22:29:59 --> Loader Class Initialized
INFO - 2018-04-12 22:29:59 --> Helper loaded: url_helper
INFO - 2018-04-12 22:29:59 --> Helper loaded: file_helper
INFO - 2018-04-12 22:29:59 --> Helper loaded: date_helper
INFO - 2018-04-12 22:29:59 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:29:59 --> Controller Class Initialized
INFO - 2018-04-12 22:29:59 --> Model Class Initialized
INFO - 2018-04-12 22:29:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:29:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-12 22:29:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:29:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:29:59 --> Final output sent to browser
DEBUG - 2018-04-12 22:29:59 --> Total execution time: 0.3698
INFO - 2018-04-12 22:31:19 --> Config Class Initialized
INFO - 2018-04-12 22:31:19 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:31:19 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:31:19 --> Utf8 Class Initialized
INFO - 2018-04-12 22:31:19 --> URI Class Initialized
INFO - 2018-04-12 22:31:19 --> Router Class Initialized
INFO - 2018-04-12 22:31:19 --> Output Class Initialized
INFO - 2018-04-12 22:31:19 --> Security Class Initialized
DEBUG - 2018-04-12 22:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:31:19 --> Input Class Initialized
INFO - 2018-04-12 22:31:19 --> Language Class Initialized
INFO - 2018-04-12 22:31:19 --> Loader Class Initialized
INFO - 2018-04-12 22:31:19 --> Helper loaded: url_helper
INFO - 2018-04-12 22:31:19 --> Helper loaded: file_helper
INFO - 2018-04-12 22:31:19 --> Helper loaded: date_helper
INFO - 2018-04-12 22:31:19 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:31:19 --> Controller Class Initialized
INFO - 2018-04-12 22:31:19 --> Model Class Initialized
INFO - 2018-04-12 22:31:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:31:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 22:31:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:31:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:31:19 --> Final output sent to browser
DEBUG - 2018-04-12 22:31:19 --> Total execution time: 0.3801
INFO - 2018-04-12 22:31:21 --> Config Class Initialized
INFO - 2018-04-12 22:31:21 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:31:21 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:31:21 --> Utf8 Class Initialized
INFO - 2018-04-12 22:31:21 --> URI Class Initialized
INFO - 2018-04-12 22:31:21 --> Router Class Initialized
INFO - 2018-04-12 22:31:21 --> Output Class Initialized
INFO - 2018-04-12 22:31:21 --> Security Class Initialized
DEBUG - 2018-04-12 22:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:31:21 --> Input Class Initialized
INFO - 2018-04-12 22:31:21 --> Language Class Initialized
INFO - 2018-04-12 22:31:21 --> Loader Class Initialized
INFO - 2018-04-12 22:31:21 --> Helper loaded: url_helper
INFO - 2018-04-12 22:31:21 --> Helper loaded: file_helper
INFO - 2018-04-12 22:31:21 --> Helper loaded: date_helper
INFO - 2018-04-12 22:31:21 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:31:21 --> Controller Class Initialized
INFO - 2018-04-12 22:31:21 --> Model Class Initialized
INFO - 2018-04-12 22:31:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:31:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-12 22:31:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:31:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:31:21 --> Final output sent to browser
DEBUG - 2018-04-12 22:31:21 --> Total execution time: 0.4110
INFO - 2018-04-12 22:31:23 --> Config Class Initialized
INFO - 2018-04-12 22:31:23 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:31:23 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:31:23 --> Utf8 Class Initialized
INFO - 2018-04-12 22:31:23 --> URI Class Initialized
INFO - 2018-04-12 22:31:23 --> Router Class Initialized
INFO - 2018-04-12 22:31:23 --> Output Class Initialized
INFO - 2018-04-12 22:31:23 --> Security Class Initialized
DEBUG - 2018-04-12 22:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:31:23 --> Input Class Initialized
INFO - 2018-04-12 22:31:23 --> Language Class Initialized
INFO - 2018-04-12 22:31:23 --> Loader Class Initialized
INFO - 2018-04-12 22:31:23 --> Helper loaded: url_helper
INFO - 2018-04-12 22:31:23 --> Helper loaded: file_helper
INFO - 2018-04-12 22:31:23 --> Helper loaded: date_helper
INFO - 2018-04-12 22:31:23 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:31:23 --> Controller Class Initialized
INFO - 2018-04-12 22:31:23 --> Model Class Initialized
INFO - 2018-04-12 22:31:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:31:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 22:31:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:31:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:31:23 --> Final output sent to browser
DEBUG - 2018-04-12 22:31:23 --> Total execution time: 0.4363
INFO - 2018-04-12 22:31:35 --> Config Class Initialized
INFO - 2018-04-12 22:31:35 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:31:35 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:31:35 --> Utf8 Class Initialized
INFO - 2018-04-12 22:31:35 --> URI Class Initialized
INFO - 2018-04-12 22:31:35 --> Router Class Initialized
INFO - 2018-04-12 22:31:35 --> Output Class Initialized
INFO - 2018-04-12 22:31:35 --> Security Class Initialized
DEBUG - 2018-04-12 22:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:31:35 --> Input Class Initialized
INFO - 2018-04-12 22:31:35 --> Language Class Initialized
INFO - 2018-04-12 22:31:35 --> Loader Class Initialized
INFO - 2018-04-12 22:31:35 --> Helper loaded: url_helper
INFO - 2018-04-12 22:31:35 --> Helper loaded: file_helper
INFO - 2018-04-12 22:31:35 --> Helper loaded: date_helper
INFO - 2018-04-12 22:31:35 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:31:35 --> Controller Class Initialized
INFO - 2018-04-12 22:31:35 --> Final output sent to browser
DEBUG - 2018-04-12 22:31:35 --> Total execution time: 0.3029
INFO - 2018-04-12 22:36:46 --> Config Class Initialized
INFO - 2018-04-12 22:36:46 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:36:46 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:36:46 --> Utf8 Class Initialized
INFO - 2018-04-12 22:36:46 --> URI Class Initialized
INFO - 2018-04-12 22:36:46 --> Router Class Initialized
INFO - 2018-04-12 22:36:46 --> Output Class Initialized
INFO - 2018-04-12 22:36:46 --> Security Class Initialized
DEBUG - 2018-04-12 22:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:36:46 --> Input Class Initialized
INFO - 2018-04-12 22:36:46 --> Language Class Initialized
INFO - 2018-04-12 22:36:46 --> Loader Class Initialized
INFO - 2018-04-12 22:36:46 --> Helper loaded: url_helper
INFO - 2018-04-12 22:36:46 --> Helper loaded: file_helper
INFO - 2018-04-12 22:36:46 --> Helper loaded: date_helper
INFO - 2018-04-12 22:36:46 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:36:46 --> Controller Class Initialized
INFO - 2018-04-12 22:36:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-12 22:36:46 --> Final output sent to browser
DEBUG - 2018-04-12 22:36:46 --> Total execution time: 0.3343
INFO - 2018-04-12 22:36:53 --> Config Class Initialized
INFO - 2018-04-12 22:36:53 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:36:53 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:36:53 --> Utf8 Class Initialized
INFO - 2018-04-12 22:36:53 --> URI Class Initialized
INFO - 2018-04-12 22:36:53 --> Router Class Initialized
INFO - 2018-04-12 22:36:53 --> Output Class Initialized
INFO - 2018-04-12 22:36:53 --> Security Class Initialized
DEBUG - 2018-04-12 22:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:36:53 --> Input Class Initialized
INFO - 2018-04-12 22:36:53 --> Language Class Initialized
INFO - 2018-04-12 22:36:53 --> Loader Class Initialized
INFO - 2018-04-12 22:36:53 --> Helper loaded: url_helper
INFO - 2018-04-12 22:36:53 --> Helper loaded: file_helper
INFO - 2018-04-12 22:36:53 --> Helper loaded: date_helper
INFO - 2018-04-12 22:36:53 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:36:53 --> Controller Class Initialized
INFO - 2018-04-12 22:36:53 --> Model Class Initialized
INFO - 2018-04-12 22:36:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-12 22:36:53 --> Final output sent to browser
DEBUG - 2018-04-12 22:36:53 --> Total execution time: 0.3910
INFO - 2018-04-12 22:37:03 --> Config Class Initialized
INFO - 2018-04-12 22:37:03 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:37:03 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:37:03 --> Utf8 Class Initialized
INFO - 2018-04-12 22:37:03 --> URI Class Initialized
INFO - 2018-04-12 22:37:03 --> Router Class Initialized
INFO - 2018-04-12 22:37:03 --> Output Class Initialized
INFO - 2018-04-12 22:37:03 --> Security Class Initialized
DEBUG - 2018-04-12 22:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:37:03 --> Input Class Initialized
INFO - 2018-04-12 22:37:03 --> Language Class Initialized
INFO - 2018-04-12 22:37:03 --> Loader Class Initialized
INFO - 2018-04-12 22:37:03 --> Helper loaded: url_helper
INFO - 2018-04-12 22:37:03 --> Helper loaded: file_helper
INFO - 2018-04-12 22:37:03 --> Helper loaded: date_helper
INFO - 2018-04-12 22:37:03 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:37:03 --> Controller Class Initialized
INFO - 2018-04-12 22:37:03 --> Model Class Initialized
INFO - 2018-04-12 22:37:03 --> Final output sent to browser
DEBUG - 2018-04-12 22:37:03 --> Total execution time: 0.3232
INFO - 2018-04-12 22:37:03 --> Config Class Initialized
INFO - 2018-04-12 22:37:03 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:37:03 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:37:03 --> Utf8 Class Initialized
INFO - 2018-04-12 22:37:03 --> URI Class Initialized
INFO - 2018-04-12 22:37:03 --> Router Class Initialized
INFO - 2018-04-12 22:37:03 --> Output Class Initialized
INFO - 2018-04-12 22:37:03 --> Security Class Initialized
DEBUG - 2018-04-12 22:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:37:03 --> Input Class Initialized
INFO - 2018-04-12 22:37:03 --> Language Class Initialized
INFO - 2018-04-12 22:37:03 --> Loader Class Initialized
INFO - 2018-04-12 22:37:03 --> Helper loaded: url_helper
INFO - 2018-04-12 22:37:03 --> Helper loaded: file_helper
INFO - 2018-04-12 22:37:03 --> Helper loaded: date_helper
INFO - 2018-04-12 22:37:03 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:37:03 --> Controller Class Initialized
INFO - 2018-04-12 22:37:04 --> Model Class Initialized
INFO - 2018-04-12 22:37:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:37:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 22:37:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:37:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:37:04 --> Final output sent to browser
DEBUG - 2018-04-12 22:37:04 --> Total execution time: 0.3686
INFO - 2018-04-12 22:37:08 --> Config Class Initialized
INFO - 2018-04-12 22:37:08 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:37:08 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:37:08 --> Utf8 Class Initialized
INFO - 2018-04-12 22:37:08 --> URI Class Initialized
INFO - 2018-04-12 22:37:08 --> Router Class Initialized
INFO - 2018-04-12 22:37:08 --> Output Class Initialized
INFO - 2018-04-12 22:37:08 --> Security Class Initialized
DEBUG - 2018-04-12 22:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:37:08 --> Input Class Initialized
INFO - 2018-04-12 22:37:08 --> Language Class Initialized
INFO - 2018-04-12 22:37:08 --> Loader Class Initialized
INFO - 2018-04-12 22:37:08 --> Helper loaded: url_helper
INFO - 2018-04-12 22:37:08 --> Helper loaded: file_helper
INFO - 2018-04-12 22:37:08 --> Helper loaded: date_helper
INFO - 2018-04-12 22:37:08 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:37:08 --> Controller Class Initialized
INFO - 2018-04-12 22:37:08 --> Model Class Initialized
INFO - 2018-04-12 22:37:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:37:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-12 22:37:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:37:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:37:08 --> Final output sent to browser
DEBUG - 2018-04-12 22:37:08 --> Total execution time: 0.3739
INFO - 2018-04-12 22:37:21 --> Config Class Initialized
INFO - 2018-04-12 22:37:21 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:37:21 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:37:21 --> Utf8 Class Initialized
INFO - 2018-04-12 22:37:21 --> URI Class Initialized
INFO - 2018-04-12 22:37:21 --> Router Class Initialized
INFO - 2018-04-12 22:37:21 --> Output Class Initialized
INFO - 2018-04-12 22:37:21 --> Security Class Initialized
DEBUG - 2018-04-12 22:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:37:21 --> Input Class Initialized
INFO - 2018-04-12 22:37:21 --> Language Class Initialized
INFO - 2018-04-12 22:37:21 --> Loader Class Initialized
INFO - 2018-04-12 22:37:21 --> Helper loaded: url_helper
INFO - 2018-04-12 22:37:21 --> Helper loaded: file_helper
INFO - 2018-04-12 22:37:21 --> Helper loaded: date_helper
INFO - 2018-04-12 22:37:21 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:37:22 --> Controller Class Initialized
INFO - 2018-04-12 22:37:22 --> Model Class Initialized
INFO - 2018-04-12 22:37:22 --> Config Class Initialized
INFO - 2018-04-12 22:37:22 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:37:22 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:37:22 --> Utf8 Class Initialized
INFO - 2018-04-12 22:37:22 --> URI Class Initialized
INFO - 2018-04-12 22:37:22 --> Router Class Initialized
INFO - 2018-04-12 22:37:22 --> Output Class Initialized
INFO - 2018-04-12 22:37:22 --> Security Class Initialized
DEBUG - 2018-04-12 22:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:37:22 --> Input Class Initialized
INFO - 2018-04-12 22:37:22 --> Language Class Initialized
INFO - 2018-04-12 22:37:22 --> Loader Class Initialized
INFO - 2018-04-12 22:37:22 --> Helper loaded: url_helper
INFO - 2018-04-12 22:37:22 --> Helper loaded: file_helper
INFO - 2018-04-12 22:37:22 --> Helper loaded: date_helper
INFO - 2018-04-12 22:37:22 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:37:22 --> Controller Class Initialized
INFO - 2018-04-12 22:37:22 --> Model Class Initialized
INFO - 2018-04-12 22:37:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:37:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 22:37:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:37:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:37:22 --> Final output sent to browser
DEBUG - 2018-04-12 22:37:22 --> Total execution time: 0.7677
INFO - 2018-04-12 22:43:44 --> Config Class Initialized
INFO - 2018-04-12 22:43:44 --> Hooks Class Initialized
DEBUG - 2018-04-12 22:43:44 --> UTF-8 Support Enabled
INFO - 2018-04-12 22:43:44 --> Utf8 Class Initialized
INFO - 2018-04-12 22:43:44 --> URI Class Initialized
INFO - 2018-04-12 22:43:44 --> Router Class Initialized
INFO - 2018-04-12 22:43:44 --> Output Class Initialized
INFO - 2018-04-12 22:43:44 --> Security Class Initialized
DEBUG - 2018-04-12 22:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-12 22:43:44 --> Input Class Initialized
INFO - 2018-04-12 22:43:44 --> Language Class Initialized
INFO - 2018-04-12 22:43:44 --> Loader Class Initialized
INFO - 2018-04-12 22:43:44 --> Helper loaded: url_helper
INFO - 2018-04-12 22:43:44 --> Helper loaded: file_helper
INFO - 2018-04-12 22:43:44 --> Helper loaded: date_helper
INFO - 2018-04-12 22:43:44 --> Database Driver Class Initialized
DEBUG - 2018-04-12 22:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-12 22:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-12 22:43:44 --> Controller Class Initialized
INFO - 2018-04-12 22:43:44 --> Model Class Initialized
INFO - 2018-04-12 22:43:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-12 22:43:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-12 22:43:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-12 22:43:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-12 22:43:44 --> Final output sent to browser
DEBUG - 2018-04-12 22:43:44 --> Total execution time: 0.4438
