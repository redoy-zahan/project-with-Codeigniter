<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-13 10:52:37 --> Config Class Initialized
INFO - 2017-03-13 10:52:37 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:52:37 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:52:37 --> Utf8 Class Initialized
INFO - 2017-03-13 10:52:37 --> URI Class Initialized
DEBUG - 2017-03-13 10:52:37 --> No URI present. Default controller set.
INFO - 2017-03-13 10:52:37 --> Router Class Initialized
INFO - 2017-03-13 10:52:37 --> Output Class Initialized
INFO - 2017-03-13 10:52:37 --> Security Class Initialized
DEBUG - 2017-03-13 10:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:52:37 --> Input Class Initialized
INFO - 2017-03-13 10:52:37 --> Language Class Initialized
INFO - 2017-03-13 10:52:37 --> Loader Class Initialized
INFO - 2017-03-13 10:52:37 --> Helper loaded: url_helper
INFO - 2017-03-13 10:52:37 --> Helper loaded: file_helper
INFO - 2017-03-13 10:52:37 --> Helper loaded: date_helper
INFO - 2017-03-13 10:52:37 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:52:37 --> Controller Class Initialized
INFO - 2017-03-13 10:52:37 --> Config Class Initialized
INFO - 2017-03-13 10:52:37 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:52:37 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:52:37 --> Utf8 Class Initialized
INFO - 2017-03-13 10:52:37 --> URI Class Initialized
INFO - 2017-03-13 10:52:37 --> Router Class Initialized
INFO - 2017-03-13 10:52:37 --> Output Class Initialized
INFO - 2017-03-13 10:52:37 --> Security Class Initialized
DEBUG - 2017-03-13 10:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:52:37 --> Input Class Initialized
INFO - 2017-03-13 10:52:37 --> Language Class Initialized
INFO - 2017-03-13 10:52:37 --> Loader Class Initialized
INFO - 2017-03-13 10:52:37 --> Helper loaded: url_helper
INFO - 2017-03-13 10:52:37 --> Helper loaded: file_helper
INFO - 2017-03-13 10:52:37 --> Helper loaded: date_helper
INFO - 2017-03-13 10:52:37 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:52:37 --> Controller Class Initialized
INFO - 2017-03-13 10:52:37 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-13 10:52:37 --> Final output sent to browser
DEBUG - 2017-03-13 10:52:37 --> Total execution time: 0.0345
INFO - 2017-03-13 10:52:52 --> Config Class Initialized
INFO - 2017-03-13 10:52:52 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:52:52 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:52:52 --> Utf8 Class Initialized
INFO - 2017-03-13 10:52:52 --> URI Class Initialized
INFO - 2017-03-13 10:52:52 --> Router Class Initialized
INFO - 2017-03-13 10:52:52 --> Output Class Initialized
INFO - 2017-03-13 10:52:52 --> Security Class Initialized
DEBUG - 2017-03-13 10:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:52:52 --> Input Class Initialized
INFO - 2017-03-13 10:52:52 --> Language Class Initialized
INFO - 2017-03-13 10:52:52 --> Loader Class Initialized
INFO - 2017-03-13 10:52:52 --> Helper loaded: url_helper
INFO - 2017-03-13 10:52:52 --> Helper loaded: file_helper
INFO - 2017-03-13 10:52:52 --> Helper loaded: date_helper
INFO - 2017-03-13 10:52:52 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:52:52 --> Controller Class Initialized
INFO - 2017-03-13 10:52:52 --> Model Class Initialized
INFO - 2017-03-13 10:52:52 --> Final output sent to browser
DEBUG - 2017-03-13 10:52:52 --> Total execution time: 0.0278
INFO - 2017-03-13 10:52:52 --> Config Class Initialized
INFO - 2017-03-13 10:52:52 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:52:52 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:52:52 --> Utf8 Class Initialized
INFO - 2017-03-13 10:52:52 --> URI Class Initialized
INFO - 2017-03-13 10:52:52 --> Router Class Initialized
INFO - 2017-03-13 10:52:52 --> Output Class Initialized
INFO - 2017-03-13 10:52:52 --> Security Class Initialized
DEBUG - 2017-03-13 10:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:52:52 --> Input Class Initialized
INFO - 2017-03-13 10:52:52 --> Language Class Initialized
INFO - 2017-03-13 10:52:52 --> Loader Class Initialized
INFO - 2017-03-13 10:52:52 --> Helper loaded: url_helper
INFO - 2017-03-13 10:52:52 --> Helper loaded: file_helper
INFO - 2017-03-13 10:52:52 --> Helper loaded: date_helper
INFO - 2017-03-13 10:52:52 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:52:52 --> Controller Class Initialized
INFO - 2017-03-13 10:52:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-13 10:52:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-13 10:52:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/dashboard.php
INFO - 2017-03-13 10:52:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-13 10:52:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-13 10:52:52 --> Final output sent to browser
DEBUG - 2017-03-13 10:52:52 --> Total execution time: 0.0433
INFO - 2017-03-13 10:53:10 --> Config Class Initialized
INFO - 2017-03-13 10:53:10 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:53:10 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:53:10 --> Utf8 Class Initialized
INFO - 2017-03-13 10:53:10 --> URI Class Initialized
INFO - 2017-03-13 10:53:10 --> Router Class Initialized
INFO - 2017-03-13 10:53:10 --> Output Class Initialized
INFO - 2017-03-13 10:53:10 --> Security Class Initialized
DEBUG - 2017-03-13 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:53:10 --> Input Class Initialized
INFO - 2017-03-13 10:53:10 --> Language Class Initialized
INFO - 2017-03-13 10:53:10 --> Loader Class Initialized
INFO - 2017-03-13 10:53:10 --> Helper loaded: url_helper
INFO - 2017-03-13 10:53:10 --> Helper loaded: file_helper
INFO - 2017-03-13 10:53:10 --> Helper loaded: date_helper
INFO - 2017-03-13 10:53:10 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:53:10 --> Controller Class Initialized
INFO - 2017-03-13 10:53:10 --> Model Class Initialized
INFO - 2017-03-13 10:53:10 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-13 10:53:10 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-13 10:53:10 --> File loaded: /home/thestudytown/public_html/mcq/application/views/teacher/teacher_view.php
INFO - 2017-03-13 10:53:10 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-13 10:53:10 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-13 10:53:10 --> Final output sent to browser
DEBUG - 2017-03-13 10:53:10 --> Total execution time: 0.0476
INFO - 2017-03-13 10:53:13 --> Config Class Initialized
INFO - 2017-03-13 10:53:13 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:53:13 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:53:13 --> Utf8 Class Initialized
INFO - 2017-03-13 10:53:13 --> URI Class Initialized
INFO - 2017-03-13 10:53:13 --> Router Class Initialized
INFO - 2017-03-13 10:53:13 --> Output Class Initialized
INFO - 2017-03-13 10:53:13 --> Security Class Initialized
DEBUG - 2017-03-13 10:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:53:13 --> Input Class Initialized
INFO - 2017-03-13 10:53:13 --> Language Class Initialized
INFO - 2017-03-13 10:53:13 --> Loader Class Initialized
INFO - 2017-03-13 10:53:13 --> Helper loaded: url_helper
INFO - 2017-03-13 10:53:13 --> Helper loaded: file_helper
INFO - 2017-03-13 10:53:13 --> Helper loaded: date_helper
INFO - 2017-03-13 10:53:13 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:53:13 --> Controller Class Initialized
INFO - 2017-03-13 10:53:13 --> Model Class Initialized
INFO - 2017-03-13 10:53:13 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-13 10:53:13 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-13 10:53:13 --> File loaded: /home/thestudytown/public_html/mcq/application/views/teacher/edit_teacher.php
INFO - 2017-03-13 10:53:13 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-13 10:53:13 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-13 10:53:13 --> Final output sent to browser
DEBUG - 2017-03-13 10:53:13 --> Total execution time: 0.0197
INFO - 2017-03-13 10:53:16 --> Config Class Initialized
INFO - 2017-03-13 10:53:16 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:53:16 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:53:16 --> Utf8 Class Initialized
INFO - 2017-03-13 10:53:16 --> URI Class Initialized
INFO - 2017-03-13 10:53:16 --> Router Class Initialized
INFO - 2017-03-13 10:53:16 --> Output Class Initialized
INFO - 2017-03-13 10:53:16 --> Security Class Initialized
DEBUG - 2017-03-13 10:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:53:16 --> Input Class Initialized
INFO - 2017-03-13 10:53:16 --> Language Class Initialized
INFO - 2017-03-13 10:53:16 --> Loader Class Initialized
INFO - 2017-03-13 10:53:16 --> Helper loaded: url_helper
INFO - 2017-03-13 10:53:16 --> Helper loaded: file_helper
INFO - 2017-03-13 10:53:16 --> Helper loaded: date_helper
INFO - 2017-03-13 10:53:16 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:53:16 --> Controller Class Initialized
INFO - 2017-03-13 10:53:16 --> Model Class Initialized
INFO - 2017-03-13 10:53:16 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-13 10:53:16 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-13 10:53:16 --> File loaded: /home/thestudytown/public_html/mcq/application/views/teacher/teacher_view.php
INFO - 2017-03-13 10:53:16 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-13 10:53:16 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-13 10:53:16 --> Final output sent to browser
DEBUG - 2017-03-13 10:53:16 --> Total execution time: 0.0189
INFO - 2017-03-13 10:53:33 --> Config Class Initialized
INFO - 2017-03-13 10:53:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:53:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:53:33 --> Utf8 Class Initialized
INFO - 2017-03-13 10:53:33 --> URI Class Initialized
INFO - 2017-03-13 10:53:33 --> Router Class Initialized
INFO - 2017-03-13 10:53:33 --> Output Class Initialized
INFO - 2017-03-13 10:53:33 --> Security Class Initialized
DEBUG - 2017-03-13 10:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:53:33 --> Input Class Initialized
INFO - 2017-03-13 10:53:33 --> Language Class Initialized
INFO - 2017-03-13 10:53:33 --> Loader Class Initialized
INFO - 2017-03-13 10:53:33 --> Helper loaded: url_helper
INFO - 2017-03-13 10:53:33 --> Helper loaded: file_helper
INFO - 2017-03-13 10:53:33 --> Helper loaded: date_helper
INFO - 2017-03-13 10:53:33 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:53:33 --> Controller Class Initialized
INFO - 2017-03-13 10:53:33 --> Model Class Initialized
INFO - 2017-03-13 10:53:33 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-13 10:53:33 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-13 10:53:33 --> File loaded: /home/thestudytown/public_html/mcq/application/views/exam/assign_exam.php
INFO - 2017-03-13 10:53:33 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-13 10:53:33 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-13 10:53:33 --> Final output sent to browser
DEBUG - 2017-03-13 10:53:33 --> Total execution time: 0.2872
INFO - 2017-03-13 10:54:08 --> Config Class Initialized
INFO - 2017-03-13 10:54:08 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:54:08 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:54:08 --> Utf8 Class Initialized
INFO - 2017-03-13 10:54:08 --> URI Class Initialized
INFO - 2017-03-13 10:54:08 --> Router Class Initialized
INFO - 2017-03-13 10:54:08 --> Output Class Initialized
INFO - 2017-03-13 10:54:08 --> Security Class Initialized
DEBUG - 2017-03-13 10:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:54:08 --> Input Class Initialized
INFO - 2017-03-13 10:54:08 --> Language Class Initialized
INFO - 2017-03-13 10:54:08 --> Loader Class Initialized
INFO - 2017-03-13 10:54:08 --> Helper loaded: url_helper
INFO - 2017-03-13 10:54:08 --> Helper loaded: file_helper
INFO - 2017-03-13 10:54:08 --> Helper loaded: date_helper
INFO - 2017-03-13 10:54:08 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:54:08 --> Controller Class Initialized
DEBUG - 2017-03-13 10:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 10:54:08 --> Config Class Initialized
INFO - 2017-03-13 10:54:08 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:54:08 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:54:08 --> Utf8 Class Initialized
INFO - 2017-03-13 10:54:08 --> URI Class Initialized
INFO - 2017-03-13 10:54:08 --> Router Class Initialized
INFO - 2017-03-13 10:54:08 --> Output Class Initialized
INFO - 2017-03-13 10:54:08 --> Security Class Initialized
DEBUG - 2017-03-13 10:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:54:08 --> Input Class Initialized
INFO - 2017-03-13 10:54:08 --> Language Class Initialized
INFO - 2017-03-13 10:54:08 --> Loader Class Initialized
INFO - 2017-03-13 10:54:08 --> Helper loaded: url_helper
INFO - 2017-03-13 10:54:08 --> Helper loaded: file_helper
INFO - 2017-03-13 10:54:08 --> Helper loaded: date_helper
INFO - 2017-03-13 10:54:08 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:54:08 --> Controller Class Initialized
INFO - 2017-03-13 10:54:08 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-13 10:54:08 --> Final output sent to browser
DEBUG - 2017-03-13 10:54:08 --> Total execution time: 0.0170
INFO - 2017-03-13 10:54:16 --> Config Class Initialized
INFO - 2017-03-13 10:54:16 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:54:16 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:54:16 --> Utf8 Class Initialized
INFO - 2017-03-13 10:54:16 --> URI Class Initialized
INFO - 2017-03-13 10:54:16 --> Router Class Initialized
INFO - 2017-03-13 10:54:16 --> Output Class Initialized
INFO - 2017-03-13 10:54:16 --> Security Class Initialized
DEBUG - 2017-03-13 10:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:54:16 --> Input Class Initialized
INFO - 2017-03-13 10:54:16 --> Language Class Initialized
INFO - 2017-03-13 10:54:16 --> Loader Class Initialized
INFO - 2017-03-13 10:54:16 --> Helper loaded: url_helper
INFO - 2017-03-13 10:54:16 --> Helper loaded: file_helper
INFO - 2017-03-13 10:54:16 --> Helper loaded: date_helper
INFO - 2017-03-13 10:54:16 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:54:16 --> Controller Class Initialized
INFO - 2017-03-13 10:54:16 --> Model Class Initialized
INFO - 2017-03-13 10:54:16 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-13 10:54:16 --> Final output sent to browser
DEBUG - 2017-03-13 10:54:16 --> Total execution time: 0.0184
INFO - 2017-03-13 10:54:23 --> Config Class Initialized
INFO - 2017-03-13 10:54:23 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:54:23 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:54:23 --> Utf8 Class Initialized
INFO - 2017-03-13 10:54:23 --> URI Class Initialized
INFO - 2017-03-13 10:54:23 --> Router Class Initialized
INFO - 2017-03-13 10:54:23 --> Output Class Initialized
INFO - 2017-03-13 10:54:23 --> Security Class Initialized
DEBUG - 2017-03-13 10:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:54:23 --> Input Class Initialized
INFO - 2017-03-13 10:54:23 --> Language Class Initialized
INFO - 2017-03-13 10:54:23 --> Loader Class Initialized
INFO - 2017-03-13 10:54:23 --> Helper loaded: url_helper
INFO - 2017-03-13 10:54:23 --> Helper loaded: file_helper
INFO - 2017-03-13 10:54:23 --> Helper loaded: date_helper
INFO - 2017-03-13 10:54:23 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:54:23 --> Controller Class Initialized
INFO - 2017-03-13 10:54:23 --> Model Class Initialized
INFO - 2017-03-13 10:54:23 --> Final output sent to browser
DEBUG - 2017-03-13 10:54:23 --> Total execution time: 0.0188
INFO - 2017-03-13 10:54:23 --> Config Class Initialized
INFO - 2017-03-13 10:54:23 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:54:23 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:54:23 --> Utf8 Class Initialized
INFO - 2017-03-13 10:54:23 --> URI Class Initialized
INFO - 2017-03-13 10:54:23 --> Router Class Initialized
INFO - 2017-03-13 10:54:23 --> Output Class Initialized
INFO - 2017-03-13 10:54:23 --> Security Class Initialized
DEBUG - 2017-03-13 10:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:54:23 --> Input Class Initialized
INFO - 2017-03-13 10:54:23 --> Language Class Initialized
INFO - 2017-03-13 10:54:23 --> Loader Class Initialized
INFO - 2017-03-13 10:54:23 --> Helper loaded: url_helper
INFO - 2017-03-13 10:54:23 --> Helper loaded: file_helper
INFO - 2017-03-13 10:54:23 --> Helper loaded: date_helper
INFO - 2017-03-13 10:54:23 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:54:23 --> Controller Class Initialized
INFO - 2017-03-13 10:54:23 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-13 10:54:23 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-13 10:54:23 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/dashboard.php
INFO - 2017-03-13 10:54:23 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-13 10:54:23 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-13 10:54:23 --> Final output sent to browser
DEBUG - 2017-03-13 10:54:23 --> Total execution time: 0.0176
INFO - 2017-03-13 10:54:44 --> Config Class Initialized
INFO - 2017-03-13 10:54:44 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:54:44 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:54:44 --> Utf8 Class Initialized
INFO - 2017-03-13 10:54:44 --> URI Class Initialized
INFO - 2017-03-13 10:54:44 --> Router Class Initialized
INFO - 2017-03-13 10:54:44 --> Output Class Initialized
INFO - 2017-03-13 10:54:44 --> Security Class Initialized
DEBUG - 2017-03-13 10:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:54:44 --> Input Class Initialized
INFO - 2017-03-13 10:54:44 --> Language Class Initialized
INFO - 2017-03-13 10:54:44 --> Loader Class Initialized
INFO - 2017-03-13 10:54:44 --> Helper loaded: url_helper
INFO - 2017-03-13 10:54:44 --> Helper loaded: file_helper
INFO - 2017-03-13 10:54:44 --> Helper loaded: date_helper
INFO - 2017-03-13 10:54:44 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:54:44 --> Controller Class Initialized
INFO - 2017-03-13 10:54:44 --> Model Class Initialized
INFO - 2017-03-13 10:54:44 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-13 10:54:44 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-13 10:54:44 --> File loaded: /home/thestudytown/public_html/mcq/application/views/chapter/create_chapter.php
INFO - 2017-03-13 10:54:44 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-13 10:54:44 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-13 10:54:44 --> Final output sent to browser
DEBUG - 2017-03-13 10:54:44 --> Total execution time: 0.5418
INFO - 2017-03-13 10:55:29 --> Config Class Initialized
INFO - 2017-03-13 10:55:29 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:55:29 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:55:29 --> Utf8 Class Initialized
INFO - 2017-03-13 10:55:29 --> URI Class Initialized
INFO - 2017-03-13 10:55:29 --> Router Class Initialized
INFO - 2017-03-13 10:55:29 --> Output Class Initialized
INFO - 2017-03-13 10:55:29 --> Security Class Initialized
DEBUG - 2017-03-13 10:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:55:29 --> Input Class Initialized
INFO - 2017-03-13 10:55:29 --> Language Class Initialized
INFO - 2017-03-13 10:55:29 --> Loader Class Initialized
INFO - 2017-03-13 10:55:29 --> Helper loaded: url_helper
INFO - 2017-03-13 10:55:29 --> Helper loaded: file_helper
INFO - 2017-03-13 10:55:29 --> Helper loaded: date_helper
INFO - 2017-03-13 10:55:29 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:55:29 --> Controller Class Initialized
DEBUG - 2017-03-13 10:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-13 10:55:29 --> Config Class Initialized
INFO - 2017-03-13 10:55:29 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:55:29 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:55:29 --> Utf8 Class Initialized
INFO - 2017-03-13 10:55:29 --> URI Class Initialized
INFO - 2017-03-13 10:55:30 --> Router Class Initialized
INFO - 2017-03-13 10:55:30 --> Output Class Initialized
INFO - 2017-03-13 10:55:30 --> Security Class Initialized
DEBUG - 2017-03-13 10:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:55:30 --> Input Class Initialized
INFO - 2017-03-13 10:55:30 --> Language Class Initialized
INFO - 2017-03-13 10:55:30 --> Loader Class Initialized
INFO - 2017-03-13 10:55:30 --> Helper loaded: url_helper
INFO - 2017-03-13 10:55:30 --> Helper loaded: file_helper
INFO - 2017-03-13 10:55:30 --> Helper loaded: date_helper
INFO - 2017-03-13 10:55:30 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:55:30 --> Controller Class Initialized
INFO - 2017-03-13 10:55:30 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-13 10:55:30 --> Final output sent to browser
DEBUG - 2017-03-13 10:55:30 --> Total execution time: 0.0176
INFO - 2017-03-13 10:55:40 --> Config Class Initialized
INFO - 2017-03-13 10:55:40 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:55:40 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:55:40 --> Utf8 Class Initialized
INFO - 2017-03-13 10:55:40 --> URI Class Initialized
INFO - 2017-03-13 10:55:40 --> Router Class Initialized
INFO - 2017-03-13 10:55:40 --> Output Class Initialized
INFO - 2017-03-13 10:55:40 --> Security Class Initialized
DEBUG - 2017-03-13 10:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:55:40 --> Input Class Initialized
INFO - 2017-03-13 10:55:40 --> Language Class Initialized
INFO - 2017-03-13 10:55:40 --> Loader Class Initialized
INFO - 2017-03-13 10:55:40 --> Helper loaded: url_helper
INFO - 2017-03-13 10:55:40 --> Helper loaded: file_helper
INFO - 2017-03-13 10:55:40 --> Helper loaded: date_helper
INFO - 2017-03-13 10:55:40 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:55:40 --> Controller Class Initialized
INFO - 2017-03-13 10:55:40 --> Model Class Initialized
INFO - 2017-03-13 10:55:40 --> Config Class Initialized
INFO - 2017-03-13 10:55:40 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:55:40 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:55:40 --> Utf8 Class Initialized
INFO - 2017-03-13 10:55:40 --> URI Class Initialized
INFO - 2017-03-13 10:55:40 --> Router Class Initialized
INFO - 2017-03-13 10:55:40 --> Output Class Initialized
INFO - 2017-03-13 10:55:40 --> Security Class Initialized
DEBUG - 2017-03-13 10:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:55:40 --> Input Class Initialized
INFO - 2017-03-13 10:55:40 --> Language Class Initialized
INFO - 2017-03-13 10:55:40 --> Loader Class Initialized
INFO - 2017-03-13 10:55:40 --> Helper loaded: url_helper
INFO - 2017-03-13 10:55:40 --> Helper loaded: file_helper
INFO - 2017-03-13 10:55:40 --> Helper loaded: date_helper
INFO - 2017-03-13 10:55:40 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:55:40 --> Controller Class Initialized
INFO - 2017-03-13 10:55:40 --> Model Class Initialized
INFO - 2017-03-13 10:55:40 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/header.php
INFO - 2017-03-13 10:55:40 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/left.php
INFO - 2017-03-13 10:55:40 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/dashboard.php
INFO - 2017-03-13 10:55:40 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/footer.php
INFO - 2017-03-13 10:55:40 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/index.php
INFO - 2017-03-13 10:55:40 --> Final output sent to browser
DEBUG - 2017-03-13 10:55:40 --> Total execution time: 0.0610
INFO - 2017-03-13 10:55:59 --> Config Class Initialized
INFO - 2017-03-13 10:55:59 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:55:59 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:55:59 --> Utf8 Class Initialized
INFO - 2017-03-13 10:55:59 --> URI Class Initialized
INFO - 2017-03-13 10:55:59 --> Router Class Initialized
INFO - 2017-03-13 10:55:59 --> Output Class Initialized
INFO - 2017-03-13 10:55:59 --> Security Class Initialized
DEBUG - 2017-03-13 10:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:55:59 --> Input Class Initialized
INFO - 2017-03-13 10:55:59 --> Language Class Initialized
INFO - 2017-03-13 10:55:59 --> Loader Class Initialized
INFO - 2017-03-13 10:55:59 --> Helper loaded: url_helper
INFO - 2017-03-13 10:55:59 --> Helper loaded: file_helper
INFO - 2017-03-13 10:55:59 --> Helper loaded: date_helper
INFO - 2017-03-13 10:55:59 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:55:59 --> Controller Class Initialized
INFO - 2017-03-13 10:55:59 --> Model Class Initialized
INFO - 2017-03-13 10:55:59 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/header.php
INFO - 2017-03-13 10:55:59 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/left.php
INFO - 2017-03-13 10:56:00 --> File loaded: /home/thestudytown/public_html/mcq/application/views/student/exam_view.php
INFO - 2017-03-13 10:56:00 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/footer.php
INFO - 2017-03-13 10:56:00 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/index.php
INFO - 2017-03-13 10:56:00 --> Final output sent to browser
DEBUG - 2017-03-13 10:56:00 --> Total execution time: 0.0427
INFO - 2017-03-13 10:56:05 --> Config Class Initialized
INFO - 2017-03-13 10:56:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:56:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:56:05 --> Utf8 Class Initialized
INFO - 2017-03-13 10:56:05 --> URI Class Initialized
INFO - 2017-03-13 10:56:05 --> Router Class Initialized
INFO - 2017-03-13 10:56:05 --> Output Class Initialized
INFO - 2017-03-13 10:56:05 --> Security Class Initialized
DEBUG - 2017-03-13 10:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:56:05 --> Input Class Initialized
INFO - 2017-03-13 10:56:05 --> Language Class Initialized
INFO - 2017-03-13 10:56:05 --> Loader Class Initialized
INFO - 2017-03-13 10:56:05 --> Helper loaded: url_helper
INFO - 2017-03-13 10:56:05 --> Helper loaded: file_helper
INFO - 2017-03-13 10:56:05 --> Helper loaded: date_helper
INFO - 2017-03-13 10:56:05 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:56:05 --> Controller Class Initialized
INFO - 2017-03-13 10:56:05 --> Model Class Initialized
INFO - 2017-03-13 10:56:05 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/header.php
INFO - 2017-03-13 10:56:05 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/left.php
INFO - 2017-03-13 10:56:05 --> File loaded: /home/thestudytown/public_html/mcq/application/views/student/taken_exam.php
INFO - 2017-03-13 10:56:05 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/footer.php
INFO - 2017-03-13 10:56:05 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/index.php
INFO - 2017-03-13 10:56:05 --> Final output sent to browser
DEBUG - 2017-03-13 10:56:05 --> Total execution time: 0.0218
INFO - 2017-03-13 10:56:09 --> Config Class Initialized
INFO - 2017-03-13 10:56:09 --> Hooks Class Initialized
DEBUG - 2017-03-13 10:56:09 --> UTF-8 Support Enabled
INFO - 2017-03-13 10:56:09 --> Utf8 Class Initialized
INFO - 2017-03-13 10:56:09 --> URI Class Initialized
INFO - 2017-03-13 10:56:09 --> Router Class Initialized
INFO - 2017-03-13 10:56:09 --> Output Class Initialized
INFO - 2017-03-13 10:56:09 --> Security Class Initialized
DEBUG - 2017-03-13 10:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 10:56:09 --> Input Class Initialized
INFO - 2017-03-13 10:56:09 --> Language Class Initialized
INFO - 2017-03-13 10:56:09 --> Loader Class Initialized
INFO - 2017-03-13 10:56:09 --> Helper loaded: url_helper
INFO - 2017-03-13 10:56:09 --> Helper loaded: file_helper
INFO - 2017-03-13 10:56:09 --> Helper loaded: date_helper
INFO - 2017-03-13 10:56:09 --> Database Driver Class Initialized
DEBUG - 2017-03-13 10:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-13 10:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 10:56:09 --> Controller Class Initialized
INFO - 2017-03-13 10:56:09 --> Model Class Initialized
INFO - 2017-03-13 10:56:09 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/header.php
INFO - 2017-03-13 10:56:09 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/left.php
INFO - 2017-03-13 10:56:09 --> File loaded: /home/thestudytown/public_html/mcq/application/views/student/exam_view.php
INFO - 2017-03-13 10:56:09 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/footer.php
INFO - 2017-03-13 10:56:09 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/index.php
INFO - 2017-03-13 10:56:09 --> Final output sent to browser
DEBUG - 2017-03-13 10:56:09 --> Total execution time: 0.0224
