<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-02 11:20:54 --> Config Class Initialized
INFO - 2017-03-02 11:20:54 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:20:54 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:20:54 --> Utf8 Class Initialized
INFO - 2017-03-02 11:20:54 --> URI Class Initialized
DEBUG - 2017-03-02 11:20:54 --> No URI present. Default controller set.
INFO - 2017-03-02 11:20:54 --> Router Class Initialized
INFO - 2017-03-02 11:20:54 --> Output Class Initialized
INFO - 2017-03-02 11:20:55 --> Security Class Initialized
DEBUG - 2017-03-02 11:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:20:55 --> Input Class Initialized
INFO - 2017-03-02 11:20:55 --> Language Class Initialized
INFO - 2017-03-02 11:20:55 --> Loader Class Initialized
INFO - 2017-03-02 11:20:55 --> Helper loaded: url_helper
INFO - 2017-03-02 11:20:55 --> Helper loaded: file_helper
INFO - 2017-03-02 11:20:55 --> Helper loaded: date_helper
INFO - 2017-03-02 11:20:55 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:20:55 --> Controller Class Initialized
INFO - 2017-03-02 11:20:55 --> Config Class Initialized
INFO - 2017-03-02 11:20:55 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:20:55 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:20:55 --> Utf8 Class Initialized
INFO - 2017-03-02 11:20:55 --> URI Class Initialized
INFO - 2017-03-02 11:20:55 --> Router Class Initialized
INFO - 2017-03-02 11:20:55 --> Output Class Initialized
INFO - 2017-03-02 11:20:55 --> Security Class Initialized
DEBUG - 2017-03-02 11:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:20:55 --> Input Class Initialized
INFO - 2017-03-02 11:20:56 --> Language Class Initialized
INFO - 2017-03-02 11:20:56 --> Loader Class Initialized
INFO - 2017-03-02 11:20:56 --> Helper loaded: url_helper
INFO - 2017-03-02 11:20:56 --> Helper loaded: file_helper
INFO - 2017-03-02 11:20:56 --> Helper loaded: date_helper
INFO - 2017-03-02 11:20:56 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:20:56 --> Controller Class Initialized
INFO - 2017-03-02 11:20:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-02 11:20:56 --> Final output sent to browser
DEBUG - 2017-03-02 11:20:56 --> Total execution time: 0.2047
INFO - 2017-03-02 11:21:00 --> Config Class Initialized
INFO - 2017-03-02 11:21:00 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:21:00 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:21:00 --> Utf8 Class Initialized
INFO - 2017-03-02 11:21:00 --> URI Class Initialized
INFO - 2017-03-02 11:21:00 --> Router Class Initialized
INFO - 2017-03-02 11:21:00 --> Output Class Initialized
INFO - 2017-03-02 11:21:00 --> Security Class Initialized
DEBUG - 2017-03-02 11:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:21:00 --> Input Class Initialized
INFO - 2017-03-02 11:21:00 --> Language Class Initialized
INFO - 2017-03-02 11:21:00 --> Loader Class Initialized
INFO - 2017-03-02 11:21:00 --> Helper loaded: url_helper
INFO - 2017-03-02 11:21:00 --> Helper loaded: file_helper
INFO - 2017-03-02 11:21:00 --> Helper loaded: date_helper
INFO - 2017-03-02 11:21:00 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:21:00 --> Controller Class Initialized
INFO - 2017-03-02 11:21:00 --> Model Class Initialized
INFO - 2017-03-02 11:21:00 --> Final output sent to browser
DEBUG - 2017-03-02 11:21:00 --> Total execution time: 0.3694
INFO - 2017-03-02 11:21:00 --> Config Class Initialized
INFO - 2017-03-02 11:21:00 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:21:00 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:21:00 --> Utf8 Class Initialized
INFO - 2017-03-02 11:21:00 --> URI Class Initialized
INFO - 2017-03-02 11:21:00 --> Router Class Initialized
INFO - 2017-03-02 11:21:00 --> Output Class Initialized
INFO - 2017-03-02 11:21:00 --> Security Class Initialized
DEBUG - 2017-03-02 11:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:21:00 --> Input Class Initialized
INFO - 2017-03-02 11:21:00 --> Language Class Initialized
INFO - 2017-03-02 11:21:00 --> Loader Class Initialized
INFO - 2017-03-02 11:21:00 --> Helper loaded: url_helper
INFO - 2017-03-02 11:21:00 --> Helper loaded: file_helper
INFO - 2017-03-02 11:21:00 --> Helper loaded: date_helper
INFO - 2017-03-02 11:21:00 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:21:00 --> Controller Class Initialized
INFO - 2017-03-02 11:21:00 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:21:00 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:21:00 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/dashboard.php
INFO - 2017-03-02 11:21:00 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:21:00 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:21:00 --> Final output sent to browser
DEBUG - 2017-03-02 11:21:00 --> Total execution time: 0.2143
INFO - 2017-03-02 11:21:08 --> Config Class Initialized
INFO - 2017-03-02 11:21:08 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:21:08 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:21:08 --> Utf8 Class Initialized
INFO - 2017-03-02 11:21:08 --> URI Class Initialized
INFO - 2017-03-02 11:21:08 --> Router Class Initialized
INFO - 2017-03-02 11:21:08 --> Output Class Initialized
INFO - 2017-03-02 11:21:08 --> Security Class Initialized
DEBUG - 2017-03-02 11:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:21:08 --> Input Class Initialized
INFO - 2017-03-02 11:21:08 --> Language Class Initialized
INFO - 2017-03-02 11:21:08 --> Loader Class Initialized
INFO - 2017-03-02 11:21:08 --> Helper loaded: url_helper
INFO - 2017-03-02 11:21:08 --> Helper loaded: file_helper
INFO - 2017-03-02 11:21:08 --> Helper loaded: date_helper
INFO - 2017-03-02 11:21:08 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:21:09 --> Controller Class Initialized
INFO - 2017-03-02 11:21:09 --> Config Class Initialized
INFO - 2017-03-02 11:21:09 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:21:09 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:21:09 --> Utf8 Class Initialized
INFO - 2017-03-02 11:21:09 --> URI Class Initialized
INFO - 2017-03-02 11:21:09 --> Router Class Initialized
INFO - 2017-03-02 11:21:09 --> Output Class Initialized
INFO - 2017-03-02 11:21:09 --> Security Class Initialized
DEBUG - 2017-03-02 11:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:21:09 --> Input Class Initialized
INFO - 2017-03-02 11:21:09 --> Language Class Initialized
INFO - 2017-03-02 11:21:09 --> Loader Class Initialized
INFO - 2017-03-02 11:21:09 --> Helper loaded: url_helper
INFO - 2017-03-02 11:21:09 --> Helper loaded: file_helper
INFO - 2017-03-02 11:21:09 --> Helper loaded: date_helper
INFO - 2017-03-02 11:21:09 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:21:09 --> Controller Class Initialized
INFO - 2017-03-02 11:21:09 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-02 11:21:09 --> Final output sent to browser
DEBUG - 2017-03-02 11:21:09 --> Total execution time: 0.1460
INFO - 2017-03-02 11:26:38 --> Config Class Initialized
INFO - 2017-03-02 11:26:38 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:26:38 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:26:38 --> Utf8 Class Initialized
INFO - 2017-03-02 11:26:38 --> URI Class Initialized
INFO - 2017-03-02 11:26:38 --> Router Class Initialized
INFO - 2017-03-02 11:26:38 --> Output Class Initialized
INFO - 2017-03-02 11:26:38 --> Security Class Initialized
DEBUG - 2017-03-02 11:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:26:38 --> Input Class Initialized
INFO - 2017-03-02 11:26:38 --> Language Class Initialized
INFO - 2017-03-02 11:26:38 --> Loader Class Initialized
INFO - 2017-03-02 11:26:38 --> Helper loaded: url_helper
INFO - 2017-03-02 11:26:38 --> Helper loaded: file_helper
INFO - 2017-03-02 11:26:38 --> Helper loaded: date_helper
INFO - 2017-03-02 11:26:38 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:26:38 --> Controller Class Initialized
INFO - 2017-03-02 11:26:38 --> Model Class Initialized
INFO - 2017-03-02 11:26:39 --> Final output sent to browser
DEBUG - 2017-03-02 11:26:39 --> Total execution time: 0.6291
INFO - 2017-03-02 11:26:39 --> Config Class Initialized
INFO - 2017-03-02 11:26:39 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:26:39 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:26:39 --> Utf8 Class Initialized
INFO - 2017-03-02 11:26:39 --> URI Class Initialized
INFO - 2017-03-02 11:26:39 --> Router Class Initialized
INFO - 2017-03-02 11:26:39 --> Output Class Initialized
INFO - 2017-03-02 11:26:39 --> Security Class Initialized
DEBUG - 2017-03-02 11:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:26:39 --> Input Class Initialized
INFO - 2017-03-02 11:26:39 --> Language Class Initialized
INFO - 2017-03-02 11:26:39 --> Loader Class Initialized
INFO - 2017-03-02 11:26:39 --> Helper loaded: url_helper
INFO - 2017-03-02 11:26:39 --> Helper loaded: file_helper
INFO - 2017-03-02 11:26:39 --> Helper loaded: date_helper
INFO - 2017-03-02 11:26:39 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:26:39 --> Controller Class Initialized
INFO - 2017-03-02 11:26:39 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:26:39 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:26:39 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/dashboard.php
INFO - 2017-03-02 11:26:39 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:26:39 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:26:39 --> Final output sent to browser
DEBUG - 2017-03-02 11:26:39 --> Total execution time: 0.2081
INFO - 2017-03-02 11:26:43 --> Config Class Initialized
INFO - 2017-03-02 11:26:43 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:26:43 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:26:43 --> Utf8 Class Initialized
INFO - 2017-03-02 11:26:43 --> URI Class Initialized
INFO - 2017-03-02 11:26:43 --> Router Class Initialized
INFO - 2017-03-02 11:26:43 --> Output Class Initialized
INFO - 2017-03-02 11:26:43 --> Security Class Initialized
DEBUG - 2017-03-02 11:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:26:43 --> Input Class Initialized
INFO - 2017-03-02 11:26:43 --> Language Class Initialized
INFO - 2017-03-02 11:26:43 --> Loader Class Initialized
INFO - 2017-03-02 11:26:43 --> Helper loaded: url_helper
INFO - 2017-03-02 11:26:43 --> Helper loaded: file_helper
INFO - 2017-03-02 11:26:43 --> Helper loaded: date_helper
INFO - 2017-03-02 11:26:43 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:26:43 --> Controller Class Initialized
INFO - 2017-03-02 11:26:43 --> Model Class Initialized
INFO - 2017-03-02 11:26:43 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:26:43 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:26:43 --> File loaded: E:\XAMPP\htdocs\ci\application\views\questions/all_question.php
INFO - 2017-03-02 11:26:43 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:26:43 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:26:43 --> Final output sent to browser
DEBUG - 2017-03-02 11:26:43 --> Total execution time: 0.2038
INFO - 2017-03-02 11:26:47 --> Config Class Initialized
INFO - 2017-03-02 11:26:47 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:26:47 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:26:47 --> Utf8 Class Initialized
INFO - 2017-03-02 11:26:47 --> URI Class Initialized
INFO - 2017-03-02 11:26:47 --> Router Class Initialized
INFO - 2017-03-02 11:26:47 --> Output Class Initialized
INFO - 2017-03-02 11:26:47 --> Security Class Initialized
DEBUG - 2017-03-02 11:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:26:47 --> Input Class Initialized
INFO - 2017-03-02 11:26:47 --> Language Class Initialized
INFO - 2017-03-02 11:26:47 --> Loader Class Initialized
INFO - 2017-03-02 11:26:47 --> Helper loaded: url_helper
INFO - 2017-03-02 11:26:47 --> Helper loaded: file_helper
INFO - 2017-03-02 11:26:47 --> Helper loaded: date_helper
INFO - 2017-03-02 11:26:47 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:26:47 --> Controller Class Initialized
INFO - 2017-03-02 11:26:47 --> Model Class Initialized
INFO - 2017-03-02 11:26:47 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:26:47 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:26:47 --> File loaded: E:\XAMPP\htdocs\ci\application\views\subjects/subject_view.php
INFO - 2017-03-02 11:26:47 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:26:47 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:26:47 --> Final output sent to browser
DEBUG - 2017-03-02 11:26:47 --> Total execution time: 0.1866
INFO - 2017-03-02 11:26:49 --> Config Class Initialized
INFO - 2017-03-02 11:26:49 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:26:49 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:26:49 --> Utf8 Class Initialized
INFO - 2017-03-02 11:26:49 --> URI Class Initialized
INFO - 2017-03-02 11:26:49 --> Router Class Initialized
INFO - 2017-03-02 11:26:49 --> Output Class Initialized
INFO - 2017-03-02 11:26:49 --> Security Class Initialized
DEBUG - 2017-03-02 11:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:26:49 --> Input Class Initialized
INFO - 2017-03-02 11:26:49 --> Language Class Initialized
INFO - 2017-03-02 11:26:49 --> Loader Class Initialized
INFO - 2017-03-02 11:26:49 --> Helper loaded: url_helper
INFO - 2017-03-02 11:26:49 --> Helper loaded: file_helper
INFO - 2017-03-02 11:26:49 --> Helper loaded: date_helper
INFO - 2017-03-02 11:26:49 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:26:49 --> Controller Class Initialized
INFO - 2017-03-02 11:26:49 --> Model Class Initialized
INFO - 2017-03-02 11:26:49 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:26:49 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:26:49 --> File loaded: E:\XAMPP\htdocs\ci\application\views\subjects/edit_subject.php
INFO - 2017-03-02 11:26:49 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:26:49 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:26:49 --> Final output sent to browser
DEBUG - 2017-03-02 11:26:49 --> Total execution time: 0.1897
INFO - 2017-03-02 11:26:52 --> Config Class Initialized
INFO - 2017-03-02 11:26:52 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:26:52 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:26:52 --> Utf8 Class Initialized
INFO - 2017-03-02 11:26:52 --> URI Class Initialized
INFO - 2017-03-02 11:26:52 --> Router Class Initialized
INFO - 2017-03-02 11:26:52 --> Output Class Initialized
INFO - 2017-03-02 11:26:52 --> Security Class Initialized
DEBUG - 2017-03-02 11:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:26:52 --> Input Class Initialized
INFO - 2017-03-02 11:26:52 --> Language Class Initialized
INFO - 2017-03-02 11:26:52 --> Loader Class Initialized
INFO - 2017-03-02 11:26:52 --> Helper loaded: url_helper
INFO - 2017-03-02 11:26:52 --> Helper loaded: file_helper
INFO - 2017-03-02 11:26:52 --> Helper loaded: date_helper
INFO - 2017-03-02 11:26:52 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:26:52 --> Controller Class Initialized
INFO - 2017-03-02 11:26:52 --> Model Class Initialized
INFO - 2017-03-02 11:26:52 --> Config Class Initialized
INFO - 2017-03-02 11:26:52 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:26:52 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:26:52 --> Utf8 Class Initialized
INFO - 2017-03-02 11:26:52 --> URI Class Initialized
INFO - 2017-03-02 11:26:52 --> Router Class Initialized
INFO - 2017-03-02 11:26:52 --> Output Class Initialized
INFO - 2017-03-02 11:26:52 --> Security Class Initialized
DEBUG - 2017-03-02 11:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:26:52 --> Input Class Initialized
INFO - 2017-03-02 11:26:52 --> Language Class Initialized
INFO - 2017-03-02 11:26:52 --> Loader Class Initialized
INFO - 2017-03-02 11:26:52 --> Helper loaded: url_helper
INFO - 2017-03-02 11:26:53 --> Helper loaded: file_helper
INFO - 2017-03-02 11:26:53 --> Helper loaded: date_helper
INFO - 2017-03-02 11:26:53 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:26:53 --> Controller Class Initialized
INFO - 2017-03-02 11:26:53 --> Model Class Initialized
INFO - 2017-03-02 11:26:53 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:26:53 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:26:53 --> File loaded: E:\XAMPP\htdocs\ci\application\views\subjects/subject_view.php
INFO - 2017-03-02 11:26:53 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:26:53 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:26:53 --> Final output sent to browser
DEBUG - 2017-03-02 11:26:53 --> Total execution time: 0.1451
INFO - 2017-03-02 11:26:56 --> Config Class Initialized
INFO - 2017-03-02 11:26:56 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:26:56 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:26:56 --> Utf8 Class Initialized
INFO - 2017-03-02 11:26:56 --> URI Class Initialized
INFO - 2017-03-02 11:26:56 --> Router Class Initialized
INFO - 2017-03-02 11:26:56 --> Output Class Initialized
INFO - 2017-03-02 11:26:56 --> Security Class Initialized
DEBUG - 2017-03-02 11:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:26:56 --> Input Class Initialized
INFO - 2017-03-02 11:26:56 --> Language Class Initialized
INFO - 2017-03-02 11:26:56 --> Loader Class Initialized
INFO - 2017-03-02 11:26:56 --> Helper loaded: url_helper
INFO - 2017-03-02 11:26:56 --> Helper loaded: file_helper
INFO - 2017-03-02 11:26:56 --> Helper loaded: date_helper
INFO - 2017-03-02 11:26:56 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:26:56 --> Controller Class Initialized
INFO - 2017-03-02 11:26:56 --> Model Class Initialized
INFO - 2017-03-02 11:26:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:26:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:26:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\questions/all_question.php
INFO - 2017-03-02 11:26:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:26:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:26:56 --> Final output sent to browser
DEBUG - 2017-03-02 11:26:56 --> Total execution time: 0.1601
INFO - 2017-03-02 11:26:59 --> Config Class Initialized
INFO - 2017-03-02 11:26:59 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:26:59 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:26:59 --> Utf8 Class Initialized
INFO - 2017-03-02 11:26:59 --> URI Class Initialized
INFO - 2017-03-02 11:26:59 --> Router Class Initialized
INFO - 2017-03-02 11:26:59 --> Output Class Initialized
INFO - 2017-03-02 11:26:59 --> Security Class Initialized
DEBUG - 2017-03-02 11:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:26:59 --> Input Class Initialized
INFO - 2017-03-02 11:26:59 --> Language Class Initialized
INFO - 2017-03-02 11:26:59 --> Loader Class Initialized
INFO - 2017-03-02 11:26:59 --> Helper loaded: url_helper
INFO - 2017-03-02 11:26:59 --> Helper loaded: file_helper
INFO - 2017-03-02 11:26:59 --> Helper loaded: date_helper
INFO - 2017-03-02 11:26:59 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:26:59 --> Controller Class Initialized
INFO - 2017-03-02 11:26:59 --> Model Class Initialized
INFO - 2017-03-02 11:26:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:26:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:26:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/all_exam_view.php
INFO - 2017-03-02 11:26:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:26:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:26:59 --> Final output sent to browser
DEBUG - 2017-03-02 11:26:59 --> Total execution time: 0.2045
INFO - 2017-03-02 11:27:01 --> Config Class Initialized
INFO - 2017-03-02 11:27:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:27:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:27:01 --> Utf8 Class Initialized
INFO - 2017-03-02 11:27:01 --> URI Class Initialized
INFO - 2017-03-02 11:27:01 --> Router Class Initialized
INFO - 2017-03-02 11:27:01 --> Output Class Initialized
INFO - 2017-03-02 11:27:01 --> Security Class Initialized
DEBUG - 2017-03-02 11:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:27:01 --> Input Class Initialized
INFO - 2017-03-02 11:27:01 --> Language Class Initialized
INFO - 2017-03-02 11:27:01 --> Loader Class Initialized
INFO - 2017-03-02 11:27:01 --> Helper loaded: url_helper
INFO - 2017-03-02 11:27:01 --> Helper loaded: file_helper
INFO - 2017-03-02 11:27:01 --> Helper loaded: date_helper
INFO - 2017-03-02 11:27:01 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:27:01 --> Controller Class Initialized
INFO - 2017-03-02 11:27:01 --> Model Class Initialized
INFO - 2017-03-02 11:27:01 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:27:01 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:27:01 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/assign_exam.php
INFO - 2017-03-02 11:27:01 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:27:01 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:27:01 --> Final output sent to browser
DEBUG - 2017-03-02 11:27:01 --> Total execution time: 0.1629
INFO - 2017-03-02 11:27:56 --> Config Class Initialized
INFO - 2017-03-02 11:27:56 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:27:56 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:27:56 --> Utf8 Class Initialized
INFO - 2017-03-02 11:27:56 --> URI Class Initialized
INFO - 2017-03-02 11:27:56 --> Router Class Initialized
INFO - 2017-03-02 11:27:56 --> Output Class Initialized
INFO - 2017-03-02 11:27:56 --> Security Class Initialized
DEBUG - 2017-03-02 11:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:27:56 --> Input Class Initialized
INFO - 2017-03-02 11:27:56 --> Language Class Initialized
INFO - 2017-03-02 11:27:56 --> Loader Class Initialized
INFO - 2017-03-02 11:27:56 --> Helper loaded: url_helper
INFO - 2017-03-02 11:27:56 --> Helper loaded: file_helper
INFO - 2017-03-02 11:27:56 --> Helper loaded: date_helper
INFO - 2017-03-02 11:27:56 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:27:56 --> Controller Class Initialized
INFO - 2017-03-02 11:27:56 --> Model Class Initialized
INFO - 2017-03-02 11:27:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:27:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:27:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/assign_exam.php
INFO - 2017-03-02 11:27:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:27:56 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:27:56 --> Final output sent to browser
DEBUG - 2017-03-02 11:27:56 --> Total execution time: 0.1570
INFO - 2017-03-02 11:28:01 --> Config Class Initialized
INFO - 2017-03-02 11:28:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:01 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:01 --> URI Class Initialized
INFO - 2017-03-02 11:28:01 --> Router Class Initialized
INFO - 2017-03-02 11:28:01 --> Output Class Initialized
INFO - 2017-03-02 11:28:01 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:01 --> Input Class Initialized
INFO - 2017-03-02 11:28:01 --> Language Class Initialized
INFO - 2017-03-02 11:28:01 --> Loader Class Initialized
INFO - 2017-03-02 11:28:01 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:01 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:01 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:01 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:01 --> Controller Class Initialized
INFO - 2017-03-02 11:28:01 --> Model Class Initialized
INFO - 2017-03-02 11:28:01 --> Config Class Initialized
INFO - 2017-03-02 11:28:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:01 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:01 --> URI Class Initialized
INFO - 2017-03-02 11:28:01 --> Router Class Initialized
INFO - 2017-03-02 11:28:01 --> Output Class Initialized
INFO - 2017-03-02 11:28:01 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:01 --> Input Class Initialized
INFO - 2017-03-02 11:28:01 --> Language Class Initialized
INFO - 2017-03-02 11:28:01 --> Loader Class Initialized
INFO - 2017-03-02 11:28:01 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:01 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:01 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:01 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:01 --> Controller Class Initialized
INFO - 2017-03-02 11:28:01 --> Model Class Initialized
INFO - 2017-03-02 11:28:01 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:28:01 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:28:01 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/assign_exam.php
INFO - 2017-03-02 11:28:01 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:28:01 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:28:01 --> Final output sent to browser
DEBUG - 2017-03-02 11:28:01 --> Total execution time: 0.1675
INFO - 2017-03-02 11:28:03 --> Config Class Initialized
INFO - 2017-03-02 11:28:03 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:03 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:03 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:03 --> URI Class Initialized
INFO - 2017-03-02 11:28:03 --> Router Class Initialized
INFO - 2017-03-02 11:28:03 --> Output Class Initialized
INFO - 2017-03-02 11:28:03 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:03 --> Input Class Initialized
INFO - 2017-03-02 11:28:03 --> Language Class Initialized
INFO - 2017-03-02 11:28:03 --> Loader Class Initialized
INFO - 2017-03-02 11:28:03 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:03 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:03 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:03 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:03 --> Controller Class Initialized
DEBUG - 2017-03-02 11:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 11:28:03 --> Config Class Initialized
INFO - 2017-03-02 11:28:03 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:03 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:03 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:03 --> URI Class Initialized
INFO - 2017-03-02 11:28:03 --> Router Class Initialized
INFO - 2017-03-02 11:28:03 --> Output Class Initialized
INFO - 2017-03-02 11:28:03 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:03 --> Input Class Initialized
INFO - 2017-03-02 11:28:03 --> Language Class Initialized
INFO - 2017-03-02 11:28:03 --> Loader Class Initialized
INFO - 2017-03-02 11:28:03 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:03 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:03 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:03 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:03 --> Controller Class Initialized
INFO - 2017-03-02 11:28:03 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-02 11:28:03 --> Final output sent to browser
DEBUG - 2017-03-02 11:28:03 --> Total execution time: 0.1387
INFO - 2017-03-02 11:28:10 --> Config Class Initialized
INFO - 2017-03-02 11:28:10 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:10 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:10 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:10 --> URI Class Initialized
INFO - 2017-03-02 11:28:10 --> Router Class Initialized
INFO - 2017-03-02 11:28:10 --> Output Class Initialized
INFO - 2017-03-02 11:28:10 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:10 --> Input Class Initialized
INFO - 2017-03-02 11:28:10 --> Language Class Initialized
INFO - 2017-03-02 11:28:10 --> Loader Class Initialized
INFO - 2017-03-02 11:28:10 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:10 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:10 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:10 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:10 --> Controller Class Initialized
INFO - 2017-03-02 11:28:10 --> Model Class Initialized
INFO - 2017-03-02 11:28:10 --> Config Class Initialized
INFO - 2017-03-02 11:28:10 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:10 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:10 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:10 --> URI Class Initialized
INFO - 2017-03-02 11:28:10 --> Router Class Initialized
INFO - 2017-03-02 11:28:10 --> Output Class Initialized
INFO - 2017-03-02 11:28:10 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:10 --> Input Class Initialized
INFO - 2017-03-02 11:28:10 --> Language Class Initialized
INFO - 2017-03-02 11:28:10 --> Loader Class Initialized
INFO - 2017-03-02 11:28:10 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:10 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:10 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:10 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:10 --> Controller Class Initialized
INFO - 2017-03-02 11:28:10 --> Model Class Initialized
INFO - 2017-03-02 11:28:10 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:28:10 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:28:10 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/dashboard.php
INFO - 2017-03-02 11:28:11 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:28:11 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:28:11 --> Final output sent to browser
DEBUG - 2017-03-02 11:28:11 --> Total execution time: 0.2248
INFO - 2017-03-02 11:28:12 --> Config Class Initialized
INFO - 2017-03-02 11:28:12 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:12 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:12 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:12 --> URI Class Initialized
INFO - 2017-03-02 11:28:12 --> Router Class Initialized
INFO - 2017-03-02 11:28:12 --> Output Class Initialized
INFO - 2017-03-02 11:28:12 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:12 --> Input Class Initialized
INFO - 2017-03-02 11:28:12 --> Language Class Initialized
INFO - 2017-03-02 11:28:12 --> Loader Class Initialized
INFO - 2017-03-02 11:28:12 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:12 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:12 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:12 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:12 --> Controller Class Initialized
INFO - 2017-03-02 11:28:12 --> Model Class Initialized
INFO - 2017-03-02 11:28:12 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:28:12 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:28:12 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/exam_view.php
INFO - 2017-03-02 11:28:12 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:28:12 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:28:12 --> Final output sent to browser
DEBUG - 2017-03-02 11:28:12 --> Total execution time: 0.1682
INFO - 2017-03-02 11:28:14 --> Config Class Initialized
INFO - 2017-03-02 11:28:14 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:14 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:14 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:14 --> URI Class Initialized
INFO - 2017-03-02 11:28:14 --> Router Class Initialized
INFO - 2017-03-02 11:28:14 --> Output Class Initialized
INFO - 2017-03-02 11:28:14 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:14 --> Input Class Initialized
INFO - 2017-03-02 11:28:14 --> Language Class Initialized
INFO - 2017-03-02 11:28:14 --> Loader Class Initialized
INFO - 2017-03-02 11:28:14 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:14 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:14 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:14 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:14 --> Controller Class Initialized
INFO - 2017-03-02 11:28:14 --> Model Class Initialized
INFO - 2017-03-02 11:28:14 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:28:14 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:28:14 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/exam.php
INFO - 2017-03-02 11:28:14 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:28:14 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:28:14 --> Final output sent to browser
DEBUG - 2017-03-02 11:28:14 --> Total execution time: 0.1854
INFO - 2017-03-02 11:28:18 --> Config Class Initialized
INFO - 2017-03-02 11:28:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:18 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:18 --> URI Class Initialized
INFO - 2017-03-02 11:28:18 --> Router Class Initialized
INFO - 2017-03-02 11:28:18 --> Output Class Initialized
INFO - 2017-03-02 11:28:18 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:18 --> Input Class Initialized
INFO - 2017-03-02 11:28:18 --> Language Class Initialized
INFO - 2017-03-02 11:28:18 --> Loader Class Initialized
INFO - 2017-03-02 11:28:18 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:18 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:18 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:18 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:18 --> Controller Class Initialized
INFO - 2017-03-02 11:28:18 --> Model Class Initialized
INFO - 2017-03-02 11:28:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:28:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:28:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/exam.php
INFO - 2017-03-02 11:28:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:28:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:28:18 --> Final output sent to browser
DEBUG - 2017-03-02 11:28:18 --> Total execution time: 0.1934
INFO - 2017-03-02 11:28:20 --> Config Class Initialized
INFO - 2017-03-02 11:28:20 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:20 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:20 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:20 --> URI Class Initialized
INFO - 2017-03-02 11:28:20 --> Router Class Initialized
INFO - 2017-03-02 11:28:20 --> Output Class Initialized
INFO - 2017-03-02 11:28:20 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:20 --> Input Class Initialized
INFO - 2017-03-02 11:28:20 --> Language Class Initialized
INFO - 2017-03-02 11:28:20 --> Loader Class Initialized
INFO - 2017-03-02 11:28:20 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:20 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:20 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:20 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:20 --> Controller Class Initialized
INFO - 2017-03-02 11:28:20 --> Model Class Initialized
INFO - 2017-03-02 11:28:20 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:28:20 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:28:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/exam_finish.php
INFO - 2017-03-02 11:28:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:28:21 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:28:21 --> Final output sent to browser
DEBUG - 2017-03-02 11:28:21 --> Total execution time: 1.6911
INFO - 2017-03-02 11:28:24 --> Config Class Initialized
INFO - 2017-03-02 11:28:24 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:24 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:24 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:24 --> URI Class Initialized
INFO - 2017-03-02 11:28:24 --> Router Class Initialized
INFO - 2017-03-02 11:28:24 --> Output Class Initialized
INFO - 2017-03-02 11:28:24 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:24 --> Input Class Initialized
INFO - 2017-03-02 11:28:24 --> Language Class Initialized
INFO - 2017-03-02 11:28:24 --> Loader Class Initialized
INFO - 2017-03-02 11:28:24 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:24 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:24 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:24 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:24 --> Controller Class Initialized
INFO - 2017-03-02 11:28:24 --> Model Class Initialized
INFO - 2017-03-02 11:28:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:28:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:28:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/exam_view.php
INFO - 2017-03-02 11:28:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:28:24 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:28:24 --> Final output sent to browser
DEBUG - 2017-03-02 11:28:24 --> Total execution time: 0.1650
INFO - 2017-03-02 11:28:25 --> Config Class Initialized
INFO - 2017-03-02 11:28:25 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:28:25 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:28:25 --> Utf8 Class Initialized
INFO - 2017-03-02 11:28:25 --> URI Class Initialized
INFO - 2017-03-02 11:28:25 --> Router Class Initialized
INFO - 2017-03-02 11:28:25 --> Output Class Initialized
INFO - 2017-03-02 11:28:25 --> Security Class Initialized
DEBUG - 2017-03-02 11:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:28:25 --> Input Class Initialized
INFO - 2017-03-02 11:28:25 --> Language Class Initialized
INFO - 2017-03-02 11:28:25 --> Loader Class Initialized
INFO - 2017-03-02 11:28:25 --> Helper loaded: url_helper
INFO - 2017-03-02 11:28:25 --> Helper loaded: file_helper
INFO - 2017-03-02 11:28:25 --> Helper loaded: date_helper
INFO - 2017-03-02 11:28:25 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:28:25 --> Controller Class Initialized
INFO - 2017-03-02 11:28:25 --> Model Class Initialized
INFO - 2017-03-02 11:28:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:28:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:28:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/taken_exam.php
INFO - 2017-03-02 11:28:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:28:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:28:25 --> Final output sent to browser
DEBUG - 2017-03-02 11:28:25 --> Total execution time: 0.1628
INFO - 2017-03-02 11:29:19 --> Config Class Initialized
INFO - 2017-03-02 11:29:19 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:29:19 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:29:19 --> Utf8 Class Initialized
INFO - 2017-03-02 11:29:19 --> URI Class Initialized
INFO - 2017-03-02 11:29:19 --> Router Class Initialized
INFO - 2017-03-02 11:29:19 --> Output Class Initialized
INFO - 2017-03-02 11:29:19 --> Security Class Initialized
DEBUG - 2017-03-02 11:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:29:19 --> Input Class Initialized
INFO - 2017-03-02 11:29:19 --> Language Class Initialized
INFO - 2017-03-02 11:29:19 --> Loader Class Initialized
INFO - 2017-03-02 11:29:19 --> Helper loaded: url_helper
INFO - 2017-03-02 11:29:19 --> Helper loaded: file_helper
INFO - 2017-03-02 11:29:19 --> Helper loaded: date_helper
INFO - 2017-03-02 11:29:19 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:29:19 --> Controller Class Initialized
DEBUG - 2017-03-02 11:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 11:29:19 --> Config Class Initialized
INFO - 2017-03-02 11:29:19 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:29:19 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:29:19 --> Utf8 Class Initialized
INFO - 2017-03-02 11:29:19 --> URI Class Initialized
INFO - 2017-03-02 11:29:19 --> Router Class Initialized
INFO - 2017-03-02 11:29:19 --> Output Class Initialized
INFO - 2017-03-02 11:29:19 --> Security Class Initialized
DEBUG - 2017-03-02 11:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:29:19 --> Input Class Initialized
INFO - 2017-03-02 11:29:19 --> Language Class Initialized
INFO - 2017-03-02 11:29:19 --> Loader Class Initialized
INFO - 2017-03-02 11:29:19 --> Helper loaded: url_helper
INFO - 2017-03-02 11:29:19 --> Helper loaded: file_helper
INFO - 2017-03-02 11:29:19 --> Helper loaded: date_helper
INFO - 2017-03-02 11:29:19 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:29:19 --> Controller Class Initialized
INFO - 2017-03-02 11:29:19 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-02 11:29:19 --> Final output sent to browser
DEBUG - 2017-03-02 11:29:19 --> Total execution time: 0.1352
INFO - 2017-03-02 11:29:23 --> Config Class Initialized
INFO - 2017-03-02 11:29:23 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:29:23 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:29:23 --> Utf8 Class Initialized
INFO - 2017-03-02 11:29:23 --> URI Class Initialized
INFO - 2017-03-02 11:29:23 --> Router Class Initialized
INFO - 2017-03-02 11:29:23 --> Output Class Initialized
INFO - 2017-03-02 11:29:23 --> Security Class Initialized
DEBUG - 2017-03-02 11:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:29:23 --> Input Class Initialized
INFO - 2017-03-02 11:29:23 --> Language Class Initialized
INFO - 2017-03-02 11:29:23 --> Loader Class Initialized
INFO - 2017-03-02 11:29:23 --> Helper loaded: url_helper
INFO - 2017-03-02 11:29:23 --> Helper loaded: file_helper
INFO - 2017-03-02 11:29:23 --> Helper loaded: date_helper
INFO - 2017-03-02 11:29:23 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:29:23 --> Controller Class Initialized
INFO - 2017-03-02 11:29:23 --> Model Class Initialized
INFO - 2017-03-02 11:29:23 --> Final output sent to browser
DEBUG - 2017-03-02 11:29:23 --> Total execution time: 0.1416
INFO - 2017-03-02 11:29:23 --> Config Class Initialized
INFO - 2017-03-02 11:29:23 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:29:23 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:29:23 --> Utf8 Class Initialized
INFO - 2017-03-02 11:29:23 --> URI Class Initialized
INFO - 2017-03-02 11:29:23 --> Router Class Initialized
INFO - 2017-03-02 11:29:23 --> Output Class Initialized
INFO - 2017-03-02 11:29:23 --> Security Class Initialized
DEBUG - 2017-03-02 11:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:29:23 --> Input Class Initialized
INFO - 2017-03-02 11:29:23 --> Language Class Initialized
INFO - 2017-03-02 11:29:23 --> Loader Class Initialized
INFO - 2017-03-02 11:29:23 --> Helper loaded: url_helper
INFO - 2017-03-02 11:29:23 --> Helper loaded: file_helper
INFO - 2017-03-02 11:29:23 --> Helper loaded: date_helper
INFO - 2017-03-02 11:29:23 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:29:23 --> Controller Class Initialized
INFO - 2017-03-02 11:29:23 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:29:23 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:29:23 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/dashboard.php
INFO - 2017-03-02 11:29:23 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:29:23 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:29:23 --> Final output sent to browser
DEBUG - 2017-03-02 11:29:23 --> Total execution time: 0.1558
INFO - 2017-03-02 11:29:25 --> Config Class Initialized
INFO - 2017-03-02 11:29:25 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:29:25 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:29:25 --> Utf8 Class Initialized
INFO - 2017-03-02 11:29:25 --> URI Class Initialized
INFO - 2017-03-02 11:29:25 --> Router Class Initialized
INFO - 2017-03-02 11:29:25 --> Output Class Initialized
INFO - 2017-03-02 11:29:25 --> Security Class Initialized
DEBUG - 2017-03-02 11:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:29:25 --> Input Class Initialized
INFO - 2017-03-02 11:29:25 --> Language Class Initialized
INFO - 2017-03-02 11:29:25 --> Loader Class Initialized
INFO - 2017-03-02 11:29:25 --> Helper loaded: url_helper
INFO - 2017-03-02 11:29:25 --> Helper loaded: file_helper
INFO - 2017-03-02 11:29:25 --> Helper loaded: date_helper
INFO - 2017-03-02 11:29:25 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:29:25 --> Controller Class Initialized
INFO - 2017-03-02 11:29:25 --> Model Class Initialized
INFO - 2017-03-02 11:29:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:29:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:29:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/all_exam_view.php
INFO - 2017-03-02 11:29:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:29:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:29:25 --> Final output sent to browser
DEBUG - 2017-03-02 11:29:25 --> Total execution time: 0.1676
INFO - 2017-03-02 11:29:29 --> Config Class Initialized
INFO - 2017-03-02 11:29:29 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:29:29 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:29:29 --> Utf8 Class Initialized
INFO - 2017-03-02 11:29:29 --> URI Class Initialized
INFO - 2017-03-02 11:29:29 --> Router Class Initialized
INFO - 2017-03-02 11:29:29 --> Output Class Initialized
INFO - 2017-03-02 11:29:29 --> Security Class Initialized
DEBUG - 2017-03-02 11:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:29:30 --> Input Class Initialized
INFO - 2017-03-02 11:29:30 --> Language Class Initialized
INFO - 2017-03-02 11:29:30 --> Loader Class Initialized
INFO - 2017-03-02 11:29:30 --> Helper loaded: url_helper
INFO - 2017-03-02 11:29:30 --> Helper loaded: file_helper
INFO - 2017-03-02 11:29:30 --> Helper loaded: date_helper
INFO - 2017-03-02 11:29:30 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:29:30 --> Controller Class Initialized
INFO - 2017-03-02 11:29:30 --> Model Class Initialized
INFO - 2017-03-02 11:29:30 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:29:30 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:29:30 --> File loaded: E:\XAMPP\htdocs\ci\application\views\questions/all_question.php
INFO - 2017-03-02 11:29:30 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:29:30 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:29:30 --> Final output sent to browser
DEBUG - 2017-03-02 11:29:30 --> Total execution time: 0.1656
INFO - 2017-03-02 11:29:40 --> Config Class Initialized
INFO - 2017-03-02 11:29:40 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:29:40 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:29:40 --> Utf8 Class Initialized
INFO - 2017-03-02 11:29:40 --> URI Class Initialized
INFO - 2017-03-02 11:29:40 --> Router Class Initialized
INFO - 2017-03-02 11:29:40 --> Output Class Initialized
INFO - 2017-03-02 11:29:40 --> Security Class Initialized
DEBUG - 2017-03-02 11:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:29:40 --> Input Class Initialized
INFO - 2017-03-02 11:29:40 --> Language Class Initialized
INFO - 2017-03-02 11:29:40 --> Loader Class Initialized
INFO - 2017-03-02 11:29:40 --> Helper loaded: url_helper
INFO - 2017-03-02 11:29:40 --> Helper loaded: file_helper
INFO - 2017-03-02 11:29:40 --> Helper loaded: date_helper
INFO - 2017-03-02 11:29:40 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:29:40 --> Controller Class Initialized
INFO - 2017-03-02 11:29:40 --> Model Class Initialized
INFO - 2017-03-02 11:29:40 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:29:40 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:29:40 --> File loaded: E:\XAMPP\htdocs\ci\application\views\teacher/create_teacher.php
INFO - 2017-03-02 11:29:40 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:29:40 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:29:40 --> Final output sent to browser
DEBUG - 2017-03-02 11:29:40 --> Total execution time: 0.1998
INFO - 2017-03-02 11:30:01 --> Config Class Initialized
INFO - 2017-03-02 11:30:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:30:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:30:01 --> Utf8 Class Initialized
INFO - 2017-03-02 11:30:01 --> URI Class Initialized
INFO - 2017-03-02 11:30:01 --> Router Class Initialized
INFO - 2017-03-02 11:30:01 --> Output Class Initialized
INFO - 2017-03-02 11:30:01 --> Security Class Initialized
DEBUG - 2017-03-02 11:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:30:01 --> Input Class Initialized
INFO - 2017-03-02 11:30:01 --> Language Class Initialized
INFO - 2017-03-02 11:30:01 --> Loader Class Initialized
INFO - 2017-03-02 11:30:01 --> Helper loaded: url_helper
INFO - 2017-03-02 11:30:01 --> Helper loaded: file_helper
INFO - 2017-03-02 11:30:01 --> Helper loaded: date_helper
INFO - 2017-03-02 11:30:01 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:30:01 --> Controller Class Initialized
INFO - 2017-03-02 11:30:01 --> Model Class Initialized
INFO - 2017-03-02 11:30:01 --> Config Class Initialized
INFO - 2017-03-02 11:30:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:30:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:30:01 --> Utf8 Class Initialized
INFO - 2017-03-02 11:30:01 --> URI Class Initialized
INFO - 2017-03-02 11:30:02 --> Router Class Initialized
INFO - 2017-03-02 11:30:02 --> Output Class Initialized
INFO - 2017-03-02 11:30:02 --> Security Class Initialized
DEBUG - 2017-03-02 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:30:02 --> Input Class Initialized
INFO - 2017-03-02 11:30:02 --> Language Class Initialized
INFO - 2017-03-02 11:30:02 --> Loader Class Initialized
INFO - 2017-03-02 11:30:02 --> Helper loaded: url_helper
INFO - 2017-03-02 11:30:02 --> Helper loaded: file_helper
INFO - 2017-03-02 11:30:02 --> Helper loaded: date_helper
INFO - 2017-03-02 11:30:02 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:30:02 --> Controller Class Initialized
INFO - 2017-03-02 11:30:02 --> Model Class Initialized
INFO - 2017-03-02 11:30:02 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:30:02 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:30:02 --> File loaded: E:\XAMPP\htdocs\ci\application\views\teacher/teacher_view.php
INFO - 2017-03-02 11:30:02 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:30:02 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:30:02 --> Final output sent to browser
DEBUG - 2017-03-02 11:30:02 --> Total execution time: 0.1842
INFO - 2017-03-02 11:30:16 --> Config Class Initialized
INFO - 2017-03-02 11:30:16 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:30:16 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:30:16 --> Utf8 Class Initialized
INFO - 2017-03-02 11:30:16 --> URI Class Initialized
INFO - 2017-03-02 11:30:16 --> Router Class Initialized
INFO - 2017-03-02 11:30:16 --> Output Class Initialized
INFO - 2017-03-02 11:30:16 --> Security Class Initialized
DEBUG - 2017-03-02 11:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:30:16 --> Input Class Initialized
INFO - 2017-03-02 11:30:16 --> Language Class Initialized
ERROR - 2017-03-02 11:30:16 --> 404 Page Not Found: Teacher_Controller/delete_teacher
INFO - 2017-03-02 11:30:18 --> Config Class Initialized
INFO - 2017-03-02 11:30:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:30:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:30:18 --> Utf8 Class Initialized
INFO - 2017-03-02 11:30:18 --> URI Class Initialized
INFO - 2017-03-02 11:30:18 --> Router Class Initialized
INFO - 2017-03-02 11:30:18 --> Output Class Initialized
INFO - 2017-03-02 11:30:18 --> Security Class Initialized
DEBUG - 2017-03-02 11:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:30:18 --> Input Class Initialized
INFO - 2017-03-02 11:30:18 --> Language Class Initialized
INFO - 2017-03-02 11:30:18 --> Loader Class Initialized
INFO - 2017-03-02 11:30:18 --> Helper loaded: url_helper
INFO - 2017-03-02 11:30:18 --> Helper loaded: file_helper
INFO - 2017-03-02 11:30:18 --> Helper loaded: date_helper
INFO - 2017-03-02 11:30:18 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:30:18 --> Controller Class Initialized
INFO - 2017-03-02 11:30:18 --> Model Class Initialized
INFO - 2017-03-02 11:30:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:30:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:30:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\teacher/teacher_view.php
INFO - 2017-03-02 11:30:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:30:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:30:18 --> Final output sent to browser
DEBUG - 2017-03-02 11:30:18 --> Total execution time: 0.1903
INFO - 2017-03-02 11:30:25 --> Config Class Initialized
INFO - 2017-03-02 11:30:25 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:30:25 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:30:25 --> Utf8 Class Initialized
INFO - 2017-03-02 11:30:25 --> URI Class Initialized
INFO - 2017-03-02 11:30:25 --> Router Class Initialized
INFO - 2017-03-02 11:30:25 --> Output Class Initialized
INFO - 2017-03-02 11:30:25 --> Security Class Initialized
DEBUG - 2017-03-02 11:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:30:25 --> Input Class Initialized
INFO - 2017-03-02 11:30:25 --> Language Class Initialized
INFO - 2017-03-02 11:30:25 --> Loader Class Initialized
INFO - 2017-03-02 11:30:25 --> Helper loaded: url_helper
INFO - 2017-03-02 11:30:25 --> Helper loaded: file_helper
INFO - 2017-03-02 11:30:25 --> Helper loaded: date_helper
INFO - 2017-03-02 11:30:25 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:30:25 --> Controller Class Initialized
INFO - 2017-03-02 11:30:25 --> Model Class Initialized
INFO - 2017-03-02 11:30:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:30:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:30:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\subjects/create_subject.php
INFO - 2017-03-02 11:30:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:30:25 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:30:25 --> Final output sent to browser
DEBUG - 2017-03-02 11:30:25 --> Total execution time: 0.1738
INFO - 2017-03-02 11:30:33 --> Config Class Initialized
INFO - 2017-03-02 11:30:33 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:30:33 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:30:33 --> Utf8 Class Initialized
INFO - 2017-03-02 11:30:33 --> URI Class Initialized
INFO - 2017-03-02 11:30:33 --> Router Class Initialized
INFO - 2017-03-02 11:30:33 --> Output Class Initialized
INFO - 2017-03-02 11:30:33 --> Security Class Initialized
DEBUG - 2017-03-02 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:30:33 --> Input Class Initialized
INFO - 2017-03-02 11:30:33 --> Language Class Initialized
INFO - 2017-03-02 11:30:33 --> Loader Class Initialized
INFO - 2017-03-02 11:30:34 --> Helper loaded: url_helper
INFO - 2017-03-02 11:30:34 --> Helper loaded: file_helper
INFO - 2017-03-02 11:30:34 --> Helper loaded: date_helper
INFO - 2017-03-02 11:30:34 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:30:34 --> Controller Class Initialized
INFO - 2017-03-02 11:30:34 --> Model Class Initialized
INFO - 2017-03-02 11:30:34 --> Config Class Initialized
INFO - 2017-03-02 11:30:34 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:30:34 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:30:34 --> Utf8 Class Initialized
INFO - 2017-03-02 11:30:34 --> URI Class Initialized
INFO - 2017-03-02 11:30:34 --> Router Class Initialized
INFO - 2017-03-02 11:30:34 --> Output Class Initialized
INFO - 2017-03-02 11:30:34 --> Security Class Initialized
DEBUG - 2017-03-02 11:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:30:34 --> Input Class Initialized
INFO - 2017-03-02 11:30:34 --> Language Class Initialized
INFO - 2017-03-02 11:30:34 --> Loader Class Initialized
INFO - 2017-03-02 11:30:34 --> Helper loaded: url_helper
INFO - 2017-03-02 11:30:34 --> Helper loaded: file_helper
INFO - 2017-03-02 11:30:34 --> Helper loaded: date_helper
INFO - 2017-03-02 11:30:34 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:30:34 --> Controller Class Initialized
INFO - 2017-03-02 11:30:34 --> Model Class Initialized
INFO - 2017-03-02 11:30:34 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:30:34 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:30:34 --> File loaded: E:\XAMPP\htdocs\ci\application\views\subjects/subject_view.php
INFO - 2017-03-02 11:30:34 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:30:34 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:30:34 --> Final output sent to browser
DEBUG - 2017-03-02 11:30:34 --> Total execution time: 0.1710
INFO - 2017-03-02 11:30:59 --> Config Class Initialized
INFO - 2017-03-02 11:30:59 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:30:59 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:30:59 --> Utf8 Class Initialized
INFO - 2017-03-02 11:30:59 --> URI Class Initialized
INFO - 2017-03-02 11:30:59 --> Router Class Initialized
INFO - 2017-03-02 11:30:59 --> Output Class Initialized
INFO - 2017-03-02 11:30:59 --> Security Class Initialized
DEBUG - 2017-03-02 11:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:30:59 --> Input Class Initialized
INFO - 2017-03-02 11:30:59 --> Language Class Initialized
INFO - 2017-03-02 11:30:59 --> Loader Class Initialized
INFO - 2017-03-02 11:30:59 --> Helper loaded: url_helper
INFO - 2017-03-02 11:30:59 --> Helper loaded: file_helper
INFO - 2017-03-02 11:30:59 --> Helper loaded: date_helper
INFO - 2017-03-02 11:30:59 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:30:59 --> Controller Class Initialized
INFO - 2017-03-02 11:30:59 --> Model Class Initialized
INFO - 2017-03-02 11:30:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:30:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:30:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\subjects/subject_view.php
INFO - 2017-03-02 11:30:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:30:59 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:30:59 --> Final output sent to browser
DEBUG - 2017-03-02 11:30:59 --> Total execution time: 0.1710
INFO - 2017-03-02 11:31:06 --> Config Class Initialized
INFO - 2017-03-02 11:31:06 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:06 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:06 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:06 --> URI Class Initialized
INFO - 2017-03-02 11:31:06 --> Router Class Initialized
INFO - 2017-03-02 11:31:06 --> Output Class Initialized
INFO - 2017-03-02 11:31:06 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:06 --> Input Class Initialized
INFO - 2017-03-02 11:31:06 --> Language Class Initialized
INFO - 2017-03-02 11:31:06 --> Loader Class Initialized
INFO - 2017-03-02 11:31:06 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:06 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:06 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:06 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:06 --> Controller Class Initialized
INFO - 2017-03-02 11:31:06 --> Model Class Initialized
INFO - 2017-03-02 11:31:06 --> Model Class Initialized
INFO - 2017-03-02 11:31:06 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:31:06 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:31:06 --> File loaded: E:\XAMPP\htdocs\ci\application\views\subjects/assign_subject.php
INFO - 2017-03-02 11:31:06 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:31:06 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:31:06 --> Final output sent to browser
DEBUG - 2017-03-02 11:31:06 --> Total execution time: 0.1933
INFO - 2017-03-02 11:31:11 --> Config Class Initialized
INFO - 2017-03-02 11:31:11 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:11 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:11 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:11 --> URI Class Initialized
INFO - 2017-03-02 11:31:11 --> Router Class Initialized
INFO - 2017-03-02 11:31:11 --> Output Class Initialized
INFO - 2017-03-02 11:31:11 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:11 --> Input Class Initialized
INFO - 2017-03-02 11:31:11 --> Language Class Initialized
INFO - 2017-03-02 11:31:11 --> Loader Class Initialized
INFO - 2017-03-02 11:31:11 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:11 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:11 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:11 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:11 --> Controller Class Initialized
INFO - 2017-03-02 11:31:11 --> Model Class Initialized
INFO - 2017-03-02 11:31:11 --> Config Class Initialized
INFO - 2017-03-02 11:31:11 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:11 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:11 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:11 --> URI Class Initialized
INFO - 2017-03-02 11:31:11 --> Router Class Initialized
INFO - 2017-03-02 11:31:11 --> Output Class Initialized
INFO - 2017-03-02 11:31:11 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:11 --> Input Class Initialized
INFO - 2017-03-02 11:31:11 --> Language Class Initialized
INFO - 2017-03-02 11:31:11 --> Loader Class Initialized
INFO - 2017-03-02 11:31:11 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:11 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:11 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:11 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:11 --> Controller Class Initialized
INFO - 2017-03-02 11:31:11 --> Model Class Initialized
INFO - 2017-03-02 11:31:11 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:31:11 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:31:11 --> File loaded: E:\XAMPP\htdocs\ci\application\views\subjects/subject_view.php
INFO - 2017-03-02 11:31:11 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:31:12 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:31:12 --> Final output sent to browser
DEBUG - 2017-03-02 11:31:12 --> Total execution time: 0.1725
INFO - 2017-03-02 11:31:15 --> Config Class Initialized
INFO - 2017-03-02 11:31:15 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:15 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:15 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:15 --> URI Class Initialized
INFO - 2017-03-02 11:31:15 --> Router Class Initialized
INFO - 2017-03-02 11:31:15 --> Output Class Initialized
INFO - 2017-03-02 11:31:15 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:15 --> Input Class Initialized
INFO - 2017-03-02 11:31:15 --> Language Class Initialized
INFO - 2017-03-02 11:31:15 --> Loader Class Initialized
INFO - 2017-03-02 11:31:15 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:15 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:15 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:15 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:15 --> Controller Class Initialized
DEBUG - 2017-03-02 11:31:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 11:31:15 --> Config Class Initialized
INFO - 2017-03-02 11:31:15 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:15 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:15 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:15 --> URI Class Initialized
INFO - 2017-03-02 11:31:15 --> Router Class Initialized
INFO - 2017-03-02 11:31:15 --> Output Class Initialized
INFO - 2017-03-02 11:31:15 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:15 --> Input Class Initialized
INFO - 2017-03-02 11:31:15 --> Language Class Initialized
INFO - 2017-03-02 11:31:15 --> Loader Class Initialized
INFO - 2017-03-02 11:31:15 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:15 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:15 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:15 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:15 --> Controller Class Initialized
INFO - 2017-03-02 11:31:15 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-02 11:31:15 --> Final output sent to browser
DEBUG - 2017-03-02 11:31:15 --> Total execution time: 0.1411
INFO - 2017-03-02 11:31:19 --> Config Class Initialized
INFO - 2017-03-02 11:31:19 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:19 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:19 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:19 --> URI Class Initialized
INFO - 2017-03-02 11:31:19 --> Router Class Initialized
INFO - 2017-03-02 11:31:19 --> Output Class Initialized
INFO - 2017-03-02 11:31:19 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:19 --> Input Class Initialized
INFO - 2017-03-02 11:31:19 --> Language Class Initialized
INFO - 2017-03-02 11:31:19 --> Loader Class Initialized
INFO - 2017-03-02 11:31:19 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:19 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:19 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:19 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:20 --> Controller Class Initialized
INFO - 2017-03-02 11:31:20 --> Model Class Initialized
INFO - 2017-03-02 11:31:20 --> Final output sent to browser
DEBUG - 2017-03-02 11:31:20 --> Total execution time: 0.1570
INFO - 2017-03-02 11:31:20 --> Config Class Initialized
INFO - 2017-03-02 11:31:20 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:20 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:20 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:20 --> URI Class Initialized
INFO - 2017-03-02 11:31:20 --> Router Class Initialized
INFO - 2017-03-02 11:31:20 --> Output Class Initialized
INFO - 2017-03-02 11:31:20 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:20 --> Input Class Initialized
INFO - 2017-03-02 11:31:20 --> Language Class Initialized
INFO - 2017-03-02 11:31:20 --> Loader Class Initialized
INFO - 2017-03-02 11:31:20 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:20 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:20 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:20 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:20 --> Controller Class Initialized
INFO - 2017-03-02 11:31:20 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:31:20 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:31:20 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/dashboard.php
INFO - 2017-03-02 11:31:20 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:31:20 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:31:20 --> Final output sent to browser
DEBUG - 2017-03-02 11:31:20 --> Total execution time: 0.1706
INFO - 2017-03-02 11:31:22 --> Config Class Initialized
INFO - 2017-03-02 11:31:22 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:22 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:22 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:22 --> URI Class Initialized
INFO - 2017-03-02 11:31:22 --> Router Class Initialized
INFO - 2017-03-02 11:31:22 --> Output Class Initialized
INFO - 2017-03-02 11:31:22 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:22 --> Input Class Initialized
INFO - 2017-03-02 11:31:22 --> Language Class Initialized
INFO - 2017-03-02 11:31:22 --> Loader Class Initialized
INFO - 2017-03-02 11:31:22 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:22 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:22 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:22 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:22 --> Controller Class Initialized
INFO - 2017-03-02 11:31:22 --> Model Class Initialized
INFO - 2017-03-02 11:31:22 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:31:22 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:31:22 --> File loaded: E:\XAMPP\htdocs\ci\application\views\chapter/create_chapter.php
INFO - 2017-03-02 11:31:22 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:31:22 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:31:22 --> Final output sent to browser
DEBUG - 2017-03-02 11:31:22 --> Total execution time: 0.1962
INFO - 2017-03-02 11:31:30 --> Config Class Initialized
INFO - 2017-03-02 11:31:30 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:30 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:30 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:30 --> URI Class Initialized
INFO - 2017-03-02 11:31:30 --> Router Class Initialized
INFO - 2017-03-02 11:31:30 --> Output Class Initialized
INFO - 2017-03-02 11:31:30 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:30 --> Input Class Initialized
INFO - 2017-03-02 11:31:30 --> Language Class Initialized
INFO - 2017-03-02 11:31:30 --> Loader Class Initialized
INFO - 2017-03-02 11:31:30 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:30 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:30 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:30 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:30 --> Controller Class Initialized
DEBUG - 2017-03-02 11:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 11:31:30 --> Config Class Initialized
INFO - 2017-03-02 11:31:30 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:30 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:30 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:30 --> URI Class Initialized
INFO - 2017-03-02 11:31:30 --> Router Class Initialized
INFO - 2017-03-02 11:31:30 --> Output Class Initialized
INFO - 2017-03-02 11:31:30 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:30 --> Input Class Initialized
INFO - 2017-03-02 11:31:30 --> Language Class Initialized
INFO - 2017-03-02 11:31:30 --> Loader Class Initialized
INFO - 2017-03-02 11:31:30 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:30 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:30 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:30 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:30 --> Controller Class Initialized
INFO - 2017-03-02 11:31:30 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-02 11:31:30 --> Final output sent to browser
DEBUG - 2017-03-02 11:31:30 --> Total execution time: 0.1440
INFO - 2017-03-02 11:31:34 --> Config Class Initialized
INFO - 2017-03-02 11:31:34 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:34 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:34 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:34 --> URI Class Initialized
INFO - 2017-03-02 11:31:34 --> Router Class Initialized
INFO - 2017-03-02 11:31:34 --> Output Class Initialized
INFO - 2017-03-02 11:31:34 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:34 --> Input Class Initialized
INFO - 2017-03-02 11:31:34 --> Language Class Initialized
INFO - 2017-03-02 11:31:34 --> Loader Class Initialized
INFO - 2017-03-02 11:31:34 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:34 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:34 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:34 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:34 --> Controller Class Initialized
DEBUG - 2017-03-02 11:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 11:31:34 --> Config Class Initialized
INFO - 2017-03-02 11:31:34 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:31:34 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:31:34 --> Utf8 Class Initialized
INFO - 2017-03-02 11:31:34 --> URI Class Initialized
INFO - 2017-03-02 11:31:34 --> Router Class Initialized
INFO - 2017-03-02 11:31:34 --> Output Class Initialized
INFO - 2017-03-02 11:31:34 --> Security Class Initialized
DEBUG - 2017-03-02 11:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:31:34 --> Input Class Initialized
INFO - 2017-03-02 11:31:34 --> Language Class Initialized
INFO - 2017-03-02 11:31:34 --> Loader Class Initialized
INFO - 2017-03-02 11:31:34 --> Helper loaded: url_helper
INFO - 2017-03-02 11:31:34 --> Helper loaded: file_helper
INFO - 2017-03-02 11:31:34 --> Helper loaded: date_helper
INFO - 2017-03-02 11:31:34 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:31:34 --> Controller Class Initialized
INFO - 2017-03-02 11:31:34 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-02 11:31:34 --> Final output sent to browser
DEBUG - 2017-03-02 11:31:34 --> Total execution time: 0.1566
INFO - 2017-03-02 11:32:14 --> Config Class Initialized
INFO - 2017-03-02 11:32:14 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:32:14 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:32:14 --> Utf8 Class Initialized
INFO - 2017-03-02 11:32:14 --> URI Class Initialized
DEBUG - 2017-03-02 11:32:14 --> No URI present. Default controller set.
INFO - 2017-03-02 11:32:14 --> Router Class Initialized
INFO - 2017-03-02 11:32:14 --> Output Class Initialized
INFO - 2017-03-02 11:32:14 --> Security Class Initialized
DEBUG - 2017-03-02 11:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:32:14 --> Input Class Initialized
INFO - 2017-03-02 11:32:14 --> Language Class Initialized
INFO - 2017-03-02 11:32:14 --> Loader Class Initialized
INFO - 2017-03-02 11:32:14 --> Helper loaded: url_helper
INFO - 2017-03-02 11:32:14 --> Helper loaded: file_helper
INFO - 2017-03-02 11:32:14 --> Helper loaded: date_helper
INFO - 2017-03-02 11:32:14 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:32:14 --> Controller Class Initialized
INFO - 2017-03-02 11:32:14 --> Config Class Initialized
INFO - 2017-03-02 11:32:14 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:32:14 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:32:14 --> Utf8 Class Initialized
INFO - 2017-03-02 11:32:14 --> URI Class Initialized
INFO - 2017-03-02 11:32:14 --> Router Class Initialized
INFO - 2017-03-02 11:32:14 --> Output Class Initialized
INFO - 2017-03-02 11:32:14 --> Security Class Initialized
DEBUG - 2017-03-02 11:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:32:14 --> Input Class Initialized
INFO - 2017-03-02 11:32:14 --> Language Class Initialized
INFO - 2017-03-02 11:32:14 --> Loader Class Initialized
INFO - 2017-03-02 11:32:14 --> Helper loaded: url_helper
INFO - 2017-03-02 11:32:14 --> Helper loaded: file_helper
INFO - 2017-03-02 11:32:14 --> Helper loaded: date_helper
INFO - 2017-03-02 11:32:14 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:32:14 --> Controller Class Initialized
INFO - 2017-03-02 11:32:14 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-02 11:32:14 --> Final output sent to browser
DEBUG - 2017-03-02 11:32:14 --> Total execution time: 0.1434
INFO - 2017-03-02 11:41:43 --> Config Class Initialized
INFO - 2017-03-02 11:41:43 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:41:43 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:41:43 --> Utf8 Class Initialized
INFO - 2017-03-02 11:41:43 --> URI Class Initialized
DEBUG - 2017-03-02 11:41:43 --> No URI present. Default controller set.
INFO - 2017-03-02 11:41:43 --> Router Class Initialized
INFO - 2017-03-02 11:41:43 --> Output Class Initialized
INFO - 2017-03-02 11:41:43 --> Security Class Initialized
DEBUG - 2017-03-02 11:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:41:43 --> Input Class Initialized
INFO - 2017-03-02 11:41:43 --> Language Class Initialized
INFO - 2017-03-02 11:41:43 --> Loader Class Initialized
INFO - 2017-03-02 11:41:43 --> Helper loaded: url_helper
INFO - 2017-03-02 11:41:43 --> Helper loaded: file_helper
INFO - 2017-03-02 11:41:43 --> Helper loaded: date_helper
INFO - 2017-03-02 11:41:43 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:41:43 --> Controller Class Initialized
INFO - 2017-03-02 11:41:43 --> Config Class Initialized
INFO - 2017-03-02 11:41:43 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:41:43 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:41:43 --> Utf8 Class Initialized
INFO - 2017-03-02 11:41:43 --> URI Class Initialized
INFO - 2017-03-02 11:41:43 --> Router Class Initialized
INFO - 2017-03-02 11:41:43 --> Output Class Initialized
INFO - 2017-03-02 11:41:43 --> Security Class Initialized
DEBUG - 2017-03-02 11:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:41:43 --> Input Class Initialized
INFO - 2017-03-02 11:41:43 --> Language Class Initialized
INFO - 2017-03-02 11:41:43 --> Loader Class Initialized
INFO - 2017-03-02 11:41:43 --> Helper loaded: url_helper
INFO - 2017-03-02 11:41:43 --> Helper loaded: file_helper
INFO - 2017-03-02 11:41:43 --> Helper loaded: date_helper
INFO - 2017-03-02 11:41:43 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:41:43 --> Controller Class Initialized
INFO - 2017-03-02 11:41:43 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-02 11:41:43 --> Final output sent to browser
DEBUG - 2017-03-02 11:41:43 --> Total execution time: 0.1477
INFO - 2017-03-02 11:41:45 --> Config Class Initialized
INFO - 2017-03-02 11:41:45 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:41:45 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:41:45 --> Utf8 Class Initialized
INFO - 2017-03-02 11:41:45 --> URI Class Initialized
INFO - 2017-03-02 11:41:45 --> Router Class Initialized
INFO - 2017-03-02 11:41:45 --> Output Class Initialized
INFO - 2017-03-02 11:41:45 --> Security Class Initialized
DEBUG - 2017-03-02 11:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:41:45 --> Input Class Initialized
INFO - 2017-03-02 11:41:45 --> Language Class Initialized
INFO - 2017-03-02 11:41:45 --> Loader Class Initialized
INFO - 2017-03-02 11:41:45 --> Helper loaded: url_helper
INFO - 2017-03-02 11:41:45 --> Helper loaded: file_helper
INFO - 2017-03-02 11:41:45 --> Helper loaded: date_helper
INFO - 2017-03-02 11:41:45 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:41:45 --> Controller Class Initialized
INFO - 2017-03-02 11:41:45 --> Model Class Initialized
INFO - 2017-03-02 11:41:45 --> Final output sent to browser
DEBUG - 2017-03-02 11:41:45 --> Total execution time: 0.1538
INFO - 2017-03-02 11:41:45 --> Config Class Initialized
INFO - 2017-03-02 11:41:45 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:41:45 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:41:45 --> Utf8 Class Initialized
INFO - 2017-03-02 11:41:45 --> URI Class Initialized
INFO - 2017-03-02 11:41:45 --> Router Class Initialized
INFO - 2017-03-02 11:41:45 --> Output Class Initialized
INFO - 2017-03-02 11:41:45 --> Security Class Initialized
DEBUG - 2017-03-02 11:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:41:45 --> Input Class Initialized
INFO - 2017-03-02 11:41:45 --> Language Class Initialized
INFO - 2017-03-02 11:41:45 --> Loader Class Initialized
INFO - 2017-03-02 11:41:45 --> Helper loaded: url_helper
INFO - 2017-03-02 11:41:45 --> Helper loaded: file_helper
INFO - 2017-03-02 11:41:45 --> Helper loaded: date_helper
INFO - 2017-03-02 11:41:45 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:41:45 --> Controller Class Initialized
INFO - 2017-03-02 11:41:45 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:41:45 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:41:45 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/dashboard.php
INFO - 2017-03-02 11:41:45 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:41:45 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:41:45 --> Final output sent to browser
DEBUG - 2017-03-02 11:41:45 --> Total execution time: 0.1805
INFO - 2017-03-02 11:41:48 --> Config Class Initialized
INFO - 2017-03-02 11:41:48 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:41:48 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:41:48 --> Utf8 Class Initialized
INFO - 2017-03-02 11:41:48 --> URI Class Initialized
INFO - 2017-03-02 11:41:48 --> Router Class Initialized
INFO - 2017-03-02 11:41:48 --> Output Class Initialized
INFO - 2017-03-02 11:41:48 --> Security Class Initialized
DEBUG - 2017-03-02 11:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:41:48 --> Input Class Initialized
INFO - 2017-03-02 11:41:48 --> Language Class Initialized
INFO - 2017-03-02 11:41:48 --> Loader Class Initialized
INFO - 2017-03-02 11:41:48 --> Helper loaded: url_helper
INFO - 2017-03-02 11:41:48 --> Helper loaded: file_helper
INFO - 2017-03-02 11:41:48 --> Helper loaded: date_helper
INFO - 2017-03-02 11:41:48 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:41:48 --> Controller Class Initialized
INFO - 2017-03-02 11:41:48 --> Model Class Initialized
INFO - 2017-03-02 11:41:48 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:41:48 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:41:48 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/all_exam_view.php
INFO - 2017-03-02 11:41:48 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:41:48 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:41:48 --> Final output sent to browser
DEBUG - 2017-03-02 11:41:48 --> Total execution time: 0.1846
INFO - 2017-03-02 11:41:49 --> Config Class Initialized
INFO - 2017-03-02 11:41:49 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:41:49 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:41:49 --> Utf8 Class Initialized
INFO - 2017-03-02 11:41:49 --> URI Class Initialized
INFO - 2017-03-02 11:41:49 --> Router Class Initialized
INFO - 2017-03-02 11:41:49 --> Output Class Initialized
INFO - 2017-03-02 11:41:49 --> Security Class Initialized
DEBUG - 2017-03-02 11:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:41:49 --> Input Class Initialized
INFO - 2017-03-02 11:41:49 --> Language Class Initialized
INFO - 2017-03-02 11:41:49 --> Loader Class Initialized
INFO - 2017-03-02 11:41:50 --> Helper loaded: url_helper
INFO - 2017-03-02 11:41:50 --> Helper loaded: file_helper
INFO - 2017-03-02 11:41:50 --> Helper loaded: date_helper
INFO - 2017-03-02 11:41:50 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:41:50 --> Controller Class Initialized
INFO - 2017-03-02 11:41:50 --> Model Class Initialized
INFO - 2017-03-02 11:41:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:41:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:41:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/assign_exam.php
INFO - 2017-03-02 11:41:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:41:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:41:50 --> Final output sent to browser
DEBUG - 2017-03-02 11:41:50 --> Total execution time: 0.1965
INFO - 2017-03-02 11:41:57 --> Config Class Initialized
INFO - 2017-03-02 11:41:57 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:41:57 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:41:57 --> Utf8 Class Initialized
INFO - 2017-03-02 11:41:57 --> URI Class Initialized
INFO - 2017-03-02 11:41:57 --> Router Class Initialized
INFO - 2017-03-02 11:41:57 --> Output Class Initialized
INFO - 2017-03-02 11:41:57 --> Security Class Initialized
DEBUG - 2017-03-02 11:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:41:57 --> Input Class Initialized
INFO - 2017-03-02 11:41:57 --> Language Class Initialized
INFO - 2017-03-02 11:41:57 --> Loader Class Initialized
INFO - 2017-03-02 11:41:57 --> Helper loaded: url_helper
INFO - 2017-03-02 11:41:57 --> Helper loaded: file_helper
INFO - 2017-03-02 11:41:57 --> Helper loaded: date_helper
INFO - 2017-03-02 11:41:57 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:41:57 --> Controller Class Initialized
INFO - 2017-03-02 11:41:57 --> Model Class Initialized
INFO - 2017-03-02 11:41:57 --> Config Class Initialized
INFO - 2017-03-02 11:41:57 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:41:57 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:41:57 --> Utf8 Class Initialized
INFO - 2017-03-02 11:41:57 --> URI Class Initialized
INFO - 2017-03-02 11:41:57 --> Router Class Initialized
INFO - 2017-03-02 11:41:57 --> Output Class Initialized
INFO - 2017-03-02 11:41:57 --> Security Class Initialized
DEBUG - 2017-03-02 11:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:41:57 --> Input Class Initialized
INFO - 2017-03-02 11:41:57 --> Language Class Initialized
INFO - 2017-03-02 11:41:57 --> Loader Class Initialized
INFO - 2017-03-02 11:41:57 --> Helper loaded: url_helper
INFO - 2017-03-02 11:41:57 --> Helper loaded: file_helper
INFO - 2017-03-02 11:41:57 --> Helper loaded: date_helper
INFO - 2017-03-02 11:41:57 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:41:57 --> Controller Class Initialized
INFO - 2017-03-02 11:41:57 --> Model Class Initialized
INFO - 2017-03-02 11:41:57 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:41:57 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:41:57 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/assign_exam.php
INFO - 2017-03-02 11:41:57 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:41:57 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:41:57 --> Final output sent to browser
DEBUG - 2017-03-02 11:41:57 --> Total execution time: 0.1847
INFO - 2017-03-02 11:42:02 --> Config Class Initialized
INFO - 2017-03-02 11:42:02 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:02 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:02 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:02 --> URI Class Initialized
INFO - 2017-03-02 11:42:02 --> Router Class Initialized
INFO - 2017-03-02 11:42:02 --> Output Class Initialized
INFO - 2017-03-02 11:42:02 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:02 --> Input Class Initialized
INFO - 2017-03-02 11:42:02 --> Language Class Initialized
INFO - 2017-03-02 11:42:02 --> Loader Class Initialized
INFO - 2017-03-02 11:42:02 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:02 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:02 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:02 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:02 --> Controller Class Initialized
INFO - 2017-03-02 11:42:02 --> Model Class Initialized
INFO - 2017-03-02 11:42:02 --> Config Class Initialized
INFO - 2017-03-02 11:42:02 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:02 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:02 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:02 --> URI Class Initialized
INFO - 2017-03-02 11:42:02 --> Router Class Initialized
INFO - 2017-03-02 11:42:02 --> Output Class Initialized
INFO - 2017-03-02 11:42:02 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:02 --> Input Class Initialized
INFO - 2017-03-02 11:42:02 --> Language Class Initialized
INFO - 2017-03-02 11:42:02 --> Loader Class Initialized
INFO - 2017-03-02 11:42:02 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:02 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:02 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:02 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:02 --> Controller Class Initialized
INFO - 2017-03-02 11:42:02 --> Model Class Initialized
INFO - 2017-03-02 11:42:02 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:42:02 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:42:02 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/assign_exam.php
INFO - 2017-03-02 11:42:02 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:42:02 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:42:02 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:02 --> Total execution time: 0.1942
INFO - 2017-03-02 11:42:13 --> Config Class Initialized
INFO - 2017-03-02 11:42:13 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:13 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:13 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:13 --> URI Class Initialized
INFO - 2017-03-02 11:42:13 --> Router Class Initialized
INFO - 2017-03-02 11:42:13 --> Output Class Initialized
INFO - 2017-03-02 11:42:13 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:13 --> Input Class Initialized
INFO - 2017-03-02 11:42:13 --> Language Class Initialized
INFO - 2017-03-02 11:42:13 --> Loader Class Initialized
INFO - 2017-03-02 11:42:13 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:13 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:13 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:13 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:13 --> Controller Class Initialized
INFO - 2017-03-02 11:42:13 --> Model Class Initialized
INFO - 2017-03-02 11:42:13 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:42:13 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:42:13 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/create_exam.php
INFO - 2017-03-02 11:42:13 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:42:13 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:42:13 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:13 --> Total execution time: 0.1959
INFO - 2017-03-02 11:42:15 --> Config Class Initialized
INFO - 2017-03-02 11:42:15 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:15 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:15 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:15 --> URI Class Initialized
INFO - 2017-03-02 11:42:15 --> Router Class Initialized
INFO - 2017-03-02 11:42:15 --> Output Class Initialized
INFO - 2017-03-02 11:42:15 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:15 --> Input Class Initialized
INFO - 2017-03-02 11:42:15 --> Language Class Initialized
INFO - 2017-03-02 11:42:15 --> Loader Class Initialized
INFO - 2017-03-02 11:42:15 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:15 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:15 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:15 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:15 --> Controller Class Initialized
INFO - 2017-03-02 11:42:15 --> Model Class Initialized
INFO - 2017-03-02 11:42:15 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:15 --> Total execution time: 0.1642
INFO - 2017-03-02 11:42:18 --> Config Class Initialized
INFO - 2017-03-02 11:42:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:18 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:18 --> URI Class Initialized
INFO - 2017-03-02 11:42:18 --> Router Class Initialized
INFO - 2017-03-02 11:42:18 --> Output Class Initialized
INFO - 2017-03-02 11:42:18 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:18 --> Input Class Initialized
INFO - 2017-03-02 11:42:18 --> Language Class Initialized
INFO - 2017-03-02 11:42:18 --> Loader Class Initialized
INFO - 2017-03-02 11:42:18 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:18 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:18 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:18 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:18 --> Controller Class Initialized
INFO - 2017-03-02 11:42:18 --> Model Class Initialized
INFO - 2017-03-02 11:42:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:42:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:42:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/create_exam2.php
INFO - 2017-03-02 11:42:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:42:18 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:42:18 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:18 --> Total execution time: 0.2109
INFO - 2017-03-02 11:42:26 --> Config Class Initialized
INFO - 2017-03-02 11:42:26 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:26 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:26 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:26 --> URI Class Initialized
INFO - 2017-03-02 11:42:26 --> Router Class Initialized
INFO - 2017-03-02 11:42:26 --> Output Class Initialized
INFO - 2017-03-02 11:42:26 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:26 --> Input Class Initialized
INFO - 2017-03-02 11:42:26 --> Language Class Initialized
INFO - 2017-03-02 11:42:26 --> Loader Class Initialized
INFO - 2017-03-02 11:42:26 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:26 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:26 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:26 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:26 --> Controller Class Initialized
INFO - 2017-03-02 11:42:26 --> Model Class Initialized
DEBUG - 2017-03-02 11:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 11:42:26 --> Config Class Initialized
INFO - 2017-03-02 11:42:26 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:27 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:27 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:27 --> URI Class Initialized
INFO - 2017-03-02 11:42:27 --> Router Class Initialized
INFO - 2017-03-02 11:42:27 --> Output Class Initialized
INFO - 2017-03-02 11:42:27 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:27 --> Input Class Initialized
INFO - 2017-03-02 11:42:27 --> Language Class Initialized
INFO - 2017-03-02 11:42:27 --> Loader Class Initialized
INFO - 2017-03-02 11:42:27 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:27 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:27 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:27 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:27 --> Controller Class Initialized
INFO - 2017-03-02 11:42:27 --> Model Class Initialized
INFO - 2017-03-02 11:42:27 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:42:27 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:42:27 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/all_exam_view.php
INFO - 2017-03-02 11:42:27 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:42:27 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:42:27 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:27 --> Total execution time: 0.2075
INFO - 2017-03-02 11:42:33 --> Config Class Initialized
INFO - 2017-03-02 11:42:33 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:33 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:33 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:33 --> URI Class Initialized
INFO - 2017-03-02 11:42:33 --> Router Class Initialized
INFO - 2017-03-02 11:42:33 --> Output Class Initialized
INFO - 2017-03-02 11:42:33 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:33 --> Input Class Initialized
INFO - 2017-03-02 11:42:33 --> Language Class Initialized
INFO - 2017-03-02 11:42:33 --> Loader Class Initialized
INFO - 2017-03-02 11:42:33 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:33 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:33 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:33 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:33 --> Controller Class Initialized
INFO - 2017-03-02 11:42:33 --> Model Class Initialized
INFO - 2017-03-02 11:42:33 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:42:33 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:42:33 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/assign_exam.php
INFO - 2017-03-02 11:42:33 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:42:33 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:42:33 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:33 --> Total execution time: 0.1946
INFO - 2017-03-02 11:42:38 --> Config Class Initialized
INFO - 2017-03-02 11:42:38 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:38 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:38 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:38 --> URI Class Initialized
INFO - 2017-03-02 11:42:38 --> Router Class Initialized
INFO - 2017-03-02 11:42:38 --> Output Class Initialized
INFO - 2017-03-02 11:42:38 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:38 --> Input Class Initialized
INFO - 2017-03-02 11:42:38 --> Language Class Initialized
INFO - 2017-03-02 11:42:38 --> Loader Class Initialized
INFO - 2017-03-02 11:42:38 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:38 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:38 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:38 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:38 --> Controller Class Initialized
INFO - 2017-03-02 11:42:38 --> Model Class Initialized
INFO - 2017-03-02 11:42:38 --> Config Class Initialized
INFO - 2017-03-02 11:42:38 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:38 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:38 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:38 --> URI Class Initialized
INFO - 2017-03-02 11:42:38 --> Router Class Initialized
INFO - 2017-03-02 11:42:38 --> Output Class Initialized
INFO - 2017-03-02 11:42:38 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:38 --> Input Class Initialized
INFO - 2017-03-02 11:42:38 --> Language Class Initialized
INFO - 2017-03-02 11:42:38 --> Loader Class Initialized
INFO - 2017-03-02 11:42:38 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:38 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:38 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:38 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:38 --> Controller Class Initialized
INFO - 2017-03-02 11:42:38 --> Model Class Initialized
INFO - 2017-03-02 11:42:38 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/header.php
INFO - 2017-03-02 11:42:38 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/left.php
INFO - 2017-03-02 11:42:38 --> File loaded: E:\XAMPP\htdocs\ci\application\views\exam/assign_exam.php
INFO - 2017-03-02 11:42:38 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/footer.php
INFO - 2017-03-02 11:42:38 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_admin/index.php
INFO - 2017-03-02 11:42:38 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:38 --> Total execution time: 0.1970
INFO - 2017-03-02 11:42:40 --> Config Class Initialized
INFO - 2017-03-02 11:42:41 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:41 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:41 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:41 --> URI Class Initialized
INFO - 2017-03-02 11:42:41 --> Router Class Initialized
INFO - 2017-03-02 11:42:41 --> Output Class Initialized
INFO - 2017-03-02 11:42:41 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:41 --> Input Class Initialized
INFO - 2017-03-02 11:42:41 --> Language Class Initialized
INFO - 2017-03-02 11:42:41 --> Loader Class Initialized
INFO - 2017-03-02 11:42:41 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:41 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:41 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:41 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:41 --> Controller Class Initialized
DEBUG - 2017-03-02 11:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-02 11:42:41 --> Config Class Initialized
INFO - 2017-03-02 11:42:41 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:41 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:41 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:41 --> URI Class Initialized
INFO - 2017-03-02 11:42:41 --> Router Class Initialized
INFO - 2017-03-02 11:42:41 --> Output Class Initialized
INFO - 2017-03-02 11:42:41 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:41 --> Input Class Initialized
INFO - 2017-03-02 11:42:41 --> Language Class Initialized
INFO - 2017-03-02 11:42:41 --> Loader Class Initialized
INFO - 2017-03-02 11:42:41 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:41 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:41 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:41 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:41 --> Controller Class Initialized
INFO - 2017-03-02 11:42:41 --> File loaded: E:\XAMPP\htdocs\ci\application\views\login/login.php
INFO - 2017-03-02 11:42:41 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:41 --> Total execution time: 0.1787
INFO - 2017-03-02 11:42:48 --> Config Class Initialized
INFO - 2017-03-02 11:42:48 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:48 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:49 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:49 --> URI Class Initialized
INFO - 2017-03-02 11:42:49 --> Router Class Initialized
INFO - 2017-03-02 11:42:49 --> Output Class Initialized
INFO - 2017-03-02 11:42:49 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:49 --> Input Class Initialized
INFO - 2017-03-02 11:42:49 --> Language Class Initialized
INFO - 2017-03-02 11:42:49 --> Loader Class Initialized
INFO - 2017-03-02 11:42:49 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:49 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:49 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:49 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:49 --> Controller Class Initialized
INFO - 2017-03-02 11:42:49 --> Model Class Initialized
INFO - 2017-03-02 11:42:49 --> Config Class Initialized
INFO - 2017-03-02 11:42:49 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:49 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:49 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:49 --> URI Class Initialized
INFO - 2017-03-02 11:42:49 --> Router Class Initialized
INFO - 2017-03-02 11:42:49 --> Output Class Initialized
INFO - 2017-03-02 11:42:49 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:49 --> Input Class Initialized
INFO - 2017-03-02 11:42:49 --> Language Class Initialized
INFO - 2017-03-02 11:42:49 --> Loader Class Initialized
INFO - 2017-03-02 11:42:49 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:49 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:49 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:49 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:49 --> Controller Class Initialized
INFO - 2017-03-02 11:42:49 --> Model Class Initialized
INFO - 2017-03-02 11:42:49 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:42:49 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:42:49 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/dashboard.php
INFO - 2017-03-02 11:42:49 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:42:49 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:42:49 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:49 --> Total execution time: 0.1919
INFO - 2017-03-02 11:42:50 --> Config Class Initialized
INFO - 2017-03-02 11:42:50 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:50 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:50 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:50 --> URI Class Initialized
INFO - 2017-03-02 11:42:50 --> Router Class Initialized
INFO - 2017-03-02 11:42:50 --> Output Class Initialized
INFO - 2017-03-02 11:42:50 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:50 --> Input Class Initialized
INFO - 2017-03-02 11:42:50 --> Language Class Initialized
INFO - 2017-03-02 11:42:50 --> Loader Class Initialized
INFO - 2017-03-02 11:42:50 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:50 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:50 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:50 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:50 --> Controller Class Initialized
INFO - 2017-03-02 11:42:50 --> Model Class Initialized
INFO - 2017-03-02 11:42:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:42:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:42:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/exam_view.php
INFO - 2017-03-02 11:42:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:42:50 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:42:50 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:50 --> Total execution time: 0.2146
INFO - 2017-03-02 11:42:51 --> Config Class Initialized
INFO - 2017-03-02 11:42:51 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:51 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:51 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:51 --> URI Class Initialized
INFO - 2017-03-02 11:42:51 --> Router Class Initialized
INFO - 2017-03-02 11:42:51 --> Output Class Initialized
INFO - 2017-03-02 11:42:51 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:51 --> Input Class Initialized
INFO - 2017-03-02 11:42:51 --> Language Class Initialized
INFO - 2017-03-02 11:42:51 --> Loader Class Initialized
INFO - 2017-03-02 11:42:51 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:51 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:51 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:51 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:51 --> Controller Class Initialized
INFO - 2017-03-02 11:42:51 --> Model Class Initialized
INFO - 2017-03-02 11:42:51 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:42:51 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:42:51 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/exam.php
INFO - 2017-03-02 11:42:51 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:42:51 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:42:51 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:51 --> Total execution time: 0.2354
INFO - 2017-03-02 11:42:55 --> Config Class Initialized
INFO - 2017-03-02 11:42:55 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:55 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:55 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:55 --> URI Class Initialized
INFO - 2017-03-02 11:42:55 --> Router Class Initialized
INFO - 2017-03-02 11:42:55 --> Output Class Initialized
INFO - 2017-03-02 11:42:55 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:55 --> Input Class Initialized
INFO - 2017-03-02 11:42:55 --> Language Class Initialized
INFO - 2017-03-02 11:42:55 --> Loader Class Initialized
INFO - 2017-03-02 11:42:55 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:55 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:55 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:55 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:55 --> Controller Class Initialized
INFO - 2017-03-02 11:42:55 --> Model Class Initialized
INFO - 2017-03-02 11:42:55 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:42:55 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:42:55 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/exam.php
INFO - 2017-03-02 11:42:55 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:42:55 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:42:55 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:55 --> Total execution time: 0.2835
INFO - 2017-03-02 11:42:56 --> Config Class Initialized
INFO - 2017-03-02 11:42:56 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:42:56 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:42:56 --> Utf8 Class Initialized
INFO - 2017-03-02 11:42:56 --> URI Class Initialized
INFO - 2017-03-02 11:42:56 --> Router Class Initialized
INFO - 2017-03-02 11:42:56 --> Output Class Initialized
INFO - 2017-03-02 11:42:56 --> Security Class Initialized
DEBUG - 2017-03-02 11:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:42:56 --> Input Class Initialized
INFO - 2017-03-02 11:42:56 --> Language Class Initialized
INFO - 2017-03-02 11:42:56 --> Loader Class Initialized
INFO - 2017-03-02 11:42:56 --> Helper loaded: url_helper
INFO - 2017-03-02 11:42:56 --> Helper loaded: file_helper
INFO - 2017-03-02 11:42:56 --> Helper loaded: date_helper
INFO - 2017-03-02 11:42:56 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:42:56 --> Controller Class Initialized
INFO - 2017-03-02 11:42:56 --> Model Class Initialized
INFO - 2017-03-02 11:42:57 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:42:57 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:42:58 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/exam_finish.php
INFO - 2017-03-02 11:42:58 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:42:58 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:42:58 --> Final output sent to browser
DEBUG - 2017-03-02 11:42:58 --> Total execution time: 1.3765
INFO - 2017-03-02 11:43:00 --> Config Class Initialized
INFO - 2017-03-02 11:43:00 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:43:00 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:43:00 --> Utf8 Class Initialized
INFO - 2017-03-02 11:43:00 --> URI Class Initialized
INFO - 2017-03-02 11:43:00 --> Router Class Initialized
INFO - 2017-03-02 11:43:00 --> Output Class Initialized
INFO - 2017-03-02 11:43:00 --> Security Class Initialized
DEBUG - 2017-03-02 11:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:43:00 --> Input Class Initialized
INFO - 2017-03-02 11:43:00 --> Language Class Initialized
INFO - 2017-03-02 11:43:00 --> Loader Class Initialized
INFO - 2017-03-02 11:43:00 --> Helper loaded: url_helper
INFO - 2017-03-02 11:43:00 --> Helper loaded: file_helper
INFO - 2017-03-02 11:43:00 --> Helper loaded: date_helper
INFO - 2017-03-02 11:43:00 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:43:00 --> Controller Class Initialized
INFO - 2017-03-02 11:43:00 --> Model Class Initialized
INFO - 2017-03-02 11:43:00 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:43:00 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:43:00 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/exam_view.php
INFO - 2017-03-02 11:43:00 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:43:00 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:43:00 --> Final output sent to browser
DEBUG - 2017-03-02 11:43:00 --> Total execution time: 0.2055
INFO - 2017-03-02 11:43:03 --> Config Class Initialized
INFO - 2017-03-02 11:43:03 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:43:03 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:43:03 --> Utf8 Class Initialized
INFO - 2017-03-02 11:43:03 --> URI Class Initialized
INFO - 2017-03-02 11:43:03 --> Router Class Initialized
INFO - 2017-03-02 11:43:03 --> Output Class Initialized
INFO - 2017-03-02 11:43:03 --> Security Class Initialized
DEBUG - 2017-03-02 11:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:43:03 --> Input Class Initialized
INFO - 2017-03-02 11:43:03 --> Language Class Initialized
INFO - 2017-03-02 11:43:03 --> Loader Class Initialized
INFO - 2017-03-02 11:43:03 --> Helper loaded: url_helper
INFO - 2017-03-02 11:43:03 --> Helper loaded: file_helper
INFO - 2017-03-02 11:43:03 --> Helper loaded: date_helper
INFO - 2017-03-02 11:43:03 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:43:03 --> Controller Class Initialized
INFO - 2017-03-02 11:43:03 --> Model Class Initialized
INFO - 2017-03-02 11:43:03 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/header.php
INFO - 2017-03-02 11:43:03 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/left.php
INFO - 2017-03-02 11:43:03 --> File loaded: E:\XAMPP\htdocs\ci\application\views\student/taken_exam.php
INFO - 2017-03-02 11:43:03 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/footer.php
INFO - 2017-03-02 11:43:03 --> File loaded: E:\XAMPP\htdocs\ci\application\views\layout_student/index.php
INFO - 2017-03-02 11:43:03 --> Final output sent to browser
DEBUG - 2017-03-02 11:43:03 --> Total execution time: 0.2041
INFO - 2017-03-02 11:01:02 --> Config Class Initialized
INFO - 2017-03-02 11:01:02 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:01:02 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:01:02 --> Utf8 Class Initialized
INFO - 2017-03-02 11:01:02 --> URI Class Initialized
DEBUG - 2017-03-02 11:01:02 --> No URI present. Default controller set.
INFO - 2017-03-02 11:01:02 --> Router Class Initialized
INFO - 2017-03-02 11:01:02 --> Output Class Initialized
INFO - 2017-03-02 11:01:02 --> Security Class Initialized
DEBUG - 2017-03-02 11:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:01:02 --> Input Class Initialized
INFO - 2017-03-02 11:01:02 --> Language Class Initialized
INFO - 2017-03-02 11:01:02 --> Loader Class Initialized
INFO - 2017-03-02 11:01:02 --> Helper loaded: url_helper
INFO - 2017-03-02 11:01:02 --> Helper loaded: file_helper
INFO - 2017-03-02 11:01:02 --> Helper loaded: date_helper
INFO - 2017-03-02 11:01:02 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:01:02 --> Controller Class Initialized
INFO - 2017-03-02 11:01:02 --> Config Class Initialized
INFO - 2017-03-02 11:01:02 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:01:02 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:01:02 --> Utf8 Class Initialized
INFO - 2017-03-02 11:01:02 --> URI Class Initialized
INFO - 2017-03-02 11:01:02 --> Router Class Initialized
INFO - 2017-03-02 11:01:02 --> Output Class Initialized
INFO - 2017-03-02 11:01:02 --> Security Class Initialized
DEBUG - 2017-03-02 11:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:01:02 --> Input Class Initialized
INFO - 2017-03-02 11:01:02 --> Language Class Initialized
INFO - 2017-03-02 11:01:02 --> Loader Class Initialized
INFO - 2017-03-02 11:01:02 --> Helper loaded: url_helper
INFO - 2017-03-02 11:01:02 --> Helper loaded: file_helper
INFO - 2017-03-02 11:01:02 --> Helper loaded: date_helper
INFO - 2017-03-02 11:01:02 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:01:02 --> Controller Class Initialized
INFO - 2017-03-02 11:01:02 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-02 11:01:02 --> Final output sent to browser
DEBUG - 2017-03-02 11:01:02 --> Total execution time: 0.0202
INFO - 2017-03-02 11:01:20 --> Config Class Initialized
INFO - 2017-03-02 11:01:20 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:01:20 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:01:20 --> Utf8 Class Initialized
INFO - 2017-03-02 11:01:20 --> URI Class Initialized
INFO - 2017-03-02 11:01:20 --> Router Class Initialized
INFO - 2017-03-02 11:01:20 --> Output Class Initialized
INFO - 2017-03-02 11:01:20 --> Security Class Initialized
DEBUG - 2017-03-02 11:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:01:20 --> Input Class Initialized
INFO - 2017-03-02 11:01:20 --> Language Class Initialized
INFO - 2017-03-02 11:01:20 --> Loader Class Initialized
INFO - 2017-03-02 11:01:20 --> Helper loaded: url_helper
INFO - 2017-03-02 11:01:20 --> Helper loaded: file_helper
INFO - 2017-03-02 11:01:20 --> Helper loaded: date_helper
INFO - 2017-03-02 11:01:20 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:01:20 --> Controller Class Initialized
INFO - 2017-03-02 11:01:20 --> Model Class Initialized
INFO - 2017-03-02 11:01:20 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-02 11:01:20 --> Final output sent to browser
DEBUG - 2017-03-02 11:01:20 --> Total execution time: 0.0256
INFO - 2017-03-02 11:01:25 --> Config Class Initialized
INFO - 2017-03-02 11:01:25 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:01:25 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:01:25 --> Utf8 Class Initialized
INFO - 2017-03-02 11:01:25 --> URI Class Initialized
INFO - 2017-03-02 11:01:25 --> Router Class Initialized
INFO - 2017-03-02 11:01:25 --> Output Class Initialized
INFO - 2017-03-02 11:01:25 --> Security Class Initialized
DEBUG - 2017-03-02 11:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:01:25 --> Input Class Initialized
INFO - 2017-03-02 11:01:25 --> Language Class Initialized
INFO - 2017-03-02 11:01:25 --> Loader Class Initialized
INFO - 2017-03-02 11:01:25 --> Helper loaded: url_helper
INFO - 2017-03-02 11:01:25 --> Helper loaded: file_helper
INFO - 2017-03-02 11:01:25 --> Helper loaded: date_helper
INFO - 2017-03-02 11:01:25 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:01:25 --> Controller Class Initialized
INFO - 2017-03-02 11:01:25 --> Model Class Initialized
INFO - 2017-03-02 11:01:25 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-02 11:01:25 --> Final output sent to browser
DEBUG - 2017-03-02 11:01:25 --> Total execution time: 0.0217
INFO - 2017-03-02 11:01:36 --> Config Class Initialized
INFO - 2017-03-02 11:01:36 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:01:36 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:01:36 --> Utf8 Class Initialized
INFO - 2017-03-02 11:01:36 --> URI Class Initialized
INFO - 2017-03-02 11:01:36 --> Router Class Initialized
INFO - 2017-03-02 11:01:36 --> Output Class Initialized
INFO - 2017-03-02 11:01:36 --> Security Class Initialized
DEBUG - 2017-03-02 11:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:01:36 --> Input Class Initialized
INFO - 2017-03-02 11:01:36 --> Language Class Initialized
INFO - 2017-03-02 11:01:36 --> Loader Class Initialized
INFO - 2017-03-02 11:01:36 --> Helper loaded: url_helper
INFO - 2017-03-02 11:01:36 --> Helper loaded: file_helper
INFO - 2017-03-02 11:01:36 --> Helper loaded: date_helper
INFO - 2017-03-02 11:01:36 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:01:36 --> Controller Class Initialized
INFO - 2017-03-02 11:01:36 --> Model Class Initialized
INFO - 2017-03-02 11:01:36 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-02 11:01:36 --> Final output sent to browser
DEBUG - 2017-03-02 11:01:36 --> Total execution time: 0.0215
INFO - 2017-03-02 11:04:18 --> Config Class Initialized
INFO - 2017-03-02 11:04:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:04:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:04:18 --> Utf8 Class Initialized
INFO - 2017-03-02 11:04:18 --> URI Class Initialized
INFO - 2017-03-02 11:04:18 --> Router Class Initialized
INFO - 2017-03-02 11:04:18 --> Output Class Initialized
INFO - 2017-03-02 11:04:18 --> Security Class Initialized
DEBUG - 2017-03-02 11:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:04:18 --> Input Class Initialized
INFO - 2017-03-02 11:04:18 --> Language Class Initialized
INFO - 2017-03-02 11:04:18 --> Loader Class Initialized
INFO - 2017-03-02 11:04:18 --> Helper loaded: url_helper
INFO - 2017-03-02 11:04:18 --> Helper loaded: file_helper
INFO - 2017-03-02 11:04:18 --> Helper loaded: date_helper
INFO - 2017-03-02 11:04:18 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:04:18 --> Controller Class Initialized
INFO - 2017-03-02 11:04:18 --> Model Class Initialized
INFO - 2017-03-02 11:04:18 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-02 11:04:18 --> Final output sent to browser
DEBUG - 2017-03-02 11:04:18 --> Total execution time: 0.0201
INFO - 2017-03-02 11:04:23 --> Config Class Initialized
INFO - 2017-03-02 11:04:23 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:04:23 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:04:23 --> Utf8 Class Initialized
INFO - 2017-03-02 11:04:23 --> URI Class Initialized
INFO - 2017-03-02 11:04:23 --> Router Class Initialized
INFO - 2017-03-02 11:04:23 --> Output Class Initialized
INFO - 2017-03-02 11:04:23 --> Security Class Initialized
DEBUG - 2017-03-02 11:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:04:23 --> Input Class Initialized
INFO - 2017-03-02 11:04:23 --> Language Class Initialized
INFO - 2017-03-02 11:04:23 --> Loader Class Initialized
INFO - 2017-03-02 11:04:23 --> Helper loaded: url_helper
INFO - 2017-03-02 11:04:23 --> Helper loaded: file_helper
INFO - 2017-03-02 11:04:23 --> Helper loaded: date_helper
INFO - 2017-03-02 11:04:23 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:04:23 --> Controller Class Initialized
INFO - 2017-03-02 11:04:23 --> Model Class Initialized
INFO - 2017-03-02 11:04:23 --> Final output sent to browser
DEBUG - 2017-03-02 11:04:23 --> Total execution time: 0.0194
INFO - 2017-03-02 11:04:23 --> Config Class Initialized
INFO - 2017-03-02 11:04:23 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:04:23 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:04:23 --> Utf8 Class Initialized
INFO - 2017-03-02 11:04:23 --> URI Class Initialized
INFO - 2017-03-02 11:04:23 --> Router Class Initialized
INFO - 2017-03-02 11:04:23 --> Output Class Initialized
INFO - 2017-03-02 11:04:23 --> Security Class Initialized
DEBUG - 2017-03-02 11:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:04:23 --> Input Class Initialized
INFO - 2017-03-02 11:04:23 --> Language Class Initialized
INFO - 2017-03-02 11:04:23 --> Loader Class Initialized
INFO - 2017-03-02 11:04:23 --> Helper loaded: url_helper
INFO - 2017-03-02 11:04:23 --> Helper loaded: file_helper
INFO - 2017-03-02 11:04:23 --> Helper loaded: date_helper
INFO - 2017-03-02 11:04:23 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:04:23 --> Controller Class Initialized
INFO - 2017-03-02 11:04:23 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-02 11:04:23 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-02 11:04:23 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/dashboard.php
INFO - 2017-03-02 11:04:23 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-02 11:04:23 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-02 11:04:23 --> Final output sent to browser
DEBUG - 2017-03-02 11:04:23 --> Total execution time: 0.0176
INFO - 2017-03-02 11:04:35 --> Config Class Initialized
INFO - 2017-03-02 11:04:35 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:04:35 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:04:35 --> Utf8 Class Initialized
INFO - 2017-03-02 11:04:35 --> URI Class Initialized
INFO - 2017-03-02 11:04:35 --> Router Class Initialized
INFO - 2017-03-02 11:04:35 --> Output Class Initialized
INFO - 2017-03-02 11:04:35 --> Security Class Initialized
DEBUG - 2017-03-02 11:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:04:35 --> Input Class Initialized
INFO - 2017-03-02 11:04:35 --> Language Class Initialized
INFO - 2017-03-02 11:04:35 --> Loader Class Initialized
INFO - 2017-03-02 11:04:35 --> Helper loaded: url_helper
INFO - 2017-03-02 11:04:35 --> Helper loaded: file_helper
INFO - 2017-03-02 11:04:35 --> Helper loaded: date_helper
INFO - 2017-03-02 11:04:35 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:04:35 --> Controller Class Initialized
INFO - 2017-03-02 11:04:35 --> Model Class Initialized
INFO - 2017-03-02 11:04:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-02 11:04:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-02 11:04:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/exam/assign_exam.php
INFO - 2017-03-02 11:04:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-02 11:04:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-02 11:04:35 --> Final output sent to browser
DEBUG - 2017-03-02 11:04:35 --> Total execution time: 0.0210
INFO - 2017-03-02 11:04:46 --> Config Class Initialized
INFO - 2017-03-02 11:04:46 --> Hooks Class Initialized
DEBUG - 2017-03-02 11:04:46 --> UTF-8 Support Enabled
INFO - 2017-03-02 11:04:46 --> Utf8 Class Initialized
INFO - 2017-03-02 11:04:46 --> URI Class Initialized
INFO - 2017-03-02 11:04:46 --> Router Class Initialized
INFO - 2017-03-02 11:04:46 --> Output Class Initialized
INFO - 2017-03-02 11:04:46 --> Security Class Initialized
DEBUG - 2017-03-02 11:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 11:04:46 --> Input Class Initialized
INFO - 2017-03-02 11:04:46 --> Language Class Initialized
INFO - 2017-03-02 11:04:46 --> Loader Class Initialized
INFO - 2017-03-02 11:04:46 --> Helper loaded: url_helper
INFO - 2017-03-02 11:04:46 --> Helper loaded: file_helper
INFO - 2017-03-02 11:04:46 --> Helper loaded: date_helper
INFO - 2017-03-02 11:04:46 --> Database Driver Class Initialized
DEBUG - 2017-03-02 11:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 11:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 11:04:46 --> Controller Class Initialized
INFO - 2017-03-02 11:04:46 --> Model Class Initialized
INFO - 2017-03-02 11:04:46 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-02 11:04:46 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-02 11:04:46 --> File loaded: /home/thestudytown/public_html/mcq/application/views/subjects/create_subject.php
INFO - 2017-03-02 11:04:46 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-02 11:04:46 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-02 11:04:46 --> Final output sent to browser
DEBUG - 2017-03-02 11:04:46 --> Total execution time: 0.0188
