<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-13 01:50:40 --> Config Class Initialized
INFO - 2018-04-13 01:50:40 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:50:40 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:50:40 --> Utf8 Class Initialized
INFO - 2018-04-13 01:50:40 --> URI Class Initialized
INFO - 2018-04-13 01:50:40 --> Router Class Initialized
INFO - 2018-04-13 01:50:40 --> Output Class Initialized
INFO - 2018-04-13 01:50:40 --> Security Class Initialized
DEBUG - 2018-04-13 01:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:50:40 --> Input Class Initialized
INFO - 2018-04-13 01:50:40 --> Language Class Initialized
INFO - 2018-04-13 01:50:40 --> Loader Class Initialized
INFO - 2018-04-13 01:50:40 --> Helper loaded: url_helper
INFO - 2018-04-13 01:50:40 --> Helper loaded: file_helper
INFO - 2018-04-13 01:50:40 --> Helper loaded: date_helper
INFO - 2018-04-13 01:50:40 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:50:40 --> Controller Class Initialized
INFO - 2018-04-13 01:50:40 --> Model Class Initialized
INFO - 2018-04-13 01:50:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 01:50:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 01:50:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 01:50:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 01:50:40 --> Final output sent to browser
DEBUG - 2018-04-13 01:50:40 --> Total execution time: 0.4741
INFO - 2018-04-13 01:50:46 --> Config Class Initialized
INFO - 2018-04-13 01:50:46 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:50:46 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:50:46 --> Utf8 Class Initialized
INFO - 2018-04-13 01:50:46 --> URI Class Initialized
INFO - 2018-04-13 01:50:46 --> Router Class Initialized
INFO - 2018-04-13 01:50:46 --> Output Class Initialized
INFO - 2018-04-13 01:50:46 --> Security Class Initialized
DEBUG - 2018-04-13 01:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:50:46 --> Input Class Initialized
INFO - 2018-04-13 01:50:46 --> Language Class Initialized
INFO - 2018-04-13 01:50:46 --> Loader Class Initialized
INFO - 2018-04-13 01:50:46 --> Helper loaded: url_helper
INFO - 2018-04-13 01:50:46 --> Helper loaded: file_helper
INFO - 2018-04-13 01:50:46 --> Helper loaded: date_helper
INFO - 2018-04-13 01:50:46 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:50:46 --> Controller Class Initialized
INFO - 2018-04-13 01:50:46 --> Model Class Initialized
INFO - 2018-04-13 01:50:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 01:50:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-13 01:50:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 01:50:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 01:50:46 --> Final output sent to browser
DEBUG - 2018-04-13 01:50:46 --> Total execution time: 0.2792
INFO - 2018-04-13 01:50:49 --> Config Class Initialized
INFO - 2018-04-13 01:50:49 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:50:49 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:50:49 --> Utf8 Class Initialized
INFO - 2018-04-13 01:50:49 --> URI Class Initialized
INFO - 2018-04-13 01:50:49 --> Router Class Initialized
INFO - 2018-04-13 01:50:49 --> Output Class Initialized
INFO - 2018-04-13 01:50:49 --> Security Class Initialized
DEBUG - 2018-04-13 01:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:50:49 --> Input Class Initialized
INFO - 2018-04-13 01:50:49 --> Language Class Initialized
INFO - 2018-04-13 01:50:49 --> Loader Class Initialized
INFO - 2018-04-13 01:50:49 --> Helper loaded: url_helper
INFO - 2018-04-13 01:50:49 --> Helper loaded: file_helper
INFO - 2018-04-13 01:50:49 --> Helper loaded: date_helper
INFO - 2018-04-13 01:50:49 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:50:49 --> Controller Class Initialized
INFO - 2018-04-13 01:50:49 --> Model Class Initialized
INFO - 2018-04-13 01:50:49 --> Config Class Initialized
INFO - 2018-04-13 01:50:49 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:50:49 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:50:49 --> Utf8 Class Initialized
INFO - 2018-04-13 01:50:49 --> URI Class Initialized
INFO - 2018-04-13 01:50:49 --> Router Class Initialized
INFO - 2018-04-13 01:50:49 --> Output Class Initialized
INFO - 2018-04-13 01:50:49 --> Security Class Initialized
DEBUG - 2018-04-13 01:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:50:49 --> Input Class Initialized
INFO - 2018-04-13 01:50:49 --> Language Class Initialized
INFO - 2018-04-13 01:50:49 --> Loader Class Initialized
INFO - 2018-04-13 01:50:49 --> Helper loaded: url_helper
INFO - 2018-04-13 01:50:49 --> Helper loaded: file_helper
INFO - 2018-04-13 01:50:49 --> Helper loaded: date_helper
INFO - 2018-04-13 01:50:49 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:50:50 --> Controller Class Initialized
INFO - 2018-04-13 01:50:50 --> Model Class Initialized
INFO - 2018-04-13 01:50:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 01:50:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 01:50:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 01:50:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 01:50:50 --> Final output sent to browser
DEBUG - 2018-04-13 01:50:50 --> Total execution time: 0.2726
INFO - 2018-04-13 01:51:01 --> Config Class Initialized
INFO - 2018-04-13 01:51:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:51:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:51:01 --> Utf8 Class Initialized
INFO - 2018-04-13 01:51:01 --> URI Class Initialized
DEBUG - 2018-04-13 01:51:01 --> No URI present. Default controller set.
INFO - 2018-04-13 01:51:01 --> Router Class Initialized
INFO - 2018-04-13 01:51:01 --> Output Class Initialized
INFO - 2018-04-13 01:51:01 --> Security Class Initialized
DEBUG - 2018-04-13 01:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:51:01 --> Input Class Initialized
INFO - 2018-04-13 01:51:02 --> Language Class Initialized
INFO - 2018-04-13 01:51:02 --> Loader Class Initialized
INFO - 2018-04-13 01:51:02 --> Helper loaded: url_helper
INFO - 2018-04-13 01:51:02 --> Helper loaded: file_helper
INFO - 2018-04-13 01:51:02 --> Helper loaded: date_helper
INFO - 2018-04-13 01:51:02 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:51:02 --> Controller Class Initialized
INFO - 2018-04-13 01:51:02 --> Config Class Initialized
INFO - 2018-04-13 01:51:02 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:51:02 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:51:02 --> Utf8 Class Initialized
INFO - 2018-04-13 01:51:02 --> URI Class Initialized
INFO - 2018-04-13 01:51:02 --> Router Class Initialized
INFO - 2018-04-13 01:51:02 --> Output Class Initialized
INFO - 2018-04-13 01:51:02 --> Security Class Initialized
DEBUG - 2018-04-13 01:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:51:02 --> Input Class Initialized
INFO - 2018-04-13 01:51:02 --> Language Class Initialized
INFO - 2018-04-13 01:51:02 --> Loader Class Initialized
INFO - 2018-04-13 01:51:02 --> Helper loaded: url_helper
INFO - 2018-04-13 01:51:02 --> Helper loaded: file_helper
INFO - 2018-04-13 01:51:02 --> Helper loaded: date_helper
INFO - 2018-04-13 01:51:02 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:51:02 --> Controller Class Initialized
INFO - 2018-04-13 01:51:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-13 01:51:02 --> Final output sent to browser
DEBUG - 2018-04-13 01:51:02 --> Total execution time: 0.2276
INFO - 2018-04-13 01:51:11 --> Config Class Initialized
INFO - 2018-04-13 01:51:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:51:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:51:11 --> Utf8 Class Initialized
INFO - 2018-04-13 01:51:11 --> URI Class Initialized
INFO - 2018-04-13 01:51:11 --> Router Class Initialized
INFO - 2018-04-13 01:51:11 --> Output Class Initialized
INFO - 2018-04-13 01:51:11 --> Security Class Initialized
DEBUG - 2018-04-13 01:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:51:11 --> Input Class Initialized
INFO - 2018-04-13 01:51:11 --> Language Class Initialized
INFO - 2018-04-13 01:51:11 --> Loader Class Initialized
INFO - 2018-04-13 01:51:11 --> Helper loaded: url_helper
INFO - 2018-04-13 01:51:11 --> Helper loaded: file_helper
INFO - 2018-04-13 01:51:11 --> Helper loaded: date_helper
INFO - 2018-04-13 01:51:11 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:51:11 --> Controller Class Initialized
INFO - 2018-04-13 01:51:11 --> Model Class Initialized
INFO - 2018-04-13 01:51:11 --> Final output sent to browser
DEBUG - 2018-04-13 01:51:11 --> Total execution time: 0.2592
INFO - 2018-04-13 01:51:11 --> Config Class Initialized
INFO - 2018-04-13 01:51:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:51:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:51:11 --> Utf8 Class Initialized
INFO - 2018-04-13 01:51:11 --> URI Class Initialized
INFO - 2018-04-13 01:51:11 --> Router Class Initialized
INFO - 2018-04-13 01:51:11 --> Output Class Initialized
INFO - 2018-04-13 01:51:11 --> Security Class Initialized
DEBUG - 2018-04-13 01:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:51:11 --> Input Class Initialized
INFO - 2018-04-13 01:51:11 --> Language Class Initialized
INFO - 2018-04-13 01:51:11 --> Loader Class Initialized
INFO - 2018-04-13 01:51:11 --> Helper loaded: url_helper
INFO - 2018-04-13 01:51:11 --> Helper loaded: file_helper
INFO - 2018-04-13 01:51:11 --> Helper loaded: date_helper
INFO - 2018-04-13 01:51:11 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:51:11 --> Controller Class Initialized
INFO - 2018-04-13 01:51:11 --> Model Class Initialized
INFO - 2018-04-13 01:51:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 01:51:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 01:51:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 01:51:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 01:51:11 --> Final output sent to browser
DEBUG - 2018-04-13 01:51:11 --> Total execution time: 0.2623
INFO - 2018-04-13 01:51:13 --> Config Class Initialized
INFO - 2018-04-13 01:51:13 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:51:13 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:51:13 --> Utf8 Class Initialized
INFO - 2018-04-13 01:51:13 --> URI Class Initialized
INFO - 2018-04-13 01:51:13 --> Router Class Initialized
INFO - 2018-04-13 01:51:13 --> Output Class Initialized
INFO - 2018-04-13 01:51:13 --> Security Class Initialized
DEBUG - 2018-04-13 01:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:51:13 --> Input Class Initialized
INFO - 2018-04-13 01:51:13 --> Language Class Initialized
INFO - 2018-04-13 01:51:13 --> Loader Class Initialized
INFO - 2018-04-13 01:51:13 --> Helper loaded: url_helper
INFO - 2018-04-13 01:51:13 --> Helper loaded: file_helper
INFO - 2018-04-13 01:51:13 --> Helper loaded: date_helper
INFO - 2018-04-13 01:51:13 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:51:13 --> Controller Class Initialized
INFO - 2018-04-13 01:51:13 --> Model Class Initialized
INFO - 2018-04-13 01:51:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 01:51:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-13 01:51:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 01:51:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 01:51:13 --> Final output sent to browser
DEBUG - 2018-04-13 01:51:13 --> Total execution time: 0.2893
INFO - 2018-04-13 01:51:22 --> Config Class Initialized
INFO - 2018-04-13 01:51:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:51:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:51:22 --> Utf8 Class Initialized
INFO - 2018-04-13 01:51:22 --> URI Class Initialized
INFO - 2018-04-13 01:51:22 --> Router Class Initialized
INFO - 2018-04-13 01:51:22 --> Output Class Initialized
INFO - 2018-04-13 01:51:23 --> Security Class Initialized
DEBUG - 2018-04-13 01:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:51:23 --> Input Class Initialized
INFO - 2018-04-13 01:51:23 --> Language Class Initialized
INFO - 2018-04-13 01:51:23 --> Loader Class Initialized
INFO - 2018-04-13 01:51:23 --> Helper loaded: url_helper
INFO - 2018-04-13 01:51:23 --> Helper loaded: file_helper
INFO - 2018-04-13 01:51:23 --> Helper loaded: date_helper
INFO - 2018-04-13 01:51:23 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:51:23 --> Controller Class Initialized
INFO - 2018-04-13 01:51:23 --> Model Class Initialized
INFO - 2018-04-13 01:51:23 --> Config Class Initialized
INFO - 2018-04-13 01:51:23 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:51:23 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:51:23 --> Utf8 Class Initialized
INFO - 2018-04-13 01:51:23 --> URI Class Initialized
INFO - 2018-04-13 01:51:23 --> Router Class Initialized
INFO - 2018-04-13 01:51:23 --> Output Class Initialized
INFO - 2018-04-13 01:51:23 --> Security Class Initialized
DEBUG - 2018-04-13 01:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:51:23 --> Input Class Initialized
INFO - 2018-04-13 01:51:23 --> Language Class Initialized
INFO - 2018-04-13 01:51:23 --> Loader Class Initialized
INFO - 2018-04-13 01:51:23 --> Helper loaded: url_helper
INFO - 2018-04-13 01:51:23 --> Helper loaded: file_helper
INFO - 2018-04-13 01:51:23 --> Helper loaded: date_helper
INFO - 2018-04-13 01:51:23 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:51:23 --> Controller Class Initialized
INFO - 2018-04-13 01:51:23 --> Model Class Initialized
INFO - 2018-04-13 01:51:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 01:51:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 01:51:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 01:51:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 01:51:23 --> Final output sent to browser
DEBUG - 2018-04-13 01:51:23 --> Total execution time: 0.2813
INFO - 2018-04-13 01:51:26 --> Config Class Initialized
INFO - 2018-04-13 01:51:26 --> Hooks Class Initialized
DEBUG - 2018-04-13 01:51:26 --> UTF-8 Support Enabled
INFO - 2018-04-13 01:51:26 --> Utf8 Class Initialized
INFO - 2018-04-13 01:51:26 --> URI Class Initialized
INFO - 2018-04-13 01:51:26 --> Router Class Initialized
INFO - 2018-04-13 01:51:26 --> Output Class Initialized
INFO - 2018-04-13 01:51:26 --> Security Class Initialized
DEBUG - 2018-04-13 01:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 01:51:27 --> Input Class Initialized
INFO - 2018-04-13 01:51:27 --> Language Class Initialized
INFO - 2018-04-13 01:51:27 --> Loader Class Initialized
INFO - 2018-04-13 01:51:27 --> Helper loaded: url_helper
INFO - 2018-04-13 01:51:27 --> Helper loaded: file_helper
INFO - 2018-04-13 01:51:27 --> Helper loaded: date_helper
INFO - 2018-04-13 01:51:27 --> Database Driver Class Initialized
DEBUG - 2018-04-13 01:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 01:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 01:51:27 --> Controller Class Initialized
INFO - 2018-04-13 01:51:27 --> Model Class Initialized
INFO - 2018-04-13 01:51:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 01:51:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 01:51:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 01:51:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 01:51:27 --> Final output sent to browser
DEBUG - 2018-04-13 01:51:27 --> Total execution time: 0.2961
INFO - 2018-04-13 02:42:58 --> Config Class Initialized
INFO - 2018-04-13 02:42:58 --> Hooks Class Initialized
DEBUG - 2018-04-13 02:42:58 --> UTF-8 Support Enabled
INFO - 2018-04-13 02:42:58 --> Utf8 Class Initialized
INFO - 2018-04-13 02:42:58 --> URI Class Initialized
INFO - 2018-04-13 02:42:58 --> Router Class Initialized
INFO - 2018-04-13 02:42:58 --> Output Class Initialized
INFO - 2018-04-13 02:42:58 --> Security Class Initialized
DEBUG - 2018-04-13 02:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 02:42:58 --> Input Class Initialized
INFO - 2018-04-13 02:42:59 --> Language Class Initialized
INFO - 2018-04-13 02:42:59 --> Loader Class Initialized
INFO - 2018-04-13 02:42:59 --> Helper loaded: url_helper
INFO - 2018-04-13 02:42:59 --> Helper loaded: file_helper
INFO - 2018-04-13 02:42:59 --> Helper loaded: date_helper
INFO - 2018-04-13 02:42:59 --> Database Driver Class Initialized
DEBUG - 2018-04-13 02:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 02:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 02:42:59 --> Controller Class Initialized
INFO - 2018-04-13 02:42:59 --> Model Class Initialized
INFO - 2018-04-13 02:42:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 02:42:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-13 02:42:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 02:42:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 02:42:59 --> Final output sent to browser
DEBUG - 2018-04-13 02:42:59 --> Total execution time: 0.3449
INFO - 2018-04-13 02:43:12 --> Config Class Initialized
INFO - 2018-04-13 02:43:12 --> Hooks Class Initialized
DEBUG - 2018-04-13 02:43:12 --> UTF-8 Support Enabled
INFO - 2018-04-13 02:43:12 --> Utf8 Class Initialized
INFO - 2018-04-13 02:43:12 --> URI Class Initialized
INFO - 2018-04-13 02:43:12 --> Router Class Initialized
INFO - 2018-04-13 02:43:12 --> Output Class Initialized
INFO - 2018-04-13 02:43:12 --> Security Class Initialized
DEBUG - 2018-04-13 02:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 02:43:12 --> Input Class Initialized
INFO - 2018-04-13 02:43:12 --> Language Class Initialized
INFO - 2018-04-13 02:43:12 --> Loader Class Initialized
INFO - 2018-04-13 02:43:12 --> Helper loaded: url_helper
INFO - 2018-04-13 02:43:12 --> Helper loaded: file_helper
INFO - 2018-04-13 02:43:12 --> Helper loaded: date_helper
INFO - 2018-04-13 02:43:12 --> Database Driver Class Initialized
DEBUG - 2018-04-13 02:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 02:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 02:43:12 --> Controller Class Initialized
INFO - 2018-04-13 02:43:12 --> Model Class Initialized
INFO - 2018-04-13 02:43:12 --> Config Class Initialized
INFO - 2018-04-13 02:43:12 --> Hooks Class Initialized
DEBUG - 2018-04-13 02:43:12 --> UTF-8 Support Enabled
INFO - 2018-04-13 02:43:12 --> Utf8 Class Initialized
INFO - 2018-04-13 02:43:12 --> URI Class Initialized
INFO - 2018-04-13 02:43:12 --> Router Class Initialized
INFO - 2018-04-13 02:43:12 --> Output Class Initialized
INFO - 2018-04-13 02:43:12 --> Security Class Initialized
DEBUG - 2018-04-13 02:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 02:43:12 --> Input Class Initialized
INFO - 2018-04-13 02:43:12 --> Language Class Initialized
INFO - 2018-04-13 02:43:12 --> Loader Class Initialized
INFO - 2018-04-13 02:43:12 --> Helper loaded: url_helper
INFO - 2018-04-13 02:43:12 --> Helper loaded: file_helper
INFO - 2018-04-13 02:43:13 --> Helper loaded: date_helper
INFO - 2018-04-13 02:43:13 --> Database Driver Class Initialized
DEBUG - 2018-04-13 02:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 02:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 02:43:13 --> Controller Class Initialized
INFO - 2018-04-13 02:43:13 --> Model Class Initialized
INFO - 2018-04-13 02:43:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 02:43:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 02:43:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 02:43:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 02:43:13 --> Final output sent to browser
DEBUG - 2018-04-13 02:43:13 --> Total execution time: 0.5444
INFO - 2018-04-13 02:43:30 --> Config Class Initialized
INFO - 2018-04-13 02:43:30 --> Hooks Class Initialized
DEBUG - 2018-04-13 02:43:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 02:43:30 --> Utf8 Class Initialized
INFO - 2018-04-13 02:43:30 --> URI Class Initialized
INFO - 2018-04-13 02:43:30 --> Router Class Initialized
INFO - 2018-04-13 02:43:30 --> Output Class Initialized
INFO - 2018-04-13 02:43:30 --> Security Class Initialized
DEBUG - 2018-04-13 02:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 02:43:30 --> Input Class Initialized
INFO - 2018-04-13 02:43:30 --> Language Class Initialized
INFO - 2018-04-13 02:43:30 --> Loader Class Initialized
INFO - 2018-04-13 02:43:30 --> Helper loaded: url_helper
INFO - 2018-04-13 02:43:30 --> Helper loaded: file_helper
INFO - 2018-04-13 02:43:30 --> Helper loaded: date_helper
INFO - 2018-04-13 02:43:30 --> Database Driver Class Initialized
DEBUG - 2018-04-13 02:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 02:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 02:43:30 --> Controller Class Initialized
INFO - 2018-04-13 02:43:30 --> Model Class Initialized
INFO - 2018-04-13 02:43:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 02:43:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-13 02:43:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 02:43:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 02:43:30 --> Final output sent to browser
DEBUG - 2018-04-13 02:43:30 --> Total execution time: 0.2837
INFO - 2018-04-13 02:45:00 --> Config Class Initialized
INFO - 2018-04-13 02:45:00 --> Hooks Class Initialized
DEBUG - 2018-04-13 02:45:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 02:45:00 --> Utf8 Class Initialized
INFO - 2018-04-13 02:45:00 --> URI Class Initialized
INFO - 2018-04-13 02:45:00 --> Router Class Initialized
INFO - 2018-04-13 02:45:00 --> Output Class Initialized
INFO - 2018-04-13 02:45:00 --> Security Class Initialized
DEBUG - 2018-04-13 02:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 02:45:00 --> Input Class Initialized
INFO - 2018-04-13 02:45:00 --> Language Class Initialized
INFO - 2018-04-13 02:45:00 --> Loader Class Initialized
INFO - 2018-04-13 02:45:00 --> Helper loaded: url_helper
INFO - 2018-04-13 02:45:00 --> Helper loaded: file_helper
INFO - 2018-04-13 02:45:00 --> Helper loaded: date_helper
INFO - 2018-04-13 02:45:00 --> Database Driver Class Initialized
DEBUG - 2018-04-13 02:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 02:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 02:45:00 --> Controller Class Initialized
INFO - 2018-04-13 02:45:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-13 02:45:00 --> Final output sent to browser
DEBUG - 2018-04-13 02:45:00 --> Total execution time: 0.3777
INFO - 2018-04-13 02:58:53 --> Config Class Initialized
INFO - 2018-04-13 02:58:53 --> Hooks Class Initialized
DEBUG - 2018-04-13 02:58:53 --> UTF-8 Support Enabled
INFO - 2018-04-13 02:58:53 --> Utf8 Class Initialized
INFO - 2018-04-13 02:58:53 --> URI Class Initialized
INFO - 2018-04-13 02:58:53 --> Router Class Initialized
INFO - 2018-04-13 02:58:53 --> Output Class Initialized
INFO - 2018-04-13 02:58:53 --> Security Class Initialized
DEBUG - 2018-04-13 02:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 02:58:53 --> Input Class Initialized
INFO - 2018-04-13 02:58:53 --> Language Class Initialized
INFO - 2018-04-13 02:58:53 --> Loader Class Initialized
INFO - 2018-04-13 02:58:53 --> Helper loaded: url_helper
INFO - 2018-04-13 02:58:53 --> Helper loaded: file_helper
INFO - 2018-04-13 02:58:53 --> Helper loaded: date_helper
INFO - 2018-04-13 02:58:53 --> Database Driver Class Initialized
DEBUG - 2018-04-13 02:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 02:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 02:58:53 --> Controller Class Initialized
INFO - 2018-04-13 02:58:53 --> Model Class Initialized
INFO - 2018-04-13 02:58:53 --> Config Class Initialized
INFO - 2018-04-13 02:58:54 --> Hooks Class Initialized
DEBUG - 2018-04-13 02:58:54 --> UTF-8 Support Enabled
INFO - 2018-04-13 02:58:54 --> Utf8 Class Initialized
INFO - 2018-04-13 02:58:54 --> URI Class Initialized
INFO - 2018-04-13 02:58:54 --> Router Class Initialized
INFO - 2018-04-13 02:58:54 --> Output Class Initialized
INFO - 2018-04-13 02:58:54 --> Security Class Initialized
DEBUG - 2018-04-13 02:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 02:58:54 --> Input Class Initialized
INFO - 2018-04-13 02:58:54 --> Language Class Initialized
INFO - 2018-04-13 02:58:54 --> Loader Class Initialized
INFO - 2018-04-13 02:58:54 --> Helper loaded: url_helper
INFO - 2018-04-13 02:58:54 --> Helper loaded: file_helper
INFO - 2018-04-13 02:58:54 --> Helper loaded: date_helper
INFO - 2018-04-13 02:58:54 --> Database Driver Class Initialized
DEBUG - 2018-04-13 02:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 02:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 02:58:54 --> Controller Class Initialized
INFO - 2018-04-13 02:58:54 --> Model Class Initialized
INFO - 2018-04-13 02:58:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 02:58:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 02:58:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 02:58:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 02:58:54 --> Final output sent to browser
DEBUG - 2018-04-13 02:58:54 --> Total execution time: 0.4271
INFO - 2018-04-13 03:04:08 --> Config Class Initialized
INFO - 2018-04-13 03:04:08 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:04:08 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:04:08 --> Utf8 Class Initialized
INFO - 2018-04-13 03:04:08 --> URI Class Initialized
INFO - 2018-04-13 03:04:08 --> Router Class Initialized
INFO - 2018-04-13 03:04:08 --> Output Class Initialized
INFO - 2018-04-13 03:04:08 --> Security Class Initialized
DEBUG - 2018-04-13 03:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:04:08 --> Input Class Initialized
INFO - 2018-04-13 03:04:08 --> Language Class Initialized
INFO - 2018-04-13 03:04:08 --> Loader Class Initialized
INFO - 2018-04-13 03:04:08 --> Helper loaded: url_helper
INFO - 2018-04-13 03:04:08 --> Helper loaded: file_helper
INFO - 2018-04-13 03:04:08 --> Helper loaded: date_helper
INFO - 2018-04-13 03:04:08 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:04:08 --> Controller Class Initialized
INFO - 2018-04-13 03:04:08 --> Model Class Initialized
INFO - 2018-04-13 03:04:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 03:04:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-13 03:04:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 03:04:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 03:04:08 --> Final output sent to browser
DEBUG - 2018-04-13 03:04:08 --> Total execution time: 0.4767
INFO - 2018-04-13 03:04:50 --> Config Class Initialized
INFO - 2018-04-13 03:04:50 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:04:50 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:04:50 --> Utf8 Class Initialized
INFO - 2018-04-13 03:04:50 --> URI Class Initialized
INFO - 2018-04-13 03:04:50 --> Router Class Initialized
INFO - 2018-04-13 03:04:50 --> Output Class Initialized
INFO - 2018-04-13 03:04:50 --> Security Class Initialized
DEBUG - 2018-04-13 03:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:04:50 --> Input Class Initialized
INFO - 2018-04-13 03:04:50 --> Language Class Initialized
INFO - 2018-04-13 03:04:50 --> Loader Class Initialized
INFO - 2018-04-13 03:04:50 --> Helper loaded: url_helper
INFO - 2018-04-13 03:04:50 --> Helper loaded: file_helper
INFO - 2018-04-13 03:04:50 --> Helper loaded: date_helper
INFO - 2018-04-13 03:04:50 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:04:50 --> Controller Class Initialized
DEBUG - 2018-04-13 03:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-13 03:04:50 --> Config Class Initialized
INFO - 2018-04-13 03:04:50 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:04:50 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:04:50 --> Utf8 Class Initialized
INFO - 2018-04-13 03:04:50 --> URI Class Initialized
INFO - 2018-04-13 03:04:50 --> Router Class Initialized
INFO - 2018-04-13 03:04:50 --> Output Class Initialized
INFO - 2018-04-13 03:04:50 --> Security Class Initialized
DEBUG - 2018-04-13 03:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:04:50 --> Input Class Initialized
INFO - 2018-04-13 03:04:50 --> Language Class Initialized
INFO - 2018-04-13 03:04:50 --> Loader Class Initialized
INFO - 2018-04-13 03:04:50 --> Helper loaded: url_helper
INFO - 2018-04-13 03:04:50 --> Helper loaded: file_helper
INFO - 2018-04-13 03:04:50 --> Helper loaded: date_helper
INFO - 2018-04-13 03:04:50 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:04:50 --> Controller Class Initialized
INFO - 2018-04-13 03:04:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-13 03:04:50 --> Final output sent to browser
DEBUG - 2018-04-13 03:04:50 --> Total execution time: 0.2422
INFO - 2018-04-13 03:05:01 --> Config Class Initialized
INFO - 2018-04-13 03:05:01 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:05:01 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:05:01 --> Utf8 Class Initialized
INFO - 2018-04-13 03:05:01 --> URI Class Initialized
INFO - 2018-04-13 03:05:01 --> Router Class Initialized
INFO - 2018-04-13 03:05:01 --> Output Class Initialized
INFO - 2018-04-13 03:05:01 --> Security Class Initialized
DEBUG - 2018-04-13 03:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:05:01 --> Input Class Initialized
INFO - 2018-04-13 03:05:01 --> Language Class Initialized
INFO - 2018-04-13 03:05:01 --> Loader Class Initialized
INFO - 2018-04-13 03:05:02 --> Helper loaded: url_helper
INFO - 2018-04-13 03:05:02 --> Helper loaded: file_helper
INFO - 2018-04-13 03:05:02 --> Helper loaded: date_helper
INFO - 2018-04-13 03:05:02 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:05:02 --> Controller Class Initialized
INFO - 2018-04-13 03:05:02 --> Model Class Initialized
INFO - 2018-04-13 03:05:02 --> Final output sent to browser
DEBUG - 2018-04-13 03:05:02 --> Total execution time: 0.2647
INFO - 2018-04-13 03:05:02 --> Config Class Initialized
INFO - 2018-04-13 03:05:02 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:05:02 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:05:02 --> Utf8 Class Initialized
INFO - 2018-04-13 03:05:02 --> URI Class Initialized
INFO - 2018-04-13 03:05:02 --> Router Class Initialized
INFO - 2018-04-13 03:05:02 --> Output Class Initialized
INFO - 2018-04-13 03:05:02 --> Security Class Initialized
DEBUG - 2018-04-13 03:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:05:02 --> Input Class Initialized
INFO - 2018-04-13 03:05:02 --> Language Class Initialized
INFO - 2018-04-13 03:05:02 --> Loader Class Initialized
INFO - 2018-04-13 03:05:02 --> Helper loaded: url_helper
INFO - 2018-04-13 03:05:02 --> Helper loaded: file_helper
INFO - 2018-04-13 03:05:02 --> Helper loaded: date_helper
INFO - 2018-04-13 03:05:02 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:05:02 --> Controller Class Initialized
INFO - 2018-04-13 03:05:02 --> Model Class Initialized
INFO - 2018-04-13 03:05:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-13 03:05:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-13 03:05:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-13 03:05:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-13 03:05:02 --> Final output sent to browser
DEBUG - 2018-04-13 03:05:02 --> Total execution time: 0.3347
INFO - 2018-04-13 03:05:02 --> Config Class Initialized
INFO - 2018-04-13 03:05:02 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:05:02 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:05:02 --> Utf8 Class Initialized
INFO - 2018-04-13 03:05:02 --> URI Class Initialized
INFO - 2018-04-13 03:05:02 --> Router Class Initialized
INFO - 2018-04-13 03:05:02 --> Output Class Initialized
INFO - 2018-04-13 03:05:02 --> Security Class Initialized
DEBUG - 2018-04-13 03:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:05:02 --> Input Class Initialized
INFO - 2018-04-13 03:05:02 --> Language Class Initialized
ERROR - 2018-04-13 03:05:02 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-13 03:05:42 --> Config Class Initialized
INFO - 2018-04-13 03:05:42 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:05:42 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:05:42 --> Utf8 Class Initialized
INFO - 2018-04-13 03:05:42 --> URI Class Initialized
INFO - 2018-04-13 03:05:42 --> Router Class Initialized
INFO - 2018-04-13 03:05:42 --> Output Class Initialized
INFO - 2018-04-13 03:05:42 --> Security Class Initialized
DEBUG - 2018-04-13 03:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:05:42 --> Input Class Initialized
INFO - 2018-04-13 03:05:42 --> Language Class Initialized
INFO - 2018-04-13 03:05:42 --> Loader Class Initialized
INFO - 2018-04-13 03:05:42 --> Helper loaded: url_helper
INFO - 2018-04-13 03:05:42 --> Helper loaded: file_helper
INFO - 2018-04-13 03:05:42 --> Helper loaded: date_helper
INFO - 2018-04-13 03:05:42 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:05:42 --> Controller Class Initialized
INFO - 2018-04-13 03:05:42 --> Model Class Initialized
INFO - 2018-04-13 03:05:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-13 03:05:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-13 03:05:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-13 03:05:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-13 03:05:42 --> Final output sent to browser
DEBUG - 2018-04-13 03:05:42 --> Total execution time: 0.3316
INFO - 2018-04-13 03:05:42 --> Config Class Initialized
INFO - 2018-04-13 03:05:42 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:05:42 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:05:42 --> Utf8 Class Initialized
INFO - 2018-04-13 03:05:42 --> URI Class Initialized
INFO - 2018-04-13 03:05:42 --> Router Class Initialized
INFO - 2018-04-13 03:05:42 --> Output Class Initialized
INFO - 2018-04-13 03:05:42 --> Security Class Initialized
DEBUG - 2018-04-13 03:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:05:42 --> Input Class Initialized
INFO - 2018-04-13 03:05:42 --> Language Class Initialized
ERROR - 2018-04-13 03:05:42 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-13 03:05:43 --> Config Class Initialized
INFO - 2018-04-13 03:05:43 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:05:43 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:05:43 --> Utf8 Class Initialized
INFO - 2018-04-13 03:05:43 --> URI Class Initialized
INFO - 2018-04-13 03:05:43 --> Router Class Initialized
INFO - 2018-04-13 03:05:43 --> Output Class Initialized
INFO - 2018-04-13 03:05:43 --> Security Class Initialized
DEBUG - 2018-04-13 03:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:05:43 --> Input Class Initialized
INFO - 2018-04-13 03:05:43 --> Language Class Initialized
INFO - 2018-04-13 03:05:43 --> Loader Class Initialized
INFO - 2018-04-13 03:05:43 --> Helper loaded: url_helper
INFO - 2018-04-13 03:05:43 --> Helper loaded: file_helper
INFO - 2018-04-13 03:05:43 --> Helper loaded: date_helper
INFO - 2018-04-13 03:05:43 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:05:43 --> Controller Class Initialized
INFO - 2018-04-13 03:05:44 --> Config Class Initialized
INFO - 2018-04-13 03:05:44 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:05:44 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:05:44 --> Utf8 Class Initialized
INFO - 2018-04-13 03:05:44 --> URI Class Initialized
INFO - 2018-04-13 03:05:44 --> Router Class Initialized
INFO - 2018-04-13 03:05:44 --> Output Class Initialized
INFO - 2018-04-13 03:05:44 --> Security Class Initialized
DEBUG - 2018-04-13 03:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:05:44 --> Input Class Initialized
INFO - 2018-04-13 03:05:44 --> Language Class Initialized
INFO - 2018-04-13 03:05:44 --> Loader Class Initialized
INFO - 2018-04-13 03:05:44 --> Helper loaded: url_helper
INFO - 2018-04-13 03:05:44 --> Helper loaded: file_helper
INFO - 2018-04-13 03:05:44 --> Helper loaded: date_helper
INFO - 2018-04-13 03:05:44 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:05:44 --> Controller Class Initialized
INFO - 2018-04-13 03:05:44 --> Model Class Initialized
INFO - 2018-04-13 03:05:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-13 03:05:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-13 03:05:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-13 03:05:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-13 03:05:44 --> Final output sent to browser
DEBUG - 2018-04-13 03:05:44 --> Total execution time: 0.2944
INFO - 2018-04-13 03:05:47 --> Config Class Initialized
INFO - 2018-04-13 03:05:47 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:05:47 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:05:47 --> Utf8 Class Initialized
INFO - 2018-04-13 03:05:47 --> URI Class Initialized
INFO - 2018-04-13 03:05:47 --> Router Class Initialized
INFO - 2018-04-13 03:05:47 --> Output Class Initialized
INFO - 2018-04-13 03:05:47 --> Security Class Initialized
DEBUG - 2018-04-13 03:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:05:47 --> Input Class Initialized
INFO - 2018-04-13 03:05:47 --> Language Class Initialized
INFO - 2018-04-13 03:05:48 --> Loader Class Initialized
INFO - 2018-04-13 03:05:48 --> Helper loaded: url_helper
INFO - 2018-04-13 03:05:48 --> Helper loaded: file_helper
INFO - 2018-04-13 03:05:48 --> Helper loaded: date_helper
INFO - 2018-04-13 03:05:48 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:05:48 --> Controller Class Initialized
INFO - 2018-04-13 03:05:48 --> Model Class Initialized
INFO - 2018-04-13 03:05:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-13 03:05:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-13 03:05:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-13 03:05:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-13 03:05:48 --> Final output sent to browser
DEBUG - 2018-04-13 03:05:48 --> Total execution time: 0.2982
INFO - 2018-04-13 03:05:48 --> Config Class Initialized
INFO - 2018-04-13 03:05:48 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:05:48 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:05:48 --> Utf8 Class Initialized
INFO - 2018-04-13 03:05:48 --> URI Class Initialized
INFO - 2018-04-13 03:05:48 --> Router Class Initialized
INFO - 2018-04-13 03:05:48 --> Output Class Initialized
INFO - 2018-04-13 03:05:48 --> Security Class Initialized
DEBUG - 2018-04-13 03:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:05:48 --> Input Class Initialized
INFO - 2018-04-13 03:05:48 --> Language Class Initialized
ERROR - 2018-04-13 03:05:48 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-13 03:05:53 --> Config Class Initialized
INFO - 2018-04-13 03:05:53 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:05:53 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:05:53 --> Utf8 Class Initialized
INFO - 2018-04-13 03:05:53 --> URI Class Initialized
INFO - 2018-04-13 03:05:53 --> Router Class Initialized
INFO - 2018-04-13 03:05:53 --> Output Class Initialized
INFO - 2018-04-13 03:05:53 --> Security Class Initialized
DEBUG - 2018-04-13 03:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:05:53 --> Input Class Initialized
INFO - 2018-04-13 03:05:53 --> Language Class Initialized
INFO - 2018-04-13 03:05:53 --> Loader Class Initialized
INFO - 2018-04-13 03:05:53 --> Helper loaded: url_helper
INFO - 2018-04-13 03:05:53 --> Helper loaded: file_helper
INFO - 2018-04-13 03:05:53 --> Helper loaded: date_helper
INFO - 2018-04-13 03:05:53 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:05:53 --> Controller Class Initialized
INFO - 2018-04-13 03:05:53 --> Config Class Initialized
INFO - 2018-04-13 03:05:53 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:05:53 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:05:53 --> Utf8 Class Initialized
INFO - 2018-04-13 03:05:53 --> URI Class Initialized
INFO - 2018-04-13 03:05:53 --> Router Class Initialized
INFO - 2018-04-13 03:05:53 --> Output Class Initialized
INFO - 2018-04-13 03:05:53 --> Security Class Initialized
DEBUG - 2018-04-13 03:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:05:53 --> Input Class Initialized
INFO - 2018-04-13 03:05:53 --> Language Class Initialized
INFO - 2018-04-13 03:05:54 --> Loader Class Initialized
INFO - 2018-04-13 03:05:54 --> Helper loaded: url_helper
INFO - 2018-04-13 03:05:54 --> Helper loaded: file_helper
INFO - 2018-04-13 03:05:54 --> Helper loaded: date_helper
INFO - 2018-04-13 03:05:54 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:05:54 --> Controller Class Initialized
INFO - 2018-04-13 03:05:54 --> Model Class Initialized
INFO - 2018-04-13 03:05:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-13 03:05:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-13 03:05:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-13 03:05:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-13 03:05:54 --> Final output sent to browser
DEBUG - 2018-04-13 03:05:54 --> Total execution time: 0.2967
INFO - 2018-04-13 03:06:00 --> Config Class Initialized
INFO - 2018-04-13 03:06:00 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:06:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:06:00 --> Utf8 Class Initialized
INFO - 2018-04-13 03:06:00 --> URI Class Initialized
DEBUG - 2018-04-13 03:06:00 --> No URI present. Default controller set.
INFO - 2018-04-13 03:06:00 --> Router Class Initialized
INFO - 2018-04-13 03:06:00 --> Output Class Initialized
INFO - 2018-04-13 03:06:00 --> Security Class Initialized
DEBUG - 2018-04-13 03:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:06:00 --> Input Class Initialized
INFO - 2018-04-13 03:06:00 --> Language Class Initialized
INFO - 2018-04-13 03:06:00 --> Loader Class Initialized
INFO - 2018-04-13 03:06:00 --> Helper loaded: url_helper
INFO - 2018-04-13 03:06:00 --> Helper loaded: file_helper
INFO - 2018-04-13 03:06:00 --> Helper loaded: date_helper
INFO - 2018-04-13 03:06:00 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:06:00 --> Controller Class Initialized
INFO - 2018-04-13 03:06:00 --> Model Class Initialized
INFO - 2018-04-13 03:06:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-13 03:06:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-13 03:06:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-13 03:06:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-13 03:06:00 --> Final output sent to browser
INFO - 2018-04-13 03:06:00 --> Config Class Initialized
INFO - 2018-04-13 03:06:00 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:06:00 --> Total execution time: 0.3260
DEBUG - 2018-04-13 03:06:00 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:06:00 --> Utf8 Class Initialized
INFO - 2018-04-13 03:06:00 --> URI Class Initialized
INFO - 2018-04-13 03:06:00 --> Router Class Initialized
INFO - 2018-04-13 03:06:00 --> Output Class Initialized
INFO - 2018-04-13 03:06:00 --> Security Class Initialized
DEBUG - 2018-04-13 03:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:06:00 --> Input Class Initialized
INFO - 2018-04-13 03:06:01 --> Language Class Initialized
ERROR - 2018-04-13 03:06:01 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-13 03:06:14 --> Config Class Initialized
INFO - 2018-04-13 03:06:14 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:06:14 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:06:14 --> Utf8 Class Initialized
INFO - 2018-04-13 03:06:14 --> URI Class Initialized
INFO - 2018-04-13 03:06:14 --> Router Class Initialized
INFO - 2018-04-13 03:06:14 --> Output Class Initialized
INFO - 2018-04-13 03:06:14 --> Security Class Initialized
DEBUG - 2018-04-13 03:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:06:14 --> Input Class Initialized
INFO - 2018-04-13 03:06:14 --> Language Class Initialized
INFO - 2018-04-13 03:06:14 --> Loader Class Initialized
INFO - 2018-04-13 03:06:14 --> Helper loaded: url_helper
INFO - 2018-04-13 03:06:14 --> Helper loaded: file_helper
INFO - 2018-04-13 03:06:14 --> Helper loaded: date_helper
INFO - 2018-04-13 03:06:14 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:06:14 --> Controller Class Initialized
DEBUG - 2018-04-13 03:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-13 03:06:14 --> Config Class Initialized
INFO - 2018-04-13 03:06:14 --> Hooks Class Initialized
DEBUG - 2018-04-13 03:06:14 --> UTF-8 Support Enabled
INFO - 2018-04-13 03:06:14 --> Utf8 Class Initialized
INFO - 2018-04-13 03:06:14 --> URI Class Initialized
INFO - 2018-04-13 03:06:14 --> Router Class Initialized
INFO - 2018-04-13 03:06:14 --> Output Class Initialized
INFO - 2018-04-13 03:06:14 --> Security Class Initialized
DEBUG - 2018-04-13 03:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 03:06:14 --> Input Class Initialized
INFO - 2018-04-13 03:06:14 --> Language Class Initialized
INFO - 2018-04-13 03:06:14 --> Loader Class Initialized
INFO - 2018-04-13 03:06:14 --> Helper loaded: url_helper
INFO - 2018-04-13 03:06:14 --> Helper loaded: file_helper
INFO - 2018-04-13 03:06:14 --> Helper loaded: date_helper
INFO - 2018-04-13 03:06:14 --> Database Driver Class Initialized
DEBUG - 2018-04-13 03:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 03:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 03:06:14 --> Controller Class Initialized
INFO - 2018-04-13 03:06:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-13 03:06:14 --> Final output sent to browser
DEBUG - 2018-04-13 03:06:14 --> Total execution time: 0.2521
INFO - 2018-04-13 22:28:41 --> Config Class Initialized
INFO - 2018-04-13 22:28:41 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:41 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:41 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:41 --> URI Class Initialized
DEBUG - 2018-04-13 22:28:41 --> No URI present. Default controller set.
INFO - 2018-04-13 22:28:41 --> Router Class Initialized
INFO - 2018-04-13 22:28:41 --> Output Class Initialized
INFO - 2018-04-13 22:28:41 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:41 --> Input Class Initialized
INFO - 2018-04-13 22:28:41 --> Language Class Initialized
INFO - 2018-04-13 22:28:41 --> Loader Class Initialized
INFO - 2018-04-13 22:28:41 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:41 --> Helper loaded: file_helper
INFO - 2018-04-13 22:28:41 --> Helper loaded: date_helper
INFO - 2018-04-13 22:28:41 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:42 --> Controller Class Initialized
INFO - 2018-04-13 22:28:42 --> Config Class Initialized
INFO - 2018-04-13 22:28:42 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:42 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:42 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:42 --> URI Class Initialized
INFO - 2018-04-13 22:28:42 --> Router Class Initialized
INFO - 2018-04-13 22:28:42 --> Output Class Initialized
INFO - 2018-04-13 22:28:42 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:42 --> Input Class Initialized
INFO - 2018-04-13 22:28:42 --> Language Class Initialized
INFO - 2018-04-13 22:28:42 --> Loader Class Initialized
INFO - 2018-04-13 22:28:42 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:42 --> Helper loaded: file_helper
INFO - 2018-04-13 22:28:42 --> Helper loaded: date_helper
INFO - 2018-04-13 22:28:43 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:43 --> Controller Class Initialized
INFO - 2018-04-13 22:28:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-13 22:28:43 --> Final output sent to browser
DEBUG - 2018-04-13 22:28:43 --> Total execution time: 0.2891
INFO - 2018-04-13 22:28:52 --> Config Class Initialized
INFO - 2018-04-13 22:28:52 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:52 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:52 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:52 --> URI Class Initialized
INFO - 2018-04-13 22:28:52 --> Router Class Initialized
INFO - 2018-04-13 22:28:52 --> Output Class Initialized
INFO - 2018-04-13 22:28:53 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:53 --> Input Class Initialized
INFO - 2018-04-13 22:28:53 --> Language Class Initialized
INFO - 2018-04-13 22:28:53 --> Loader Class Initialized
INFO - 2018-04-13 22:28:53 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:53 --> Helper loaded: file_helper
INFO - 2018-04-13 22:28:53 --> Helper loaded: date_helper
INFO - 2018-04-13 22:28:53 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:53 --> Controller Class Initialized
INFO - 2018-04-13 22:28:53 --> Model Class Initialized
INFO - 2018-04-13 22:28:53 --> Final output sent to browser
DEBUG - 2018-04-13 22:28:53 --> Total execution time: 0.6899
INFO - 2018-04-13 22:28:53 --> Config Class Initialized
INFO - 2018-04-13 22:28:53 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:53 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:53 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:53 --> URI Class Initialized
INFO - 2018-04-13 22:28:53 --> Router Class Initialized
INFO - 2018-04-13 22:28:53 --> Output Class Initialized
INFO - 2018-04-13 22:28:53 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:53 --> Input Class Initialized
INFO - 2018-04-13 22:28:53 --> Language Class Initialized
INFO - 2018-04-13 22:28:53 --> Loader Class Initialized
INFO - 2018-04-13 22:28:53 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:53 --> Helper loaded: file_helper
INFO - 2018-04-13 22:28:53 --> Helper loaded: date_helper
INFO - 2018-04-13 22:28:53 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:53 --> Controller Class Initialized
INFO - 2018-04-13 22:28:53 --> Model Class Initialized
INFO - 2018-04-13 22:28:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 22:28:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 22:28:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 22:28:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 22:28:54 --> Final output sent to browser
DEBUG - 2018-04-13 22:28:54 --> Total execution time: 0.3588
INFO - 2018-04-13 22:28:54 --> Config Class Initialized
INFO - 2018-04-13 22:28:54 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:54 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:54 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:54 --> URI Class Initialized
INFO - 2018-04-13 22:28:54 --> Router Class Initialized
INFO - 2018-04-13 22:28:54 --> Output Class Initialized
INFO - 2018-04-13 22:28:54 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:54 --> Input Class Initialized
INFO - 2018-04-13 22:28:54 --> Language Class Initialized
ERROR - 2018-04-13 22:28:54 --> 404 Page Not Found: Assets/img
INFO - 2018-04-13 22:28:56 --> Config Class Initialized
INFO - 2018-04-13 22:28:56 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:28:56 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:28:56 --> Utf8 Class Initialized
INFO - 2018-04-13 22:28:56 --> URI Class Initialized
INFO - 2018-04-13 22:28:56 --> Router Class Initialized
INFO - 2018-04-13 22:28:56 --> Output Class Initialized
INFO - 2018-04-13 22:28:56 --> Security Class Initialized
DEBUG - 2018-04-13 22:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:28:56 --> Input Class Initialized
INFO - 2018-04-13 22:28:56 --> Language Class Initialized
INFO - 2018-04-13 22:28:56 --> Loader Class Initialized
INFO - 2018-04-13 22:28:56 --> Helper loaded: url_helper
INFO - 2018-04-13 22:28:56 --> Helper loaded: file_helper
INFO - 2018-04-13 22:28:56 --> Helper loaded: date_helper
INFO - 2018-04-13 22:28:56 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:28:56 --> Controller Class Initialized
INFO - 2018-04-13 22:28:56 --> Model Class Initialized
INFO - 2018-04-13 22:28:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 22:28:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-13 22:28:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 22:28:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 22:28:56 --> Final output sent to browser
DEBUG - 2018-04-13 22:28:56 --> Total execution time: 0.3461
INFO - 2018-04-13 22:29:05 --> Config Class Initialized
INFO - 2018-04-13 22:29:05 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:06 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:06 --> URI Class Initialized
INFO - 2018-04-13 22:29:06 --> Router Class Initialized
INFO - 2018-04-13 22:29:06 --> Output Class Initialized
INFO - 2018-04-13 22:29:06 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:06 --> Input Class Initialized
INFO - 2018-04-13 22:29:06 --> Language Class Initialized
INFO - 2018-04-13 22:29:06 --> Loader Class Initialized
INFO - 2018-04-13 22:29:06 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:06 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:06 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:06 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:06 --> Controller Class Initialized
INFO - 2018-04-13 22:29:06 --> Model Class Initialized
INFO - 2018-04-13 22:29:06 --> Config Class Initialized
INFO - 2018-04-13 22:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:06 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:06 --> URI Class Initialized
INFO - 2018-04-13 22:29:06 --> Router Class Initialized
INFO - 2018-04-13 22:29:06 --> Output Class Initialized
INFO - 2018-04-13 22:29:06 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:06 --> Input Class Initialized
INFO - 2018-04-13 22:29:06 --> Language Class Initialized
INFO - 2018-04-13 22:29:06 --> Loader Class Initialized
INFO - 2018-04-13 22:29:06 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:06 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:06 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:06 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:06 --> Controller Class Initialized
INFO - 2018-04-13 22:29:06 --> Model Class Initialized
INFO - 2018-04-13 22:29:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 22:29:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 22:29:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 22:29:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 22:29:06 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:06 --> Total execution time: 0.3157
INFO - 2018-04-13 22:29:08 --> Config Class Initialized
INFO - 2018-04-13 22:29:08 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:08 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:08 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:08 --> URI Class Initialized
INFO - 2018-04-13 22:29:08 --> Router Class Initialized
INFO - 2018-04-13 22:29:08 --> Output Class Initialized
INFO - 2018-04-13 22:29:08 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:08 --> Input Class Initialized
INFO - 2018-04-13 22:29:08 --> Language Class Initialized
INFO - 2018-04-13 22:29:08 --> Loader Class Initialized
INFO - 2018-04-13 22:29:08 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:08 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:08 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:08 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:09 --> Controller Class Initialized
INFO - 2018-04-13 22:29:09 --> Model Class Initialized
INFO - 2018-04-13 22:29:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 22:29:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-13 22:29:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 22:29:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 22:29:09 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:09 --> Total execution time: 0.2990
INFO - 2018-04-13 22:29:11 --> Config Class Initialized
INFO - 2018-04-13 22:29:11 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:11 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:11 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:11 --> URI Class Initialized
INFO - 2018-04-13 22:29:11 --> Router Class Initialized
INFO - 2018-04-13 22:29:11 --> Output Class Initialized
INFO - 2018-04-13 22:29:11 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:11 --> Input Class Initialized
INFO - 2018-04-13 22:29:11 --> Language Class Initialized
INFO - 2018-04-13 22:29:11 --> Loader Class Initialized
INFO - 2018-04-13 22:29:11 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:11 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:11 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:11 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:11 --> Controller Class Initialized
INFO - 2018-04-13 22:29:11 --> Model Class Initialized
INFO - 2018-04-13 22:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 22:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 22:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 22:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 22:29:11 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:11 --> Total execution time: 0.3180
INFO - 2018-04-13 22:29:12 --> Config Class Initialized
INFO - 2018-04-13 22:29:12 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:12 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:12 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:12 --> URI Class Initialized
INFO - 2018-04-13 22:29:12 --> Router Class Initialized
INFO - 2018-04-13 22:29:12 --> Output Class Initialized
INFO - 2018-04-13 22:29:12 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:12 --> Input Class Initialized
INFO - 2018-04-13 22:29:12 --> Language Class Initialized
INFO - 2018-04-13 22:29:12 --> Loader Class Initialized
INFO - 2018-04-13 22:29:12 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:12 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:12 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:13 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:13 --> Controller Class Initialized
INFO - 2018-04-13 22:29:13 --> Model Class Initialized
INFO - 2018-04-13 22:29:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 22:29:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-13 22:29:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 22:29:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 22:29:13 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:13 --> Total execution time: 0.3121
INFO - 2018-04-13 22:29:14 --> Config Class Initialized
INFO - 2018-04-13 22:29:14 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:14 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:14 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:14 --> URI Class Initialized
INFO - 2018-04-13 22:29:14 --> Router Class Initialized
INFO - 2018-04-13 22:29:14 --> Output Class Initialized
INFO - 2018-04-13 22:29:14 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:14 --> Input Class Initialized
INFO - 2018-04-13 22:29:14 --> Language Class Initialized
INFO - 2018-04-13 22:29:14 --> Loader Class Initialized
INFO - 2018-04-13 22:29:14 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:14 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:14 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:14 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:14 --> Controller Class Initialized
INFO - 2018-04-13 22:29:14 --> Model Class Initialized
INFO - 2018-04-13 22:29:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 22:29:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 22:29:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 22:29:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 22:29:14 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:14 --> Total execution time: 0.3148
INFO - 2018-04-13 22:29:15 --> Config Class Initialized
INFO - 2018-04-13 22:29:15 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:15 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:15 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:15 --> URI Class Initialized
INFO - 2018-04-13 22:29:15 --> Router Class Initialized
INFO - 2018-04-13 22:29:15 --> Output Class Initialized
INFO - 2018-04-13 22:29:15 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:15 --> Input Class Initialized
INFO - 2018-04-13 22:29:15 --> Language Class Initialized
INFO - 2018-04-13 22:29:15 --> Loader Class Initialized
INFO - 2018-04-13 22:29:15 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:15 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:15 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:15 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:15 --> Controller Class Initialized
INFO - 2018-04-13 22:29:15 --> Config Class Initialized
INFO - 2018-04-13 22:29:15 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:15 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:15 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:15 --> URI Class Initialized
INFO - 2018-04-13 22:29:15 --> Router Class Initialized
INFO - 2018-04-13 22:29:15 --> Output Class Initialized
INFO - 2018-04-13 22:29:15 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:15 --> Input Class Initialized
INFO - 2018-04-13 22:29:15 --> Language Class Initialized
INFO - 2018-04-13 22:29:15 --> Loader Class Initialized
INFO - 2018-04-13 22:29:15 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:15 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:15 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:15 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:16 --> Controller Class Initialized
INFO - 2018-04-13 22:29:16 --> Model Class Initialized
INFO - 2018-04-13 22:29:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-13 22:29:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-13 22:29:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-13 22:29:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-13 22:29:16 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:16 --> Total execution time: 0.3083
INFO - 2018-04-13 22:29:22 --> Config Class Initialized
INFO - 2018-04-13 22:29:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:22 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:22 --> URI Class Initialized
INFO - 2018-04-13 22:29:22 --> Router Class Initialized
INFO - 2018-04-13 22:29:22 --> Output Class Initialized
INFO - 2018-04-13 22:29:22 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:22 --> Input Class Initialized
INFO - 2018-04-13 22:29:22 --> Language Class Initialized
INFO - 2018-04-13 22:29:22 --> Loader Class Initialized
INFO - 2018-04-13 22:29:22 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:22 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:22 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:22 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:22 --> Controller Class Initialized
DEBUG - 2018-04-13 22:29:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-13 22:29:22 --> Config Class Initialized
INFO - 2018-04-13 22:29:22 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:22 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:22 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:22 --> URI Class Initialized
INFO - 2018-04-13 22:29:22 --> Router Class Initialized
INFO - 2018-04-13 22:29:22 --> Output Class Initialized
INFO - 2018-04-13 22:29:22 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:22 --> Input Class Initialized
INFO - 2018-04-13 22:29:22 --> Language Class Initialized
INFO - 2018-04-13 22:29:22 --> Loader Class Initialized
INFO - 2018-04-13 22:29:22 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:22 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:22 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:22 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:22 --> Controller Class Initialized
INFO - 2018-04-13 22:29:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-13 22:29:22 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:22 --> Total execution time: 0.3248
INFO - 2018-04-13 22:29:29 --> Config Class Initialized
INFO - 2018-04-13 22:29:29 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:29 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:29 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:29 --> URI Class Initialized
INFO - 2018-04-13 22:29:29 --> Router Class Initialized
INFO - 2018-04-13 22:29:29 --> Output Class Initialized
INFO - 2018-04-13 22:29:29 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:29 --> Input Class Initialized
INFO - 2018-04-13 22:29:30 --> Language Class Initialized
INFO - 2018-04-13 22:29:30 --> Loader Class Initialized
INFO - 2018-04-13 22:29:30 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:30 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:30 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:30 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:30 --> Controller Class Initialized
INFO - 2018-04-13 22:29:30 --> Model Class Initialized
INFO - 2018-04-13 22:29:30 --> Final output sent to browser
DEBUG - 2018-04-13 22:29:30 --> Total execution time: 0.2694
INFO - 2018-04-13 22:29:30 --> Config Class Initialized
INFO - 2018-04-13 22:29:30 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:29:30 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:29:30 --> Utf8 Class Initialized
INFO - 2018-04-13 22:29:30 --> URI Class Initialized
INFO - 2018-04-13 22:29:30 --> Router Class Initialized
INFO - 2018-04-13 22:29:30 --> Output Class Initialized
INFO - 2018-04-13 22:29:30 --> Security Class Initialized
DEBUG - 2018-04-13 22:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:29:30 --> Input Class Initialized
INFO - 2018-04-13 22:29:30 --> Language Class Initialized
INFO - 2018-04-13 22:29:30 --> Loader Class Initialized
INFO - 2018-04-13 22:29:30 --> Helper loaded: url_helper
INFO - 2018-04-13 22:29:30 --> Helper loaded: file_helper
INFO - 2018-04-13 22:29:30 --> Helper loaded: date_helper
INFO - 2018-04-13 22:29:30 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:29:30 --> Controller Class Initialized
ERROR - 2018-04-13 22:29:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin_Model G:\xampp\htdocs\codeigniter\system\core\Loader.php 344
INFO - 2018-04-13 22:30:18 --> Config Class Initialized
INFO - 2018-04-13 22:30:18 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:18 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:18 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:18 --> URI Class Initialized
INFO - 2018-04-13 22:30:18 --> Router Class Initialized
INFO - 2018-04-13 22:30:18 --> Output Class Initialized
INFO - 2018-04-13 22:30:18 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:19 --> Input Class Initialized
INFO - 2018-04-13 22:30:19 --> Language Class Initialized
INFO - 2018-04-13 22:30:19 --> Loader Class Initialized
INFO - 2018-04-13 22:30:19 --> Helper loaded: url_helper
INFO - 2018-04-13 22:30:19 --> Helper loaded: file_helper
INFO - 2018-04-13 22:30:19 --> Helper loaded: date_helper
INFO - 2018-04-13 22:30:19 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:30:19 --> Controller Class Initialized
INFO - 2018-04-13 22:30:19 --> Model Class Initialized
INFO - 2018-04-13 22:30:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-13 22:30:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-13 22:30:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-13 22:30:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-13 22:30:19 --> Final output sent to browser
DEBUG - 2018-04-13 22:30:19 --> Total execution time: 0.4477
INFO - 2018-04-13 22:30:19 --> Config Class Initialized
INFO - 2018-04-13 22:30:19 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:30:19 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:30:19 --> Utf8 Class Initialized
INFO - 2018-04-13 22:30:19 --> URI Class Initialized
INFO - 2018-04-13 22:30:19 --> Router Class Initialized
INFO - 2018-04-13 22:30:19 --> Output Class Initialized
INFO - 2018-04-13 22:30:19 --> Security Class Initialized
DEBUG - 2018-04-13 22:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:30:19 --> Input Class Initialized
INFO - 2018-04-13 22:30:19 --> Language Class Initialized
ERROR - 2018-04-13 22:30:19 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-13 22:32:45 --> Config Class Initialized
INFO - 2018-04-13 22:32:45 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:32:45 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:32:45 --> Utf8 Class Initialized
INFO - 2018-04-13 22:32:45 --> URI Class Initialized
DEBUG - 2018-04-13 22:32:45 --> No URI present. Default controller set.
INFO - 2018-04-13 22:32:45 --> Router Class Initialized
INFO - 2018-04-13 22:32:45 --> Output Class Initialized
INFO - 2018-04-13 22:32:45 --> Security Class Initialized
DEBUG - 2018-04-13 22:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:32:45 --> Input Class Initialized
INFO - 2018-04-13 22:32:45 --> Language Class Initialized
INFO - 2018-04-13 22:32:45 --> Loader Class Initialized
INFO - 2018-04-13 22:32:45 --> Helper loaded: url_helper
INFO - 2018-04-13 22:32:45 --> Helper loaded: file_helper
INFO - 2018-04-13 22:32:45 --> Helper loaded: date_helper
INFO - 2018-04-13 22:32:45 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:32:45 --> Controller Class Initialized
INFO - 2018-04-13 22:32:45 --> Model Class Initialized
INFO - 2018-04-13 22:32:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-13 22:32:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-13 22:32:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-13 22:32:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-13 22:32:45 --> Final output sent to browser
DEBUG - 2018-04-13 22:32:45 --> Total execution time: 0.3860
INFO - 2018-04-13 22:32:45 --> Config Class Initialized
INFO - 2018-04-13 22:32:45 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:32:45 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:32:46 --> Utf8 Class Initialized
INFO - 2018-04-13 22:32:46 --> URI Class Initialized
INFO - 2018-04-13 22:32:46 --> Router Class Initialized
INFO - 2018-04-13 22:32:46 --> Output Class Initialized
INFO - 2018-04-13 22:32:46 --> Security Class Initialized
DEBUG - 2018-04-13 22:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:32:46 --> Input Class Initialized
INFO - 2018-04-13 22:32:46 --> Language Class Initialized
ERROR - 2018-04-13 22:32:46 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-13 22:46:58 --> Config Class Initialized
INFO - 2018-04-13 22:46:58 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:46:58 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:46:58 --> Utf8 Class Initialized
INFO - 2018-04-13 22:46:58 --> URI Class Initialized
DEBUG - 2018-04-13 22:46:58 --> No URI present. Default controller set.
INFO - 2018-04-13 22:46:58 --> Router Class Initialized
INFO - 2018-04-13 22:46:58 --> Output Class Initialized
INFO - 2018-04-13 22:46:58 --> Security Class Initialized
DEBUG - 2018-04-13 22:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:46:58 --> Input Class Initialized
INFO - 2018-04-13 22:46:58 --> Language Class Initialized
INFO - 2018-04-13 22:46:58 --> Loader Class Initialized
INFO - 2018-04-13 22:46:58 --> Helper loaded: url_helper
INFO - 2018-04-13 22:46:58 --> Helper loaded: file_helper
INFO - 2018-04-13 22:46:58 --> Helper loaded: date_helper
INFO - 2018-04-13 22:46:58 --> Database Driver Class Initialized
DEBUG - 2018-04-13 22:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-13 22:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-13 22:46:58 --> Controller Class Initialized
INFO - 2018-04-13 22:46:58 --> Model Class Initialized
INFO - 2018-04-13 22:46:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-13 22:46:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-13 22:46:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-13 22:46:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-13 22:46:58 --> Final output sent to browser
DEBUG - 2018-04-13 22:46:58 --> Total execution time: 0.4293
INFO - 2018-04-13 22:46:58 --> Config Class Initialized
INFO - 2018-04-13 22:46:58 --> Hooks Class Initialized
DEBUG - 2018-04-13 22:46:58 --> UTF-8 Support Enabled
INFO - 2018-04-13 22:46:58 --> Utf8 Class Initialized
INFO - 2018-04-13 22:46:58 --> URI Class Initialized
INFO - 2018-04-13 22:46:58 --> Router Class Initialized
INFO - 2018-04-13 22:46:58 --> Output Class Initialized
INFO - 2018-04-13 22:46:58 --> Security Class Initialized
DEBUG - 2018-04-13 22:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-13 22:46:58 --> Input Class Initialized
INFO - 2018-04-13 22:46:58 --> Language Class Initialized
ERROR - 2018-04-13 22:46:58 --> 404 Page Not Found: Css/bootstrap.min.css
