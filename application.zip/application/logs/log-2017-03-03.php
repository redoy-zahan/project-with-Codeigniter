<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-03 16:25:19 --> Config Class Initialized
INFO - 2017-03-03 16:25:19 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:25:19 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:25:19 --> Utf8 Class Initialized
INFO - 2017-03-03 16:25:19 --> URI Class Initialized
DEBUG - 2017-03-03 16:25:19 --> No URI present. Default controller set.
INFO - 2017-03-03 16:25:19 --> Router Class Initialized
INFO - 2017-03-03 16:25:19 --> Output Class Initialized
INFO - 2017-03-03 16:25:19 --> Security Class Initialized
DEBUG - 2017-03-03 16:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:25:19 --> Input Class Initialized
INFO - 2017-03-03 16:25:19 --> Language Class Initialized
INFO - 2017-03-03 16:25:19 --> Loader Class Initialized
INFO - 2017-03-03 16:25:19 --> Helper loaded: url_helper
INFO - 2017-03-03 16:25:19 --> Helper loaded: file_helper
INFO - 2017-03-03 16:25:19 --> Helper loaded: date_helper
INFO - 2017-03-03 16:25:19 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:25:19 --> Controller Class Initialized
INFO - 2017-03-03 16:25:20 --> Config Class Initialized
INFO - 2017-03-03 16:25:20 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:25:20 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:25:20 --> Utf8 Class Initialized
INFO - 2017-03-03 16:25:20 --> URI Class Initialized
INFO - 2017-03-03 16:25:20 --> Router Class Initialized
INFO - 2017-03-03 16:25:20 --> Output Class Initialized
INFO - 2017-03-03 16:25:20 --> Security Class Initialized
DEBUG - 2017-03-03 16:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:25:20 --> Input Class Initialized
INFO - 2017-03-03 16:25:20 --> Language Class Initialized
INFO - 2017-03-03 16:25:20 --> Loader Class Initialized
INFO - 2017-03-03 16:25:20 --> Helper loaded: url_helper
INFO - 2017-03-03 16:25:20 --> Helper loaded: file_helper
INFO - 2017-03-03 16:25:20 --> Helper loaded: date_helper
INFO - 2017-03-03 16:25:20 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:25:20 --> Controller Class Initialized
INFO - 2017-03-03 16:25:20 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-03 16:25:20 --> Final output sent to browser
DEBUG - 2017-03-03 16:25:20 --> Total execution time: 0.0331
INFO - 2017-03-03 16:25:34 --> Config Class Initialized
INFO - 2017-03-03 16:25:34 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:25:34 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:25:34 --> Utf8 Class Initialized
INFO - 2017-03-03 16:25:34 --> URI Class Initialized
INFO - 2017-03-03 16:25:34 --> Router Class Initialized
INFO - 2017-03-03 16:25:34 --> Output Class Initialized
INFO - 2017-03-03 16:25:34 --> Security Class Initialized
DEBUG - 2017-03-03 16:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:25:34 --> Input Class Initialized
INFO - 2017-03-03 16:25:34 --> Language Class Initialized
INFO - 2017-03-03 16:25:34 --> Loader Class Initialized
INFO - 2017-03-03 16:25:34 --> Helper loaded: url_helper
INFO - 2017-03-03 16:25:34 --> Helper loaded: file_helper
INFO - 2017-03-03 16:25:34 --> Helper loaded: date_helper
INFO - 2017-03-03 16:25:34 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:25:34 --> Controller Class Initialized
INFO - 2017-03-03 16:25:34 --> Model Class Initialized
INFO - 2017-03-03 16:25:34 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-03 16:25:34 --> Final output sent to browser
DEBUG - 2017-03-03 16:25:34 --> Total execution time: 0.0577
INFO - 2017-03-03 16:25:46 --> Config Class Initialized
INFO - 2017-03-03 16:25:46 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:25:46 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:25:46 --> Utf8 Class Initialized
INFO - 2017-03-03 16:25:46 --> URI Class Initialized
INFO - 2017-03-03 16:25:46 --> Router Class Initialized
INFO - 2017-03-03 16:25:46 --> Output Class Initialized
INFO - 2017-03-03 16:25:46 --> Security Class Initialized
DEBUG - 2017-03-03 16:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:25:46 --> Input Class Initialized
INFO - 2017-03-03 16:25:46 --> Language Class Initialized
INFO - 2017-03-03 16:25:46 --> Loader Class Initialized
INFO - 2017-03-03 16:25:46 --> Helper loaded: url_helper
INFO - 2017-03-03 16:25:46 --> Helper loaded: file_helper
INFO - 2017-03-03 16:25:46 --> Helper loaded: date_helper
INFO - 2017-03-03 16:25:46 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:25:46 --> Controller Class Initialized
INFO - 2017-03-03 16:25:46 --> Model Class Initialized
INFO - 2017-03-03 16:25:46 --> Final output sent to browser
DEBUG - 2017-03-03 16:25:46 --> Total execution time: 0.0185
INFO - 2017-03-03 16:25:47 --> Config Class Initialized
INFO - 2017-03-03 16:25:47 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:25:47 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:25:47 --> Utf8 Class Initialized
INFO - 2017-03-03 16:25:47 --> URI Class Initialized
INFO - 2017-03-03 16:25:47 --> Router Class Initialized
INFO - 2017-03-03 16:25:47 --> Output Class Initialized
INFO - 2017-03-03 16:25:47 --> Security Class Initialized
DEBUG - 2017-03-03 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:25:47 --> Input Class Initialized
INFO - 2017-03-03 16:25:47 --> Language Class Initialized
INFO - 2017-03-03 16:25:47 --> Loader Class Initialized
INFO - 2017-03-03 16:25:47 --> Helper loaded: url_helper
INFO - 2017-03-03 16:25:47 --> Helper loaded: file_helper
INFO - 2017-03-03 16:25:47 --> Helper loaded: date_helper
INFO - 2017-03-03 16:25:47 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:25:47 --> Controller Class Initialized
INFO - 2017-03-03 16:25:47 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-03 16:25:47 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-03 16:25:47 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/dashboard.php
INFO - 2017-03-03 16:25:47 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-03 16:25:47 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-03 16:25:47 --> Final output sent to browser
DEBUG - 2017-03-03 16:25:47 --> Total execution time: 0.0389
INFO - 2017-03-03 16:26:25 --> Config Class Initialized
INFO - 2017-03-03 16:26:25 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:26:25 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:26:25 --> Utf8 Class Initialized
INFO - 2017-03-03 16:26:25 --> URI Class Initialized
INFO - 2017-03-03 16:26:25 --> Router Class Initialized
INFO - 2017-03-03 16:26:25 --> Output Class Initialized
INFO - 2017-03-03 16:26:25 --> Security Class Initialized
DEBUG - 2017-03-03 16:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:26:25 --> Input Class Initialized
INFO - 2017-03-03 16:26:25 --> Language Class Initialized
INFO - 2017-03-03 16:26:25 --> Loader Class Initialized
INFO - 2017-03-03 16:26:25 --> Helper loaded: url_helper
INFO - 2017-03-03 16:26:25 --> Helper loaded: file_helper
INFO - 2017-03-03 16:26:25 --> Helper loaded: date_helper
INFO - 2017-03-03 16:26:25 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:26:25 --> Controller Class Initialized
INFO - 2017-03-03 16:26:25 --> Model Class Initialized
INFO - 2017-03-03 16:26:25 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-03 16:26:25 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-03 16:26:25 --> File loaded: /home/thestudytown/public_html/mcq/application/views/teacher/teacher_view.php
INFO - 2017-03-03 16:26:25 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-03 16:26:25 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-03 16:26:25 --> Final output sent to browser
DEBUG - 2017-03-03 16:26:25 --> Total execution time: 0.0494
INFO - 2017-03-03 16:26:31 --> Config Class Initialized
INFO - 2017-03-03 16:26:31 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:26:31 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:26:31 --> Utf8 Class Initialized
INFO - 2017-03-03 16:26:31 --> URI Class Initialized
INFO - 2017-03-03 16:26:31 --> Router Class Initialized
INFO - 2017-03-03 16:26:31 --> Output Class Initialized
INFO - 2017-03-03 16:26:31 --> Security Class Initialized
DEBUG - 2017-03-03 16:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:26:31 --> Input Class Initialized
INFO - 2017-03-03 16:26:31 --> Language Class Initialized
INFO - 2017-03-03 16:26:31 --> Loader Class Initialized
INFO - 2017-03-03 16:26:31 --> Helper loaded: url_helper
INFO - 2017-03-03 16:26:31 --> Helper loaded: file_helper
INFO - 2017-03-03 16:26:31 --> Helper loaded: date_helper
INFO - 2017-03-03 16:26:31 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:26:31 --> Controller Class Initialized
INFO - 2017-03-03 16:26:31 --> Model Class Initialized
INFO - 2017-03-03 16:26:31 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-03 16:26:31 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-03 16:26:31 --> File loaded: /home/thestudytown/public_html/mcq/application/views/subjects/subject_view.php
INFO - 2017-03-03 16:26:31 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-03 16:26:31 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-03 16:26:31 --> Final output sent to browser
DEBUG - 2017-03-03 16:26:31 --> Total execution time: 0.0714
INFO - 2017-03-03 16:26:35 --> Config Class Initialized
INFO - 2017-03-03 16:26:35 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:26:35 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:26:35 --> Utf8 Class Initialized
INFO - 2017-03-03 16:26:35 --> URI Class Initialized
INFO - 2017-03-03 16:26:35 --> Router Class Initialized
INFO - 2017-03-03 16:26:35 --> Output Class Initialized
INFO - 2017-03-03 16:26:35 --> Security Class Initialized
DEBUG - 2017-03-03 16:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:26:35 --> Input Class Initialized
INFO - 2017-03-03 16:26:35 --> Language Class Initialized
INFO - 2017-03-03 16:26:35 --> Loader Class Initialized
INFO - 2017-03-03 16:26:35 --> Helper loaded: url_helper
INFO - 2017-03-03 16:26:35 --> Helper loaded: file_helper
INFO - 2017-03-03 16:26:35 --> Helper loaded: date_helper
INFO - 2017-03-03 16:26:35 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:26:35 --> Controller Class Initialized
INFO - 2017-03-03 16:26:35 --> Model Class Initialized
INFO - 2017-03-03 16:26:35 --> Model Class Initialized
INFO - 2017-03-03 16:26:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-03 16:26:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-03 16:26:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/subjects/assign_subject.php
INFO - 2017-03-03 16:26:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-03 16:26:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-03 16:26:35 --> Final output sent to browser
DEBUG - 2017-03-03 16:26:35 --> Total execution time: 0.0427
INFO - 2017-03-03 16:26:41 --> Config Class Initialized
INFO - 2017-03-03 16:26:41 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:26:41 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:26:41 --> Utf8 Class Initialized
INFO - 2017-03-03 16:26:41 --> URI Class Initialized
INFO - 2017-03-03 16:26:41 --> Router Class Initialized
INFO - 2017-03-03 16:26:41 --> Output Class Initialized
INFO - 2017-03-03 16:26:41 --> Security Class Initialized
DEBUG - 2017-03-03 16:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:26:41 --> Input Class Initialized
INFO - 2017-03-03 16:26:41 --> Language Class Initialized
INFO - 2017-03-03 16:26:41 --> Loader Class Initialized
INFO - 2017-03-03 16:26:41 --> Helper loaded: url_helper
INFO - 2017-03-03 16:26:41 --> Helper loaded: file_helper
INFO - 2017-03-03 16:26:41 --> Helper loaded: date_helper
INFO - 2017-03-03 16:26:41 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:26:41 --> Controller Class Initialized
INFO - 2017-03-03 16:26:41 --> Model Class Initialized
INFO - 2017-03-03 16:26:41 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-03 16:26:41 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-03 16:26:41 --> File loaded: /home/thestudytown/public_html/mcq/application/views/subjects/subject_view.php
INFO - 2017-03-03 16:26:41 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-03 16:26:41 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-03 16:26:41 --> Final output sent to browser
DEBUG - 2017-03-03 16:26:41 --> Total execution time: 0.0210
INFO - 2017-03-03 16:26:44 --> Config Class Initialized
INFO - 2017-03-03 16:26:44 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:26:44 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:26:44 --> Utf8 Class Initialized
INFO - 2017-03-03 16:26:44 --> URI Class Initialized
INFO - 2017-03-03 16:26:44 --> Router Class Initialized
INFO - 2017-03-03 16:26:44 --> Output Class Initialized
INFO - 2017-03-03 16:26:44 --> Security Class Initialized
DEBUG - 2017-03-03 16:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:26:44 --> Input Class Initialized
INFO - 2017-03-03 16:26:44 --> Language Class Initialized
INFO - 2017-03-03 16:26:44 --> Loader Class Initialized
INFO - 2017-03-03 16:26:44 --> Helper loaded: url_helper
INFO - 2017-03-03 16:26:44 --> Helper loaded: file_helper
INFO - 2017-03-03 16:26:44 --> Helper loaded: date_helper
INFO - 2017-03-03 16:26:44 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:26:44 --> Controller Class Initialized
INFO - 2017-03-03 16:26:44 --> Model Class Initialized
INFO - 2017-03-03 16:26:44 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-03 16:26:44 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-03 16:26:44 --> File loaded: /home/thestudytown/public_html/mcq/application/views/teacher/teacher_view.php
INFO - 2017-03-03 16:26:44 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-03 16:26:44 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-03 16:26:44 --> Final output sent to browser
DEBUG - 2017-03-03 16:26:44 --> Total execution time: 0.0200
INFO - 2017-03-03 16:26:49 --> Config Class Initialized
INFO - 2017-03-03 16:26:49 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:26:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:26:49 --> Utf8 Class Initialized
INFO - 2017-03-03 16:26:49 --> URI Class Initialized
INFO - 2017-03-03 16:26:49 --> Router Class Initialized
INFO - 2017-03-03 16:26:49 --> Output Class Initialized
INFO - 2017-03-03 16:26:49 --> Security Class Initialized
DEBUG - 2017-03-03 16:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:26:49 --> Input Class Initialized
INFO - 2017-03-03 16:26:49 --> Language Class Initialized
INFO - 2017-03-03 16:26:49 --> Loader Class Initialized
INFO - 2017-03-03 16:26:49 --> Helper loaded: url_helper
INFO - 2017-03-03 16:26:49 --> Helper loaded: file_helper
INFO - 2017-03-03 16:26:49 --> Helper loaded: date_helper
INFO - 2017-03-03 16:26:49 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:26:49 --> Controller Class Initialized
INFO - 2017-03-03 16:26:49 --> Model Class Initialized
INFO - 2017-03-03 16:26:49 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-03 16:26:49 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-03 16:26:49 --> File loaded: /home/thestudytown/public_html/mcq/application/views/questions/all_question.php
INFO - 2017-03-03 16:26:49 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-03 16:26:49 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-03 16:26:49 --> Final output sent to browser
DEBUG - 2017-03-03 16:26:49 --> Total execution time: 0.0691
INFO - 2017-03-03 16:26:53 --> Config Class Initialized
INFO - 2017-03-03 16:26:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:26:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:26:53 --> Utf8 Class Initialized
INFO - 2017-03-03 16:26:53 --> URI Class Initialized
INFO - 2017-03-03 16:26:53 --> Router Class Initialized
INFO - 2017-03-03 16:26:53 --> Output Class Initialized
INFO - 2017-03-03 16:26:53 --> Security Class Initialized
DEBUG - 2017-03-03 16:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:26:53 --> Input Class Initialized
INFO - 2017-03-03 16:26:53 --> Language Class Initialized
INFO - 2017-03-03 16:26:53 --> Loader Class Initialized
INFO - 2017-03-03 16:26:53 --> Helper loaded: url_helper
INFO - 2017-03-03 16:26:53 --> Helper loaded: file_helper
INFO - 2017-03-03 16:26:53 --> Helper loaded: date_helper
INFO - 2017-03-03 16:26:53 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:26:53 --> Controller Class Initialized
INFO - 2017-03-03 16:26:53 --> Model Class Initialized
INFO - 2017-03-03 16:26:53 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-03 16:26:53 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-03 16:26:53 --> File loaded: /home/thestudytown/public_html/mcq/application/views/questions/all_question.php
INFO - 2017-03-03 16:26:53 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-03 16:26:53 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-03 16:26:53 --> Final output sent to browser
DEBUG - 2017-03-03 16:26:53 --> Total execution time: 0.0193
INFO - 2017-03-03 16:27:15 --> Config Class Initialized
INFO - 2017-03-03 16:27:15 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:27:15 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:27:15 --> Utf8 Class Initialized
INFO - 2017-03-03 16:27:15 --> URI Class Initialized
INFO - 2017-03-03 16:27:15 --> Router Class Initialized
INFO - 2017-03-03 16:27:15 --> Output Class Initialized
INFO - 2017-03-03 16:27:15 --> Security Class Initialized
DEBUG - 2017-03-03 16:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:27:15 --> Input Class Initialized
INFO - 2017-03-03 16:27:15 --> Language Class Initialized
INFO - 2017-03-03 16:27:15 --> Loader Class Initialized
INFO - 2017-03-03 16:27:15 --> Helper loaded: url_helper
INFO - 2017-03-03 16:27:15 --> Helper loaded: file_helper
INFO - 2017-03-03 16:27:15 --> Helper loaded: date_helper
INFO - 2017-03-03 16:27:15 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:27:15 --> Controller Class Initialized
DEBUG - 2017-03-03 16:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-03 16:27:16 --> Config Class Initialized
INFO - 2017-03-03 16:27:16 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:27:16 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:27:16 --> Utf8 Class Initialized
INFO - 2017-03-03 16:27:16 --> URI Class Initialized
INFO - 2017-03-03 16:27:16 --> Router Class Initialized
INFO - 2017-03-03 16:27:16 --> Output Class Initialized
INFO - 2017-03-03 16:27:16 --> Security Class Initialized
DEBUG - 2017-03-03 16:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:27:16 --> Input Class Initialized
INFO - 2017-03-03 16:27:16 --> Language Class Initialized
INFO - 2017-03-03 16:27:16 --> Loader Class Initialized
INFO - 2017-03-03 16:27:16 --> Helper loaded: url_helper
INFO - 2017-03-03 16:27:16 --> Helper loaded: file_helper
INFO - 2017-03-03 16:27:16 --> Helper loaded: date_helper
INFO - 2017-03-03 16:27:16 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:27:16 --> Controller Class Initialized
INFO - 2017-03-03 16:27:16 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-03 16:27:16 --> Final output sent to browser
DEBUG - 2017-03-03 16:27:16 --> Total execution time: 0.0174
