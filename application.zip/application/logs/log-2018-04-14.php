<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-14 02:31:37 --> Config Class Initialized
INFO - 2018-04-14 02:31:37 --> Hooks Class Initialized
DEBUG - 2018-04-14 02:31:37 --> UTF-8 Support Enabled
INFO - 2018-04-14 02:31:37 --> Utf8 Class Initialized
INFO - 2018-04-14 02:31:37 --> URI Class Initialized
DEBUG - 2018-04-14 02:31:37 --> No URI present. Default controller set.
INFO - 2018-04-14 02:31:37 --> Router Class Initialized
INFO - 2018-04-14 02:31:37 --> Output Class Initialized
INFO - 2018-04-14 02:31:37 --> Security Class Initialized
DEBUG - 2018-04-14 02:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 02:31:37 --> Input Class Initialized
INFO - 2018-04-14 02:31:37 --> Language Class Initialized
INFO - 2018-04-14 02:31:37 --> Loader Class Initialized
INFO - 2018-04-14 02:31:37 --> Helper loaded: url_helper
INFO - 2018-04-14 02:31:37 --> Helper loaded: file_helper
INFO - 2018-04-14 02:31:37 --> Helper loaded: date_helper
INFO - 2018-04-14 02:31:38 --> Database Driver Class Initialized
DEBUG - 2018-04-14 02:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 02:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 02:31:38 --> Controller Class Initialized
INFO - 2018-04-14 02:31:38 --> Config Class Initialized
INFO - 2018-04-14 02:31:38 --> Hooks Class Initialized
DEBUG - 2018-04-14 02:31:38 --> UTF-8 Support Enabled
INFO - 2018-04-14 02:31:38 --> Utf8 Class Initialized
INFO - 2018-04-14 02:31:38 --> URI Class Initialized
INFO - 2018-04-14 02:31:38 --> Router Class Initialized
INFO - 2018-04-14 02:31:38 --> Output Class Initialized
INFO - 2018-04-14 02:31:38 --> Security Class Initialized
DEBUG - 2018-04-14 02:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 02:31:38 --> Input Class Initialized
INFO - 2018-04-14 02:31:38 --> Language Class Initialized
INFO - 2018-04-14 02:31:38 --> Loader Class Initialized
INFO - 2018-04-14 02:31:38 --> Helper loaded: url_helper
INFO - 2018-04-14 02:31:38 --> Helper loaded: file_helper
INFO - 2018-04-14 02:31:38 --> Helper loaded: date_helper
INFO - 2018-04-14 02:31:38 --> Database Driver Class Initialized
DEBUG - 2018-04-14 02:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 02:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 02:31:38 --> Controller Class Initialized
INFO - 2018-04-14 02:31:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-14 02:31:38 --> Final output sent to browser
DEBUG - 2018-04-14 02:31:38 --> Total execution time: 0.3877
INFO - 2018-04-14 02:32:11 --> Config Class Initialized
INFO - 2018-04-14 02:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-14 02:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-14 02:32:11 --> Utf8 Class Initialized
INFO - 2018-04-14 02:32:11 --> URI Class Initialized
INFO - 2018-04-14 02:32:11 --> Router Class Initialized
INFO - 2018-04-14 02:32:11 --> Output Class Initialized
INFO - 2018-04-14 02:32:11 --> Security Class Initialized
DEBUG - 2018-04-14 02:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 02:32:11 --> Input Class Initialized
INFO - 2018-04-14 02:32:11 --> Language Class Initialized
ERROR - 2018-04-14 02:32:11 --> 404 Page Not Found: Auth_Controller/create
INFO - 2018-04-14 02:32:24 --> Config Class Initialized
INFO - 2018-04-14 02:32:24 --> Hooks Class Initialized
DEBUG - 2018-04-14 02:32:24 --> UTF-8 Support Enabled
INFO - 2018-04-14 02:32:24 --> Utf8 Class Initialized
INFO - 2018-04-14 02:32:24 --> URI Class Initialized
INFO - 2018-04-14 02:32:24 --> Router Class Initialized
INFO - 2018-04-14 02:32:24 --> Output Class Initialized
INFO - 2018-04-14 02:32:24 --> Security Class Initialized
DEBUG - 2018-04-14 02:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 02:32:24 --> Input Class Initialized
INFO - 2018-04-14 02:32:24 --> Language Class Initialized
ERROR - 2018-04-14 02:32:24 --> 404 Page Not Found: Auth_Controller/edit
INFO - 2018-04-14 02:34:21 --> Config Class Initialized
INFO - 2018-04-14 02:34:21 --> Hooks Class Initialized
DEBUG - 2018-04-14 02:34:21 --> UTF-8 Support Enabled
INFO - 2018-04-14 02:34:21 --> Utf8 Class Initialized
INFO - 2018-04-14 02:34:21 --> URI Class Initialized
DEBUG - 2018-04-14 02:34:21 --> No URI present. Default controller set.
INFO - 2018-04-14 02:34:21 --> Router Class Initialized
INFO - 2018-04-14 02:34:21 --> Output Class Initialized
INFO - 2018-04-14 02:34:21 --> Security Class Initialized
DEBUG - 2018-04-14 02:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 02:34:21 --> Input Class Initialized
INFO - 2018-04-14 02:34:21 --> Language Class Initialized
INFO - 2018-04-14 02:34:21 --> Loader Class Initialized
INFO - 2018-04-14 02:34:21 --> Helper loaded: url_helper
INFO - 2018-04-14 02:34:21 --> Helper loaded: file_helper
INFO - 2018-04-14 02:34:21 --> Helper loaded: date_helper
INFO - 2018-04-14 02:34:21 --> Database Driver Class Initialized
DEBUG - 2018-04-14 02:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 02:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 02:34:21 --> Controller Class Initialized
INFO - 2018-04-14 02:34:21 --> Config Class Initialized
INFO - 2018-04-14 02:34:21 --> Hooks Class Initialized
DEBUG - 2018-04-14 02:34:21 --> UTF-8 Support Enabled
INFO - 2018-04-14 02:34:21 --> Utf8 Class Initialized
INFO - 2018-04-14 02:34:21 --> URI Class Initialized
INFO - 2018-04-14 02:34:21 --> Router Class Initialized
INFO - 2018-04-14 02:34:21 --> Output Class Initialized
INFO - 2018-04-14 02:34:21 --> Security Class Initialized
DEBUG - 2018-04-14 02:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 02:34:21 --> Input Class Initialized
INFO - 2018-04-14 02:34:21 --> Language Class Initialized
INFO - 2018-04-14 02:34:21 --> Loader Class Initialized
INFO - 2018-04-14 02:34:21 --> Helper loaded: url_helper
INFO - 2018-04-14 02:34:21 --> Helper loaded: file_helper
INFO - 2018-04-14 02:34:21 --> Helper loaded: date_helper
INFO - 2018-04-14 02:34:21 --> Database Driver Class Initialized
DEBUG - 2018-04-14 02:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 02:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 02:34:21 --> Controller Class Initialized
INFO - 2018-04-14 02:34:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-14 02:34:21 --> Final output sent to browser
DEBUG - 2018-04-14 02:34:21 --> Total execution time: 0.2172
INFO - 2018-04-14 02:34:39 --> Config Class Initialized
INFO - 2018-04-14 02:34:39 --> Hooks Class Initialized
DEBUG - 2018-04-14 02:34:39 --> UTF-8 Support Enabled
INFO - 2018-04-14 02:34:39 --> Utf8 Class Initialized
INFO - 2018-04-14 02:34:39 --> URI Class Initialized
INFO - 2018-04-14 02:34:39 --> Router Class Initialized
INFO - 2018-04-14 02:34:39 --> Output Class Initialized
INFO - 2018-04-14 02:34:39 --> Security Class Initialized
DEBUG - 2018-04-14 02:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 02:34:39 --> Input Class Initialized
INFO - 2018-04-14 02:34:39 --> Language Class Initialized
INFO - 2018-04-14 02:34:39 --> Loader Class Initialized
INFO - 2018-04-14 02:34:39 --> Helper loaded: url_helper
INFO - 2018-04-14 02:34:39 --> Helper loaded: file_helper
INFO - 2018-04-14 02:34:39 --> Helper loaded: date_helper
INFO - 2018-04-14 02:34:39 --> Database Driver Class Initialized
DEBUG - 2018-04-14 02:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 02:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 02:34:39 --> Controller Class Initialized
INFO - 2018-04-14 02:34:40 --> Model Class Initialized
INFO - 2018-04-14 02:34:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-14 02:34:40 --> Final output sent to browser
DEBUG - 2018-04-14 02:34:40 --> Total execution time: 0.3915
INFO - 2018-04-14 02:34:47 --> Config Class Initialized
INFO - 2018-04-14 02:34:47 --> Hooks Class Initialized
DEBUG - 2018-04-14 02:34:47 --> UTF-8 Support Enabled
INFO - 2018-04-14 02:34:47 --> Utf8 Class Initialized
INFO - 2018-04-14 02:34:47 --> URI Class Initialized
INFO - 2018-04-14 02:34:47 --> Router Class Initialized
INFO - 2018-04-14 02:34:47 --> Output Class Initialized
INFO - 2018-04-14 02:34:47 --> Security Class Initialized
DEBUG - 2018-04-14 02:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 02:34:47 --> Input Class Initialized
INFO - 2018-04-14 02:34:47 --> Language Class Initialized
INFO - 2018-04-14 02:34:47 --> Loader Class Initialized
INFO - 2018-04-14 02:34:47 --> Helper loaded: url_helper
INFO - 2018-04-14 02:34:47 --> Helper loaded: file_helper
INFO - 2018-04-14 02:34:47 --> Helper loaded: date_helper
INFO - 2018-04-14 02:34:47 --> Database Driver Class Initialized
DEBUG - 2018-04-14 02:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 02:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 02:34:47 --> Controller Class Initialized
INFO - 2018-04-14 02:34:47 --> Model Class Initialized
INFO - 2018-04-14 02:34:47 --> Final output sent to browser
DEBUG - 2018-04-14 02:34:47 --> Total execution time: 0.2372
INFO - 2018-04-14 02:34:47 --> Config Class Initialized
INFO - 2018-04-14 02:34:47 --> Hooks Class Initialized
DEBUG - 2018-04-14 02:34:47 --> UTF-8 Support Enabled
INFO - 2018-04-14 02:34:47 --> Utf8 Class Initialized
INFO - 2018-04-14 02:34:47 --> URI Class Initialized
INFO - 2018-04-14 02:34:47 --> Router Class Initialized
INFO - 2018-04-14 02:34:47 --> Output Class Initialized
INFO - 2018-04-14 02:34:47 --> Security Class Initialized
DEBUG - 2018-04-14 02:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 02:34:47 --> Input Class Initialized
INFO - 2018-04-14 02:34:47 --> Language Class Initialized
INFO - 2018-04-14 02:34:47 --> Loader Class Initialized
INFO - 2018-04-14 02:34:47 --> Helper loaded: url_helper
INFO - 2018-04-14 02:34:47 --> Helper loaded: file_helper
INFO - 2018-04-14 02:34:47 --> Helper loaded: date_helper
INFO - 2018-04-14 02:34:47 --> Database Driver Class Initialized
DEBUG - 2018-04-14 02:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 02:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 02:34:48 --> Controller Class Initialized
INFO - 2018-04-14 02:34:48 --> Model Class Initialized
INFO - 2018-04-14 02:34:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 02:34:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 02:34:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 02:34:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 02:34:48 --> Final output sent to browser
DEBUG - 2018-04-14 02:34:48 --> Total execution time: 0.3512
INFO - 2018-04-14 02:34:50 --> Config Class Initialized
INFO - 2018-04-14 02:34:50 --> Hooks Class Initialized
DEBUG - 2018-04-14 02:34:50 --> UTF-8 Support Enabled
INFO - 2018-04-14 02:34:50 --> Utf8 Class Initialized
INFO - 2018-04-14 02:34:50 --> URI Class Initialized
INFO - 2018-04-14 02:34:50 --> Router Class Initialized
INFO - 2018-04-14 02:34:50 --> Output Class Initialized
INFO - 2018-04-14 02:34:50 --> Security Class Initialized
DEBUG - 2018-04-14 02:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 02:34:50 --> Input Class Initialized
INFO - 2018-04-14 02:34:50 --> Language Class Initialized
INFO - 2018-04-14 02:34:50 --> Loader Class Initialized
INFO - 2018-04-14 02:34:50 --> Helper loaded: url_helper
INFO - 2018-04-14 02:34:50 --> Helper loaded: file_helper
INFO - 2018-04-14 02:34:50 --> Helper loaded: date_helper
INFO - 2018-04-14 02:34:51 --> Database Driver Class Initialized
DEBUG - 2018-04-14 02:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 02:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 02:34:51 --> Controller Class Initialized
INFO - 2018-04-14 02:34:51 --> Model Class Initialized
INFO - 2018-04-14 02:34:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 02:34:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-14 02:34:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 02:34:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 02:34:51 --> Final output sent to browser
DEBUG - 2018-04-14 02:34:51 --> Total execution time: 0.3085
INFO - 2018-04-14 02:35:05 --> Config Class Initialized
INFO - 2018-04-14 02:35:05 --> Hooks Class Initialized
DEBUG - 2018-04-14 02:35:05 --> UTF-8 Support Enabled
INFO - 2018-04-14 02:35:05 --> Utf8 Class Initialized
INFO - 2018-04-14 02:35:05 --> URI Class Initialized
INFO - 2018-04-14 02:35:05 --> Router Class Initialized
INFO - 2018-04-14 02:35:05 --> Output Class Initialized
INFO - 2018-04-14 02:35:05 --> Security Class Initialized
DEBUG - 2018-04-14 02:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 02:35:05 --> Input Class Initialized
INFO - 2018-04-14 02:35:05 --> Language Class Initialized
INFO - 2018-04-14 02:35:05 --> Loader Class Initialized
INFO - 2018-04-14 02:35:05 --> Helper loaded: url_helper
INFO - 2018-04-14 02:35:05 --> Helper loaded: file_helper
INFO - 2018-04-14 02:35:05 --> Helper loaded: date_helper
INFO - 2018-04-14 02:35:05 --> Database Driver Class Initialized
DEBUG - 2018-04-14 02:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 02:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 02:35:05 --> Controller Class Initialized
INFO - 2018-04-14 02:35:05 --> Model Class Initialized
INFO - 2018-04-14 02:35:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 02:35:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 02:35:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 02:35:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 02:35:05 --> Final output sent to browser
DEBUG - 2018-04-14 02:35:05 --> Total execution time: 0.2972
INFO - 2018-04-14 03:27:27 --> Config Class Initialized
INFO - 2018-04-14 03:27:27 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:27:27 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:27:27 --> Utf8 Class Initialized
INFO - 2018-04-14 03:27:27 --> URI Class Initialized
INFO - 2018-04-14 03:27:27 --> Router Class Initialized
INFO - 2018-04-14 03:27:27 --> Output Class Initialized
INFO - 2018-04-14 03:27:27 --> Security Class Initialized
DEBUG - 2018-04-14 03:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:27:27 --> Input Class Initialized
INFO - 2018-04-14 03:27:27 --> Language Class Initialized
INFO - 2018-04-14 03:27:27 --> Loader Class Initialized
INFO - 2018-04-14 03:27:27 --> Helper loaded: url_helper
INFO - 2018-04-14 03:27:27 --> Helper loaded: file_helper
INFO - 2018-04-14 03:27:27 --> Helper loaded: date_helper
INFO - 2018-04-14 03:27:27 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:27:27 --> Controller Class Initialized
INFO - 2018-04-14 03:27:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-14 03:27:27 --> Final output sent to browser
DEBUG - 2018-04-14 03:27:27 --> Total execution time: 0.2973
INFO - 2018-04-14 03:28:26 --> Config Class Initialized
INFO - 2018-04-14 03:28:26 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:28:26 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:28:26 --> Utf8 Class Initialized
INFO - 2018-04-14 03:28:26 --> URI Class Initialized
DEBUG - 2018-04-14 03:28:26 --> No URI present. Default controller set.
INFO - 2018-04-14 03:28:26 --> Router Class Initialized
INFO - 2018-04-14 03:28:26 --> Output Class Initialized
INFO - 2018-04-14 03:28:26 --> Security Class Initialized
DEBUG - 2018-04-14 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:28:26 --> Input Class Initialized
INFO - 2018-04-14 03:28:26 --> Language Class Initialized
INFO - 2018-04-14 03:28:26 --> Loader Class Initialized
INFO - 2018-04-14 03:28:26 --> Helper loaded: url_helper
INFO - 2018-04-14 03:28:26 --> Helper loaded: file_helper
INFO - 2018-04-14 03:28:26 --> Helper loaded: date_helper
INFO - 2018-04-14 03:28:26 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:28:26 --> Controller Class Initialized
INFO - 2018-04-14 03:28:26 --> Config Class Initialized
INFO - 2018-04-14 03:28:26 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:28:26 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:28:26 --> Utf8 Class Initialized
INFO - 2018-04-14 03:28:26 --> URI Class Initialized
INFO - 2018-04-14 03:28:26 --> Router Class Initialized
INFO - 2018-04-14 03:28:26 --> Output Class Initialized
INFO - 2018-04-14 03:28:26 --> Security Class Initialized
DEBUG - 2018-04-14 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:28:26 --> Input Class Initialized
INFO - 2018-04-14 03:28:26 --> Language Class Initialized
INFO - 2018-04-14 03:28:26 --> Loader Class Initialized
INFO - 2018-04-14 03:28:26 --> Helper loaded: url_helper
INFO - 2018-04-14 03:28:26 --> Helper loaded: file_helper
INFO - 2018-04-14 03:28:26 --> Helper loaded: date_helper
INFO - 2018-04-14 03:28:26 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:28:26 --> Controller Class Initialized
INFO - 2018-04-14 03:28:26 --> Model Class Initialized
INFO - 2018-04-14 03:28:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 03:28:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 03:28:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 03:28:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 03:28:26 --> Final output sent to browser
DEBUG - 2018-04-14 03:28:26 --> Total execution time: 0.2704
INFO - 2018-04-14 03:28:31 --> Config Class Initialized
INFO - 2018-04-14 03:28:31 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:28:31 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:28:31 --> Utf8 Class Initialized
INFO - 2018-04-14 03:28:31 --> URI Class Initialized
INFO - 2018-04-14 03:28:31 --> Router Class Initialized
INFO - 2018-04-14 03:28:31 --> Output Class Initialized
INFO - 2018-04-14 03:28:31 --> Security Class Initialized
DEBUG - 2018-04-14 03:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:28:31 --> Input Class Initialized
INFO - 2018-04-14 03:28:31 --> Language Class Initialized
INFO - 2018-04-14 03:28:31 --> Loader Class Initialized
INFO - 2018-04-14 03:28:31 --> Helper loaded: url_helper
INFO - 2018-04-14 03:28:31 --> Helper loaded: file_helper
INFO - 2018-04-14 03:28:31 --> Helper loaded: date_helper
INFO - 2018-04-14 03:28:31 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:28:31 --> Controller Class Initialized
INFO - 2018-04-14 03:28:31 --> Model Class Initialized
INFO - 2018-04-14 03:28:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 03:28:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-14 03:28:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 03:28:31 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 03:28:31 --> Final output sent to browser
DEBUG - 2018-04-14 03:28:31 --> Total execution time: 0.2885
INFO - 2018-04-14 03:28:41 --> Config Class Initialized
INFO - 2018-04-14 03:28:41 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:28:41 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:28:42 --> Utf8 Class Initialized
INFO - 2018-04-14 03:28:42 --> URI Class Initialized
INFO - 2018-04-14 03:28:42 --> Router Class Initialized
INFO - 2018-04-14 03:28:42 --> Output Class Initialized
INFO - 2018-04-14 03:28:42 --> Security Class Initialized
DEBUG - 2018-04-14 03:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:28:42 --> Input Class Initialized
INFO - 2018-04-14 03:28:42 --> Language Class Initialized
INFO - 2018-04-14 03:28:42 --> Loader Class Initialized
INFO - 2018-04-14 03:28:42 --> Helper loaded: url_helper
INFO - 2018-04-14 03:28:42 --> Helper loaded: file_helper
INFO - 2018-04-14 03:28:42 --> Helper loaded: date_helper
INFO - 2018-04-14 03:28:42 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:28:42 --> Controller Class Initialized
INFO - 2018-04-14 03:28:42 --> Model Class Initialized
INFO - 2018-04-14 03:28:42 --> Config Class Initialized
INFO - 2018-04-14 03:28:42 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:28:42 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:28:42 --> Utf8 Class Initialized
INFO - 2018-04-14 03:28:42 --> URI Class Initialized
INFO - 2018-04-14 03:28:42 --> Router Class Initialized
INFO - 2018-04-14 03:28:42 --> Output Class Initialized
INFO - 2018-04-14 03:28:42 --> Security Class Initialized
DEBUG - 2018-04-14 03:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:28:42 --> Input Class Initialized
INFO - 2018-04-14 03:28:42 --> Language Class Initialized
INFO - 2018-04-14 03:28:42 --> Loader Class Initialized
INFO - 2018-04-14 03:28:42 --> Helper loaded: url_helper
INFO - 2018-04-14 03:28:42 --> Helper loaded: file_helper
INFO - 2018-04-14 03:28:42 --> Helper loaded: date_helper
INFO - 2018-04-14 03:28:42 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:28:42 --> Controller Class Initialized
INFO - 2018-04-14 03:28:42 --> Model Class Initialized
INFO - 2018-04-14 03:28:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 03:28:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 03:28:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 03:28:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 03:28:43 --> Final output sent to browser
DEBUG - 2018-04-14 03:28:43 --> Total execution time: 0.7095
INFO - 2018-04-14 03:28:59 --> Config Class Initialized
INFO - 2018-04-14 03:28:59 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:28:59 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:28:59 --> Utf8 Class Initialized
INFO - 2018-04-14 03:28:59 --> URI Class Initialized
INFO - 2018-04-14 03:29:00 --> Router Class Initialized
INFO - 2018-04-14 03:29:00 --> Output Class Initialized
INFO - 2018-04-14 03:29:00 --> Security Class Initialized
DEBUG - 2018-04-14 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:29:00 --> Input Class Initialized
INFO - 2018-04-14 03:29:00 --> Language Class Initialized
INFO - 2018-04-14 03:29:00 --> Loader Class Initialized
INFO - 2018-04-14 03:29:00 --> Helper loaded: url_helper
INFO - 2018-04-14 03:29:00 --> Helper loaded: file_helper
INFO - 2018-04-14 03:29:00 --> Helper loaded: date_helper
INFO - 2018-04-14 03:29:00 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:29:00 --> Controller Class Initialized
INFO - 2018-04-14 03:29:00 --> Model Class Initialized
INFO - 2018-04-14 03:29:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 03:29:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-14 03:29:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 03:29:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 03:29:00 --> Final output sent to browser
DEBUG - 2018-04-14 03:29:00 --> Total execution time: 0.2812
INFO - 2018-04-14 03:29:07 --> Config Class Initialized
INFO - 2018-04-14 03:29:07 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:29:07 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:29:07 --> Utf8 Class Initialized
INFO - 2018-04-14 03:29:07 --> URI Class Initialized
INFO - 2018-04-14 03:29:07 --> Router Class Initialized
INFO - 2018-04-14 03:29:07 --> Output Class Initialized
INFO - 2018-04-14 03:29:07 --> Security Class Initialized
DEBUG - 2018-04-14 03:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:29:07 --> Input Class Initialized
INFO - 2018-04-14 03:29:07 --> Language Class Initialized
INFO - 2018-04-14 03:29:07 --> Loader Class Initialized
INFO - 2018-04-14 03:29:07 --> Helper loaded: url_helper
INFO - 2018-04-14 03:29:07 --> Helper loaded: file_helper
INFO - 2018-04-14 03:29:07 --> Helper loaded: date_helper
INFO - 2018-04-14 03:29:07 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:29:07 --> Controller Class Initialized
INFO - 2018-04-14 03:29:07 --> Model Class Initialized
INFO - 2018-04-14 03:29:07 --> Config Class Initialized
INFO - 2018-04-14 03:29:07 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:29:07 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:29:07 --> Utf8 Class Initialized
INFO - 2018-04-14 03:29:07 --> URI Class Initialized
INFO - 2018-04-14 03:29:07 --> Router Class Initialized
INFO - 2018-04-14 03:29:08 --> Output Class Initialized
INFO - 2018-04-14 03:29:08 --> Security Class Initialized
DEBUG - 2018-04-14 03:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:29:08 --> Input Class Initialized
INFO - 2018-04-14 03:29:08 --> Language Class Initialized
INFO - 2018-04-14 03:29:08 --> Loader Class Initialized
INFO - 2018-04-14 03:29:08 --> Helper loaded: url_helper
INFO - 2018-04-14 03:29:08 --> Helper loaded: file_helper
INFO - 2018-04-14 03:29:08 --> Helper loaded: date_helper
INFO - 2018-04-14 03:29:08 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:29:08 --> Controller Class Initialized
INFO - 2018-04-14 03:29:08 --> Model Class Initialized
INFO - 2018-04-14 03:29:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 03:29:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 03:29:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 03:29:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 03:29:08 --> Final output sent to browser
DEBUG - 2018-04-14 03:29:08 --> Total execution time: 0.2756
INFO - 2018-04-14 03:29:10 --> Config Class Initialized
INFO - 2018-04-14 03:29:10 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:29:10 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:29:10 --> Utf8 Class Initialized
INFO - 2018-04-14 03:29:10 --> URI Class Initialized
INFO - 2018-04-14 03:29:10 --> Router Class Initialized
INFO - 2018-04-14 03:29:10 --> Output Class Initialized
INFO - 2018-04-14 03:29:10 --> Security Class Initialized
DEBUG - 2018-04-14 03:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:29:10 --> Input Class Initialized
INFO - 2018-04-14 03:29:10 --> Language Class Initialized
INFO - 2018-04-14 03:29:10 --> Loader Class Initialized
INFO - 2018-04-14 03:29:10 --> Helper loaded: url_helper
INFO - 2018-04-14 03:29:10 --> Helper loaded: file_helper
INFO - 2018-04-14 03:29:10 --> Helper loaded: date_helper
INFO - 2018-04-14 03:29:10 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:29:10 --> Controller Class Initialized
INFO - 2018-04-14 03:29:11 --> Model Class Initialized
INFO - 2018-04-14 03:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 03:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-14 03:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 03:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 03:29:11 --> Final output sent to browser
DEBUG - 2018-04-14 03:29:11 --> Total execution time: 0.2947
INFO - 2018-04-14 03:29:14 --> Config Class Initialized
INFO - 2018-04-14 03:29:14 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:29:14 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:29:15 --> Utf8 Class Initialized
INFO - 2018-04-14 03:29:15 --> URI Class Initialized
INFO - 2018-04-14 03:29:15 --> Router Class Initialized
INFO - 2018-04-14 03:29:15 --> Output Class Initialized
INFO - 2018-04-14 03:29:15 --> Security Class Initialized
DEBUG - 2018-04-14 03:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:29:15 --> Input Class Initialized
INFO - 2018-04-14 03:29:15 --> Language Class Initialized
INFO - 2018-04-14 03:29:15 --> Loader Class Initialized
INFO - 2018-04-14 03:29:15 --> Helper loaded: url_helper
INFO - 2018-04-14 03:29:15 --> Helper loaded: file_helper
INFO - 2018-04-14 03:29:15 --> Helper loaded: date_helper
INFO - 2018-04-14 03:29:15 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:29:15 --> Controller Class Initialized
INFO - 2018-04-14 03:29:15 --> Model Class Initialized
INFO - 2018-04-14 03:29:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 03:29:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 03:29:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 03:29:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 03:29:15 --> Final output sent to browser
DEBUG - 2018-04-14 03:29:15 --> Total execution time: 0.2938
INFO - 2018-04-14 03:29:17 --> Config Class Initialized
INFO - 2018-04-14 03:29:17 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:29:17 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:29:17 --> Utf8 Class Initialized
INFO - 2018-04-14 03:29:17 --> URI Class Initialized
INFO - 2018-04-14 03:29:17 --> Router Class Initialized
INFO - 2018-04-14 03:29:17 --> Output Class Initialized
INFO - 2018-04-14 03:29:17 --> Security Class Initialized
DEBUG - 2018-04-14 03:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:29:17 --> Input Class Initialized
INFO - 2018-04-14 03:29:17 --> Language Class Initialized
INFO - 2018-04-14 03:29:17 --> Loader Class Initialized
INFO - 2018-04-14 03:29:17 --> Helper loaded: url_helper
INFO - 2018-04-14 03:29:17 --> Helper loaded: file_helper
INFO - 2018-04-14 03:29:17 --> Helper loaded: date_helper
INFO - 2018-04-14 03:29:17 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:29:17 --> Controller Class Initialized
INFO - 2018-04-14 03:29:18 --> Model Class Initialized
INFO - 2018-04-14 03:29:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 03:29:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-14 03:29:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 03:29:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 03:29:18 --> Final output sent to browser
DEBUG - 2018-04-14 03:29:18 --> Total execution time: 0.2974
INFO - 2018-04-14 03:29:20 --> Config Class Initialized
INFO - 2018-04-14 03:29:20 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:29:20 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:29:20 --> Utf8 Class Initialized
INFO - 2018-04-14 03:29:20 --> URI Class Initialized
INFO - 2018-04-14 03:29:20 --> Router Class Initialized
INFO - 2018-04-14 03:29:20 --> Output Class Initialized
INFO - 2018-04-14 03:29:20 --> Security Class Initialized
DEBUG - 2018-04-14 03:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:29:20 --> Input Class Initialized
INFO - 2018-04-14 03:29:20 --> Language Class Initialized
INFO - 2018-04-14 03:29:21 --> Loader Class Initialized
INFO - 2018-04-14 03:29:21 --> Helper loaded: url_helper
INFO - 2018-04-14 03:29:21 --> Helper loaded: file_helper
INFO - 2018-04-14 03:29:21 --> Helper loaded: date_helper
INFO - 2018-04-14 03:29:21 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:29:21 --> Controller Class Initialized
INFO - 2018-04-14 03:29:21 --> Model Class Initialized
INFO - 2018-04-14 03:29:21 --> Config Class Initialized
INFO - 2018-04-14 03:29:21 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:29:21 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:29:21 --> Utf8 Class Initialized
INFO - 2018-04-14 03:29:21 --> URI Class Initialized
INFO - 2018-04-14 03:29:21 --> Router Class Initialized
INFO - 2018-04-14 03:29:21 --> Output Class Initialized
INFO - 2018-04-14 03:29:21 --> Security Class Initialized
DEBUG - 2018-04-14 03:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:29:21 --> Input Class Initialized
INFO - 2018-04-14 03:29:21 --> Language Class Initialized
INFO - 2018-04-14 03:29:21 --> Loader Class Initialized
INFO - 2018-04-14 03:29:21 --> Helper loaded: url_helper
INFO - 2018-04-14 03:29:21 --> Helper loaded: file_helper
INFO - 2018-04-14 03:29:21 --> Helper loaded: date_helper
INFO - 2018-04-14 03:29:21 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:29:21 --> Controller Class Initialized
INFO - 2018-04-14 03:29:21 --> Model Class Initialized
INFO - 2018-04-14 03:29:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 03:29:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 03:29:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 03:29:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 03:29:22 --> Final output sent to browser
DEBUG - 2018-04-14 03:29:22 --> Total execution time: 0.7149
INFO - 2018-04-14 03:29:24 --> Config Class Initialized
INFO - 2018-04-14 03:29:24 --> Hooks Class Initialized
DEBUG - 2018-04-14 03:29:24 --> UTF-8 Support Enabled
INFO - 2018-04-14 03:29:24 --> Utf8 Class Initialized
INFO - 2018-04-14 03:29:24 --> URI Class Initialized
INFO - 2018-04-14 03:29:24 --> Router Class Initialized
INFO - 2018-04-14 03:29:24 --> Output Class Initialized
INFO - 2018-04-14 03:29:24 --> Security Class Initialized
DEBUG - 2018-04-14 03:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 03:29:24 --> Input Class Initialized
INFO - 2018-04-14 03:29:24 --> Language Class Initialized
INFO - 2018-04-14 03:29:24 --> Loader Class Initialized
INFO - 2018-04-14 03:29:24 --> Helper loaded: url_helper
INFO - 2018-04-14 03:29:24 --> Helper loaded: file_helper
INFO - 2018-04-14 03:29:24 --> Helper loaded: date_helper
INFO - 2018-04-14 03:29:24 --> Database Driver Class Initialized
DEBUG - 2018-04-14 03:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 03:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 03:29:24 --> Controller Class Initialized
INFO - 2018-04-14 03:29:24 --> Model Class Initialized
INFO - 2018-04-14 03:29:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 03:29:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-14 03:29:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 03:29:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 03:29:24 --> Final output sent to browser
DEBUG - 2018-04-14 03:29:24 --> Total execution time: 0.2935
INFO - 2018-04-14 05:22:23 --> Config Class Initialized
INFO - 2018-04-14 05:22:23 --> Hooks Class Initialized
DEBUG - 2018-04-14 05:22:23 --> UTF-8 Support Enabled
INFO - 2018-04-14 05:22:23 --> Utf8 Class Initialized
INFO - 2018-04-14 05:22:23 --> URI Class Initialized
DEBUG - 2018-04-14 05:22:23 --> No URI present. Default controller set.
INFO - 2018-04-14 05:22:23 --> Router Class Initialized
INFO - 2018-04-14 05:22:23 --> Output Class Initialized
INFO - 2018-04-14 05:22:23 --> Security Class Initialized
DEBUG - 2018-04-14 05:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 05:22:23 --> Input Class Initialized
INFO - 2018-04-14 05:22:23 --> Language Class Initialized
INFO - 2018-04-14 05:22:23 --> Loader Class Initialized
INFO - 2018-04-14 05:22:23 --> Helper loaded: url_helper
INFO - 2018-04-14 05:22:23 --> Helper loaded: file_helper
INFO - 2018-04-14 05:22:23 --> Helper loaded: date_helper
INFO - 2018-04-14 05:22:23 --> Database Driver Class Initialized
DEBUG - 2018-04-14 05:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 05:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 05:22:23 --> Controller Class Initialized
INFO - 2018-04-14 05:22:23 --> Config Class Initialized
INFO - 2018-04-14 05:22:23 --> Hooks Class Initialized
DEBUG - 2018-04-14 05:22:23 --> UTF-8 Support Enabled
INFO - 2018-04-14 05:22:23 --> Utf8 Class Initialized
INFO - 2018-04-14 05:22:23 --> URI Class Initialized
INFO - 2018-04-14 05:22:23 --> Router Class Initialized
INFO - 2018-04-14 05:22:23 --> Output Class Initialized
INFO - 2018-04-14 05:22:23 --> Security Class Initialized
DEBUG - 2018-04-14 05:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 05:22:23 --> Input Class Initialized
INFO - 2018-04-14 05:22:23 --> Language Class Initialized
INFO - 2018-04-14 05:22:24 --> Loader Class Initialized
INFO - 2018-04-14 05:22:24 --> Helper loaded: url_helper
INFO - 2018-04-14 05:22:24 --> Helper loaded: file_helper
INFO - 2018-04-14 05:22:24 --> Helper loaded: date_helper
INFO - 2018-04-14 05:22:24 --> Database Driver Class Initialized
DEBUG - 2018-04-14 05:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 05:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 05:22:24 --> Controller Class Initialized
INFO - 2018-04-14 05:22:24 --> Model Class Initialized
INFO - 2018-04-14 05:22:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 05:22:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 05:22:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 05:22:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 05:22:24 --> Final output sent to browser
DEBUG - 2018-04-14 05:22:24 --> Total execution time: 0.5517
INFO - 2018-04-14 05:22:24 --> Config Class Initialized
INFO - 2018-04-14 05:22:24 --> Hooks Class Initialized
DEBUG - 2018-04-14 05:22:24 --> UTF-8 Support Enabled
INFO - 2018-04-14 05:22:24 --> Utf8 Class Initialized
INFO - 2018-04-14 05:22:24 --> URI Class Initialized
INFO - 2018-04-14 05:22:24 --> Router Class Initialized
INFO - 2018-04-14 05:22:24 --> Output Class Initialized
INFO - 2018-04-14 05:22:24 --> Security Class Initialized
DEBUG - 2018-04-14 05:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 05:22:24 --> Input Class Initialized
INFO - 2018-04-14 05:22:24 --> Language Class Initialized
ERROR - 2018-04-14 05:22:24 --> 404 Page Not Found: Assets/img
INFO - 2018-04-14 23:34:50 --> Config Class Initialized
INFO - 2018-04-14 23:34:50 --> Hooks Class Initialized
DEBUG - 2018-04-14 23:34:50 --> UTF-8 Support Enabled
INFO - 2018-04-14 23:34:50 --> Utf8 Class Initialized
INFO - 2018-04-14 23:34:50 --> URI Class Initialized
DEBUG - 2018-04-14 23:34:51 --> No URI present. Default controller set.
INFO - 2018-04-14 23:34:51 --> Router Class Initialized
INFO - 2018-04-14 23:34:51 --> Output Class Initialized
INFO - 2018-04-14 23:34:51 --> Security Class Initialized
DEBUG - 2018-04-14 23:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 23:34:51 --> Input Class Initialized
INFO - 2018-04-14 23:34:51 --> Language Class Initialized
INFO - 2018-04-14 23:34:51 --> Loader Class Initialized
INFO - 2018-04-14 23:34:51 --> Helper loaded: url_helper
INFO - 2018-04-14 23:34:51 --> Helper loaded: file_helper
INFO - 2018-04-14 23:34:51 --> Helper loaded: date_helper
INFO - 2018-04-14 23:34:52 --> Database Driver Class Initialized
DEBUG - 2018-04-14 23:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 23:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 23:34:52 --> Controller Class Initialized
INFO - 2018-04-14 23:34:52 --> Config Class Initialized
INFO - 2018-04-14 23:34:52 --> Hooks Class Initialized
DEBUG - 2018-04-14 23:34:52 --> UTF-8 Support Enabled
INFO - 2018-04-14 23:34:52 --> Utf8 Class Initialized
INFO - 2018-04-14 23:34:52 --> URI Class Initialized
INFO - 2018-04-14 23:34:52 --> Router Class Initialized
INFO - 2018-04-14 23:34:52 --> Output Class Initialized
INFO - 2018-04-14 23:34:52 --> Security Class Initialized
DEBUG - 2018-04-14 23:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 23:34:52 --> Input Class Initialized
INFO - 2018-04-14 23:34:53 --> Language Class Initialized
INFO - 2018-04-14 23:34:53 --> Loader Class Initialized
INFO - 2018-04-14 23:34:53 --> Helper loaded: url_helper
INFO - 2018-04-14 23:34:53 --> Helper loaded: file_helper
INFO - 2018-04-14 23:34:53 --> Helper loaded: date_helper
INFO - 2018-04-14 23:34:53 --> Database Driver Class Initialized
DEBUG - 2018-04-14 23:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 23:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 23:34:53 --> Controller Class Initialized
INFO - 2018-04-14 23:34:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-14 23:34:53 --> Final output sent to browser
DEBUG - 2018-04-14 23:34:53 --> Total execution time: 0.5405
INFO - 2018-04-14 23:35:11 --> Config Class Initialized
INFO - 2018-04-14 23:35:11 --> Hooks Class Initialized
DEBUG - 2018-04-14 23:35:11 --> UTF-8 Support Enabled
INFO - 2018-04-14 23:35:11 --> Utf8 Class Initialized
INFO - 2018-04-14 23:35:11 --> URI Class Initialized
INFO - 2018-04-14 23:35:11 --> Router Class Initialized
INFO - 2018-04-14 23:35:11 --> Output Class Initialized
INFO - 2018-04-14 23:35:11 --> Security Class Initialized
DEBUG - 2018-04-14 23:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 23:35:11 --> Input Class Initialized
INFO - 2018-04-14 23:35:11 --> Language Class Initialized
INFO - 2018-04-14 23:35:11 --> Loader Class Initialized
INFO - 2018-04-14 23:35:11 --> Helper loaded: url_helper
INFO - 2018-04-14 23:35:11 --> Helper loaded: file_helper
INFO - 2018-04-14 23:35:11 --> Helper loaded: date_helper
INFO - 2018-04-14 23:35:11 --> Database Driver Class Initialized
DEBUG - 2018-04-14 23:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 23:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 23:35:11 --> Controller Class Initialized
INFO - 2018-04-14 23:35:12 --> Model Class Initialized
INFO - 2018-04-14 23:35:12 --> Final output sent to browser
DEBUG - 2018-04-14 23:35:12 --> Total execution time: 0.7595
INFO - 2018-04-14 23:35:12 --> Config Class Initialized
INFO - 2018-04-14 23:35:12 --> Hooks Class Initialized
DEBUG - 2018-04-14 23:35:12 --> UTF-8 Support Enabled
INFO - 2018-04-14 23:35:12 --> Utf8 Class Initialized
INFO - 2018-04-14 23:35:12 --> URI Class Initialized
INFO - 2018-04-14 23:35:12 --> Router Class Initialized
INFO - 2018-04-14 23:35:12 --> Output Class Initialized
INFO - 2018-04-14 23:35:12 --> Security Class Initialized
DEBUG - 2018-04-14 23:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 23:35:12 --> Input Class Initialized
INFO - 2018-04-14 23:35:12 --> Language Class Initialized
INFO - 2018-04-14 23:35:12 --> Loader Class Initialized
INFO - 2018-04-14 23:35:12 --> Helper loaded: url_helper
INFO - 2018-04-14 23:35:12 --> Helper loaded: file_helper
INFO - 2018-04-14 23:35:12 --> Helper loaded: date_helper
INFO - 2018-04-14 23:35:12 --> Database Driver Class Initialized
DEBUG - 2018-04-14 23:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 23:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 23:35:12 --> Controller Class Initialized
INFO - 2018-04-14 23:35:12 --> Model Class Initialized
INFO - 2018-04-14 23:35:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 23:35:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 23:35:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 23:35:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 23:35:13 --> Final output sent to browser
DEBUG - 2018-04-14 23:35:13 --> Total execution time: 0.7454
INFO - 2018-04-14 23:35:13 --> Config Class Initialized
INFO - 2018-04-14 23:35:13 --> Hooks Class Initialized
DEBUG - 2018-04-14 23:35:13 --> UTF-8 Support Enabled
INFO - 2018-04-14 23:35:13 --> Utf8 Class Initialized
INFO - 2018-04-14 23:35:13 --> URI Class Initialized
INFO - 2018-04-14 23:35:13 --> Router Class Initialized
INFO - 2018-04-14 23:35:13 --> Output Class Initialized
INFO - 2018-04-14 23:35:13 --> Security Class Initialized
DEBUG - 2018-04-14 23:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 23:35:13 --> Input Class Initialized
INFO - 2018-04-14 23:35:13 --> Language Class Initialized
ERROR - 2018-04-14 23:35:13 --> 404 Page Not Found: Assets/img
INFO - 2018-04-14 23:35:59 --> Config Class Initialized
INFO - 2018-04-14 23:35:59 --> Hooks Class Initialized
DEBUG - 2018-04-14 23:35:59 --> UTF-8 Support Enabled
INFO - 2018-04-14 23:35:59 --> Utf8 Class Initialized
INFO - 2018-04-14 23:35:59 --> URI Class Initialized
INFO - 2018-04-14 23:35:59 --> Router Class Initialized
INFO - 2018-04-14 23:35:59 --> Output Class Initialized
INFO - 2018-04-14 23:35:59 --> Security Class Initialized
DEBUG - 2018-04-14 23:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 23:35:59 --> Input Class Initialized
INFO - 2018-04-14 23:35:59 --> Language Class Initialized
INFO - 2018-04-14 23:35:59 --> Loader Class Initialized
INFO - 2018-04-14 23:35:59 --> Helper loaded: url_helper
INFO - 2018-04-14 23:35:59 --> Helper loaded: file_helper
INFO - 2018-04-14 23:35:59 --> Helper loaded: date_helper
INFO - 2018-04-14 23:35:59 --> Database Driver Class Initialized
DEBUG - 2018-04-14 23:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 23:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 23:35:59 --> Controller Class Initialized
INFO - 2018-04-14 23:35:59 --> Model Class Initialized
INFO - 2018-04-14 23:35:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 23:35:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 23:35:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 23:35:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 23:35:59 --> Final output sent to browser
DEBUG - 2018-04-14 23:35:59 --> Total execution time: 0.3013
INFO - 2018-04-14 23:36:23 --> Config Class Initialized
INFO - 2018-04-14 23:36:23 --> Hooks Class Initialized
DEBUG - 2018-04-14 23:36:23 --> UTF-8 Support Enabled
INFO - 2018-04-14 23:36:23 --> Utf8 Class Initialized
INFO - 2018-04-14 23:36:23 --> URI Class Initialized
INFO - 2018-04-14 23:36:23 --> Router Class Initialized
INFO - 2018-04-14 23:36:23 --> Output Class Initialized
INFO - 2018-04-14 23:36:23 --> Security Class Initialized
DEBUG - 2018-04-14 23:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 23:36:23 --> Input Class Initialized
INFO - 2018-04-14 23:36:23 --> Language Class Initialized
INFO - 2018-04-14 23:36:23 --> Loader Class Initialized
INFO - 2018-04-14 23:36:23 --> Helper loaded: url_helper
INFO - 2018-04-14 23:36:23 --> Helper loaded: file_helper
INFO - 2018-04-14 23:36:23 --> Helper loaded: date_helper
INFO - 2018-04-14 23:36:23 --> Database Driver Class Initialized
DEBUG - 2018-04-14 23:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 23:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 23:36:23 --> Controller Class Initialized
INFO - 2018-04-14 23:36:23 --> Model Class Initialized
INFO - 2018-04-14 23:36:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 23:36:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 23:36:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 23:36:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 23:36:23 --> Final output sent to browser
DEBUG - 2018-04-14 23:36:23 --> Total execution time: 0.3039
INFO - 2018-04-14 23:36:48 --> Config Class Initialized
INFO - 2018-04-14 23:36:48 --> Hooks Class Initialized
DEBUG - 2018-04-14 23:36:49 --> UTF-8 Support Enabled
INFO - 2018-04-14 23:36:49 --> Utf8 Class Initialized
INFO - 2018-04-14 23:36:49 --> URI Class Initialized
INFO - 2018-04-14 23:36:49 --> Router Class Initialized
INFO - 2018-04-14 23:36:49 --> Output Class Initialized
INFO - 2018-04-14 23:36:49 --> Security Class Initialized
DEBUG - 2018-04-14 23:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-14 23:36:49 --> Input Class Initialized
INFO - 2018-04-14 23:36:49 --> Language Class Initialized
INFO - 2018-04-14 23:36:49 --> Loader Class Initialized
INFO - 2018-04-14 23:36:49 --> Helper loaded: url_helper
INFO - 2018-04-14 23:36:49 --> Helper loaded: file_helper
INFO - 2018-04-14 23:36:49 --> Helper loaded: date_helper
INFO - 2018-04-14 23:36:49 --> Database Driver Class Initialized
DEBUG - 2018-04-14 23:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-14 23:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-14 23:36:49 --> Controller Class Initialized
INFO - 2018-04-14 23:36:49 --> Model Class Initialized
INFO - 2018-04-14 23:36:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-14 23:36:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-14 23:36:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-14 23:36:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-14 23:36:49 --> Final output sent to browser
DEBUG - 2018-04-14 23:36:49 --> Total execution time: 0.3181
