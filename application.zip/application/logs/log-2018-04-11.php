<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-11 03:22:12 --> Config Class Initialized
INFO - 2018-04-11 03:22:12 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:22:12 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:22:12 --> Utf8 Class Initialized
INFO - 2018-04-11 03:22:12 --> URI Class Initialized
INFO - 2018-04-11 03:22:12 --> Router Class Initialized
INFO - 2018-04-11 03:22:12 --> Output Class Initialized
INFO - 2018-04-11 03:22:12 --> Security Class Initialized
DEBUG - 2018-04-11 03:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:22:12 --> Input Class Initialized
INFO - 2018-04-11 03:22:12 --> Language Class Initialized
INFO - 2018-04-11 03:22:12 --> Loader Class Initialized
INFO - 2018-04-11 03:22:12 --> Helper loaded: url_helper
INFO - 2018-04-11 03:22:12 --> Helper loaded: file_helper
INFO - 2018-04-11 03:22:12 --> Helper loaded: date_helper
INFO - 2018-04-11 03:22:12 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:22:12 --> Controller Class Initialized
INFO - 2018-04-11 03:22:26 --> Config Class Initialized
INFO - 2018-04-11 03:22:26 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:22:26 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:22:26 --> Utf8 Class Initialized
INFO - 2018-04-11 03:22:26 --> URI Class Initialized
DEBUG - 2018-04-11 03:22:26 --> No URI present. Default controller set.
INFO - 2018-04-11 03:22:26 --> Router Class Initialized
INFO - 2018-04-11 03:22:26 --> Output Class Initialized
INFO - 2018-04-11 03:22:26 --> Security Class Initialized
DEBUG - 2018-04-11 03:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:22:26 --> Input Class Initialized
INFO - 2018-04-11 03:22:26 --> Language Class Initialized
INFO - 2018-04-11 03:22:26 --> Loader Class Initialized
INFO - 2018-04-11 03:22:26 --> Helper loaded: url_helper
INFO - 2018-04-11 03:22:26 --> Helper loaded: file_helper
INFO - 2018-04-11 03:22:26 --> Helper loaded: date_helper
INFO - 2018-04-11 03:22:26 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:22:26 --> Controller Class Initialized
INFO - 2018-04-11 03:22:27 --> Config Class Initialized
INFO - 2018-04-11 03:22:27 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:22:27 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:22:27 --> Utf8 Class Initialized
INFO - 2018-04-11 03:22:27 --> URI Class Initialized
INFO - 2018-04-11 03:22:27 --> Router Class Initialized
INFO - 2018-04-11 03:22:27 --> Output Class Initialized
INFO - 2018-04-11 03:22:27 --> Security Class Initialized
DEBUG - 2018-04-11 03:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:22:27 --> Input Class Initialized
INFO - 2018-04-11 03:22:27 --> Language Class Initialized
INFO - 2018-04-11 03:22:27 --> Loader Class Initialized
INFO - 2018-04-11 03:22:27 --> Helper loaded: url_helper
INFO - 2018-04-11 03:22:27 --> Helper loaded: file_helper
INFO - 2018-04-11 03:22:27 --> Helper loaded: date_helper
INFO - 2018-04-11 03:22:27 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:22:27 --> Controller Class Initialized
INFO - 2018-04-11 03:22:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-11 03:22:27 --> Final output sent to browser
DEBUG - 2018-04-11 03:22:27 --> Total execution time: 0.3428
INFO - 2018-04-11 03:22:32 --> Config Class Initialized
INFO - 2018-04-11 03:22:32 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:22:32 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:22:32 --> Utf8 Class Initialized
INFO - 2018-04-11 03:22:32 --> URI Class Initialized
INFO - 2018-04-11 03:22:32 --> Router Class Initialized
INFO - 2018-04-11 03:22:32 --> Output Class Initialized
INFO - 2018-04-11 03:22:32 --> Security Class Initialized
DEBUG - 2018-04-11 03:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:22:32 --> Input Class Initialized
INFO - 2018-04-11 03:22:32 --> Language Class Initialized
INFO - 2018-04-11 03:22:32 --> Loader Class Initialized
INFO - 2018-04-11 03:22:32 --> Helper loaded: url_helper
INFO - 2018-04-11 03:22:32 --> Helper loaded: file_helper
INFO - 2018-04-11 03:22:32 --> Helper loaded: date_helper
INFO - 2018-04-11 03:22:32 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:22:32 --> Controller Class Initialized
INFO - 2018-04-11 03:22:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-11 03:22:32 --> Final output sent to browser
DEBUG - 2018-04-11 03:22:32 --> Total execution time: 0.2767
INFO - 2018-04-11 03:26:31 --> Config Class Initialized
INFO - 2018-04-11 03:26:31 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:26:31 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:26:31 --> Utf8 Class Initialized
INFO - 2018-04-11 03:26:31 --> URI Class Initialized
INFO - 2018-04-11 03:26:31 --> Router Class Initialized
INFO - 2018-04-11 03:26:31 --> Output Class Initialized
INFO - 2018-04-11 03:26:31 --> Security Class Initialized
DEBUG - 2018-04-11 03:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:26:32 --> Input Class Initialized
INFO - 2018-04-11 03:26:32 --> Language Class Initialized
INFO - 2018-04-11 03:26:32 --> Loader Class Initialized
INFO - 2018-04-11 03:26:32 --> Helper loaded: url_helper
INFO - 2018-04-11 03:26:32 --> Helper loaded: file_helper
INFO - 2018-04-11 03:26:32 --> Helper loaded: date_helper
INFO - 2018-04-11 03:26:32 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:26:32 --> Controller Class Initialized
INFO - 2018-04-11 03:26:32 --> Model Class Initialized
INFO - 2018-04-11 03:26:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-11 03:26:32 --> Final output sent to browser
DEBUG - 2018-04-11 03:26:32 --> Total execution time: 0.3732
INFO - 2018-04-11 03:27:03 --> Config Class Initialized
INFO - 2018-04-11 03:27:03 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:27:03 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:27:03 --> Utf8 Class Initialized
INFO - 2018-04-11 03:27:03 --> URI Class Initialized
INFO - 2018-04-11 03:27:03 --> Router Class Initialized
INFO - 2018-04-11 03:27:03 --> Output Class Initialized
INFO - 2018-04-11 03:27:03 --> Security Class Initialized
DEBUG - 2018-04-11 03:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:27:03 --> Input Class Initialized
INFO - 2018-04-11 03:27:03 --> Language Class Initialized
INFO - 2018-04-11 03:27:03 --> Loader Class Initialized
INFO - 2018-04-11 03:27:03 --> Helper loaded: url_helper
INFO - 2018-04-11 03:27:03 --> Helper loaded: file_helper
INFO - 2018-04-11 03:27:04 --> Helper loaded: date_helper
INFO - 2018-04-11 03:27:04 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:27:04 --> Controller Class Initialized
INFO - 2018-04-11 03:27:04 --> Model Class Initialized
INFO - 2018-04-11 03:27:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-11 03:27:04 --> Final output sent to browser
DEBUG - 2018-04-11 03:27:04 --> Total execution time: 0.3162
INFO - 2018-04-11 03:27:17 --> Config Class Initialized
INFO - 2018-04-11 03:27:17 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:27:17 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:27:17 --> Utf8 Class Initialized
INFO - 2018-04-11 03:27:17 --> URI Class Initialized
INFO - 2018-04-11 03:27:17 --> Router Class Initialized
INFO - 2018-04-11 03:27:17 --> Output Class Initialized
INFO - 2018-04-11 03:27:17 --> Security Class Initialized
DEBUG - 2018-04-11 03:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:27:18 --> Input Class Initialized
INFO - 2018-04-11 03:27:18 --> Language Class Initialized
INFO - 2018-04-11 03:27:18 --> Loader Class Initialized
INFO - 2018-04-11 03:27:18 --> Helper loaded: url_helper
INFO - 2018-04-11 03:27:18 --> Helper loaded: file_helper
INFO - 2018-04-11 03:27:18 --> Helper loaded: date_helper
INFO - 2018-04-11 03:27:18 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:27:18 --> Controller Class Initialized
INFO - 2018-04-11 03:27:18 --> Model Class Initialized
INFO - 2018-04-11 03:27:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-11 03:27:18 --> Final output sent to browser
DEBUG - 2018-04-11 03:27:18 --> Total execution time: 0.2713
INFO - 2018-04-11 03:27:36 --> Config Class Initialized
INFO - 2018-04-11 03:27:36 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:27:36 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:27:36 --> Utf8 Class Initialized
INFO - 2018-04-11 03:27:36 --> URI Class Initialized
INFO - 2018-04-11 03:27:36 --> Router Class Initialized
INFO - 2018-04-11 03:27:36 --> Output Class Initialized
INFO - 2018-04-11 03:27:36 --> Security Class Initialized
DEBUG - 2018-04-11 03:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:27:36 --> Input Class Initialized
INFO - 2018-04-11 03:27:36 --> Language Class Initialized
INFO - 2018-04-11 03:27:36 --> Loader Class Initialized
INFO - 2018-04-11 03:27:36 --> Helper loaded: url_helper
INFO - 2018-04-11 03:27:36 --> Helper loaded: file_helper
INFO - 2018-04-11 03:27:36 --> Helper loaded: date_helper
INFO - 2018-04-11 03:27:36 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:27:36 --> Controller Class Initialized
INFO - 2018-04-11 03:27:36 --> Model Class Initialized
INFO - 2018-04-11 03:27:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-11 03:27:36 --> Final output sent to browser
DEBUG - 2018-04-11 03:27:36 --> Total execution time: 0.2604
INFO - 2018-04-11 03:27:50 --> Config Class Initialized
INFO - 2018-04-11 03:27:50 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:27:50 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:27:50 --> Utf8 Class Initialized
INFO - 2018-04-11 03:27:50 --> URI Class Initialized
INFO - 2018-04-11 03:27:50 --> Router Class Initialized
INFO - 2018-04-11 03:27:50 --> Output Class Initialized
INFO - 2018-04-11 03:27:50 --> Security Class Initialized
DEBUG - 2018-04-11 03:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:27:50 --> Input Class Initialized
INFO - 2018-04-11 03:27:50 --> Language Class Initialized
INFO - 2018-04-11 03:27:50 --> Loader Class Initialized
INFO - 2018-04-11 03:27:50 --> Helper loaded: url_helper
INFO - 2018-04-11 03:27:50 --> Helper loaded: file_helper
INFO - 2018-04-11 03:27:50 --> Helper loaded: date_helper
INFO - 2018-04-11 03:27:50 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:27:50 --> Controller Class Initialized
INFO - 2018-04-11 03:27:50 --> Model Class Initialized
INFO - 2018-04-11 03:27:50 --> Final output sent to browser
DEBUG - 2018-04-11 03:27:50 --> Total execution time: 0.4841
INFO - 2018-04-11 03:27:50 --> Config Class Initialized
INFO - 2018-04-11 03:27:50 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:27:50 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:27:50 --> Utf8 Class Initialized
INFO - 2018-04-11 03:27:50 --> URI Class Initialized
INFO - 2018-04-11 03:27:50 --> Router Class Initialized
INFO - 2018-04-11 03:27:50 --> Output Class Initialized
INFO - 2018-04-11 03:27:50 --> Security Class Initialized
DEBUG - 2018-04-11 03:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:27:50 --> Input Class Initialized
INFO - 2018-04-11 03:27:50 --> Language Class Initialized
INFO - 2018-04-11 03:27:50 --> Loader Class Initialized
INFO - 2018-04-11 03:27:50 --> Helper loaded: url_helper
INFO - 2018-04-11 03:27:50 --> Helper loaded: file_helper
INFO - 2018-04-11 03:27:50 --> Helper loaded: date_helper
INFO - 2018-04-11 03:27:50 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:27:50 --> Controller Class Initialized
INFO - 2018-04-11 03:27:50 --> Model Class Initialized
INFO - 2018-04-11 03:27:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-11 03:27:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-11 03:27:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-11 03:27:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-11 03:27:51 --> Final output sent to browser
DEBUG - 2018-04-11 03:27:51 --> Total execution time: 0.4156
INFO - 2018-04-11 03:27:51 --> Config Class Initialized
INFO - 2018-04-11 03:27:51 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:27:51 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:27:51 --> Utf8 Class Initialized
INFO - 2018-04-11 03:27:51 --> URI Class Initialized
INFO - 2018-04-11 03:27:51 --> Router Class Initialized
INFO - 2018-04-11 03:27:51 --> Output Class Initialized
INFO - 2018-04-11 03:27:51 --> Security Class Initialized
DEBUG - 2018-04-11 03:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:27:51 --> Input Class Initialized
INFO - 2018-04-11 03:27:51 --> Language Class Initialized
ERROR - 2018-04-11 03:27:51 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-11 03:27:52 --> Config Class Initialized
INFO - 2018-04-11 03:27:52 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:27:52 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:27:52 --> Utf8 Class Initialized
INFO - 2018-04-11 03:27:52 --> URI Class Initialized
INFO - 2018-04-11 03:27:52 --> Router Class Initialized
INFO - 2018-04-11 03:27:52 --> Output Class Initialized
INFO - 2018-04-11 03:27:52 --> Security Class Initialized
DEBUG - 2018-04-11 03:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:27:52 --> Input Class Initialized
INFO - 2018-04-11 03:27:52 --> Language Class Initialized
ERROR - 2018-04-11 03:27:52 --> 404 Page Not Found: Assets/img
INFO - 2018-04-11 03:27:57 --> Config Class Initialized
INFO - 2018-04-11 03:27:57 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:27:57 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:27:57 --> Utf8 Class Initialized
INFO - 2018-04-11 03:27:57 --> URI Class Initialized
INFO - 2018-04-11 03:27:57 --> Router Class Initialized
INFO - 2018-04-11 03:27:57 --> Output Class Initialized
INFO - 2018-04-11 03:27:57 --> Security Class Initialized
DEBUG - 2018-04-11 03:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:27:57 --> Input Class Initialized
INFO - 2018-04-11 03:27:57 --> Language Class Initialized
INFO - 2018-04-11 03:27:57 --> Loader Class Initialized
INFO - 2018-04-11 03:27:57 --> Helper loaded: url_helper
INFO - 2018-04-11 03:27:57 --> Helper loaded: file_helper
INFO - 2018-04-11 03:27:57 --> Helper loaded: date_helper
INFO - 2018-04-11 03:27:57 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:27:57 --> Controller Class Initialized
INFO - 2018-04-11 03:27:57 --> Model Class Initialized
INFO - 2018-04-11 03:27:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-11 03:27:57 --> Final output sent to browser
DEBUG - 2018-04-11 03:27:57 --> Total execution time: 0.4626
INFO - 2018-04-11 03:28:08 --> Config Class Initialized
INFO - 2018-04-11 03:28:08 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:28:08 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:28:08 --> Utf8 Class Initialized
INFO - 2018-04-11 03:28:08 --> URI Class Initialized
INFO - 2018-04-11 03:28:08 --> Router Class Initialized
INFO - 2018-04-11 03:28:08 --> Output Class Initialized
INFO - 2018-04-11 03:28:08 --> Security Class Initialized
DEBUG - 2018-04-11 03:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:28:08 --> Input Class Initialized
INFO - 2018-04-11 03:28:08 --> Language Class Initialized
INFO - 2018-04-11 03:28:08 --> Loader Class Initialized
INFO - 2018-04-11 03:28:08 --> Helper loaded: url_helper
INFO - 2018-04-11 03:28:08 --> Helper loaded: file_helper
INFO - 2018-04-11 03:28:08 --> Helper loaded: date_helper
INFO - 2018-04-11 03:28:08 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:28:08 --> Controller Class Initialized
INFO - 2018-04-11 03:28:08 --> Model Class Initialized
INFO - 2018-04-11 03:28:09 --> Final output sent to browser
DEBUG - 2018-04-11 03:28:09 --> Total execution time: 0.2543
INFO - 2018-04-11 03:28:09 --> Config Class Initialized
INFO - 2018-04-11 03:28:09 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:28:09 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:28:09 --> Utf8 Class Initialized
INFO - 2018-04-11 03:28:09 --> URI Class Initialized
INFO - 2018-04-11 03:28:09 --> Router Class Initialized
INFO - 2018-04-11 03:28:09 --> Output Class Initialized
INFO - 2018-04-11 03:28:09 --> Security Class Initialized
DEBUG - 2018-04-11 03:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:28:09 --> Input Class Initialized
INFO - 2018-04-11 03:28:09 --> Language Class Initialized
INFO - 2018-04-11 03:28:09 --> Loader Class Initialized
INFO - 2018-04-11 03:28:09 --> Helper loaded: url_helper
INFO - 2018-04-11 03:28:09 --> Helper loaded: file_helper
INFO - 2018-04-11 03:28:09 --> Helper loaded: date_helper
INFO - 2018-04-11 03:28:09 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:28:09 --> Controller Class Initialized
INFO - 2018-04-11 03:28:09 --> Model Class Initialized
INFO - 2018-04-11 03:28:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-11 03:28:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-11 03:28:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-11 03:28:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-11 03:28:09 --> Final output sent to browser
DEBUG - 2018-04-11 03:28:09 --> Total execution time: 0.6480
INFO - 2018-04-11 03:28:12 --> Config Class Initialized
INFO - 2018-04-11 03:28:12 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:28:12 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:28:12 --> Utf8 Class Initialized
INFO - 2018-04-11 03:28:12 --> URI Class Initialized
INFO - 2018-04-11 03:28:12 --> Router Class Initialized
INFO - 2018-04-11 03:28:12 --> Output Class Initialized
INFO - 2018-04-11 03:28:12 --> Security Class Initialized
DEBUG - 2018-04-11 03:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:28:12 --> Input Class Initialized
INFO - 2018-04-11 03:28:12 --> Language Class Initialized
INFO - 2018-04-11 03:28:12 --> Loader Class Initialized
INFO - 2018-04-11 03:28:12 --> Helper loaded: url_helper
INFO - 2018-04-11 03:28:12 --> Helper loaded: file_helper
INFO - 2018-04-11 03:28:12 --> Helper loaded: date_helper
INFO - 2018-04-11 03:28:12 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:28:12 --> Controller Class Initialized
INFO - 2018-04-11 03:28:12 --> Model Class Initialized
INFO - 2018-04-11 03:28:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-11 03:28:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-11 03:28:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-11 03:28:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-11 03:28:12 --> Final output sent to browser
DEBUG - 2018-04-11 03:28:12 --> Total execution time: 0.2996
INFO - 2018-04-11 03:28:19 --> Config Class Initialized
INFO - 2018-04-11 03:28:19 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:28:19 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:28:19 --> Utf8 Class Initialized
INFO - 2018-04-11 03:28:20 --> URI Class Initialized
INFO - 2018-04-11 03:28:20 --> Router Class Initialized
INFO - 2018-04-11 03:28:20 --> Output Class Initialized
INFO - 2018-04-11 03:28:20 --> Security Class Initialized
DEBUG - 2018-04-11 03:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:28:20 --> Input Class Initialized
INFO - 2018-04-11 03:28:20 --> Language Class Initialized
INFO - 2018-04-11 03:28:20 --> Loader Class Initialized
INFO - 2018-04-11 03:28:20 --> Helper loaded: url_helper
INFO - 2018-04-11 03:28:20 --> Helper loaded: file_helper
INFO - 2018-04-11 03:28:20 --> Helper loaded: date_helper
INFO - 2018-04-11 03:28:20 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:28:20 --> Controller Class Initialized
INFO - 2018-04-11 03:28:20 --> Model Class Initialized
INFO - 2018-04-11 03:28:20 --> Config Class Initialized
INFO - 2018-04-11 03:28:20 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:28:20 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:28:20 --> Utf8 Class Initialized
INFO - 2018-04-11 03:28:20 --> URI Class Initialized
INFO - 2018-04-11 03:28:20 --> Router Class Initialized
INFO - 2018-04-11 03:28:20 --> Output Class Initialized
INFO - 2018-04-11 03:28:20 --> Security Class Initialized
DEBUG - 2018-04-11 03:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:28:20 --> Input Class Initialized
INFO - 2018-04-11 03:28:20 --> Language Class Initialized
INFO - 2018-04-11 03:28:20 --> Loader Class Initialized
INFO - 2018-04-11 03:28:20 --> Helper loaded: url_helper
INFO - 2018-04-11 03:28:20 --> Helper loaded: file_helper
INFO - 2018-04-11 03:28:20 --> Helper loaded: date_helper
INFO - 2018-04-11 03:28:20 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:28:20 --> Controller Class Initialized
INFO - 2018-04-11 03:28:20 --> Model Class Initialized
INFO - 2018-04-11 03:28:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-11 03:28:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-11 03:28:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-11 03:28:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-11 03:28:20 --> Final output sent to browser
DEBUG - 2018-04-11 03:28:20 --> Total execution time: 0.3177
INFO - 2018-04-11 03:28:26 --> Config Class Initialized
INFO - 2018-04-11 03:28:26 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:28:26 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:28:26 --> Utf8 Class Initialized
INFO - 2018-04-11 03:28:26 --> URI Class Initialized
INFO - 2018-04-11 03:28:26 --> Router Class Initialized
INFO - 2018-04-11 03:28:26 --> Output Class Initialized
INFO - 2018-04-11 03:28:26 --> Security Class Initialized
DEBUG - 2018-04-11 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:28:26 --> Input Class Initialized
INFO - 2018-04-11 03:28:26 --> Language Class Initialized
INFO - 2018-04-11 03:28:26 --> Loader Class Initialized
INFO - 2018-04-11 03:28:26 --> Helper loaded: url_helper
INFO - 2018-04-11 03:28:26 --> Helper loaded: file_helper
INFO - 2018-04-11 03:28:26 --> Helper loaded: date_helper
INFO - 2018-04-11 03:28:26 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:28:26 --> Controller Class Initialized
INFO - 2018-04-11 03:28:26 --> Model Class Initialized
INFO - 2018-04-11 03:28:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-11 03:28:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-11 03:28:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-11 03:28:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-11 03:28:26 --> Final output sent to browser
DEBUG - 2018-04-11 03:28:26 --> Total execution time: 0.2981
INFO - 2018-04-11 03:28:56 --> Config Class Initialized
INFO - 2018-04-11 03:28:56 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:28:56 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:28:56 --> Utf8 Class Initialized
INFO - 2018-04-11 03:28:56 --> URI Class Initialized
INFO - 2018-04-11 03:28:56 --> Router Class Initialized
INFO - 2018-04-11 03:28:56 --> Output Class Initialized
INFO - 2018-04-11 03:28:57 --> Security Class Initialized
DEBUG - 2018-04-11 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:28:57 --> Input Class Initialized
INFO - 2018-04-11 03:28:57 --> Language Class Initialized
INFO - 2018-04-11 03:28:57 --> Loader Class Initialized
INFO - 2018-04-11 03:28:57 --> Helper loaded: url_helper
INFO - 2018-04-11 03:28:57 --> Helper loaded: file_helper
INFO - 2018-04-11 03:28:57 --> Helper loaded: date_helper
INFO - 2018-04-11 03:28:57 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:28:57 --> Controller Class Initialized
INFO - 2018-04-11 03:28:57 --> Model Class Initialized
INFO - 2018-04-11 03:28:57 --> Config Class Initialized
INFO - 2018-04-11 03:28:57 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:28:57 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:28:57 --> Utf8 Class Initialized
INFO - 2018-04-11 03:28:57 --> URI Class Initialized
INFO - 2018-04-11 03:28:57 --> Router Class Initialized
INFO - 2018-04-11 03:28:57 --> Output Class Initialized
INFO - 2018-04-11 03:28:57 --> Security Class Initialized
DEBUG - 2018-04-11 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:28:57 --> Input Class Initialized
INFO - 2018-04-11 03:28:57 --> Language Class Initialized
INFO - 2018-04-11 03:28:57 --> Loader Class Initialized
INFO - 2018-04-11 03:28:57 --> Helper loaded: url_helper
INFO - 2018-04-11 03:28:57 --> Helper loaded: file_helper
INFO - 2018-04-11 03:28:57 --> Helper loaded: date_helper
INFO - 2018-04-11 03:28:57 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:28:57 --> Controller Class Initialized
INFO - 2018-04-11 03:28:57 --> Model Class Initialized
INFO - 2018-04-11 03:28:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-11 03:28:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-11 03:28:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-11 03:28:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-11 03:28:57 --> Final output sent to browser
DEBUG - 2018-04-11 03:28:57 --> Total execution time: 0.6151
INFO - 2018-04-11 03:29:06 --> Config Class Initialized
INFO - 2018-04-11 03:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:29:06 --> Utf8 Class Initialized
INFO - 2018-04-11 03:29:06 --> URI Class Initialized
INFO - 2018-04-11 03:29:06 --> Router Class Initialized
INFO - 2018-04-11 03:29:06 --> Output Class Initialized
INFO - 2018-04-11 03:29:06 --> Security Class Initialized
DEBUG - 2018-04-11 03:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:29:06 --> Input Class Initialized
INFO - 2018-04-11 03:29:06 --> Language Class Initialized
INFO - 2018-04-11 03:29:06 --> Loader Class Initialized
INFO - 2018-04-11 03:29:06 --> Helper loaded: url_helper
INFO - 2018-04-11 03:29:06 --> Helper loaded: file_helper
INFO - 2018-04-11 03:29:06 --> Helper loaded: date_helper
INFO - 2018-04-11 03:29:06 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:29:06 --> Controller Class Initialized
INFO - 2018-04-11 03:29:06 --> Model Class Initialized
INFO - 2018-04-11 03:29:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-11 03:29:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-11 03:29:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-11 03:29:06 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-11 03:29:06 --> Final output sent to browser
DEBUG - 2018-04-11 03:29:06 --> Total execution time: 0.3090
INFO - 2018-04-11 03:29:10 --> Config Class Initialized
INFO - 2018-04-11 03:29:10 --> Hooks Class Initialized
DEBUG - 2018-04-11 03:29:10 --> UTF-8 Support Enabled
INFO - 2018-04-11 03:29:10 --> Utf8 Class Initialized
INFO - 2018-04-11 03:29:10 --> URI Class Initialized
INFO - 2018-04-11 03:29:10 --> Router Class Initialized
INFO - 2018-04-11 03:29:10 --> Output Class Initialized
INFO - 2018-04-11 03:29:10 --> Security Class Initialized
DEBUG - 2018-04-11 03:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-11 03:29:10 --> Input Class Initialized
INFO - 2018-04-11 03:29:10 --> Language Class Initialized
INFO - 2018-04-11 03:29:10 --> Loader Class Initialized
INFO - 2018-04-11 03:29:10 --> Helper loaded: url_helper
INFO - 2018-04-11 03:29:10 --> Helper loaded: file_helper
INFO - 2018-04-11 03:29:10 --> Helper loaded: date_helper
INFO - 2018-04-11 03:29:10 --> Database Driver Class Initialized
DEBUG - 2018-04-11 03:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-11 03:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-11 03:29:10 --> Controller Class Initialized
INFO - 2018-04-11 03:29:11 --> Model Class Initialized
INFO - 2018-04-11 03:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-11 03:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-11 03:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-11 03:29:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-11 03:29:11 --> Final output sent to browser
DEBUG - 2018-04-11 03:29:11 --> Total execution time: 0.3121
