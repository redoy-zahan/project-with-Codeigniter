<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-10 19:15:34 --> Config Class Initialized
INFO - 2018-04-10 19:15:34 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:15:34 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:15:34 --> Utf8 Class Initialized
INFO - 2018-04-10 19:15:34 --> URI Class Initialized
DEBUG - 2018-04-10 19:15:34 --> No URI present. Default controller set.
INFO - 2018-04-10 19:15:34 --> Router Class Initialized
INFO - 2018-04-10 19:15:35 --> Output Class Initialized
INFO - 2018-04-10 19:15:35 --> Security Class Initialized
DEBUG - 2018-04-10 19:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:15:35 --> Input Class Initialized
INFO - 2018-04-10 19:15:35 --> Language Class Initialized
INFO - 2018-04-10 19:15:35 --> Loader Class Initialized
INFO - 2018-04-10 19:15:35 --> Helper loaded: url_helper
INFO - 2018-04-10 19:15:35 --> Helper loaded: file_helper
INFO - 2018-04-10 19:15:35 --> Helper loaded: date_helper
INFO - 2018-04-10 19:15:36 --> Database Driver Class Initialized
DEBUG - 2018-04-10 19:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:15:36 --> Controller Class Initialized
INFO - 2018-04-10 19:15:36 --> Config Class Initialized
INFO - 2018-04-10 19:15:36 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:15:36 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:15:36 --> Utf8 Class Initialized
INFO - 2018-04-10 19:15:36 --> URI Class Initialized
INFO - 2018-04-10 19:15:36 --> Router Class Initialized
INFO - 2018-04-10 19:15:36 --> Output Class Initialized
INFO - 2018-04-10 19:15:36 --> Security Class Initialized
DEBUG - 2018-04-10 19:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:15:36 --> Input Class Initialized
INFO - 2018-04-10 19:15:36 --> Language Class Initialized
INFO - 2018-04-10 19:15:37 --> Loader Class Initialized
INFO - 2018-04-10 19:15:37 --> Helper loaded: url_helper
INFO - 2018-04-10 19:15:37 --> Helper loaded: file_helper
INFO - 2018-04-10 19:15:37 --> Helper loaded: date_helper
INFO - 2018-04-10 19:15:37 --> Database Driver Class Initialized
DEBUG - 2018-04-10 19:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:15:37 --> Controller Class Initialized
INFO - 2018-04-10 19:15:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-10 19:15:37 --> Final output sent to browser
DEBUG - 2018-04-10 19:15:37 --> Total execution time: 0.9113
INFO - 2018-04-10 19:15:46 --> Config Class Initialized
INFO - 2018-04-10 19:15:46 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:15:46 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:15:46 --> Utf8 Class Initialized
INFO - 2018-04-10 19:15:46 --> URI Class Initialized
INFO - 2018-04-10 19:15:46 --> Router Class Initialized
INFO - 2018-04-10 19:15:46 --> Output Class Initialized
INFO - 2018-04-10 19:15:46 --> Security Class Initialized
DEBUG - 2018-04-10 19:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:15:46 --> Input Class Initialized
INFO - 2018-04-10 19:15:46 --> Language Class Initialized
INFO - 2018-04-10 19:15:46 --> Loader Class Initialized
INFO - 2018-04-10 19:15:46 --> Helper loaded: url_helper
INFO - 2018-04-10 19:15:46 --> Helper loaded: file_helper
INFO - 2018-04-10 19:15:46 --> Helper loaded: date_helper
INFO - 2018-04-10 19:15:46 --> Database Driver Class Initialized
DEBUG - 2018-04-10 19:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:15:46 --> Controller Class Initialized
INFO - 2018-04-10 19:15:46 --> Model Class Initialized
INFO - 2018-04-10 19:15:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-10 19:15:46 --> Final output sent to browser
DEBUG - 2018-04-10 19:15:46 --> Total execution time: 0.5012
INFO - 2018-04-10 19:16:38 --> Config Class Initialized
INFO - 2018-04-10 19:16:38 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:16:38 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:16:38 --> Utf8 Class Initialized
INFO - 2018-04-10 19:16:38 --> URI Class Initialized
INFO - 2018-04-10 19:16:39 --> Router Class Initialized
INFO - 2018-04-10 19:16:39 --> Output Class Initialized
INFO - 2018-04-10 19:16:39 --> Security Class Initialized
DEBUG - 2018-04-10 19:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:16:39 --> Input Class Initialized
INFO - 2018-04-10 19:16:39 --> Language Class Initialized
INFO - 2018-04-10 19:16:39 --> Loader Class Initialized
INFO - 2018-04-10 19:16:39 --> Helper loaded: url_helper
INFO - 2018-04-10 19:16:39 --> Helper loaded: file_helper
INFO - 2018-04-10 19:16:39 --> Helper loaded: date_helper
INFO - 2018-04-10 19:16:39 --> Database Driver Class Initialized
DEBUG - 2018-04-10 19:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:16:39 --> Controller Class Initialized
INFO - 2018-04-10 19:16:39 --> Model Class Initialized
INFO - 2018-04-10 19:16:39 --> Final output sent to browser
DEBUG - 2018-04-10 19:16:39 --> Total execution time: 0.2342
INFO - 2018-04-10 19:16:39 --> Config Class Initialized
INFO - 2018-04-10 19:16:39 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:16:39 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:16:39 --> Utf8 Class Initialized
INFO - 2018-04-10 19:16:39 --> URI Class Initialized
INFO - 2018-04-10 19:16:39 --> Router Class Initialized
INFO - 2018-04-10 19:16:39 --> Output Class Initialized
INFO - 2018-04-10 19:16:39 --> Security Class Initialized
DEBUG - 2018-04-10 19:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:16:39 --> Input Class Initialized
INFO - 2018-04-10 19:16:39 --> Language Class Initialized
INFO - 2018-04-10 19:16:39 --> Loader Class Initialized
INFO - 2018-04-10 19:16:39 --> Helper loaded: url_helper
INFO - 2018-04-10 19:16:39 --> Helper loaded: file_helper
INFO - 2018-04-10 19:16:39 --> Helper loaded: date_helper
INFO - 2018-04-10 19:16:39 --> Database Driver Class Initialized
DEBUG - 2018-04-10 19:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:16:39 --> Controller Class Initialized
INFO - 2018-04-10 19:16:39 --> Model Class Initialized
INFO - 2018-04-10 19:16:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-10 19:16:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-10 19:16:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-10 19:16:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-10 19:16:39 --> Final output sent to browser
DEBUG - 2018-04-10 19:16:39 --> Total execution time: 0.4254
INFO - 2018-04-10 19:16:39 --> Config Class Initialized
INFO - 2018-04-10 19:16:39 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:16:39 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:16:39 --> Utf8 Class Initialized
INFO - 2018-04-10 19:16:39 --> URI Class Initialized
INFO - 2018-04-10 19:16:39 --> Router Class Initialized
INFO - 2018-04-10 19:16:39 --> Output Class Initialized
INFO - 2018-04-10 19:16:39 --> Security Class Initialized
DEBUG - 2018-04-10 19:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:16:39 --> Input Class Initialized
INFO - 2018-04-10 19:16:39 --> Language Class Initialized
ERROR - 2018-04-10 19:16:40 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 19:16:40 --> Config Class Initialized
INFO - 2018-04-10 19:16:40 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:16:40 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:16:40 --> Utf8 Class Initialized
INFO - 2018-04-10 19:16:40 --> URI Class Initialized
INFO - 2018-04-10 19:16:40 --> Router Class Initialized
INFO - 2018-04-10 19:16:40 --> Output Class Initialized
INFO - 2018-04-10 19:16:40 --> Security Class Initialized
DEBUG - 2018-04-10 19:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:16:40 --> Input Class Initialized
INFO - 2018-04-10 19:16:40 --> Language Class Initialized
ERROR - 2018-04-10 19:16:40 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 19:16:40 --> Config Class Initialized
INFO - 2018-04-10 19:16:40 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:16:40 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:16:40 --> Utf8 Class Initialized
INFO - 2018-04-10 19:16:40 --> URI Class Initialized
INFO - 2018-04-10 19:16:40 --> Router Class Initialized
INFO - 2018-04-10 19:16:40 --> Output Class Initialized
INFO - 2018-04-10 19:16:40 --> Security Class Initialized
DEBUG - 2018-04-10 19:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:16:40 --> Input Class Initialized
INFO - 2018-04-10 19:16:40 --> Language Class Initialized
ERROR - 2018-04-10 19:16:40 --> 404 Page Not Found: Assets/img
INFO - 2018-04-10 19:17:40 --> Config Class Initialized
INFO - 2018-04-10 19:17:40 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:17:40 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:17:40 --> Utf8 Class Initialized
INFO - 2018-04-10 19:17:40 --> URI Class Initialized
INFO - 2018-04-10 19:17:40 --> Router Class Initialized
INFO - 2018-04-10 19:17:40 --> Output Class Initialized
INFO - 2018-04-10 19:17:40 --> Security Class Initialized
DEBUG - 2018-04-10 19:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:17:40 --> Input Class Initialized
INFO - 2018-04-10 19:17:40 --> Language Class Initialized
INFO - 2018-04-10 19:17:40 --> Loader Class Initialized
INFO - 2018-04-10 19:17:40 --> Helper loaded: url_helper
INFO - 2018-04-10 19:17:40 --> Helper loaded: file_helper
INFO - 2018-04-10 19:17:40 --> Helper loaded: date_helper
INFO - 2018-04-10 19:17:40 --> Database Driver Class Initialized
DEBUG - 2018-04-10 19:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:17:40 --> Controller Class Initialized
INFO - 2018-04-10 19:17:40 --> Model Class Initialized
INFO - 2018-04-10 19:17:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-10 19:17:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-10 19:17:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-10 19:17:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-10 19:17:40 --> Final output sent to browser
DEBUG - 2018-04-10 19:17:40 --> Total execution time: 0.2844
INFO - 2018-04-10 19:17:40 --> Config Class Initialized
INFO - 2018-04-10 19:17:40 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:17:40 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:17:40 --> Utf8 Class Initialized
INFO - 2018-04-10 19:17:40 --> URI Class Initialized
INFO - 2018-04-10 19:17:40 --> Router Class Initialized
INFO - 2018-04-10 19:17:40 --> Output Class Initialized
INFO - 2018-04-10 19:17:40 --> Security Class Initialized
DEBUG - 2018-04-10 19:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:17:40 --> Input Class Initialized
INFO - 2018-04-10 19:17:40 --> Language Class Initialized
ERROR - 2018-04-10 19:17:40 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 19:18:34 --> Config Class Initialized
INFO - 2018-04-10 19:18:34 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:18:34 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:18:34 --> Utf8 Class Initialized
INFO - 2018-04-10 19:18:34 --> URI Class Initialized
INFO - 2018-04-10 19:18:34 --> Router Class Initialized
INFO - 2018-04-10 19:18:34 --> Output Class Initialized
INFO - 2018-04-10 19:18:34 --> Security Class Initialized
DEBUG - 2018-04-10 19:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:18:34 --> Input Class Initialized
INFO - 2018-04-10 19:18:34 --> Language Class Initialized
INFO - 2018-04-10 19:18:34 --> Loader Class Initialized
INFO - 2018-04-10 19:18:34 --> Helper loaded: url_helper
INFO - 2018-04-10 19:18:34 --> Helper loaded: file_helper
INFO - 2018-04-10 19:18:34 --> Helper loaded: date_helper
INFO - 2018-04-10 19:18:34 --> Database Driver Class Initialized
DEBUG - 2018-04-10 19:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 19:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 19:18:35 --> Controller Class Initialized
INFO - 2018-04-10 19:18:35 --> Model Class Initialized
INFO - 2018-04-10 19:18:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-10 19:18:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-10 19:18:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-10 19:18:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-10 19:18:35 --> Final output sent to browser
DEBUG - 2018-04-10 19:18:35 --> Total execution time: 0.2880
INFO - 2018-04-10 19:18:35 --> Config Class Initialized
INFO - 2018-04-10 19:18:35 --> Hooks Class Initialized
DEBUG - 2018-04-10 19:18:35 --> UTF-8 Support Enabled
INFO - 2018-04-10 19:18:35 --> Utf8 Class Initialized
INFO - 2018-04-10 19:18:35 --> URI Class Initialized
INFO - 2018-04-10 19:18:35 --> Router Class Initialized
INFO - 2018-04-10 19:18:35 --> Output Class Initialized
INFO - 2018-04-10 19:18:35 --> Security Class Initialized
DEBUG - 2018-04-10 19:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 19:18:35 --> Input Class Initialized
INFO - 2018-04-10 19:18:35 --> Language Class Initialized
ERROR - 2018-04-10 19:18:35 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 22:25:25 --> Config Class Initialized
INFO - 2018-04-10 22:25:25 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:25:25 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:25:25 --> Utf8 Class Initialized
INFO - 2018-04-10 22:25:25 --> URI Class Initialized
INFO - 2018-04-10 22:25:25 --> Router Class Initialized
INFO - 2018-04-10 22:25:25 --> Output Class Initialized
INFO - 2018-04-10 22:25:25 --> Security Class Initialized
DEBUG - 2018-04-10 22:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:25:25 --> Input Class Initialized
INFO - 2018-04-10 22:25:25 --> Language Class Initialized
INFO - 2018-04-10 22:25:25 --> Loader Class Initialized
INFO - 2018-04-10 22:25:25 --> Helper loaded: url_helper
INFO - 2018-04-10 22:25:25 --> Helper loaded: file_helper
INFO - 2018-04-10 22:25:25 --> Helper loaded: date_helper
INFO - 2018-04-10 22:25:25 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:25:25 --> Controller Class Initialized
INFO - 2018-04-10 22:25:25 --> Config Class Initialized
INFO - 2018-04-10 22:25:25 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:25:25 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:25:25 --> Utf8 Class Initialized
INFO - 2018-04-10 22:25:25 --> URI Class Initialized
INFO - 2018-04-10 22:25:25 --> Router Class Initialized
INFO - 2018-04-10 22:25:25 --> Output Class Initialized
INFO - 2018-04-10 22:25:25 --> Security Class Initialized
DEBUG - 2018-04-10 22:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:25:25 --> Input Class Initialized
INFO - 2018-04-10 22:25:25 --> Language Class Initialized
INFO - 2018-04-10 22:25:25 --> Loader Class Initialized
INFO - 2018-04-10 22:25:25 --> Helper loaded: url_helper
INFO - 2018-04-10 22:25:25 --> Helper loaded: file_helper
INFO - 2018-04-10 22:25:25 --> Helper loaded: date_helper
INFO - 2018-04-10 22:25:25 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:25:25 --> Controller Class Initialized
INFO - 2018-04-10 22:25:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-10 22:25:25 --> Final output sent to browser
DEBUG - 2018-04-10 22:25:25 --> Total execution time: 0.2477
INFO - 2018-04-10 22:25:29 --> Config Class Initialized
INFO - 2018-04-10 22:25:29 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:25:29 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:25:29 --> Utf8 Class Initialized
INFO - 2018-04-10 22:25:29 --> URI Class Initialized
INFO - 2018-04-10 22:25:29 --> Router Class Initialized
INFO - 2018-04-10 22:25:29 --> Output Class Initialized
INFO - 2018-04-10 22:25:29 --> Security Class Initialized
DEBUG - 2018-04-10 22:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:25:29 --> Input Class Initialized
INFO - 2018-04-10 22:25:29 --> Language Class Initialized
INFO - 2018-04-10 22:25:29 --> Loader Class Initialized
INFO - 2018-04-10 22:25:29 --> Helper loaded: url_helper
INFO - 2018-04-10 22:25:29 --> Helper loaded: file_helper
INFO - 2018-04-10 22:25:29 --> Helper loaded: date_helper
INFO - 2018-04-10 22:25:29 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:25:29 --> Controller Class Initialized
INFO - 2018-04-10 22:25:29 --> Config Class Initialized
INFO - 2018-04-10 22:25:29 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:25:29 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:25:30 --> Utf8 Class Initialized
INFO - 2018-04-10 22:25:30 --> URI Class Initialized
INFO - 2018-04-10 22:25:30 --> Router Class Initialized
INFO - 2018-04-10 22:25:30 --> Output Class Initialized
INFO - 2018-04-10 22:25:30 --> Security Class Initialized
DEBUG - 2018-04-10 22:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:25:30 --> Input Class Initialized
INFO - 2018-04-10 22:25:30 --> Language Class Initialized
INFO - 2018-04-10 22:25:30 --> Loader Class Initialized
INFO - 2018-04-10 22:25:30 --> Helper loaded: url_helper
INFO - 2018-04-10 22:25:30 --> Helper loaded: file_helper
INFO - 2018-04-10 22:25:30 --> Helper loaded: date_helper
INFO - 2018-04-10 22:25:30 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:25:30 --> Controller Class Initialized
INFO - 2018-04-10 22:25:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-10 22:25:30 --> Final output sent to browser
DEBUG - 2018-04-10 22:25:30 --> Total execution time: 0.2506
INFO - 2018-04-10 22:25:33 --> Config Class Initialized
INFO - 2018-04-10 22:25:33 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:25:33 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:25:33 --> Utf8 Class Initialized
INFO - 2018-04-10 22:25:33 --> URI Class Initialized
INFO - 2018-04-10 22:25:33 --> Router Class Initialized
INFO - 2018-04-10 22:25:33 --> Output Class Initialized
INFO - 2018-04-10 22:25:33 --> Security Class Initialized
DEBUG - 2018-04-10 22:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:25:33 --> Input Class Initialized
INFO - 2018-04-10 22:25:33 --> Language Class Initialized
INFO - 2018-04-10 22:25:33 --> Loader Class Initialized
INFO - 2018-04-10 22:25:33 --> Helper loaded: url_helper
INFO - 2018-04-10 22:25:33 --> Helper loaded: file_helper
INFO - 2018-04-10 22:25:33 --> Helper loaded: date_helper
INFO - 2018-04-10 22:25:34 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:25:34 --> Controller Class Initialized
INFO - 2018-04-10 22:25:34 --> Model Class Initialized
INFO - 2018-04-10 22:25:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-10 22:25:34 --> Final output sent to browser
DEBUG - 2018-04-10 22:25:34 --> Total execution time: 0.3228
INFO - 2018-04-10 22:25:50 --> Config Class Initialized
INFO - 2018-04-10 22:25:50 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:25:50 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:25:50 --> Utf8 Class Initialized
INFO - 2018-04-10 22:25:50 --> URI Class Initialized
INFO - 2018-04-10 22:25:50 --> Router Class Initialized
INFO - 2018-04-10 22:25:50 --> Output Class Initialized
INFO - 2018-04-10 22:25:50 --> Security Class Initialized
DEBUG - 2018-04-10 22:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:25:50 --> Input Class Initialized
INFO - 2018-04-10 22:25:50 --> Language Class Initialized
INFO - 2018-04-10 22:25:50 --> Loader Class Initialized
INFO - 2018-04-10 22:25:50 --> Helper loaded: url_helper
INFO - 2018-04-10 22:25:50 --> Helper loaded: file_helper
INFO - 2018-04-10 22:25:50 --> Helper loaded: date_helper
INFO - 2018-04-10 22:25:50 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:25:50 --> Controller Class Initialized
INFO - 2018-04-10 22:25:50 --> Model Class Initialized
INFO - 2018-04-10 22:25:50 --> Final output sent to browser
DEBUG - 2018-04-10 22:25:50 --> Total execution time: 0.2629
INFO - 2018-04-10 22:25:50 --> Config Class Initialized
INFO - 2018-04-10 22:25:50 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:25:50 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:25:50 --> Utf8 Class Initialized
INFO - 2018-04-10 22:25:50 --> URI Class Initialized
INFO - 2018-04-10 22:25:50 --> Router Class Initialized
INFO - 2018-04-10 22:25:50 --> Output Class Initialized
INFO - 2018-04-10 22:25:50 --> Security Class Initialized
DEBUG - 2018-04-10 22:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:25:50 --> Input Class Initialized
INFO - 2018-04-10 22:25:50 --> Language Class Initialized
INFO - 2018-04-10 22:25:50 --> Loader Class Initialized
INFO - 2018-04-10 22:25:50 --> Helper loaded: url_helper
INFO - 2018-04-10 22:25:50 --> Helper loaded: file_helper
INFO - 2018-04-10 22:25:50 --> Helper loaded: date_helper
INFO - 2018-04-10 22:25:50 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:25:50 --> Controller Class Initialized
INFO - 2018-04-10 22:25:50 --> Model Class Initialized
INFO - 2018-04-10 22:25:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-10 22:25:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-10 22:25:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-10 22:25:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-10 22:25:51 --> Final output sent to browser
DEBUG - 2018-04-10 22:25:51 --> Total execution time: 0.3454
INFO - 2018-04-10 22:25:51 --> Config Class Initialized
INFO - 2018-04-10 22:25:51 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:25:51 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:25:51 --> Utf8 Class Initialized
INFO - 2018-04-10 22:25:51 --> URI Class Initialized
INFO - 2018-04-10 22:25:51 --> Router Class Initialized
INFO - 2018-04-10 22:25:51 --> Output Class Initialized
INFO - 2018-04-10 22:25:51 --> Security Class Initialized
DEBUG - 2018-04-10 22:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:25:51 --> Input Class Initialized
INFO - 2018-04-10 22:25:51 --> Language Class Initialized
ERROR - 2018-04-10 22:25:51 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 22:25:53 --> Config Class Initialized
INFO - 2018-04-10 22:25:53 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:25:53 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:25:53 --> Utf8 Class Initialized
INFO - 2018-04-10 22:25:53 --> URI Class Initialized
INFO - 2018-04-10 22:25:53 --> Router Class Initialized
INFO - 2018-04-10 22:25:53 --> Output Class Initialized
INFO - 2018-04-10 22:25:53 --> Security Class Initialized
DEBUG - 2018-04-10 22:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:25:53 --> Input Class Initialized
INFO - 2018-04-10 22:25:53 --> Language Class Initialized
INFO - 2018-04-10 22:25:53 --> Loader Class Initialized
INFO - 2018-04-10 22:25:53 --> Helper loaded: url_helper
INFO - 2018-04-10 22:25:53 --> Helper loaded: file_helper
INFO - 2018-04-10 22:25:53 --> Helper loaded: date_helper
INFO - 2018-04-10 22:25:53 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:25:53 --> Controller Class Initialized
INFO - 2018-04-10 22:25:57 --> Config Class Initialized
INFO - 2018-04-10 22:25:57 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:25:57 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:25:57 --> Utf8 Class Initialized
INFO - 2018-04-10 22:25:57 --> URI Class Initialized
INFO - 2018-04-10 22:25:57 --> Router Class Initialized
INFO - 2018-04-10 22:25:57 --> Output Class Initialized
INFO - 2018-04-10 22:25:57 --> Security Class Initialized
DEBUG - 2018-04-10 22:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:25:57 --> Input Class Initialized
INFO - 2018-04-10 22:25:57 --> Language Class Initialized
INFO - 2018-04-10 22:25:57 --> Loader Class Initialized
INFO - 2018-04-10 22:25:57 --> Helper loaded: url_helper
INFO - 2018-04-10 22:25:57 --> Helper loaded: file_helper
INFO - 2018-04-10 22:25:57 --> Helper loaded: date_helper
INFO - 2018-04-10 22:25:57 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:25:57 --> Controller Class Initialized
INFO - 2018-04-10 22:25:57 --> Model Class Initialized
INFO - 2018-04-10 22:25:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-10 22:25:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-10 22:25:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-10 22:25:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-10 22:25:57 --> Final output sent to browser
DEBUG - 2018-04-10 22:25:57 --> Total execution time: 0.3095
INFO - 2018-04-10 22:25:57 --> Config Class Initialized
INFO - 2018-04-10 22:25:57 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:25:57 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:25:57 --> Utf8 Class Initialized
INFO - 2018-04-10 22:25:57 --> URI Class Initialized
INFO - 2018-04-10 22:25:57 --> Router Class Initialized
INFO - 2018-04-10 22:25:57 --> Output Class Initialized
INFO - 2018-04-10 22:25:57 --> Security Class Initialized
DEBUG - 2018-04-10 22:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:25:57 --> Input Class Initialized
INFO - 2018-04-10 22:25:57 --> Language Class Initialized
ERROR - 2018-04-10 22:25:57 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 22:26:39 --> Config Class Initialized
INFO - 2018-04-10 22:26:39 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:26:39 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:26:39 --> Utf8 Class Initialized
INFO - 2018-04-10 22:26:39 --> URI Class Initialized
INFO - 2018-04-10 22:26:39 --> Router Class Initialized
INFO - 2018-04-10 22:26:39 --> Output Class Initialized
INFO - 2018-04-10 22:26:39 --> Security Class Initialized
DEBUG - 2018-04-10 22:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:26:39 --> Input Class Initialized
INFO - 2018-04-10 22:26:39 --> Language Class Initialized
INFO - 2018-04-10 22:26:39 --> Loader Class Initialized
INFO - 2018-04-10 22:26:39 --> Helper loaded: url_helper
INFO - 2018-04-10 22:26:39 --> Helper loaded: file_helper
INFO - 2018-04-10 22:26:39 --> Helper loaded: date_helper
INFO - 2018-04-10 22:26:39 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:26:39 --> Controller Class Initialized
INFO - 2018-04-10 22:26:39 --> Model Class Initialized
INFO - 2018-04-10 22:26:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-10 22:26:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-10 22:26:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-10 22:26:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-10 22:26:39 --> Final output sent to browser
DEBUG - 2018-04-10 22:26:39 --> Total execution time: 0.3099
INFO - 2018-04-10 22:26:39 --> Config Class Initialized
INFO - 2018-04-10 22:26:39 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:26:39 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:26:39 --> Utf8 Class Initialized
INFO - 2018-04-10 22:26:39 --> URI Class Initialized
INFO - 2018-04-10 22:26:39 --> Router Class Initialized
INFO - 2018-04-10 22:26:39 --> Output Class Initialized
INFO - 2018-04-10 22:26:39 --> Security Class Initialized
DEBUG - 2018-04-10 22:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:26:39 --> Input Class Initialized
INFO - 2018-04-10 22:26:39 --> Language Class Initialized
ERROR - 2018-04-10 22:26:39 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 22:27:19 --> Config Class Initialized
INFO - 2018-04-10 22:27:19 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:27:19 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:27:19 --> Utf8 Class Initialized
INFO - 2018-04-10 22:27:19 --> URI Class Initialized
INFO - 2018-04-10 22:27:19 --> Router Class Initialized
INFO - 2018-04-10 22:27:19 --> Output Class Initialized
INFO - 2018-04-10 22:27:19 --> Security Class Initialized
DEBUG - 2018-04-10 22:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:27:19 --> Input Class Initialized
INFO - 2018-04-10 22:27:19 --> Language Class Initialized
INFO - 2018-04-10 22:27:19 --> Loader Class Initialized
INFO - 2018-04-10 22:27:19 --> Helper loaded: url_helper
INFO - 2018-04-10 22:27:19 --> Helper loaded: file_helper
INFO - 2018-04-10 22:27:19 --> Helper loaded: date_helper
INFO - 2018-04-10 22:27:19 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:27:19 --> Controller Class Initialized
INFO - 2018-04-10 22:27:19 --> Model Class Initialized
INFO - 2018-04-10 22:27:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-10 22:27:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-10 22:27:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-10 22:27:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-10 22:27:19 --> Final output sent to browser
DEBUG - 2018-04-10 22:27:19 --> Total execution time: 0.3096
INFO - 2018-04-10 22:27:19 --> Config Class Initialized
INFO - 2018-04-10 22:27:19 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:27:19 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:27:19 --> Utf8 Class Initialized
INFO - 2018-04-10 22:27:19 --> URI Class Initialized
INFO - 2018-04-10 22:27:19 --> Router Class Initialized
INFO - 2018-04-10 22:27:19 --> Output Class Initialized
INFO - 2018-04-10 22:27:19 --> Security Class Initialized
DEBUG - 2018-04-10 22:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:27:19 --> Input Class Initialized
INFO - 2018-04-10 22:27:19 --> Language Class Initialized
ERROR - 2018-04-10 22:27:19 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 22:27:23 --> Config Class Initialized
INFO - 2018-04-10 22:27:23 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:27:23 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:27:23 --> Utf8 Class Initialized
INFO - 2018-04-10 22:27:23 --> URI Class Initialized
INFO - 2018-04-10 22:27:23 --> Router Class Initialized
INFO - 2018-04-10 22:27:23 --> Output Class Initialized
INFO - 2018-04-10 22:27:23 --> Security Class Initialized
DEBUG - 2018-04-10 22:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:27:23 --> Input Class Initialized
INFO - 2018-04-10 22:27:23 --> Language Class Initialized
INFO - 2018-04-10 22:27:23 --> Loader Class Initialized
INFO - 2018-04-10 22:27:23 --> Helper loaded: url_helper
INFO - 2018-04-10 22:27:23 --> Helper loaded: file_helper
INFO - 2018-04-10 22:27:23 --> Helper loaded: date_helper
INFO - 2018-04-10 22:27:23 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:27:23 --> Controller Class Initialized
INFO - 2018-04-10 22:27:23 --> Model Class Initialized
INFO - 2018-04-10 22:27:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-10 22:27:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-10 22:27:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-10 22:27:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-10 22:27:23 --> Final output sent to browser
DEBUG - 2018-04-10 22:27:23 --> Total execution time: 0.3042
INFO - 2018-04-10 22:27:23 --> Config Class Initialized
INFO - 2018-04-10 22:27:23 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:27:23 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:27:23 --> Utf8 Class Initialized
INFO - 2018-04-10 22:27:23 --> URI Class Initialized
INFO - 2018-04-10 22:27:23 --> Router Class Initialized
INFO - 2018-04-10 22:27:23 --> Output Class Initialized
INFO - 2018-04-10 22:27:23 --> Security Class Initialized
DEBUG - 2018-04-10 22:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:27:23 --> Input Class Initialized
INFO - 2018-04-10 22:27:23 --> Language Class Initialized
ERROR - 2018-04-10 22:27:23 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 22:27:59 --> Config Class Initialized
INFO - 2018-04-10 22:27:59 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:27:59 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:27:59 --> Utf8 Class Initialized
INFO - 2018-04-10 22:27:59 --> URI Class Initialized
INFO - 2018-04-10 22:27:59 --> Router Class Initialized
INFO - 2018-04-10 22:27:59 --> Output Class Initialized
INFO - 2018-04-10 22:27:59 --> Security Class Initialized
DEBUG - 2018-04-10 22:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:27:59 --> Input Class Initialized
INFO - 2018-04-10 22:27:59 --> Language Class Initialized
INFO - 2018-04-10 22:27:59 --> Loader Class Initialized
INFO - 2018-04-10 22:27:59 --> Helper loaded: url_helper
INFO - 2018-04-10 22:27:59 --> Helper loaded: file_helper
INFO - 2018-04-10 22:27:59 --> Helper loaded: date_helper
INFO - 2018-04-10 22:27:59 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:27:59 --> Controller Class Initialized
INFO - 2018-04-10 22:27:59 --> Model Class Initialized
INFO - 2018-04-10 22:27:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-10 22:27:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-10 22:27:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-10 22:27:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-10 22:27:59 --> Final output sent to browser
DEBUG - 2018-04-10 22:27:59 --> Total execution time: 0.3095
INFO - 2018-04-10 22:27:59 --> Config Class Initialized
INFO - 2018-04-10 22:27:59 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:28:00 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:28:00 --> Utf8 Class Initialized
INFO - 2018-04-10 22:28:00 --> URI Class Initialized
INFO - 2018-04-10 22:28:00 --> Router Class Initialized
INFO - 2018-04-10 22:28:00 --> Output Class Initialized
INFO - 2018-04-10 22:28:00 --> Security Class Initialized
DEBUG - 2018-04-10 22:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:28:00 --> Input Class Initialized
INFO - 2018-04-10 22:28:00 --> Language Class Initialized
ERROR - 2018-04-10 22:28:00 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 22:52:22 --> Config Class Initialized
INFO - 2018-04-10 22:52:22 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:52:22 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:52:22 --> Utf8 Class Initialized
INFO - 2018-04-10 22:52:22 --> URI Class Initialized
INFO - 2018-04-10 22:52:22 --> Router Class Initialized
INFO - 2018-04-10 22:52:22 --> Output Class Initialized
INFO - 2018-04-10 22:52:22 --> Security Class Initialized
DEBUG - 2018-04-10 22:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:52:22 --> Input Class Initialized
INFO - 2018-04-10 22:52:22 --> Language Class Initialized
INFO - 2018-04-10 22:52:22 --> Loader Class Initialized
INFO - 2018-04-10 22:52:22 --> Helper loaded: url_helper
INFO - 2018-04-10 22:52:22 --> Helper loaded: file_helper
INFO - 2018-04-10 22:52:22 --> Helper loaded: date_helper
INFO - 2018-04-10 22:52:22 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:52:22 --> Controller Class Initialized
INFO - 2018-04-10 22:52:22 --> Model Class Initialized
INFO - 2018-04-10 22:52:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-10 22:52:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-10 22:52:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-10 22:52:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-10 22:52:22 --> Final output sent to browser
DEBUG - 2018-04-10 22:52:22 --> Total execution time: 0.3648
INFO - 2018-04-10 22:52:22 --> Config Class Initialized
INFO - 2018-04-10 22:52:22 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:52:22 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:52:23 --> Utf8 Class Initialized
INFO - 2018-04-10 22:52:23 --> URI Class Initialized
INFO - 2018-04-10 22:52:23 --> Router Class Initialized
INFO - 2018-04-10 22:52:23 --> Output Class Initialized
INFO - 2018-04-10 22:52:23 --> Security Class Initialized
DEBUG - 2018-04-10 22:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:52:23 --> Input Class Initialized
INFO - 2018-04-10 22:52:23 --> Language Class Initialized
ERROR - 2018-04-10 22:52:23 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 22:52:26 --> Config Class Initialized
INFO - 2018-04-10 22:52:26 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:52:26 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:52:26 --> Utf8 Class Initialized
INFO - 2018-04-10 22:52:26 --> URI Class Initialized
INFO - 2018-04-10 22:52:26 --> Router Class Initialized
INFO - 2018-04-10 22:52:26 --> Output Class Initialized
INFO - 2018-04-10 22:52:26 --> Security Class Initialized
DEBUG - 2018-04-10 22:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:52:26 --> Input Class Initialized
INFO - 2018-04-10 22:52:26 --> Language Class Initialized
INFO - 2018-04-10 22:52:26 --> Loader Class Initialized
INFO - 2018-04-10 22:52:26 --> Helper loaded: url_helper
INFO - 2018-04-10 22:52:26 --> Helper loaded: file_helper
INFO - 2018-04-10 22:52:26 --> Helper loaded: date_helper
INFO - 2018-04-10 22:52:26 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:52:26 --> Controller Class Initialized
INFO - 2018-04-10 22:52:26 --> Final output sent to browser
DEBUG - 2018-04-10 22:52:26 --> Total execution time: 0.2937
INFO - 2018-04-10 22:52:32 --> Config Class Initialized
INFO - 2018-04-10 22:52:32 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:52:32 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:52:32 --> Utf8 Class Initialized
INFO - 2018-04-10 22:52:32 --> URI Class Initialized
INFO - 2018-04-10 22:52:32 --> Router Class Initialized
INFO - 2018-04-10 22:52:32 --> Output Class Initialized
INFO - 2018-04-10 22:52:32 --> Security Class Initialized
DEBUG - 2018-04-10 22:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:52:32 --> Input Class Initialized
INFO - 2018-04-10 22:52:32 --> Language Class Initialized
INFO - 2018-04-10 22:52:32 --> Loader Class Initialized
INFO - 2018-04-10 22:52:32 --> Helper loaded: url_helper
INFO - 2018-04-10 22:52:32 --> Helper loaded: file_helper
INFO - 2018-04-10 22:52:32 --> Helper loaded: date_helper
INFO - 2018-04-10 22:52:32 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:52:32 --> Controller Class Initialized
INFO - 2018-04-10 22:52:32 --> Model Class Initialized
INFO - 2018-04-10 22:52:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-04-10 22:52:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\admin/index.php
INFO - 2018-04-10 22:52:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-04-10 22:52:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-04-10 22:52:33 --> Final output sent to browser
DEBUG - 2018-04-10 22:52:33 --> Total execution time: 0.3144
INFO - 2018-04-10 22:52:33 --> Config Class Initialized
INFO - 2018-04-10 22:52:33 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:52:33 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:52:33 --> Utf8 Class Initialized
INFO - 2018-04-10 22:52:33 --> URI Class Initialized
INFO - 2018-04-10 22:52:33 --> Router Class Initialized
INFO - 2018-04-10 22:52:33 --> Output Class Initialized
INFO - 2018-04-10 22:52:33 --> Security Class Initialized
DEBUG - 2018-04-10 22:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:52:33 --> Input Class Initialized
INFO - 2018-04-10 22:52:33 --> Language Class Initialized
ERROR - 2018-04-10 22:52:33 --> 404 Page Not Found: Css/bootstrap.min.css
INFO - 2018-04-10 22:52:36 --> Config Class Initialized
INFO - 2018-04-10 22:52:36 --> Hooks Class Initialized
DEBUG - 2018-04-10 22:52:36 --> UTF-8 Support Enabled
INFO - 2018-04-10 22:52:36 --> Utf8 Class Initialized
INFO - 2018-04-10 22:52:36 --> URI Class Initialized
INFO - 2018-04-10 22:52:36 --> Router Class Initialized
INFO - 2018-04-10 22:52:36 --> Output Class Initialized
INFO - 2018-04-10 22:52:36 --> Security Class Initialized
DEBUG - 2018-04-10 22:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 22:52:36 --> Input Class Initialized
INFO - 2018-04-10 22:52:36 --> Language Class Initialized
INFO - 2018-04-10 22:52:36 --> Loader Class Initialized
INFO - 2018-04-10 22:52:36 --> Helper loaded: url_helper
INFO - 2018-04-10 22:52:36 --> Helper loaded: file_helper
INFO - 2018-04-10 22:52:36 --> Helper loaded: date_helper
INFO - 2018-04-10 22:52:36 --> Database Driver Class Initialized
DEBUG - 2018-04-10 22:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 22:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 22:52:37 --> Controller Class Initialized
INFO - 2018-04-10 22:52:37 --> Final output sent to browser
DEBUG - 2018-04-10 22:52:37 --> Total execution time: 0.2642
INFO - 2018-04-10 23:45:39 --> Config Class Initialized
INFO - 2018-04-10 23:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:45:39 --> Utf8 Class Initialized
INFO - 2018-04-10 23:45:39 --> URI Class Initialized
INFO - 2018-04-10 23:45:39 --> Router Class Initialized
INFO - 2018-04-10 23:45:39 --> Output Class Initialized
INFO - 2018-04-10 23:45:39 --> Security Class Initialized
DEBUG - 2018-04-10 23:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:45:39 --> Input Class Initialized
INFO - 2018-04-10 23:45:39 --> Language Class Initialized
INFO - 2018-04-10 23:45:39 --> Loader Class Initialized
INFO - 2018-04-10 23:45:39 --> Helper loaded: url_helper
INFO - 2018-04-10 23:45:39 --> Helper loaded: file_helper
INFO - 2018-04-10 23:45:39 --> Helper loaded: date_helper
INFO - 2018-04-10 23:45:39 --> Database Driver Class Initialized
DEBUG - 2018-04-10 23:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:45:39 --> Controller Class Initialized
INFO - 2018-04-10 23:46:53 --> Config Class Initialized
INFO - 2018-04-10 23:46:53 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:46:53 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:46:53 --> Utf8 Class Initialized
INFO - 2018-04-10 23:46:53 --> URI Class Initialized
INFO - 2018-04-10 23:46:53 --> Router Class Initialized
INFO - 2018-04-10 23:46:53 --> Output Class Initialized
INFO - 2018-04-10 23:46:53 --> Security Class Initialized
DEBUG - 2018-04-10 23:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:46:53 --> Input Class Initialized
INFO - 2018-04-10 23:46:53 --> Language Class Initialized
INFO - 2018-04-10 23:46:53 --> Loader Class Initialized
INFO - 2018-04-10 23:46:53 --> Helper loaded: url_helper
INFO - 2018-04-10 23:46:53 --> Helper loaded: file_helper
INFO - 2018-04-10 23:46:53 --> Helper loaded: date_helper
INFO - 2018-04-10 23:46:53 --> Database Driver Class Initialized
DEBUG - 2018-04-10 23:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:46:53 --> Controller Class Initialized
INFO - 2018-04-10 23:46:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/register.php
INFO - 2018-04-10 23:46:53 --> Final output sent to browser
DEBUG - 2018-04-10 23:46:53 --> Total execution time: 0.3240
INFO - 2018-04-10 23:47:22 --> Config Class Initialized
INFO - 2018-04-10 23:47:22 --> Hooks Class Initialized
DEBUG - 2018-04-10 23:47:22 --> UTF-8 Support Enabled
INFO - 2018-04-10 23:47:22 --> Utf8 Class Initialized
INFO - 2018-04-10 23:47:22 --> URI Class Initialized
INFO - 2018-04-10 23:47:22 --> Router Class Initialized
INFO - 2018-04-10 23:47:22 --> Output Class Initialized
INFO - 2018-04-10 23:47:22 --> Security Class Initialized
DEBUG - 2018-04-10 23:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-10 23:47:22 --> Input Class Initialized
INFO - 2018-04-10 23:47:22 --> Language Class Initialized
INFO - 2018-04-10 23:47:22 --> Loader Class Initialized
INFO - 2018-04-10 23:47:22 --> Helper loaded: url_helper
INFO - 2018-04-10 23:47:22 --> Helper loaded: file_helper
INFO - 2018-04-10 23:47:22 --> Helper loaded: date_helper
INFO - 2018-04-10 23:47:22 --> Database Driver Class Initialized
DEBUG - 2018-04-10 23:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-10 23:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-10 23:47:22 --> Controller Class Initialized
INFO - 2018-04-10 23:47:22 --> Model Class Initialized
ERROR - 2018-04-10 23:47:22 --> Query error: Column 'gender' cannot be null - Invalid query: INSERT INTO `user` (`user_type`, `name`, `email`, `gender`, `blood_group`, `phone`, `dob`, `weight`, `country`) VALUES (2, '', '', NULL, 'select group', '', '', '', 'select')
INFO - 2018-04-10 23:47:22 --> Language file loaded: language/english/db_lang.php
