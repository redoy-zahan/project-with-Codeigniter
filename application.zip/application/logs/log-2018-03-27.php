<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-27 20:23:39 --> Config Class Initialized
INFO - 2018-03-27 20:23:39 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:23:39 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:23:39 --> Utf8 Class Initialized
INFO - 2018-03-27 20:23:39 --> URI Class Initialized
DEBUG - 2018-03-27 20:23:39 --> No URI present. Default controller set.
INFO - 2018-03-27 20:23:39 --> Router Class Initialized
INFO - 2018-03-27 20:23:39 --> Output Class Initialized
INFO - 2018-03-27 20:23:39 --> Security Class Initialized
DEBUG - 2018-03-27 20:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:23:39 --> Input Class Initialized
INFO - 2018-03-27 20:23:39 --> Language Class Initialized
INFO - 2018-03-27 20:23:39 --> Loader Class Initialized
INFO - 2018-03-27 20:23:39 --> Helper loaded: url_helper
INFO - 2018-03-27 20:23:39 --> Helper loaded: file_helper
INFO - 2018-03-27 20:23:40 --> Helper loaded: date_helper
INFO - 2018-03-27 20:23:40 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:23:40 --> Controller Class Initialized
INFO - 2018-03-27 20:23:40 --> Config Class Initialized
INFO - 2018-03-27 20:23:40 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:23:40 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:23:40 --> Utf8 Class Initialized
INFO - 2018-03-27 20:23:40 --> URI Class Initialized
INFO - 2018-03-27 20:23:40 --> Router Class Initialized
INFO - 2018-03-27 20:23:40 --> Output Class Initialized
INFO - 2018-03-27 20:23:40 --> Security Class Initialized
DEBUG - 2018-03-27 20:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:23:40 --> Input Class Initialized
INFO - 2018-03-27 20:23:40 --> Language Class Initialized
INFO - 2018-03-27 20:23:40 --> Loader Class Initialized
INFO - 2018-03-27 20:23:40 --> Helper loaded: url_helper
INFO - 2018-03-27 20:23:40 --> Helper loaded: file_helper
INFO - 2018-03-27 20:23:40 --> Helper loaded: date_helper
INFO - 2018-03-27 20:23:40 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:23:40 --> Controller Class Initialized
INFO - 2018-03-27 20:23:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\login/login.php
INFO - 2018-03-27 20:23:40 --> Final output sent to browser
DEBUG - 2018-03-27 20:23:40 --> Total execution time: 0.4910
INFO - 2018-03-27 20:24:23 --> Config Class Initialized
INFO - 2018-03-27 20:24:23 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:24:23 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:24:23 --> Utf8 Class Initialized
INFO - 2018-03-27 20:24:23 --> URI Class Initialized
INFO - 2018-03-27 20:24:23 --> Router Class Initialized
INFO - 2018-03-27 20:24:23 --> Output Class Initialized
INFO - 2018-03-27 20:24:23 --> Security Class Initialized
DEBUG - 2018-03-27 20:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:24:23 --> Input Class Initialized
INFO - 2018-03-27 20:24:23 --> Language Class Initialized
INFO - 2018-03-27 20:24:23 --> Loader Class Initialized
INFO - 2018-03-27 20:24:23 --> Helper loaded: url_helper
INFO - 2018-03-27 20:24:23 --> Helper loaded: file_helper
INFO - 2018-03-27 20:24:23 --> Helper loaded: date_helper
INFO - 2018-03-27 20:24:23 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:24:23 --> Controller Class Initialized
INFO - 2018-03-27 20:24:23 --> Model Class Initialized
INFO - 2018-03-27 20:24:23 --> Final output sent to browser
DEBUG - 2018-03-27 20:24:23 --> Total execution time: 0.5227
INFO - 2018-03-27 20:24:23 --> Config Class Initialized
INFO - 2018-03-27 20:24:23 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:24:23 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:24:23 --> Utf8 Class Initialized
INFO - 2018-03-27 20:24:23 --> URI Class Initialized
INFO - 2018-03-27 20:24:23 --> Router Class Initialized
INFO - 2018-03-27 20:24:23 --> Output Class Initialized
INFO - 2018-03-27 20:24:23 --> Security Class Initialized
DEBUG - 2018-03-27 20:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:24:23 --> Input Class Initialized
INFO - 2018-03-27 20:24:23 --> Language Class Initialized
INFO - 2018-03-27 20:24:23 --> Loader Class Initialized
INFO - 2018-03-27 20:24:23 --> Helper loaded: url_helper
INFO - 2018-03-27 20:24:23 --> Helper loaded: file_helper
INFO - 2018-03-27 20:24:23 --> Helper loaded: date_helper
INFO - 2018-03-27 20:24:23 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:24:23 --> Controller Class Initialized
INFO - 2018-03-27 20:24:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-03-27 20:24:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/left.php
INFO - 2018-03-27 20:24:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/dashboard.php
INFO - 2018-03-27 20:24:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-03-27 20:24:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-03-27 20:24:23 --> Final output sent to browser
DEBUG - 2018-03-27 20:24:23 --> Total execution time: 0.3940
INFO - 2018-03-27 20:24:55 --> Config Class Initialized
INFO - 2018-03-27 20:24:55 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:24:55 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:24:55 --> Utf8 Class Initialized
INFO - 2018-03-27 20:24:55 --> URI Class Initialized
DEBUG - 2018-03-27 20:24:55 --> No URI present. Default controller set.
INFO - 2018-03-27 20:24:55 --> Router Class Initialized
INFO - 2018-03-27 20:24:55 --> Output Class Initialized
INFO - 2018-03-27 20:24:55 --> Security Class Initialized
DEBUG - 2018-03-27 20:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:24:55 --> Input Class Initialized
INFO - 2018-03-27 20:24:55 --> Language Class Initialized
INFO - 2018-03-27 20:24:55 --> Loader Class Initialized
INFO - 2018-03-27 20:24:55 --> Helper loaded: url_helper
INFO - 2018-03-27 20:24:55 --> Helper loaded: file_helper
INFO - 2018-03-27 20:24:55 --> Helper loaded: date_helper
INFO - 2018-03-27 20:24:55 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:24:55 --> Controller Class Initialized
INFO - 2018-03-27 20:24:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-03-27 20:24:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/left.php
INFO - 2018-03-27 20:24:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/dashboard.php
INFO - 2018-03-27 20:24:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-03-27 20:24:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-03-27 20:24:55 --> Final output sent to browser
DEBUG - 2018-03-27 20:24:55 --> Total execution time: 0.2702
INFO - 2018-03-27 20:25:14 --> Config Class Initialized
INFO - 2018-03-27 20:25:14 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:25:14 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:25:14 --> Utf8 Class Initialized
INFO - 2018-03-27 20:25:14 --> URI Class Initialized
DEBUG - 2018-03-27 20:25:14 --> No URI present. Default controller set.
INFO - 2018-03-27 20:25:14 --> Router Class Initialized
INFO - 2018-03-27 20:25:14 --> Output Class Initialized
INFO - 2018-03-27 20:25:14 --> Security Class Initialized
DEBUG - 2018-03-27 20:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:25:14 --> Input Class Initialized
INFO - 2018-03-27 20:25:14 --> Language Class Initialized
INFO - 2018-03-27 20:25:14 --> Loader Class Initialized
INFO - 2018-03-27 20:25:14 --> Helper loaded: url_helper
INFO - 2018-03-27 20:25:14 --> Helper loaded: file_helper
INFO - 2018-03-27 20:25:14 --> Helper loaded: date_helper
INFO - 2018-03-27 20:25:14 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:25:14 --> Controller Class Initialized
INFO - 2018-03-27 20:25:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-03-27 20:25:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/left.php
INFO - 2018-03-27 20:25:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/dashboard.php
INFO - 2018-03-27 20:25:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-03-27 20:25:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-03-27 20:25:14 --> Final output sent to browser
DEBUG - 2018-03-27 20:25:14 --> Total execution time: 0.3509
INFO - 2018-03-27 20:25:39 --> Config Class Initialized
INFO - 2018-03-27 20:25:39 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:25:39 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:25:39 --> Utf8 Class Initialized
INFO - 2018-03-27 20:25:39 --> URI Class Initialized
INFO - 2018-03-27 20:25:39 --> Router Class Initialized
INFO - 2018-03-27 20:25:39 --> Output Class Initialized
INFO - 2018-03-27 20:25:39 --> Security Class Initialized
DEBUG - 2018-03-27 20:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:25:39 --> Input Class Initialized
INFO - 2018-03-27 20:25:40 --> Language Class Initialized
INFO - 2018-03-27 20:25:40 --> Loader Class Initialized
INFO - 2018-03-27 20:25:40 --> Helper loaded: url_helper
INFO - 2018-03-27 20:25:40 --> Helper loaded: file_helper
INFO - 2018-03-27 20:25:40 --> Helper loaded: date_helper
INFO - 2018-03-27 20:25:40 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:25:40 --> Controller Class Initialized
INFO - 2018-03-27 20:25:40 --> Model Class Initialized
INFO - 2018-03-27 20:25:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-03-27 20:25:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/left.php
INFO - 2018-03-27 20:25:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\teacher/create_teacher.php
INFO - 2018-03-27 20:25:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-03-27 20:25:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-03-27 20:25:40 --> Final output sent to browser
DEBUG - 2018-03-27 20:25:40 --> Total execution time: 0.3147
INFO - 2018-03-27 20:26:43 --> Config Class Initialized
INFO - 2018-03-27 20:26:43 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:26:43 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:26:43 --> Utf8 Class Initialized
INFO - 2018-03-27 20:26:43 --> URI Class Initialized
DEBUG - 2018-03-27 20:26:43 --> No URI present. Default controller set.
INFO - 2018-03-27 20:26:43 --> Router Class Initialized
INFO - 2018-03-27 20:26:43 --> Output Class Initialized
INFO - 2018-03-27 20:26:43 --> Security Class Initialized
DEBUG - 2018-03-27 20:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:26:43 --> Input Class Initialized
INFO - 2018-03-27 20:26:43 --> Language Class Initialized
INFO - 2018-03-27 20:26:43 --> Loader Class Initialized
INFO - 2018-03-27 20:26:43 --> Helper loaded: url_helper
INFO - 2018-03-27 20:26:43 --> Helper loaded: file_helper
INFO - 2018-03-27 20:26:43 --> Helper loaded: date_helper
INFO - 2018-03-27 20:26:43 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:26:43 --> Controller Class Initialized
INFO - 2018-03-27 20:26:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-03-27 20:26:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/left.php
INFO - 2018-03-27 20:26:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/dashboard.php
INFO - 2018-03-27 20:26:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-03-27 20:26:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-03-27 20:26:43 --> Final output sent to browser
DEBUG - 2018-03-27 20:26:43 --> Total execution time: 0.3327
INFO - 2018-03-27 20:26:43 --> Config Class Initialized
INFO - 2018-03-27 20:26:43 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:26:43 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:26:43 --> Utf8 Class Initialized
INFO - 2018-03-27 20:26:43 --> URI Class Initialized
DEBUG - 2018-03-27 20:26:43 --> No URI present. Default controller set.
INFO - 2018-03-27 20:26:43 --> Router Class Initialized
INFO - 2018-03-27 20:26:43 --> Output Class Initialized
INFO - 2018-03-27 20:26:43 --> Security Class Initialized
DEBUG - 2018-03-27 20:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:26:43 --> Input Class Initialized
INFO - 2018-03-27 20:26:43 --> Language Class Initialized
INFO - 2018-03-27 20:26:43 --> Loader Class Initialized
INFO - 2018-03-27 20:26:43 --> Helper loaded: url_helper
INFO - 2018-03-27 20:26:43 --> Helper loaded: file_helper
INFO - 2018-03-27 20:26:43 --> Helper loaded: date_helper
INFO - 2018-03-27 20:26:43 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:26:43 --> Controller Class Initialized
INFO - 2018-03-27 20:26:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-03-27 20:26:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/left.php
INFO - 2018-03-27 20:26:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/dashboard.php
INFO - 2018-03-27 20:26:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-03-27 20:26:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-03-27 20:26:43 --> Final output sent to browser
DEBUG - 2018-03-27 20:26:43 --> Total execution time: 0.2786
INFO - 2018-03-27 20:26:55 --> Config Class Initialized
INFO - 2018-03-27 20:26:55 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:26:55 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:26:55 --> Utf8 Class Initialized
INFO - 2018-03-27 20:26:55 --> URI Class Initialized
DEBUG - 2018-03-27 20:26:55 --> No URI present. Default controller set.
INFO - 2018-03-27 20:26:55 --> Router Class Initialized
INFO - 2018-03-27 20:26:55 --> Output Class Initialized
INFO - 2018-03-27 20:26:55 --> Security Class Initialized
DEBUG - 2018-03-27 20:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:26:55 --> Input Class Initialized
INFO - 2018-03-27 20:26:55 --> Language Class Initialized
INFO - 2018-03-27 20:26:55 --> Loader Class Initialized
INFO - 2018-03-27 20:26:55 --> Helper loaded: url_helper
INFO - 2018-03-27 20:26:55 --> Helper loaded: file_helper
INFO - 2018-03-27 20:26:55 --> Helper loaded: date_helper
INFO - 2018-03-27 20:26:55 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:26:55 --> Controller Class Initialized
INFO - 2018-03-27 20:26:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/header.php
INFO - 2018-03-27 20:26:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/left.php
INFO - 2018-03-27 20:26:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/dashboard.php
INFO - 2018-03-27 20:26:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/footer.php
INFO - 2018-03-27 20:26:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_admin/index.php
INFO - 2018-03-27 20:26:55 --> Final output sent to browser
DEBUG - 2018-03-27 20:26:55 --> Total execution time: 0.2885
INFO - 2018-03-27 20:30:22 --> Config Class Initialized
INFO - 2018-03-27 20:30:22 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:30:22 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:30:22 --> Utf8 Class Initialized
INFO - 2018-03-27 20:30:22 --> URI Class Initialized
DEBUG - 2018-03-27 20:30:22 --> No URI present. Default controller set.
INFO - 2018-03-27 20:30:22 --> Router Class Initialized
INFO - 2018-03-27 20:30:22 --> Output Class Initialized
INFO - 2018-03-27 20:30:22 --> Security Class Initialized
DEBUG - 2018-03-27 20:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:30:22 --> Input Class Initialized
INFO - 2018-03-27 20:30:22 --> Language Class Initialized
INFO - 2018-03-27 20:30:22 --> Loader Class Initialized
INFO - 2018-03-27 20:30:22 --> Helper loaded: url_helper
INFO - 2018-03-27 20:30:22 --> Helper loaded: file_helper
INFO - 2018-03-27 20:30:22 --> Helper loaded: date_helper
INFO - 2018-03-27 20:30:22 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:30:22 --> Controller Class Initialized
INFO - 2018-03-27 20:30:27 --> Config Class Initialized
INFO - 2018-03-27 20:30:27 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:30:27 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:30:27 --> Utf8 Class Initialized
INFO - 2018-03-27 20:30:27 --> URI Class Initialized
DEBUG - 2018-03-27 20:30:27 --> No URI present. Default controller set.
INFO - 2018-03-27 20:30:27 --> Router Class Initialized
INFO - 2018-03-27 20:30:27 --> Output Class Initialized
INFO - 2018-03-27 20:30:27 --> Security Class Initialized
DEBUG - 2018-03-27 20:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:30:27 --> Input Class Initialized
INFO - 2018-03-27 20:30:27 --> Language Class Initialized
INFO - 2018-03-27 20:30:27 --> Loader Class Initialized
INFO - 2018-03-27 20:30:27 --> Helper loaded: url_helper
INFO - 2018-03-27 20:30:27 --> Helper loaded: file_helper
INFO - 2018-03-27 20:30:27 --> Helper loaded: date_helper
INFO - 2018-03-27 20:30:27 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:30:27 --> Controller Class Initialized
INFO - 2018-03-27 20:30:31 --> Config Class Initialized
INFO - 2018-03-27 20:30:31 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:30:31 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:30:31 --> Utf8 Class Initialized
INFO - 2018-03-27 20:30:31 --> URI Class Initialized
DEBUG - 2018-03-27 20:30:31 --> No URI present. Default controller set.
INFO - 2018-03-27 20:30:31 --> Router Class Initialized
INFO - 2018-03-27 20:30:31 --> Output Class Initialized
INFO - 2018-03-27 20:30:31 --> Security Class Initialized
DEBUG - 2018-03-27 20:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:30:31 --> Input Class Initialized
INFO - 2018-03-27 20:30:31 --> Language Class Initialized
INFO - 2018-03-27 20:30:31 --> Loader Class Initialized
INFO - 2018-03-27 20:30:31 --> Helper loaded: url_helper
INFO - 2018-03-27 20:30:31 --> Helper loaded: file_helper
INFO - 2018-03-27 20:30:31 --> Helper loaded: date_helper
INFO - 2018-03-27 20:30:31 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:30:31 --> Controller Class Initialized
INFO - 2018-03-27 20:30:34 --> Config Class Initialized
INFO - 2018-03-27 20:30:34 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:30:34 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:30:34 --> Utf8 Class Initialized
INFO - 2018-03-27 20:30:34 --> URI Class Initialized
DEBUG - 2018-03-27 20:30:34 --> No URI present. Default controller set.
INFO - 2018-03-27 20:30:34 --> Router Class Initialized
INFO - 2018-03-27 20:30:34 --> Output Class Initialized
INFO - 2018-03-27 20:30:34 --> Security Class Initialized
DEBUG - 2018-03-27 20:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:30:34 --> Input Class Initialized
INFO - 2018-03-27 20:30:34 --> Language Class Initialized
INFO - 2018-03-27 20:30:34 --> Loader Class Initialized
INFO - 2018-03-27 20:30:34 --> Helper loaded: url_helper
INFO - 2018-03-27 20:30:34 --> Helper loaded: file_helper
INFO - 2018-03-27 20:30:34 --> Helper loaded: date_helper
INFO - 2018-03-27 20:30:34 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:30:34 --> Controller Class Initialized
INFO - 2018-03-27 20:32:47 --> Config Class Initialized
INFO - 2018-03-27 20:32:47 --> Hooks Class Initialized
DEBUG - 2018-03-27 20:32:47 --> UTF-8 Support Enabled
INFO - 2018-03-27 20:32:47 --> Utf8 Class Initialized
INFO - 2018-03-27 20:32:47 --> URI Class Initialized
DEBUG - 2018-03-27 20:32:47 --> No URI present. Default controller set.
INFO - 2018-03-27 20:32:47 --> Router Class Initialized
INFO - 2018-03-27 20:32:47 --> Output Class Initialized
INFO - 2018-03-27 20:32:47 --> Security Class Initialized
DEBUG - 2018-03-27 20:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 20:32:47 --> Input Class Initialized
INFO - 2018-03-27 20:32:47 --> Language Class Initialized
INFO - 2018-03-27 20:32:47 --> Loader Class Initialized
INFO - 2018-03-27 20:32:47 --> Helper loaded: url_helper
INFO - 2018-03-27 20:32:47 --> Helper loaded: file_helper
INFO - 2018-03-27 20:32:47 --> Helper loaded: date_helper
INFO - 2018-03-27 20:32:47 --> Database Driver Class Initialized
DEBUG - 2018-03-27 20:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-27 20:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 20:32:47 --> Controller Class Initialized
INFO - 2018-03-27 20:32:47 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-03-27 20:32:47 --> Final output sent to browser
DEBUG - 2018-03-27 20:32:47 --> Total execution time: 0.2555
