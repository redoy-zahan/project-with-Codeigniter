<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-22 14:27:54 --> Config Class Initialized
INFO - 2017-03-22 14:27:54 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:27:54 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:27:54 --> Utf8 Class Initialized
INFO - 2017-03-22 14:27:54 --> URI Class Initialized
DEBUG - 2017-03-22 14:27:54 --> No URI present. Default controller set.
INFO - 2017-03-22 14:27:54 --> Router Class Initialized
INFO - 2017-03-22 14:27:54 --> Output Class Initialized
INFO - 2017-03-22 14:27:54 --> Security Class Initialized
DEBUG - 2017-03-22 14:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:27:54 --> Input Class Initialized
INFO - 2017-03-22 14:27:54 --> Language Class Initialized
INFO - 2017-03-22 14:27:54 --> Loader Class Initialized
INFO - 2017-03-22 14:27:54 --> Helper loaded: url_helper
INFO - 2017-03-22 14:27:54 --> Helper loaded: file_helper
INFO - 2017-03-22 14:27:54 --> Helper loaded: date_helper
INFO - 2017-03-22 14:27:54 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:27:54 --> Controller Class Initialized
INFO - 2017-03-22 14:27:55 --> Config Class Initialized
INFO - 2017-03-22 14:27:55 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:27:55 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:27:55 --> Utf8 Class Initialized
INFO - 2017-03-22 14:27:55 --> URI Class Initialized
INFO - 2017-03-22 14:27:55 --> Router Class Initialized
INFO - 2017-03-22 14:27:55 --> Output Class Initialized
INFO - 2017-03-22 14:27:55 --> Security Class Initialized
DEBUG - 2017-03-22 14:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:27:55 --> Input Class Initialized
INFO - 2017-03-22 14:27:55 --> Language Class Initialized
INFO - 2017-03-22 14:27:55 --> Loader Class Initialized
INFO - 2017-03-22 14:27:55 --> Helper loaded: url_helper
INFO - 2017-03-22 14:27:55 --> Helper loaded: file_helper
INFO - 2017-03-22 14:27:55 --> Helper loaded: date_helper
INFO - 2017-03-22 14:27:55 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:27:55 --> Controller Class Initialized
INFO - 2017-03-22 14:27:55 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-22 14:27:55 --> Final output sent to browser
DEBUG - 2017-03-22 14:27:55 --> Total execution time: 0.0252
INFO - 2017-03-22 14:28:17 --> Config Class Initialized
INFO - 2017-03-22 14:28:17 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:28:17 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:28:17 --> Utf8 Class Initialized
INFO - 2017-03-22 14:28:17 --> URI Class Initialized
INFO - 2017-03-22 14:28:17 --> Router Class Initialized
INFO - 2017-03-22 14:28:17 --> Output Class Initialized
INFO - 2017-03-22 14:28:17 --> Security Class Initialized
DEBUG - 2017-03-22 14:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:28:17 --> Input Class Initialized
INFO - 2017-03-22 14:28:17 --> Language Class Initialized
INFO - 2017-03-22 14:28:17 --> Loader Class Initialized
INFO - 2017-03-22 14:28:17 --> Helper loaded: url_helper
INFO - 2017-03-22 14:28:17 --> Helper loaded: file_helper
INFO - 2017-03-22 14:28:17 --> Helper loaded: date_helper
INFO - 2017-03-22 14:28:17 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:28:17 --> Controller Class Initialized
INFO - 2017-03-22 14:28:17 --> Model Class Initialized
INFO - 2017-03-22 14:28:17 --> Final output sent to browser
DEBUG - 2017-03-22 14:28:17 --> Total execution time: 0.0669
INFO - 2017-03-22 14:28:17 --> Config Class Initialized
INFO - 2017-03-22 14:28:17 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:28:17 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:28:17 --> Utf8 Class Initialized
INFO - 2017-03-22 14:28:17 --> URI Class Initialized
INFO - 2017-03-22 14:28:17 --> Router Class Initialized
INFO - 2017-03-22 14:28:17 --> Output Class Initialized
INFO - 2017-03-22 14:28:17 --> Security Class Initialized
DEBUG - 2017-03-22 14:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:28:17 --> Input Class Initialized
INFO - 2017-03-22 14:28:17 --> Language Class Initialized
INFO - 2017-03-22 14:28:17 --> Loader Class Initialized
INFO - 2017-03-22 14:28:17 --> Helper loaded: url_helper
INFO - 2017-03-22 14:28:17 --> Helper loaded: file_helper
INFO - 2017-03-22 14:28:17 --> Helper loaded: date_helper
INFO - 2017-03-22 14:28:17 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:28:17 --> Controller Class Initialized
INFO - 2017-03-22 14:28:17 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-22 14:28:17 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-22 14:28:17 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/dashboard.php
INFO - 2017-03-22 14:28:17 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-22 14:28:17 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-22 14:28:17 --> Final output sent to browser
DEBUG - 2017-03-22 14:28:17 --> Total execution time: 0.0541
INFO - 2017-03-22 14:28:52 --> Config Class Initialized
INFO - 2017-03-22 14:28:52 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:28:52 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:28:52 --> Utf8 Class Initialized
INFO - 2017-03-22 14:28:52 --> URI Class Initialized
INFO - 2017-03-22 14:28:52 --> Router Class Initialized
INFO - 2017-03-22 14:28:52 --> Output Class Initialized
INFO - 2017-03-22 14:28:52 --> Security Class Initialized
DEBUG - 2017-03-22 14:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:28:52 --> Input Class Initialized
INFO - 2017-03-22 14:28:52 --> Language Class Initialized
INFO - 2017-03-22 14:28:52 --> Loader Class Initialized
INFO - 2017-03-22 14:28:52 --> Helper loaded: url_helper
INFO - 2017-03-22 14:28:52 --> Helper loaded: file_helper
INFO - 2017-03-22 14:28:52 --> Helper loaded: date_helper
INFO - 2017-03-22 14:28:52 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:28:52 --> Controller Class Initialized
INFO - 2017-03-22 14:28:52 --> Model Class Initialized
INFO - 2017-03-22 14:28:52 --> Model Class Initialized
INFO - 2017-03-22 14:28:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-22 14:28:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-22 14:28:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/subjects/assign_subject.php
INFO - 2017-03-22 14:28:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-22 14:28:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-22 14:28:52 --> Final output sent to browser
DEBUG - 2017-03-22 14:28:52 --> Total execution time: 0.0629
INFO - 2017-03-22 14:29:24 --> Config Class Initialized
INFO - 2017-03-22 14:29:24 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:29:24 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:29:24 --> Utf8 Class Initialized
INFO - 2017-03-22 14:29:24 --> URI Class Initialized
INFO - 2017-03-22 14:29:24 --> Router Class Initialized
INFO - 2017-03-22 14:29:24 --> Output Class Initialized
INFO - 2017-03-22 14:29:24 --> Security Class Initialized
DEBUG - 2017-03-22 14:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:29:24 --> Input Class Initialized
INFO - 2017-03-22 14:29:24 --> Language Class Initialized
INFO - 2017-03-22 14:29:24 --> Loader Class Initialized
INFO - 2017-03-22 14:29:24 --> Helper loaded: url_helper
INFO - 2017-03-22 14:29:24 --> Helper loaded: file_helper
INFO - 2017-03-22 14:29:24 --> Helper loaded: date_helper
INFO - 2017-03-22 14:29:24 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:29:24 --> Controller Class Initialized
DEBUG - 2017-03-22 14:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-22 14:29:25 --> Config Class Initialized
INFO - 2017-03-22 14:29:25 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:29:25 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:29:25 --> Utf8 Class Initialized
INFO - 2017-03-22 14:29:25 --> URI Class Initialized
INFO - 2017-03-22 14:29:25 --> Router Class Initialized
INFO - 2017-03-22 14:29:25 --> Output Class Initialized
INFO - 2017-03-22 14:29:25 --> Security Class Initialized
DEBUG - 2017-03-22 14:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:29:25 --> Input Class Initialized
INFO - 2017-03-22 14:29:25 --> Language Class Initialized
INFO - 2017-03-22 14:29:25 --> Loader Class Initialized
INFO - 2017-03-22 14:29:25 --> Helper loaded: url_helper
INFO - 2017-03-22 14:29:25 --> Helper loaded: file_helper
INFO - 2017-03-22 14:29:25 --> Helper loaded: date_helper
INFO - 2017-03-22 14:29:25 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:29:25 --> Controller Class Initialized
INFO - 2017-03-22 14:29:25 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-22 14:29:25 --> Final output sent to browser
DEBUG - 2017-03-22 14:29:25 --> Total execution time: 0.0179
INFO - 2017-03-22 14:29:45 --> Config Class Initialized
INFO - 2017-03-22 14:29:45 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:29:45 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:29:45 --> Utf8 Class Initialized
INFO - 2017-03-22 14:29:45 --> URI Class Initialized
INFO - 2017-03-22 14:29:45 --> Router Class Initialized
INFO - 2017-03-22 14:29:45 --> Output Class Initialized
INFO - 2017-03-22 14:29:45 --> Security Class Initialized
DEBUG - 2017-03-22 14:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:29:45 --> Input Class Initialized
INFO - 2017-03-22 14:29:45 --> Language Class Initialized
INFO - 2017-03-22 14:29:45 --> Loader Class Initialized
INFO - 2017-03-22 14:29:45 --> Helper loaded: url_helper
INFO - 2017-03-22 14:29:45 --> Helper loaded: file_helper
INFO - 2017-03-22 14:29:45 --> Helper loaded: date_helper
INFO - 2017-03-22 14:29:45 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:29:45 --> Controller Class Initialized
INFO - 2017-03-22 14:29:45 --> Model Class Initialized
INFO - 2017-03-22 14:29:45 --> Final output sent to browser
DEBUG - 2017-03-22 14:29:45 --> Total execution time: 0.0301
INFO - 2017-03-22 14:29:46 --> Config Class Initialized
INFO - 2017-03-22 14:29:46 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:29:46 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:29:46 --> Utf8 Class Initialized
INFO - 2017-03-22 14:29:46 --> URI Class Initialized
INFO - 2017-03-22 14:29:46 --> Router Class Initialized
INFO - 2017-03-22 14:29:46 --> Output Class Initialized
INFO - 2017-03-22 14:29:46 --> Security Class Initialized
DEBUG - 2017-03-22 14:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:29:46 --> Input Class Initialized
INFO - 2017-03-22 14:29:46 --> Language Class Initialized
INFO - 2017-03-22 14:29:46 --> Loader Class Initialized
INFO - 2017-03-22 14:29:46 --> Helper loaded: url_helper
INFO - 2017-03-22 14:29:46 --> Helper loaded: file_helper
INFO - 2017-03-22 14:29:46 --> Helper loaded: date_helper
INFO - 2017-03-22 14:29:46 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:29:46 --> Controller Class Initialized
INFO - 2017-03-22 14:29:46 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-22 14:29:46 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-22 14:29:46 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/dashboard.php
INFO - 2017-03-22 14:29:46 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-22 14:29:46 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-22 14:29:46 --> Final output sent to browser
DEBUG - 2017-03-22 14:29:46 --> Total execution time: 0.0177
INFO - 2017-03-22 14:29:52 --> Config Class Initialized
INFO - 2017-03-22 14:29:52 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:29:52 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:29:52 --> Utf8 Class Initialized
INFO - 2017-03-22 14:29:52 --> URI Class Initialized
INFO - 2017-03-22 14:29:52 --> Router Class Initialized
INFO - 2017-03-22 14:29:52 --> Output Class Initialized
INFO - 2017-03-22 14:29:52 --> Security Class Initialized
DEBUG - 2017-03-22 14:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:29:52 --> Input Class Initialized
INFO - 2017-03-22 14:29:52 --> Language Class Initialized
INFO - 2017-03-22 14:29:52 --> Loader Class Initialized
INFO - 2017-03-22 14:29:52 --> Helper loaded: url_helper
INFO - 2017-03-22 14:29:52 --> Helper loaded: file_helper
INFO - 2017-03-22 14:29:52 --> Helper loaded: date_helper
INFO - 2017-03-22 14:29:52 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:29:52 --> Controller Class Initialized
INFO - 2017-03-22 14:29:52 --> Model Class Initialized
INFO - 2017-03-22 14:29:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-22 14:29:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-22 14:29:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/chapter/create_chapter.php
INFO - 2017-03-22 14:29:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-22 14:29:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-22 14:29:52 --> Final output sent to browser
DEBUG - 2017-03-22 14:29:52 --> Total execution time: 0.0478
INFO - 2017-03-22 14:30:02 --> Config Class Initialized
INFO - 2017-03-22 14:30:02 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:30:02 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:30:02 --> Utf8 Class Initialized
INFO - 2017-03-22 14:30:02 --> URI Class Initialized
INFO - 2017-03-22 14:30:02 --> Router Class Initialized
INFO - 2017-03-22 14:30:02 --> Output Class Initialized
INFO - 2017-03-22 14:30:02 --> Security Class Initialized
DEBUG - 2017-03-22 14:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:30:02 --> Input Class Initialized
INFO - 2017-03-22 14:30:02 --> Language Class Initialized
INFO - 2017-03-22 14:30:02 --> Loader Class Initialized
INFO - 2017-03-22 14:30:02 --> Helper loaded: url_helper
INFO - 2017-03-22 14:30:02 --> Helper loaded: file_helper
INFO - 2017-03-22 14:30:02 --> Helper loaded: date_helper
INFO - 2017-03-22 14:30:02 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:30:02 --> Controller Class Initialized
INFO - 2017-03-22 14:30:02 --> Model Class Initialized
INFO - 2017-03-22 14:30:02 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-22 14:30:02 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-22 14:30:02 --> File loaded: /home/thestudytown/public_html/mcq/application/views/exam/assign_exam.php
INFO - 2017-03-22 14:30:02 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-22 14:30:02 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-22 14:30:02 --> Final output sent to browser
DEBUG - 2017-03-22 14:30:02 --> Total execution time: 0.0793
INFO - 2017-03-22 14:30:12 --> Config Class Initialized
INFO - 2017-03-22 14:30:12 --> Hooks Class Initialized
DEBUG - 2017-03-22 14:30:12 --> UTF-8 Support Enabled
INFO - 2017-03-22 14:30:12 --> Utf8 Class Initialized
INFO - 2017-03-22 14:30:12 --> URI Class Initialized
DEBUG - 2017-03-22 14:30:12 --> No URI present. Default controller set.
INFO - 2017-03-22 14:30:12 --> Router Class Initialized
INFO - 2017-03-22 14:30:12 --> Output Class Initialized
INFO - 2017-03-22 14:30:12 --> Security Class Initialized
DEBUG - 2017-03-22 14:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 14:30:12 --> Input Class Initialized
INFO - 2017-03-22 14:30:12 --> Language Class Initialized
INFO - 2017-03-22 14:30:12 --> Loader Class Initialized
INFO - 2017-03-22 14:30:12 --> Helper loaded: url_helper
INFO - 2017-03-22 14:30:12 --> Helper loaded: file_helper
INFO - 2017-03-22 14:30:12 --> Helper loaded: date_helper
INFO - 2017-03-22 14:30:12 --> Database Driver Class Initialized
DEBUG - 2017-03-22 14:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-22 14:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 14:30:12 --> Controller Class Initialized
INFO - 2017-03-22 14:30:12 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-22 14:30:12 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-22 14:30:12 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/dashboard.php
INFO - 2017-03-22 14:30:12 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-22 14:30:12 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-22 14:30:12 --> Final output sent to browser
DEBUG - 2017-03-22 14:30:12 --> Total execution time: 0.0192
