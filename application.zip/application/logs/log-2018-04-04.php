<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-04 19:50:55 --> Config Class Initialized
INFO - 2018-04-04 19:50:55 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:50:55 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:50:55 --> Utf8 Class Initialized
INFO - 2018-04-04 19:50:55 --> URI Class Initialized
DEBUG - 2018-04-04 19:50:55 --> No URI present. Default controller set.
INFO - 2018-04-04 19:50:55 --> Router Class Initialized
INFO - 2018-04-04 19:50:56 --> Output Class Initialized
INFO - 2018-04-04 19:50:56 --> Security Class Initialized
DEBUG - 2018-04-04 19:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:50:56 --> Input Class Initialized
INFO - 2018-04-04 19:50:56 --> Language Class Initialized
INFO - 2018-04-04 19:50:56 --> Loader Class Initialized
INFO - 2018-04-04 19:50:56 --> Helper loaded: url_helper
INFO - 2018-04-04 19:50:56 --> Helper loaded: file_helper
INFO - 2018-04-04 19:50:56 --> Helper loaded: date_helper
INFO - 2018-04-04 19:50:57 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:50:57 --> Controller Class Initialized
INFO - 2018-04-04 19:50:57 --> Config Class Initialized
INFO - 2018-04-04 19:50:57 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:50:57 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:50:57 --> Utf8 Class Initialized
INFO - 2018-04-04 19:50:57 --> URI Class Initialized
INFO - 2018-04-04 19:50:57 --> Router Class Initialized
INFO - 2018-04-04 19:50:57 --> Output Class Initialized
INFO - 2018-04-04 19:50:57 --> Security Class Initialized
DEBUG - 2018-04-04 19:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:50:57 --> Input Class Initialized
INFO - 2018-04-04 19:50:57 --> Language Class Initialized
INFO - 2018-04-04 19:50:58 --> Loader Class Initialized
INFO - 2018-04-04 19:50:58 --> Helper loaded: url_helper
INFO - 2018-04-04 19:50:58 --> Helper loaded: file_helper
INFO - 2018-04-04 19:50:58 --> Helper loaded: date_helper
INFO - 2018-04-04 19:50:58 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:50:58 --> Controller Class Initialized
INFO - 2018-04-04 19:50:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-04 19:50:58 --> Final output sent to browser
DEBUG - 2018-04-04 19:50:58 --> Total execution time: 0.6485
INFO - 2018-04-04 19:51:10 --> Config Class Initialized
INFO - 2018-04-04 19:51:10 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:51:10 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:51:10 --> Utf8 Class Initialized
INFO - 2018-04-04 19:51:10 --> URI Class Initialized
INFO - 2018-04-04 19:51:10 --> Router Class Initialized
INFO - 2018-04-04 19:51:10 --> Output Class Initialized
INFO - 2018-04-04 19:51:10 --> Security Class Initialized
DEBUG - 2018-04-04 19:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:51:10 --> Input Class Initialized
INFO - 2018-04-04 19:51:10 --> Language Class Initialized
INFO - 2018-04-04 19:51:10 --> Loader Class Initialized
INFO - 2018-04-04 19:51:10 --> Helper loaded: url_helper
INFO - 2018-04-04 19:51:10 --> Helper loaded: file_helper
INFO - 2018-04-04 19:51:10 --> Helper loaded: date_helper
INFO - 2018-04-04 19:51:10 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:51:10 --> Controller Class Initialized
INFO - 2018-04-04 19:51:10 --> Model Class Initialized
ERROR - 2018-04-04 19:51:11 --> Severity: Notice --> Undefined property: stdClass::$user_name G:\xampp\htdocs\codeigniter\application\controllers\Auth_Controller.php 50
INFO - 2018-04-04 19:51:11 --> Final output sent to browser
DEBUG - 2018-04-04 19:51:11 --> Total execution time: 0.7534
INFO - 2018-04-04 19:51:11 --> Config Class Initialized
INFO - 2018-04-04 19:51:11 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:51:11 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:51:11 --> Utf8 Class Initialized
INFO - 2018-04-04 19:51:11 --> URI Class Initialized
INFO - 2018-04-04 19:51:11 --> Router Class Initialized
INFO - 2018-04-04 19:51:11 --> Output Class Initialized
INFO - 2018-04-04 19:51:11 --> Security Class Initialized
DEBUG - 2018-04-04 19:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:51:11 --> Input Class Initialized
INFO - 2018-04-04 19:51:11 --> Language Class Initialized
INFO - 2018-04-04 19:51:11 --> Loader Class Initialized
INFO - 2018-04-04 19:51:11 --> Helper loaded: url_helper
INFO - 2018-04-04 19:51:11 --> Helper loaded: file_helper
INFO - 2018-04-04 19:51:11 --> Helper loaded: date_helper
INFO - 2018-04-04 19:51:11 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:51:11 --> Controller Class Initialized
INFO - 2018-04-04 19:51:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-04 19:51:11 --> Final output sent to browser
DEBUG - 2018-04-04 19:51:11 --> Total execution time: 0.4665
INFO - 2018-04-04 19:51:16 --> Config Class Initialized
INFO - 2018-04-04 19:51:16 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:51:16 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:51:16 --> Utf8 Class Initialized
INFO - 2018-04-04 19:51:16 --> URI Class Initialized
INFO - 2018-04-04 19:51:16 --> Router Class Initialized
INFO - 2018-04-04 19:51:16 --> Output Class Initialized
INFO - 2018-04-04 19:51:16 --> Security Class Initialized
DEBUG - 2018-04-04 19:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:51:16 --> Input Class Initialized
INFO - 2018-04-04 19:51:16 --> Language Class Initialized
INFO - 2018-04-04 19:51:16 --> Loader Class Initialized
INFO - 2018-04-04 19:51:16 --> Helper loaded: url_helper
INFO - 2018-04-04 19:51:16 --> Helper loaded: file_helper
INFO - 2018-04-04 19:51:16 --> Helper loaded: date_helper
INFO - 2018-04-04 19:51:16 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:51:16 --> Controller Class Initialized
INFO - 2018-04-04 19:51:16 --> Config Class Initialized
INFO - 2018-04-04 19:51:16 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:51:16 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:51:17 --> Utf8 Class Initialized
INFO - 2018-04-04 19:51:17 --> URI Class Initialized
INFO - 2018-04-04 19:51:17 --> Router Class Initialized
INFO - 2018-04-04 19:51:17 --> Output Class Initialized
INFO - 2018-04-04 19:51:17 --> Security Class Initialized
DEBUG - 2018-04-04 19:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:51:17 --> Input Class Initialized
INFO - 2018-04-04 19:51:17 --> Language Class Initialized
INFO - 2018-04-04 19:51:17 --> Loader Class Initialized
INFO - 2018-04-04 19:51:17 --> Helper loaded: url_helper
INFO - 2018-04-04 19:51:17 --> Helper loaded: file_helper
INFO - 2018-04-04 19:51:17 --> Helper loaded: date_helper
INFO - 2018-04-04 19:51:17 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:51:17 --> Controller Class Initialized
INFO - 2018-04-04 19:51:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-04 19:51:17 --> Final output sent to browser
DEBUG - 2018-04-04 19:51:17 --> Total execution time: 0.2714
INFO - 2018-04-04 19:51:19 --> Config Class Initialized
INFO - 2018-04-04 19:51:19 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:51:19 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:51:19 --> Utf8 Class Initialized
INFO - 2018-04-04 19:51:19 --> URI Class Initialized
INFO - 2018-04-04 19:51:19 --> Router Class Initialized
INFO - 2018-04-04 19:51:19 --> Output Class Initialized
INFO - 2018-04-04 19:51:19 --> Security Class Initialized
DEBUG - 2018-04-04 19:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:51:19 --> Input Class Initialized
INFO - 2018-04-04 19:51:19 --> Language Class Initialized
INFO - 2018-04-04 19:51:19 --> Loader Class Initialized
INFO - 2018-04-04 19:51:19 --> Helper loaded: url_helper
INFO - 2018-04-04 19:51:19 --> Helper loaded: file_helper
INFO - 2018-04-04 19:51:19 --> Helper loaded: date_helper
INFO - 2018-04-04 19:51:19 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:51:19 --> Controller Class Initialized
INFO - 2018-04-04 19:51:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-04 19:51:19 --> Final output sent to browser
DEBUG - 2018-04-04 19:51:19 --> Total execution time: 0.2417
INFO - 2018-04-04 19:51:35 --> Config Class Initialized
INFO - 2018-04-04 19:51:35 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:51:35 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:51:35 --> Utf8 Class Initialized
INFO - 2018-04-04 19:51:35 --> URI Class Initialized
INFO - 2018-04-04 19:51:35 --> Router Class Initialized
INFO - 2018-04-04 19:51:35 --> Output Class Initialized
INFO - 2018-04-04 19:51:35 --> Security Class Initialized
DEBUG - 2018-04-04 19:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:51:35 --> Input Class Initialized
INFO - 2018-04-04 19:51:35 --> Language Class Initialized
ERROR - 2018-04-04 19:51:35 --> Severity: error --> Exception: syntax error, unexpected '}' G:\xampp\htdocs\codeigniter\application\controllers\Welcome.php 14
INFO - 2018-04-04 19:51:39 --> Config Class Initialized
INFO - 2018-04-04 19:51:39 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:51:39 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:51:39 --> Utf8 Class Initialized
INFO - 2018-04-04 19:51:39 --> URI Class Initialized
DEBUG - 2018-04-04 19:51:39 --> No URI present. Default controller set.
INFO - 2018-04-04 19:51:39 --> Router Class Initialized
INFO - 2018-04-04 19:51:39 --> Output Class Initialized
INFO - 2018-04-04 19:51:39 --> Security Class Initialized
DEBUG - 2018-04-04 19:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:51:39 --> Input Class Initialized
INFO - 2018-04-04 19:51:39 --> Language Class Initialized
ERROR - 2018-04-04 19:51:39 --> Severity: error --> Exception: syntax error, unexpected '}' G:\xampp\htdocs\codeigniter\application\controllers\Welcome.php 14
INFO - 2018-04-04 19:52:07 --> Config Class Initialized
INFO - 2018-04-04 19:52:07 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:52:07 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:52:07 --> Utf8 Class Initialized
INFO - 2018-04-04 19:52:07 --> URI Class Initialized
DEBUG - 2018-04-04 19:52:07 --> No URI present. Default controller set.
INFO - 2018-04-04 19:52:07 --> Router Class Initialized
INFO - 2018-04-04 19:52:07 --> Output Class Initialized
INFO - 2018-04-04 19:52:07 --> Security Class Initialized
DEBUG - 2018-04-04 19:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:52:07 --> Input Class Initialized
INFO - 2018-04-04 19:52:07 --> Language Class Initialized
INFO - 2018-04-04 19:52:07 --> Loader Class Initialized
INFO - 2018-04-04 19:52:07 --> Helper loaded: url_helper
INFO - 2018-04-04 19:52:07 --> Helper loaded: file_helper
INFO - 2018-04-04 19:52:07 --> Helper loaded: date_helper
INFO - 2018-04-04 19:52:07 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:52:07 --> Controller Class Initialized
INFO - 2018-04-04 19:52:29 --> Config Class Initialized
INFO - 2018-04-04 19:52:29 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:52:29 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:52:29 --> Utf8 Class Initialized
INFO - 2018-04-04 19:52:29 --> URI Class Initialized
DEBUG - 2018-04-04 19:52:29 --> No URI present. Default controller set.
INFO - 2018-04-04 19:52:29 --> Router Class Initialized
INFO - 2018-04-04 19:52:29 --> Output Class Initialized
INFO - 2018-04-04 19:52:29 --> Security Class Initialized
DEBUG - 2018-04-04 19:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:52:29 --> Input Class Initialized
INFO - 2018-04-04 19:52:29 --> Language Class Initialized
INFO - 2018-04-04 19:52:29 --> Loader Class Initialized
INFO - 2018-04-04 19:52:29 --> Helper loaded: url_helper
INFO - 2018-04-04 19:52:29 --> Helper loaded: file_helper
INFO - 2018-04-04 19:52:29 --> Helper loaded: date_helper
INFO - 2018-04-04 19:52:29 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:52:29 --> Controller Class Initialized
INFO - 2018-04-04 19:53:03 --> Config Class Initialized
INFO - 2018-04-04 19:53:03 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:53:03 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:53:03 --> Utf8 Class Initialized
INFO - 2018-04-04 19:53:03 --> URI Class Initialized
DEBUG - 2018-04-04 19:53:03 --> No URI present. Default controller set.
INFO - 2018-04-04 19:53:03 --> Router Class Initialized
INFO - 2018-04-04 19:53:03 --> Output Class Initialized
INFO - 2018-04-04 19:53:03 --> Security Class Initialized
DEBUG - 2018-04-04 19:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:53:03 --> Input Class Initialized
INFO - 2018-04-04 19:53:03 --> Language Class Initialized
INFO - 2018-04-04 19:53:03 --> Loader Class Initialized
INFO - 2018-04-04 19:53:03 --> Helper loaded: url_helper
INFO - 2018-04-04 19:53:03 --> Helper loaded: file_helper
INFO - 2018-04-04 19:53:03 --> Helper loaded: date_helper
INFO - 2018-04-04 19:53:03 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:53:03 --> Controller Class Initialized
INFO - 2018-04-04 19:53:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-04 19:53:03 --> Final output sent to browser
DEBUG - 2018-04-04 19:53:03 --> Total execution time: 0.2724
INFO - 2018-04-04 19:53:09 --> Config Class Initialized
INFO - 2018-04-04 19:53:09 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:53:09 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:53:09 --> Utf8 Class Initialized
INFO - 2018-04-04 19:53:09 --> URI Class Initialized
DEBUG - 2018-04-04 19:53:09 --> No URI present. Default controller set.
INFO - 2018-04-04 19:53:09 --> Router Class Initialized
INFO - 2018-04-04 19:53:09 --> Output Class Initialized
INFO - 2018-04-04 19:53:09 --> Security Class Initialized
DEBUG - 2018-04-04 19:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:53:09 --> Input Class Initialized
INFO - 2018-04-04 19:53:09 --> Language Class Initialized
INFO - 2018-04-04 19:53:09 --> Loader Class Initialized
INFO - 2018-04-04 19:53:09 --> Helper loaded: url_helper
INFO - 2018-04-04 19:53:09 --> Helper loaded: file_helper
INFO - 2018-04-04 19:53:09 --> Helper loaded: date_helper
INFO - 2018-04-04 19:53:09 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:53:09 --> Controller Class Initialized
INFO - 2018-04-04 19:53:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-04 19:53:09 --> Final output sent to browser
DEBUG - 2018-04-04 19:53:09 --> Total execution time: 0.3053
INFO - 2018-04-04 19:53:43 --> Config Class Initialized
INFO - 2018-04-04 19:53:43 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:53:43 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:53:43 --> Utf8 Class Initialized
INFO - 2018-04-04 19:53:43 --> URI Class Initialized
DEBUG - 2018-04-04 19:53:43 --> No URI present. Default controller set.
INFO - 2018-04-04 19:53:43 --> Router Class Initialized
INFO - 2018-04-04 19:53:43 --> Output Class Initialized
INFO - 2018-04-04 19:53:43 --> Security Class Initialized
DEBUG - 2018-04-04 19:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:53:43 --> Input Class Initialized
INFO - 2018-04-04 19:53:43 --> Language Class Initialized
INFO - 2018-04-04 19:53:43 --> Loader Class Initialized
INFO - 2018-04-04 19:53:43 --> Helper loaded: url_helper
INFO - 2018-04-04 19:53:43 --> Helper loaded: file_helper
INFO - 2018-04-04 19:53:43 --> Helper loaded: date_helper
INFO - 2018-04-04 19:53:43 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:53:43 --> Controller Class Initialized
INFO - 2018-04-04 19:53:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-04-04 19:53:43 --> Final output sent to browser
DEBUG - 2018-04-04 19:53:43 --> Total execution time: 0.3130
INFO - 2018-04-04 19:53:46 --> Config Class Initialized
INFO - 2018-04-04 19:53:46 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:53:46 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:53:46 --> Utf8 Class Initialized
INFO - 2018-04-04 19:53:46 --> URI Class Initialized
INFO - 2018-04-04 19:53:46 --> Router Class Initialized
INFO - 2018-04-04 19:53:46 --> Output Class Initialized
INFO - 2018-04-04 19:53:46 --> Security Class Initialized
DEBUG - 2018-04-04 19:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:53:46 --> Input Class Initialized
INFO - 2018-04-04 19:53:46 --> Language Class Initialized
INFO - 2018-04-04 19:53:46 --> Loader Class Initialized
INFO - 2018-04-04 19:53:46 --> Helper loaded: url_helper
INFO - 2018-04-04 19:53:46 --> Helper loaded: file_helper
INFO - 2018-04-04 19:53:46 --> Helper loaded: date_helper
INFO - 2018-04-04 19:53:46 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:53:46 --> Controller Class Initialized
DEBUG - 2018-04-04 19:53:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-04 19:53:46 --> Config Class Initialized
INFO - 2018-04-04 19:53:46 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:53:46 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:53:46 --> Utf8 Class Initialized
INFO - 2018-04-04 19:53:46 --> URI Class Initialized
INFO - 2018-04-04 19:53:46 --> Router Class Initialized
INFO - 2018-04-04 19:53:46 --> Output Class Initialized
INFO - 2018-04-04 19:53:46 --> Security Class Initialized
DEBUG - 2018-04-04 19:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:53:46 --> Input Class Initialized
INFO - 2018-04-04 19:53:46 --> Language Class Initialized
INFO - 2018-04-04 19:53:46 --> Loader Class Initialized
INFO - 2018-04-04 19:53:46 --> Helper loaded: url_helper
INFO - 2018-04-04 19:53:46 --> Helper loaded: file_helper
INFO - 2018-04-04 19:53:46 --> Helper loaded: date_helper
INFO - 2018-04-04 19:53:46 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:53:46 --> Controller Class Initialized
INFO - 2018-04-04 19:53:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-04 19:53:46 --> Final output sent to browser
DEBUG - 2018-04-04 19:53:46 --> Total execution time: 0.2413
INFO - 2018-04-04 19:54:32 --> Config Class Initialized
INFO - 2018-04-04 19:54:32 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:54:32 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:54:32 --> Utf8 Class Initialized
INFO - 2018-04-04 19:54:32 --> URI Class Initialized
INFO - 2018-04-04 19:54:32 --> Router Class Initialized
INFO - 2018-04-04 19:54:32 --> Output Class Initialized
INFO - 2018-04-04 19:54:32 --> Security Class Initialized
DEBUG - 2018-04-04 19:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:54:32 --> Input Class Initialized
INFO - 2018-04-04 19:54:32 --> Language Class Initialized
INFO - 2018-04-04 19:54:32 --> Loader Class Initialized
INFO - 2018-04-04 19:54:32 --> Helper loaded: url_helper
INFO - 2018-04-04 19:54:32 --> Helper loaded: file_helper
INFO - 2018-04-04 19:54:32 --> Helper loaded: date_helper
INFO - 2018-04-04 19:54:32 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:54:32 --> Controller Class Initialized
INFO - 2018-04-04 19:54:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-04 19:54:32 --> Final output sent to browser
DEBUG - 2018-04-04 19:54:32 --> Total execution time: 0.2490
INFO - 2018-04-04 19:54:42 --> Config Class Initialized
INFO - 2018-04-04 19:54:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:54:42 --> Utf8 Class Initialized
INFO - 2018-04-04 19:54:42 --> URI Class Initialized
INFO - 2018-04-04 19:54:42 --> Router Class Initialized
INFO - 2018-04-04 19:54:42 --> Output Class Initialized
INFO - 2018-04-04 19:54:42 --> Security Class Initialized
DEBUG - 2018-04-04 19:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:54:42 --> Input Class Initialized
INFO - 2018-04-04 19:54:42 --> Language Class Initialized
INFO - 2018-04-04 19:54:42 --> Loader Class Initialized
INFO - 2018-04-04 19:54:42 --> Helper loaded: url_helper
INFO - 2018-04-04 19:54:42 --> Helper loaded: file_helper
INFO - 2018-04-04 19:54:42 --> Helper loaded: date_helper
INFO - 2018-04-04 19:54:42 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:54:42 --> Controller Class Initialized
INFO - 2018-04-04 19:54:42 --> Model Class Initialized
ERROR - 2018-04-04 19:54:42 --> Severity: Notice --> Undefined property: stdClass::$user_name G:\xampp\htdocs\codeigniter\application\controllers\Auth_Controller.php 50
INFO - 2018-04-04 19:54:42 --> Final output sent to browser
DEBUG - 2018-04-04 19:54:42 --> Total execution time: 0.2530
INFO - 2018-04-04 19:54:42 --> Config Class Initialized
INFO - 2018-04-04 19:54:42 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:54:42 --> Utf8 Class Initialized
INFO - 2018-04-04 19:54:42 --> URI Class Initialized
INFO - 2018-04-04 19:54:42 --> Router Class Initialized
INFO - 2018-04-04 19:54:42 --> Output Class Initialized
INFO - 2018-04-04 19:54:42 --> Security Class Initialized
DEBUG - 2018-04-04 19:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:54:42 --> Input Class Initialized
INFO - 2018-04-04 19:54:42 --> Language Class Initialized
INFO - 2018-04-04 19:54:42 --> Loader Class Initialized
INFO - 2018-04-04 19:54:42 --> Helper loaded: url_helper
INFO - 2018-04-04 19:54:42 --> Helper loaded: file_helper
INFO - 2018-04-04 19:54:42 --> Helper loaded: date_helper
INFO - 2018-04-04 19:54:42 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:54:42 --> Controller Class Initialized
INFO - 2018-04-04 19:56:51 --> Config Class Initialized
INFO - 2018-04-04 19:56:51 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:56:51 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:56:51 --> Utf8 Class Initialized
INFO - 2018-04-04 19:56:51 --> URI Class Initialized
DEBUG - 2018-04-04 19:56:51 --> No URI present. Default controller set.
INFO - 2018-04-04 19:56:51 --> Router Class Initialized
INFO - 2018-04-04 19:56:51 --> Output Class Initialized
INFO - 2018-04-04 19:56:51 --> Security Class Initialized
DEBUG - 2018-04-04 19:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:56:51 --> Input Class Initialized
INFO - 2018-04-04 19:56:51 --> Language Class Initialized
INFO - 2018-04-04 19:56:51 --> Loader Class Initialized
INFO - 2018-04-04 19:56:51 --> Helper loaded: url_helper
INFO - 2018-04-04 19:56:51 --> Helper loaded: file_helper
INFO - 2018-04-04 19:56:51 --> Helper loaded: date_helper
INFO - 2018-04-04 19:56:51 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:56:51 --> Controller Class Initialized
INFO - 2018-04-04 19:56:53 --> Config Class Initialized
INFO - 2018-04-04 19:56:53 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:56:53 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:56:53 --> Utf8 Class Initialized
INFO - 2018-04-04 19:56:53 --> URI Class Initialized
DEBUG - 2018-04-04 19:56:53 --> No URI present. Default controller set.
INFO - 2018-04-04 19:56:53 --> Router Class Initialized
INFO - 2018-04-04 19:56:53 --> Output Class Initialized
INFO - 2018-04-04 19:56:53 --> Security Class Initialized
DEBUG - 2018-04-04 19:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:56:53 --> Input Class Initialized
INFO - 2018-04-04 19:56:53 --> Language Class Initialized
INFO - 2018-04-04 19:56:53 --> Loader Class Initialized
INFO - 2018-04-04 19:56:53 --> Helper loaded: url_helper
INFO - 2018-04-04 19:56:53 --> Helper loaded: file_helper
INFO - 2018-04-04 19:56:53 --> Helper loaded: date_helper
INFO - 2018-04-04 19:56:53 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:56:53 --> Controller Class Initialized
INFO - 2018-04-04 19:57:00 --> Config Class Initialized
INFO - 2018-04-04 19:57:00 --> Hooks Class Initialized
DEBUG - 2018-04-04 19:57:00 --> UTF-8 Support Enabled
INFO - 2018-04-04 19:57:00 --> Utf8 Class Initialized
INFO - 2018-04-04 19:57:00 --> URI Class Initialized
DEBUG - 2018-04-04 19:57:00 --> No URI present. Default controller set.
INFO - 2018-04-04 19:57:00 --> Router Class Initialized
INFO - 2018-04-04 19:57:00 --> Output Class Initialized
INFO - 2018-04-04 19:57:00 --> Security Class Initialized
DEBUG - 2018-04-04 19:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 19:57:00 --> Input Class Initialized
INFO - 2018-04-04 19:57:00 --> Language Class Initialized
INFO - 2018-04-04 19:57:00 --> Loader Class Initialized
INFO - 2018-04-04 19:57:00 --> Helper loaded: url_helper
INFO - 2018-04-04 19:57:00 --> Helper loaded: file_helper
INFO - 2018-04-04 19:57:00 --> Helper loaded: date_helper
INFO - 2018-04-04 19:57:00 --> Database Driver Class Initialized
DEBUG - 2018-04-04 19:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 19:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 19:57:00 --> Controller Class Initialized
INFO - 2018-04-04 20:01:01 --> Config Class Initialized
INFO - 2018-04-04 20:01:01 --> Hooks Class Initialized
DEBUG - 2018-04-04 20:01:01 --> UTF-8 Support Enabled
INFO - 2018-04-04 20:01:01 --> Utf8 Class Initialized
INFO - 2018-04-04 20:01:01 --> URI Class Initialized
DEBUG - 2018-04-04 20:01:01 --> No URI present. Default controller set.
INFO - 2018-04-04 20:01:01 --> Router Class Initialized
INFO - 2018-04-04 20:01:01 --> Output Class Initialized
INFO - 2018-04-04 20:01:01 --> Security Class Initialized
DEBUG - 2018-04-04 20:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 20:01:01 --> Input Class Initialized
INFO - 2018-04-04 20:01:01 --> Language Class Initialized
INFO - 2018-04-04 20:01:01 --> Loader Class Initialized
INFO - 2018-04-04 20:01:01 --> Helper loaded: url_helper
INFO - 2018-04-04 20:01:01 --> Helper loaded: file_helper
INFO - 2018-04-04 20:01:01 --> Helper loaded: date_helper
INFO - 2018-04-04 20:01:01 --> Database Driver Class Initialized
DEBUG - 2018-04-04 20:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 20:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 20:01:01 --> Controller Class Initialized
INFO - 2018-04-04 20:01:45 --> Config Class Initialized
INFO - 2018-04-04 20:01:45 --> Hooks Class Initialized
DEBUG - 2018-04-04 20:01:45 --> UTF-8 Support Enabled
INFO - 2018-04-04 20:01:45 --> Utf8 Class Initialized
INFO - 2018-04-04 20:01:45 --> URI Class Initialized
DEBUG - 2018-04-04 20:01:45 --> No URI present. Default controller set.
INFO - 2018-04-04 20:01:45 --> Router Class Initialized
INFO - 2018-04-04 20:01:45 --> Output Class Initialized
INFO - 2018-04-04 20:01:45 --> Security Class Initialized
DEBUG - 2018-04-04 20:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 20:01:45 --> Input Class Initialized
INFO - 2018-04-04 20:01:45 --> Language Class Initialized
INFO - 2018-04-04 20:01:45 --> Loader Class Initialized
INFO - 2018-04-04 20:01:45 --> Helper loaded: url_helper
INFO - 2018-04-04 20:01:45 --> Helper loaded: file_helper
INFO - 2018-04-04 20:01:45 --> Helper loaded: date_helper
INFO - 2018-04-04 20:01:45 --> Database Driver Class Initialized
DEBUG - 2018-04-04 20:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 20:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 20:01:45 --> Controller Class Initialized
INFO - 2018-04-04 20:02:08 --> Config Class Initialized
INFO - 2018-04-04 20:02:08 --> Hooks Class Initialized
DEBUG - 2018-04-04 20:02:08 --> UTF-8 Support Enabled
INFO - 2018-04-04 20:02:08 --> Utf8 Class Initialized
INFO - 2018-04-04 20:02:08 --> URI Class Initialized
DEBUG - 2018-04-04 20:02:08 --> No URI present. Default controller set.
INFO - 2018-04-04 20:02:08 --> Router Class Initialized
INFO - 2018-04-04 20:02:08 --> Output Class Initialized
INFO - 2018-04-04 20:02:08 --> Security Class Initialized
DEBUG - 2018-04-04 20:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-04 20:02:08 --> Input Class Initialized
INFO - 2018-04-04 20:02:08 --> Language Class Initialized
INFO - 2018-04-04 20:02:08 --> Loader Class Initialized
INFO - 2018-04-04 20:02:08 --> Helper loaded: url_helper
INFO - 2018-04-04 20:02:08 --> Helper loaded: file_helper
INFO - 2018-04-04 20:02:08 --> Helper loaded: date_helper
INFO - 2018-04-04 20:02:08 --> Database Driver Class Initialized
DEBUG - 2018-04-04 20:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-04 20:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-04 20:02:08 --> Controller Class Initialized
