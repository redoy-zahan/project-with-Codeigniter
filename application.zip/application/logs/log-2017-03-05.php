<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-05 11:53:06 --> Config Class Initialized
INFO - 2017-03-05 11:53:06 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:06 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:06 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:06 --> URI Class Initialized
DEBUG - 2017-03-05 11:53:06 --> No URI present. Default controller set.
INFO - 2017-03-05 11:53:06 --> Router Class Initialized
INFO - 2017-03-05 11:53:06 --> Output Class Initialized
INFO - 2017-03-05 11:53:06 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:06 --> Input Class Initialized
INFO - 2017-03-05 11:53:06 --> Language Class Initialized
INFO - 2017-03-05 11:53:06 --> Loader Class Initialized
INFO - 2017-03-05 11:53:06 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:06 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:06 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:06 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:06 --> Controller Class Initialized
INFO - 2017-03-05 11:53:06 --> Config Class Initialized
INFO - 2017-03-05 11:53:06 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:06 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:06 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:06 --> URI Class Initialized
INFO - 2017-03-05 11:53:06 --> Router Class Initialized
INFO - 2017-03-05 11:53:06 --> Output Class Initialized
INFO - 2017-03-05 11:53:06 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:06 --> Input Class Initialized
INFO - 2017-03-05 11:53:06 --> Language Class Initialized
INFO - 2017-03-05 11:53:06 --> Loader Class Initialized
INFO - 2017-03-05 11:53:06 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:06 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:06 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:06 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:06 --> Controller Class Initialized
INFO - 2017-03-05 11:53:06 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-05 11:53:06 --> Final output sent to browser
DEBUG - 2017-03-05 11:53:06 --> Total execution time: 0.0207
INFO - 2017-03-05 11:53:11 --> Config Class Initialized
INFO - 2017-03-05 11:53:11 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:11 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:11 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:11 --> URI Class Initialized
INFO - 2017-03-05 11:53:11 --> Router Class Initialized
INFO - 2017-03-05 11:53:11 --> Output Class Initialized
INFO - 2017-03-05 11:53:11 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:11 --> Input Class Initialized
INFO - 2017-03-05 11:53:11 --> Language Class Initialized
INFO - 2017-03-05 11:53:11 --> Loader Class Initialized
INFO - 2017-03-05 11:53:11 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:11 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:11 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:11 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:11 --> Controller Class Initialized
INFO - 2017-03-05 11:53:11 --> Model Class Initialized
INFO - 2017-03-05 11:53:11 --> Final output sent to browser
DEBUG - 2017-03-05 11:53:11 --> Total execution time: 0.0426
INFO - 2017-03-05 11:53:12 --> Config Class Initialized
INFO - 2017-03-05 11:53:12 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:12 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:12 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:12 --> URI Class Initialized
INFO - 2017-03-05 11:53:12 --> Router Class Initialized
INFO - 2017-03-05 11:53:12 --> Output Class Initialized
INFO - 2017-03-05 11:53:12 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:12 --> Input Class Initialized
INFO - 2017-03-05 11:53:12 --> Language Class Initialized
INFO - 2017-03-05 11:53:12 --> Loader Class Initialized
INFO - 2017-03-05 11:53:12 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:12 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:12 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:12 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:12 --> Controller Class Initialized
INFO - 2017-03-05 11:53:12 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/header.php
INFO - 2017-03-05 11:53:12 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/left.php
INFO - 2017-03-05 11:53:12 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/dashboard.php
INFO - 2017-03-05 11:53:12 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/footer.php
INFO - 2017-03-05 11:53:12 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_admin/index.php
INFO - 2017-03-05 11:53:12 --> Final output sent to browser
DEBUG - 2017-03-05 11:53:12 --> Total execution time: 0.0460
INFO - 2017-03-05 11:53:18 --> Config Class Initialized
INFO - 2017-03-05 11:53:18 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:18 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:18 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:18 --> URI Class Initialized
INFO - 2017-03-05 11:53:18 --> Router Class Initialized
INFO - 2017-03-05 11:53:18 --> Output Class Initialized
INFO - 2017-03-05 11:53:18 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:18 --> Input Class Initialized
INFO - 2017-03-05 11:53:18 --> Language Class Initialized
INFO - 2017-03-05 11:53:18 --> Loader Class Initialized
INFO - 2017-03-05 11:53:18 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:18 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:18 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:18 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:18 --> Controller Class Initialized
DEBUG - 2017-03-05 11:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 11:53:18 --> Config Class Initialized
INFO - 2017-03-05 11:53:18 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:18 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:18 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:18 --> URI Class Initialized
INFO - 2017-03-05 11:53:18 --> Router Class Initialized
INFO - 2017-03-05 11:53:18 --> Output Class Initialized
INFO - 2017-03-05 11:53:18 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:18 --> Input Class Initialized
INFO - 2017-03-05 11:53:18 --> Language Class Initialized
INFO - 2017-03-05 11:53:18 --> Loader Class Initialized
INFO - 2017-03-05 11:53:18 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:18 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:18 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:18 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:19 --> Controller Class Initialized
INFO - 2017-03-05 11:53:19 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-05 11:53:19 --> Final output sent to browser
DEBUG - 2017-03-05 11:53:19 --> Total execution time: 0.0168
INFO - 2017-03-05 11:53:25 --> Config Class Initialized
INFO - 2017-03-05 11:53:25 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:25 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:25 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:25 --> URI Class Initialized
INFO - 2017-03-05 11:53:25 --> Router Class Initialized
INFO - 2017-03-05 11:53:25 --> Output Class Initialized
INFO - 2017-03-05 11:53:25 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:25 --> Input Class Initialized
INFO - 2017-03-05 11:53:25 --> Language Class Initialized
INFO - 2017-03-05 11:53:25 --> Loader Class Initialized
INFO - 2017-03-05 11:53:25 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:25 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:25 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:25 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:25 --> Controller Class Initialized
INFO - 2017-03-05 11:53:25 --> Model Class Initialized
INFO - 2017-03-05 11:53:26 --> Config Class Initialized
INFO - 2017-03-05 11:53:26 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:26 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:26 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:26 --> URI Class Initialized
INFO - 2017-03-05 11:53:26 --> Router Class Initialized
INFO - 2017-03-05 11:53:26 --> Output Class Initialized
INFO - 2017-03-05 11:53:26 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:26 --> Input Class Initialized
INFO - 2017-03-05 11:53:26 --> Language Class Initialized
INFO - 2017-03-05 11:53:26 --> Loader Class Initialized
INFO - 2017-03-05 11:53:26 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:26 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:26 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:26 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:26 --> Controller Class Initialized
INFO - 2017-03-05 11:53:26 --> Model Class Initialized
INFO - 2017-03-05 11:53:26 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/header.php
INFO - 2017-03-05 11:53:26 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/left.php
INFO - 2017-03-05 11:53:26 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/dashboard.php
INFO - 2017-03-05 11:53:26 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/footer.php
INFO - 2017-03-05 11:53:26 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/index.php
INFO - 2017-03-05 11:53:26 --> Final output sent to browser
DEBUG - 2017-03-05 11:53:26 --> Total execution time: 0.0230
INFO - 2017-03-05 11:53:30 --> Config Class Initialized
INFO - 2017-03-05 11:53:30 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:30 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:30 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:30 --> URI Class Initialized
INFO - 2017-03-05 11:53:30 --> Router Class Initialized
INFO - 2017-03-05 11:53:30 --> Output Class Initialized
INFO - 2017-03-05 11:53:30 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:30 --> Input Class Initialized
INFO - 2017-03-05 11:53:30 --> Language Class Initialized
INFO - 2017-03-05 11:53:30 --> Loader Class Initialized
INFO - 2017-03-05 11:53:30 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:30 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:30 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:30 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:30 --> Controller Class Initialized
INFO - 2017-03-05 11:53:30 --> Model Class Initialized
INFO - 2017-03-05 11:53:30 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/header.php
INFO - 2017-03-05 11:53:30 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/left.php
INFO - 2017-03-05 11:53:30 --> File loaded: /home/thestudytown/public_html/mcq/application/views/student/exam_view.php
INFO - 2017-03-05 11:53:30 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/footer.php
INFO - 2017-03-05 11:53:30 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/index.php
INFO - 2017-03-05 11:53:30 --> Final output sent to browser
DEBUG - 2017-03-05 11:53:30 --> Total execution time: 0.0252
INFO - 2017-03-05 11:53:32 --> Config Class Initialized
INFO - 2017-03-05 11:53:32 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:32 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:32 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:32 --> URI Class Initialized
INFO - 2017-03-05 11:53:32 --> Router Class Initialized
INFO - 2017-03-05 11:53:32 --> Output Class Initialized
INFO - 2017-03-05 11:53:32 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:32 --> Input Class Initialized
INFO - 2017-03-05 11:53:32 --> Language Class Initialized
INFO - 2017-03-05 11:53:32 --> Loader Class Initialized
INFO - 2017-03-05 11:53:32 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:32 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:32 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:32 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:32 --> Controller Class Initialized
INFO - 2017-03-05 11:53:32 --> Model Class Initialized
INFO - 2017-03-05 11:53:32 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/header.php
INFO - 2017-03-05 11:53:32 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/left.php
INFO - 2017-03-05 11:53:32 --> File loaded: /home/thestudytown/public_html/mcq/application/views/student/taken_exam.php
INFO - 2017-03-05 11:53:32 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/footer.php
INFO - 2017-03-05 11:53:32 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/index.php
INFO - 2017-03-05 11:53:32 --> Final output sent to browser
DEBUG - 2017-03-05 11:53:32 --> Total execution time: 0.0190
INFO - 2017-03-05 11:53:34 --> Config Class Initialized
INFO - 2017-03-05 11:53:34 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:34 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:34 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:34 --> URI Class Initialized
DEBUG - 2017-03-05 11:53:34 --> No URI present. Default controller set.
INFO - 2017-03-05 11:53:34 --> Router Class Initialized
INFO - 2017-03-05 11:53:34 --> Output Class Initialized
INFO - 2017-03-05 11:53:34 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:34 --> Input Class Initialized
INFO - 2017-03-05 11:53:34 --> Language Class Initialized
INFO - 2017-03-05 11:53:34 --> Loader Class Initialized
INFO - 2017-03-05 11:53:34 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:34 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:34 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:34 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:34 --> Controller Class Initialized
INFO - 2017-03-05 11:53:35 --> Config Class Initialized
INFO - 2017-03-05 11:53:35 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:53:35 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:53:35 --> Utf8 Class Initialized
INFO - 2017-03-05 11:53:35 --> URI Class Initialized
INFO - 2017-03-05 11:53:35 --> Router Class Initialized
INFO - 2017-03-05 11:53:35 --> Output Class Initialized
INFO - 2017-03-05 11:53:35 --> Security Class Initialized
DEBUG - 2017-03-05 11:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:53:35 --> Input Class Initialized
INFO - 2017-03-05 11:53:35 --> Language Class Initialized
INFO - 2017-03-05 11:53:35 --> Loader Class Initialized
INFO - 2017-03-05 11:53:35 --> Helper loaded: url_helper
INFO - 2017-03-05 11:53:35 --> Helper loaded: file_helper
INFO - 2017-03-05 11:53:35 --> Helper loaded: date_helper
INFO - 2017-03-05 11:53:35 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:53:35 --> Controller Class Initialized
INFO - 2017-03-05 11:53:35 --> Model Class Initialized
INFO - 2017-03-05 11:53:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/header.php
INFO - 2017-03-05 11:53:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/left.php
INFO - 2017-03-05 11:53:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/dashboard.php
INFO - 2017-03-05 11:53:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/footer.php
INFO - 2017-03-05 11:53:35 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/index.php
INFO - 2017-03-05 11:53:35 --> Final output sent to browser
DEBUG - 2017-03-05 11:53:35 --> Total execution time: 0.0295
INFO - 2017-03-05 11:54:12 --> Config Class Initialized
INFO - 2017-03-05 11:54:12 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:54:12 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:54:12 --> Utf8 Class Initialized
INFO - 2017-03-05 11:54:12 --> URI Class Initialized
INFO - 2017-03-05 11:54:12 --> Router Class Initialized
INFO - 2017-03-05 11:54:12 --> Output Class Initialized
INFO - 2017-03-05 11:54:12 --> Security Class Initialized
DEBUG - 2017-03-05 11:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:54:12 --> Input Class Initialized
INFO - 2017-03-05 11:54:12 --> Language Class Initialized
INFO - 2017-03-05 11:54:12 --> Loader Class Initialized
INFO - 2017-03-05 11:54:12 --> Helper loaded: url_helper
INFO - 2017-03-05 11:54:12 --> Helper loaded: file_helper
INFO - 2017-03-05 11:54:12 --> Helper loaded: date_helper
INFO - 2017-03-05 11:54:12 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:54:12 --> Controller Class Initialized
INFO - 2017-03-05 11:54:13 --> Config Class Initialized
INFO - 2017-03-05 11:54:13 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:54:13 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:54:13 --> Utf8 Class Initialized
INFO - 2017-03-05 11:54:13 --> URI Class Initialized
INFO - 2017-03-05 11:54:13 --> Router Class Initialized
INFO - 2017-03-05 11:54:13 --> Output Class Initialized
INFO - 2017-03-05 11:54:13 --> Security Class Initialized
DEBUG - 2017-03-05 11:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:54:13 --> Input Class Initialized
INFO - 2017-03-05 11:54:13 --> Language Class Initialized
INFO - 2017-03-05 11:54:13 --> Loader Class Initialized
INFO - 2017-03-05 11:54:13 --> Helper loaded: url_helper
INFO - 2017-03-05 11:54:13 --> Helper loaded: file_helper
INFO - 2017-03-05 11:54:13 --> Helper loaded: date_helper
INFO - 2017-03-05 11:54:13 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:54:13 --> Controller Class Initialized
INFO - 2017-03-05 11:54:13 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-05 11:54:13 --> Final output sent to browser
DEBUG - 2017-03-05 11:54:13 --> Total execution time: 0.0175
INFO - 2017-03-05 11:57:23 --> Config Class Initialized
INFO - 2017-03-05 11:57:23 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:57:23 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:57:23 --> Utf8 Class Initialized
INFO - 2017-03-05 11:57:23 --> URI Class Initialized
DEBUG - 2017-03-05 11:57:23 --> No URI present. Default controller set.
INFO - 2017-03-05 11:57:23 --> Router Class Initialized
INFO - 2017-03-05 11:57:23 --> Output Class Initialized
INFO - 2017-03-05 11:57:23 --> Security Class Initialized
DEBUG - 2017-03-05 11:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:57:23 --> Input Class Initialized
INFO - 2017-03-05 11:57:23 --> Language Class Initialized
INFO - 2017-03-05 11:57:23 --> Loader Class Initialized
INFO - 2017-03-05 11:57:23 --> Helper loaded: url_helper
INFO - 2017-03-05 11:57:23 --> Helper loaded: file_helper
INFO - 2017-03-05 11:57:23 --> Helper loaded: date_helper
INFO - 2017-03-05 11:57:23 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:57:23 --> Controller Class Initialized
INFO - 2017-03-05 11:57:24 --> Config Class Initialized
INFO - 2017-03-05 11:57:24 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:57:24 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:57:24 --> Utf8 Class Initialized
INFO - 2017-03-05 11:57:24 --> URI Class Initialized
INFO - 2017-03-05 11:57:24 --> Router Class Initialized
INFO - 2017-03-05 11:57:24 --> Output Class Initialized
INFO - 2017-03-05 11:57:24 --> Security Class Initialized
DEBUG - 2017-03-05 11:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:57:24 --> Input Class Initialized
INFO - 2017-03-05 11:57:24 --> Language Class Initialized
INFO - 2017-03-05 11:57:24 --> Loader Class Initialized
INFO - 2017-03-05 11:57:24 --> Helper loaded: url_helper
INFO - 2017-03-05 11:57:24 --> Helper loaded: file_helper
INFO - 2017-03-05 11:57:24 --> Helper loaded: date_helper
INFO - 2017-03-05 11:57:24 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:57:24 --> Controller Class Initialized
INFO - 2017-03-05 11:57:24 --> Model Class Initialized
INFO - 2017-03-05 11:57:24 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/header.php
INFO - 2017-03-05 11:57:24 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/left.php
INFO - 2017-03-05 11:57:24 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/dashboard.php
INFO - 2017-03-05 11:57:24 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/footer.php
INFO - 2017-03-05 11:57:24 --> File loaded: /home/thestudytown/public_html/mcq/application/views/layout_student/index.php
INFO - 2017-03-05 11:57:24 --> Final output sent to browser
DEBUG - 2017-03-05 11:57:24 --> Total execution time: 0.0184
INFO - 2017-03-05 11:57:27 --> Config Class Initialized
INFO - 2017-03-05 11:57:27 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:57:27 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:57:27 --> Utf8 Class Initialized
INFO - 2017-03-05 11:57:27 --> URI Class Initialized
INFO - 2017-03-05 11:57:27 --> Router Class Initialized
INFO - 2017-03-05 11:57:27 --> Output Class Initialized
INFO - 2017-03-05 11:57:27 --> Security Class Initialized
DEBUG - 2017-03-05 11:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:57:27 --> Input Class Initialized
INFO - 2017-03-05 11:57:27 --> Language Class Initialized
INFO - 2017-03-05 11:57:27 --> Loader Class Initialized
INFO - 2017-03-05 11:57:27 --> Helper loaded: url_helper
INFO - 2017-03-05 11:57:27 --> Helper loaded: file_helper
INFO - 2017-03-05 11:57:27 --> Helper loaded: date_helper
INFO - 2017-03-05 11:57:27 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:57:27 --> Controller Class Initialized
DEBUG - 2017-03-05 11:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-03-05 11:57:27 --> Config Class Initialized
INFO - 2017-03-05 11:57:27 --> Hooks Class Initialized
DEBUG - 2017-03-05 11:57:27 --> UTF-8 Support Enabled
INFO - 2017-03-05 11:57:27 --> Utf8 Class Initialized
INFO - 2017-03-05 11:57:27 --> URI Class Initialized
INFO - 2017-03-05 11:57:27 --> Router Class Initialized
INFO - 2017-03-05 11:57:27 --> Output Class Initialized
INFO - 2017-03-05 11:57:27 --> Security Class Initialized
DEBUG - 2017-03-05 11:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 11:57:27 --> Input Class Initialized
INFO - 2017-03-05 11:57:27 --> Language Class Initialized
INFO - 2017-03-05 11:57:27 --> Loader Class Initialized
INFO - 2017-03-05 11:57:27 --> Helper loaded: url_helper
INFO - 2017-03-05 11:57:27 --> Helper loaded: file_helper
INFO - 2017-03-05 11:57:27 --> Helper loaded: date_helper
INFO - 2017-03-05 11:57:27 --> Database Driver Class Initialized
DEBUG - 2017-03-05 11:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 11:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 11:57:27 --> Controller Class Initialized
INFO - 2017-03-05 11:57:27 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-03-05 11:57:27 --> Final output sent to browser
DEBUG - 2017-03-05 11:57:27 --> Total execution time: 0.0170
