<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-07 04:54:42 --> Config Class Initialized
INFO - 2018-04-07 04:54:42 --> Hooks Class Initialized
DEBUG - 2018-04-07 04:54:42 --> UTF-8 Support Enabled
INFO - 2018-04-07 04:54:42 --> Utf8 Class Initialized
INFO - 2018-04-07 04:54:42 --> URI Class Initialized
DEBUG - 2018-04-07 04:54:42 --> No URI present. Default controller set.
INFO - 2018-04-07 04:54:42 --> Router Class Initialized
INFO - 2018-04-07 04:54:42 --> Output Class Initialized
INFO - 2018-04-07 04:54:42 --> Security Class Initialized
DEBUG - 2018-04-07 04:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 04:54:42 --> Input Class Initialized
INFO - 2018-04-07 04:54:42 --> Language Class Initialized
INFO - 2018-04-07 04:54:42 --> Loader Class Initialized
INFO - 2018-04-07 04:54:42 --> Helper loaded: url_helper
INFO - 2018-04-07 04:54:42 --> Helper loaded: file_helper
INFO - 2018-04-07 04:54:42 --> Helper loaded: date_helper
INFO - 2018-04-07 04:54:42 --> Database Driver Class Initialized
DEBUG - 2018-04-07 04:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 04:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 04:54:43 --> Controller Class Initialized
INFO - 2018-04-07 04:54:43 --> Config Class Initialized
INFO - 2018-04-07 04:54:43 --> Hooks Class Initialized
DEBUG - 2018-04-07 04:54:43 --> UTF-8 Support Enabled
INFO - 2018-04-07 04:54:43 --> Utf8 Class Initialized
INFO - 2018-04-07 04:54:43 --> URI Class Initialized
INFO - 2018-04-07 04:54:43 --> Router Class Initialized
INFO - 2018-04-07 04:54:43 --> Output Class Initialized
INFO - 2018-04-07 04:54:43 --> Security Class Initialized
DEBUG - 2018-04-07 04:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 04:54:43 --> Input Class Initialized
INFO - 2018-04-07 04:54:43 --> Language Class Initialized
INFO - 2018-04-07 04:54:43 --> Loader Class Initialized
INFO - 2018-04-07 04:54:43 --> Helper loaded: url_helper
INFO - 2018-04-07 04:54:43 --> Helper loaded: file_helper
INFO - 2018-04-07 04:54:43 --> Helper loaded: date_helper
INFO - 2018-04-07 04:54:43 --> Database Driver Class Initialized
DEBUG - 2018-04-07 04:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 04:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 04:54:43 --> Controller Class Initialized
INFO - 2018-04-07 04:54:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 04:54:43 --> Final output sent to browser
DEBUG - 2018-04-07 04:54:43 --> Total execution time: 0.2413
INFO - 2018-04-07 04:55:15 --> Config Class Initialized
INFO - 2018-04-07 04:55:15 --> Hooks Class Initialized
DEBUG - 2018-04-07 04:55:15 --> UTF-8 Support Enabled
INFO - 2018-04-07 04:55:15 --> Utf8 Class Initialized
INFO - 2018-04-07 04:55:15 --> URI Class Initialized
INFO - 2018-04-07 04:55:15 --> Router Class Initialized
INFO - 2018-04-07 04:55:15 --> Output Class Initialized
INFO - 2018-04-07 04:55:15 --> Security Class Initialized
DEBUG - 2018-04-07 04:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 04:55:15 --> Input Class Initialized
INFO - 2018-04-07 04:55:15 --> Language Class Initialized
INFO - 2018-04-07 04:55:15 --> Loader Class Initialized
INFO - 2018-04-07 04:55:15 --> Helper loaded: url_helper
INFO - 2018-04-07 04:55:15 --> Helper loaded: file_helper
INFO - 2018-04-07 04:55:15 --> Helper loaded: date_helper
INFO - 2018-04-07 04:55:15 --> Database Driver Class Initialized
DEBUG - 2018-04-07 04:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 04:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 04:55:15 --> Controller Class Initialized
INFO - 2018-04-07 04:55:15 --> Model Class Initialized
ERROR - 2018-04-07 04:55:15 --> Severity: Notice --> Undefined variable: email G:\xampp\htdocs\codeigniter\application\models\User_Model.php 27
INFO - 2018-04-07 04:56:29 --> Config Class Initialized
INFO - 2018-04-07 04:56:29 --> Hooks Class Initialized
DEBUG - 2018-04-07 04:56:29 --> UTF-8 Support Enabled
INFO - 2018-04-07 04:56:29 --> Utf8 Class Initialized
INFO - 2018-04-07 04:56:29 --> URI Class Initialized
INFO - 2018-04-07 04:56:29 --> Router Class Initialized
INFO - 2018-04-07 04:56:29 --> Output Class Initialized
INFO - 2018-04-07 04:56:29 --> Security Class Initialized
DEBUG - 2018-04-07 04:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 04:56:29 --> Input Class Initialized
INFO - 2018-04-07 04:56:29 --> Language Class Initialized
INFO - 2018-04-07 04:56:29 --> Loader Class Initialized
INFO - 2018-04-07 04:56:29 --> Helper loaded: url_helper
INFO - 2018-04-07 04:56:29 --> Helper loaded: file_helper
INFO - 2018-04-07 04:56:29 --> Helper loaded: date_helper
INFO - 2018-04-07 04:56:29 --> Database Driver Class Initialized
DEBUG - 2018-04-07 04:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 04:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 04:56:29 --> Controller Class Initialized
INFO - 2018-04-07 04:56:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 04:56:29 --> Final output sent to browser
DEBUG - 2018-04-07 04:56:29 --> Total execution time: 0.2418
INFO - 2018-04-07 04:56:32 --> Config Class Initialized
INFO - 2018-04-07 04:56:32 --> Hooks Class Initialized
DEBUG - 2018-04-07 04:56:32 --> UTF-8 Support Enabled
INFO - 2018-04-07 04:56:32 --> Utf8 Class Initialized
INFO - 2018-04-07 04:56:32 --> URI Class Initialized
INFO - 2018-04-07 04:56:32 --> Router Class Initialized
INFO - 2018-04-07 04:56:32 --> Output Class Initialized
INFO - 2018-04-07 04:56:32 --> Security Class Initialized
DEBUG - 2018-04-07 04:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 04:56:32 --> Input Class Initialized
INFO - 2018-04-07 04:56:32 --> Language Class Initialized
INFO - 2018-04-07 04:56:32 --> Loader Class Initialized
INFO - 2018-04-07 04:56:32 --> Helper loaded: url_helper
INFO - 2018-04-07 04:56:32 --> Helper loaded: file_helper
INFO - 2018-04-07 04:56:32 --> Helper loaded: date_helper
INFO - 2018-04-07 04:56:32 --> Database Driver Class Initialized
DEBUG - 2018-04-07 04:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 04:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 04:56:32 --> Controller Class Initialized
INFO - 2018-04-07 04:56:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 04:56:32 --> Final output sent to browser
DEBUG - 2018-04-07 04:56:32 --> Total execution time: 0.2346
INFO - 2018-04-07 04:57:28 --> Config Class Initialized
INFO - 2018-04-07 04:57:28 --> Hooks Class Initialized
DEBUG - 2018-04-07 04:57:28 --> UTF-8 Support Enabled
INFO - 2018-04-07 04:57:28 --> Utf8 Class Initialized
INFO - 2018-04-07 04:57:28 --> URI Class Initialized
INFO - 2018-04-07 04:57:29 --> Router Class Initialized
INFO - 2018-04-07 04:57:29 --> Output Class Initialized
INFO - 2018-04-07 04:57:29 --> Security Class Initialized
DEBUG - 2018-04-07 04:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 04:57:29 --> Input Class Initialized
INFO - 2018-04-07 04:57:29 --> Language Class Initialized
INFO - 2018-04-07 04:57:29 --> Loader Class Initialized
INFO - 2018-04-07 04:57:29 --> Helper loaded: url_helper
INFO - 2018-04-07 04:57:29 --> Helper loaded: file_helper
INFO - 2018-04-07 04:57:29 --> Helper loaded: date_helper
INFO - 2018-04-07 04:57:29 --> Database Driver Class Initialized
DEBUG - 2018-04-07 04:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 04:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 04:57:29 --> Controller Class Initialized
INFO - 2018-04-07 04:57:29 --> Model Class Initialized
ERROR - 2018-04-07 04:57:29 --> Severity: Notice --> Undefined variable: email G:\xampp\htdocs\codeigniter\application\models\User_Model.php 27
INFO - 2018-04-07 05:00:31 --> Config Class Initialized
INFO - 2018-04-07 05:00:31 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:00:31 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:00:32 --> Utf8 Class Initialized
INFO - 2018-04-07 05:00:32 --> URI Class Initialized
INFO - 2018-04-07 05:00:32 --> Router Class Initialized
INFO - 2018-04-07 05:00:32 --> Output Class Initialized
INFO - 2018-04-07 05:00:32 --> Security Class Initialized
DEBUG - 2018-04-07 05:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:00:32 --> Input Class Initialized
INFO - 2018-04-07 05:00:32 --> Language Class Initialized
INFO - 2018-04-07 05:00:32 --> Loader Class Initialized
INFO - 2018-04-07 05:00:32 --> Helper loaded: url_helper
INFO - 2018-04-07 05:00:32 --> Helper loaded: file_helper
INFO - 2018-04-07 05:00:32 --> Helper loaded: date_helper
INFO - 2018-04-07 05:00:32 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:00:32 --> Controller Class Initialized
INFO - 2018-04-07 05:00:32 --> Model Class Initialized
INFO - 2018-04-07 05:00:52 --> Config Class Initialized
INFO - 2018-04-07 05:00:52 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:00:52 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:00:52 --> Utf8 Class Initialized
INFO - 2018-04-07 05:00:52 --> URI Class Initialized
DEBUG - 2018-04-07 05:00:52 --> No URI present. Default controller set.
INFO - 2018-04-07 05:00:52 --> Router Class Initialized
INFO - 2018-04-07 05:00:53 --> Output Class Initialized
INFO - 2018-04-07 05:00:53 --> Security Class Initialized
DEBUG - 2018-04-07 05:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:00:53 --> Input Class Initialized
INFO - 2018-04-07 05:00:53 --> Language Class Initialized
INFO - 2018-04-07 05:00:53 --> Loader Class Initialized
INFO - 2018-04-07 05:00:53 --> Helper loaded: url_helper
INFO - 2018-04-07 05:00:53 --> Helper loaded: file_helper
INFO - 2018-04-07 05:00:53 --> Helper loaded: date_helper
INFO - 2018-04-07 05:00:53 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:00:53 --> Controller Class Initialized
INFO - 2018-04-07 05:00:53 --> Config Class Initialized
INFO - 2018-04-07 05:00:53 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:00:53 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:00:53 --> Utf8 Class Initialized
INFO - 2018-04-07 05:00:53 --> URI Class Initialized
INFO - 2018-04-07 05:00:53 --> Router Class Initialized
INFO - 2018-04-07 05:00:53 --> Output Class Initialized
INFO - 2018-04-07 05:00:53 --> Security Class Initialized
DEBUG - 2018-04-07 05:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:00:53 --> Input Class Initialized
INFO - 2018-04-07 05:00:53 --> Language Class Initialized
INFO - 2018-04-07 05:00:53 --> Loader Class Initialized
INFO - 2018-04-07 05:00:53 --> Helper loaded: url_helper
INFO - 2018-04-07 05:00:53 --> Helper loaded: file_helper
INFO - 2018-04-07 05:00:53 --> Helper loaded: date_helper
INFO - 2018-04-07 05:00:53 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:00:53 --> Controller Class Initialized
INFO - 2018-04-07 05:00:53 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 05:00:53 --> Final output sent to browser
DEBUG - 2018-04-07 05:00:53 --> Total execution time: 0.2267
INFO - 2018-04-07 05:01:02 --> Config Class Initialized
INFO - 2018-04-07 05:01:02 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:01:02 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:01:03 --> Utf8 Class Initialized
INFO - 2018-04-07 05:01:03 --> URI Class Initialized
INFO - 2018-04-07 05:01:03 --> Router Class Initialized
INFO - 2018-04-07 05:01:03 --> Output Class Initialized
INFO - 2018-04-07 05:01:03 --> Security Class Initialized
DEBUG - 2018-04-07 05:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:01:03 --> Input Class Initialized
INFO - 2018-04-07 05:01:03 --> Language Class Initialized
INFO - 2018-04-07 05:01:03 --> Loader Class Initialized
INFO - 2018-04-07 05:01:03 --> Helper loaded: url_helper
INFO - 2018-04-07 05:01:03 --> Helper loaded: file_helper
INFO - 2018-04-07 05:01:03 --> Helper loaded: date_helper
INFO - 2018-04-07 05:01:03 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:01:03 --> Controller Class Initialized
INFO - 2018-04-07 05:01:03 --> Model Class Initialized
INFO - 2018-04-07 05:03:10 --> Config Class Initialized
INFO - 2018-04-07 05:03:10 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:03:10 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:03:10 --> Utf8 Class Initialized
INFO - 2018-04-07 05:03:10 --> URI Class Initialized
INFO - 2018-04-07 05:03:10 --> Router Class Initialized
INFO - 2018-04-07 05:03:10 --> Output Class Initialized
INFO - 2018-04-07 05:03:10 --> Security Class Initialized
DEBUG - 2018-04-07 05:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:03:10 --> Input Class Initialized
INFO - 2018-04-07 05:03:10 --> Language Class Initialized
INFO - 2018-04-07 05:03:10 --> Loader Class Initialized
INFO - 2018-04-07 05:03:10 --> Helper loaded: url_helper
INFO - 2018-04-07 05:03:10 --> Helper loaded: file_helper
INFO - 2018-04-07 05:03:10 --> Helper loaded: date_helper
INFO - 2018-04-07 05:03:10 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:03:11 --> Controller Class Initialized
INFO - 2018-04-07 05:03:11 --> Model Class Initialized
INFO - 2018-04-07 05:03:48 --> Config Class Initialized
INFO - 2018-04-07 05:03:48 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:03:48 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:03:48 --> Utf8 Class Initialized
INFO - 2018-04-07 05:03:48 --> URI Class Initialized
INFO - 2018-04-07 05:03:48 --> Router Class Initialized
INFO - 2018-04-07 05:03:48 --> Output Class Initialized
INFO - 2018-04-07 05:03:48 --> Security Class Initialized
DEBUG - 2018-04-07 05:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:03:48 --> Input Class Initialized
INFO - 2018-04-07 05:03:48 --> Language Class Initialized
INFO - 2018-04-07 05:03:48 --> Loader Class Initialized
INFO - 2018-04-07 05:03:48 --> Helper loaded: url_helper
INFO - 2018-04-07 05:03:48 --> Helper loaded: file_helper
INFO - 2018-04-07 05:03:48 --> Helper loaded: date_helper
INFO - 2018-04-07 05:03:48 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:03:48 --> Controller Class Initialized
INFO - 2018-04-07 05:03:48 --> Model Class Initialized
INFO - 2018-04-07 05:04:33 --> Config Class Initialized
INFO - 2018-04-07 05:04:33 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:04:33 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:04:33 --> Utf8 Class Initialized
INFO - 2018-04-07 05:04:33 --> URI Class Initialized
INFO - 2018-04-07 05:04:33 --> Router Class Initialized
INFO - 2018-04-07 05:04:33 --> Output Class Initialized
INFO - 2018-04-07 05:04:33 --> Security Class Initialized
DEBUG - 2018-04-07 05:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:04:33 --> Input Class Initialized
INFO - 2018-04-07 05:04:33 --> Language Class Initialized
INFO - 2018-04-07 05:04:33 --> Loader Class Initialized
INFO - 2018-04-07 05:04:33 --> Helper loaded: url_helper
INFO - 2018-04-07 05:04:33 --> Helper loaded: file_helper
INFO - 2018-04-07 05:04:33 --> Helper loaded: date_helper
INFO - 2018-04-07 05:04:33 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:04:33 --> Controller Class Initialized
INFO - 2018-04-07 05:04:33 --> Model Class Initialized
INFO - 2018-04-07 05:48:27 --> Config Class Initialized
INFO - 2018-04-07 05:48:27 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:48:27 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:48:27 --> Utf8 Class Initialized
INFO - 2018-04-07 05:48:27 --> URI Class Initialized
DEBUG - 2018-04-07 05:48:27 --> No URI present. Default controller set.
INFO - 2018-04-07 05:48:27 --> Router Class Initialized
INFO - 2018-04-07 05:48:28 --> Output Class Initialized
INFO - 2018-04-07 05:48:28 --> Security Class Initialized
DEBUG - 2018-04-07 05:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:48:28 --> Input Class Initialized
INFO - 2018-04-07 05:48:28 --> Language Class Initialized
INFO - 2018-04-07 05:48:28 --> Loader Class Initialized
INFO - 2018-04-07 05:48:28 --> Helper loaded: url_helper
INFO - 2018-04-07 05:48:28 --> Helper loaded: file_helper
INFO - 2018-04-07 05:48:28 --> Helper loaded: date_helper
INFO - 2018-04-07 05:48:28 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:48:28 --> Controller Class Initialized
INFO - 2018-04-07 05:48:28 --> Config Class Initialized
INFO - 2018-04-07 05:48:28 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:48:28 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:48:28 --> Utf8 Class Initialized
INFO - 2018-04-07 05:48:28 --> URI Class Initialized
INFO - 2018-04-07 05:48:28 --> Router Class Initialized
INFO - 2018-04-07 05:48:28 --> Output Class Initialized
INFO - 2018-04-07 05:48:28 --> Security Class Initialized
DEBUG - 2018-04-07 05:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:48:28 --> Input Class Initialized
INFO - 2018-04-07 05:48:28 --> Language Class Initialized
INFO - 2018-04-07 05:48:28 --> Loader Class Initialized
INFO - 2018-04-07 05:48:28 --> Helper loaded: url_helper
INFO - 2018-04-07 05:48:28 --> Helper loaded: file_helper
INFO - 2018-04-07 05:48:28 --> Helper loaded: date_helper
INFO - 2018-04-07 05:48:28 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:48:28 --> Controller Class Initialized
INFO - 2018-04-07 05:48:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 05:48:28 --> Final output sent to browser
DEBUG - 2018-04-07 05:48:28 --> Total execution time: 0.2564
INFO - 2018-04-07 05:48:36 --> Config Class Initialized
INFO - 2018-04-07 05:48:36 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:48:36 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:48:36 --> Utf8 Class Initialized
INFO - 2018-04-07 05:48:36 --> URI Class Initialized
INFO - 2018-04-07 05:48:36 --> Router Class Initialized
INFO - 2018-04-07 05:48:36 --> Output Class Initialized
INFO - 2018-04-07 05:48:36 --> Security Class Initialized
DEBUG - 2018-04-07 05:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:48:36 --> Input Class Initialized
INFO - 2018-04-07 05:48:36 --> Language Class Initialized
INFO - 2018-04-07 05:48:36 --> Loader Class Initialized
INFO - 2018-04-07 05:48:36 --> Helper loaded: url_helper
INFO - 2018-04-07 05:48:36 --> Helper loaded: file_helper
INFO - 2018-04-07 05:48:36 --> Helper loaded: date_helper
INFO - 2018-04-07 05:48:36 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:48:36 --> Controller Class Initialized
INFO - 2018-04-07 05:48:36 --> Model Class Initialized
INFO - 2018-04-07 05:48:36 --> Final output sent to browser
DEBUG - 2018-04-07 05:48:36 --> Total execution time: 0.3009
INFO - 2018-04-07 05:48:36 --> Config Class Initialized
INFO - 2018-04-07 05:48:36 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:48:36 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:48:36 --> Utf8 Class Initialized
INFO - 2018-04-07 05:48:36 --> URI Class Initialized
INFO - 2018-04-07 05:48:36 --> Router Class Initialized
INFO - 2018-04-07 05:48:36 --> Output Class Initialized
INFO - 2018-04-07 05:48:36 --> Security Class Initialized
DEBUG - 2018-04-07 05:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:48:36 --> Input Class Initialized
INFO - 2018-04-07 05:48:36 --> Language Class Initialized
INFO - 2018-04-07 05:48:36 --> Loader Class Initialized
INFO - 2018-04-07 05:48:36 --> Helper loaded: url_helper
INFO - 2018-04-07 05:48:36 --> Helper loaded: file_helper
INFO - 2018-04-07 05:48:36 --> Helper loaded: date_helper
INFO - 2018-04-07 05:48:36 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:48:36 --> Controller Class Initialized
INFO - 2018-04-07 05:48:36 --> Model Class Initialized
INFO - 2018-04-07 05:48:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 05:48:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 05:48:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 05:48:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 05:48:37 --> Final output sent to browser
DEBUG - 2018-04-07 05:48:37 --> Total execution time: 0.3666
INFO - 2018-04-07 05:48:37 --> Config Class Initialized
INFO - 2018-04-07 05:48:37 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:48:37 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:48:37 --> Utf8 Class Initialized
INFO - 2018-04-07 05:48:37 --> URI Class Initialized
INFO - 2018-04-07 05:48:37 --> Router Class Initialized
INFO - 2018-04-07 05:48:37 --> Output Class Initialized
INFO - 2018-04-07 05:48:37 --> Security Class Initialized
DEBUG - 2018-04-07 05:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:48:37 --> Input Class Initialized
INFO - 2018-04-07 05:48:37 --> Language Class Initialized
ERROR - 2018-04-07 05:48:37 --> 404 Page Not Found: Assets/img
INFO - 2018-04-07 05:48:41 --> Config Class Initialized
INFO - 2018-04-07 05:48:41 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:48:41 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:48:41 --> Utf8 Class Initialized
INFO - 2018-04-07 05:48:41 --> URI Class Initialized
INFO - 2018-04-07 05:48:41 --> Router Class Initialized
INFO - 2018-04-07 05:48:41 --> Output Class Initialized
INFO - 2018-04-07 05:48:41 --> Security Class Initialized
DEBUG - 2018-04-07 05:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:48:41 --> Input Class Initialized
INFO - 2018-04-07 05:48:41 --> Language Class Initialized
ERROR - 2018-04-07 05:48:41 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 05:51:34 --> Config Class Initialized
INFO - 2018-04-07 05:51:34 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:51:34 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:51:34 --> Utf8 Class Initialized
INFO - 2018-04-07 05:51:34 --> URI Class Initialized
INFO - 2018-04-07 05:51:34 --> Router Class Initialized
INFO - 2018-04-07 05:51:34 --> Output Class Initialized
INFO - 2018-04-07 05:51:34 --> Security Class Initialized
DEBUG - 2018-04-07 05:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:51:34 --> Input Class Initialized
INFO - 2018-04-07 05:51:34 --> Language Class Initialized
INFO - 2018-04-07 05:51:34 --> Loader Class Initialized
INFO - 2018-04-07 05:51:34 --> Helper loaded: url_helper
INFO - 2018-04-07 05:51:34 --> Helper loaded: file_helper
INFO - 2018-04-07 05:51:34 --> Helper loaded: date_helper
INFO - 2018-04-07 05:51:34 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:51:34 --> Controller Class Initialized
INFO - 2018-04-07 05:51:34 --> Model Class Initialized
INFO - 2018-04-07 05:51:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 05:51:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 05:51:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 05:51:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 05:51:34 --> Final output sent to browser
DEBUG - 2018-04-07 05:51:34 --> Total execution time: 0.2902
INFO - 2018-04-07 05:51:36 --> Config Class Initialized
INFO - 2018-04-07 05:51:36 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:51:36 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:51:36 --> Utf8 Class Initialized
INFO - 2018-04-07 05:51:36 --> URI Class Initialized
INFO - 2018-04-07 05:51:36 --> Router Class Initialized
INFO - 2018-04-07 05:51:36 --> Output Class Initialized
INFO - 2018-04-07 05:51:36 --> Security Class Initialized
DEBUG - 2018-04-07 05:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:51:37 --> Input Class Initialized
INFO - 2018-04-07 05:51:37 --> Language Class Initialized
INFO - 2018-04-07 05:51:37 --> Loader Class Initialized
INFO - 2018-04-07 05:51:37 --> Helper loaded: url_helper
INFO - 2018-04-07 05:51:37 --> Helper loaded: file_helper
INFO - 2018-04-07 05:51:37 --> Helper loaded: date_helper
INFO - 2018-04-07 05:51:37 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:51:37 --> Controller Class Initialized
INFO - 2018-04-07 05:51:37 --> Model Class Initialized
INFO - 2018-04-07 05:51:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 05:51:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 05:51:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 05:51:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 05:51:37 --> Final output sent to browser
DEBUG - 2018-04-07 05:51:37 --> Total execution time: 0.3092
INFO - 2018-04-07 05:51:40 --> Config Class Initialized
INFO - 2018-04-07 05:51:40 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:51:40 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:51:40 --> Utf8 Class Initialized
INFO - 2018-04-07 05:51:40 --> URI Class Initialized
INFO - 2018-04-07 05:51:40 --> Router Class Initialized
INFO - 2018-04-07 05:51:40 --> Output Class Initialized
INFO - 2018-04-07 05:51:40 --> Security Class Initialized
DEBUG - 2018-04-07 05:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:51:40 --> Input Class Initialized
INFO - 2018-04-07 05:51:40 --> Language Class Initialized
ERROR - 2018-04-07 05:51:40 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 05:51:55 --> Config Class Initialized
INFO - 2018-04-07 05:51:55 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:51:55 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:51:55 --> Utf8 Class Initialized
INFO - 2018-04-07 05:51:55 --> URI Class Initialized
INFO - 2018-04-07 05:51:55 --> Router Class Initialized
INFO - 2018-04-07 05:51:55 --> Output Class Initialized
INFO - 2018-04-07 05:51:55 --> Security Class Initialized
DEBUG - 2018-04-07 05:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:51:55 --> Input Class Initialized
INFO - 2018-04-07 05:51:55 --> Language Class Initialized
INFO - 2018-04-07 05:51:55 --> Loader Class Initialized
INFO - 2018-04-07 05:51:55 --> Helper loaded: url_helper
INFO - 2018-04-07 05:51:55 --> Helper loaded: file_helper
INFO - 2018-04-07 05:51:55 --> Helper loaded: date_helper
INFO - 2018-04-07 05:51:55 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:51:55 --> Controller Class Initialized
INFO - 2018-04-07 05:51:55 --> Model Class Initialized
INFO - 2018-04-07 05:51:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 05:51:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 05:51:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 05:51:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 05:51:55 --> Final output sent to browser
DEBUG - 2018-04-07 05:51:55 --> Total execution time: 0.2937
INFO - 2018-04-07 05:54:09 --> Config Class Initialized
INFO - 2018-04-07 05:54:09 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:54:09 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:54:09 --> Utf8 Class Initialized
INFO - 2018-04-07 05:54:09 --> URI Class Initialized
INFO - 2018-04-07 05:54:09 --> Router Class Initialized
INFO - 2018-04-07 05:54:09 --> Output Class Initialized
INFO - 2018-04-07 05:54:09 --> Security Class Initialized
DEBUG - 2018-04-07 05:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:54:09 --> Input Class Initialized
INFO - 2018-04-07 05:54:09 --> Language Class Initialized
ERROR - 2018-04-07 05:54:09 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 05:54:12 --> Config Class Initialized
INFO - 2018-04-07 05:54:12 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:54:12 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:54:12 --> Utf8 Class Initialized
INFO - 2018-04-07 05:54:12 --> URI Class Initialized
INFO - 2018-04-07 05:54:12 --> Router Class Initialized
INFO - 2018-04-07 05:54:12 --> Output Class Initialized
INFO - 2018-04-07 05:54:12 --> Security Class Initialized
DEBUG - 2018-04-07 05:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:54:12 --> Input Class Initialized
INFO - 2018-04-07 05:54:12 --> Language Class Initialized
ERROR - 2018-04-07 05:54:12 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 05:54:13 --> Config Class Initialized
INFO - 2018-04-07 05:54:13 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:54:13 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:54:13 --> Utf8 Class Initialized
INFO - 2018-04-07 05:54:13 --> URI Class Initialized
INFO - 2018-04-07 05:54:14 --> Router Class Initialized
INFO - 2018-04-07 05:54:14 --> Output Class Initialized
INFO - 2018-04-07 05:54:14 --> Security Class Initialized
DEBUG - 2018-04-07 05:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:54:14 --> Input Class Initialized
INFO - 2018-04-07 05:54:14 --> Language Class Initialized
INFO - 2018-04-07 05:54:14 --> Loader Class Initialized
INFO - 2018-04-07 05:54:14 --> Helper loaded: url_helper
INFO - 2018-04-07 05:54:14 --> Helper loaded: file_helper
INFO - 2018-04-07 05:54:14 --> Helper loaded: date_helper
INFO - 2018-04-07 05:54:14 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:54:14 --> Controller Class Initialized
INFO - 2018-04-07 05:54:14 --> Model Class Initialized
INFO - 2018-04-07 05:54:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 05:54:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 05:54:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 05:54:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 05:54:14 --> Final output sent to browser
DEBUG - 2018-04-07 05:54:14 --> Total execution time: 0.3370
INFO - 2018-04-07 05:54:15 --> Config Class Initialized
INFO - 2018-04-07 05:54:15 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:54:15 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:54:15 --> Utf8 Class Initialized
INFO - 2018-04-07 05:54:15 --> URI Class Initialized
INFO - 2018-04-07 05:54:15 --> Router Class Initialized
INFO - 2018-04-07 05:54:15 --> Output Class Initialized
INFO - 2018-04-07 05:54:15 --> Security Class Initialized
DEBUG - 2018-04-07 05:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:54:15 --> Input Class Initialized
INFO - 2018-04-07 05:54:15 --> Language Class Initialized
INFO - 2018-04-07 05:54:15 --> Loader Class Initialized
INFO - 2018-04-07 05:54:15 --> Helper loaded: url_helper
INFO - 2018-04-07 05:54:15 --> Helper loaded: file_helper
INFO - 2018-04-07 05:54:15 --> Helper loaded: date_helper
INFO - 2018-04-07 05:54:15 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:54:15 --> Controller Class Initialized
INFO - 2018-04-07 05:54:15 --> Model Class Initialized
INFO - 2018-04-07 05:54:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 05:54:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 05:54:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 05:54:15 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 05:54:15 --> Final output sent to browser
DEBUG - 2018-04-07 05:54:16 --> Total execution time: 0.3257
INFO - 2018-04-07 05:54:18 --> Config Class Initialized
INFO - 2018-04-07 05:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:54:18 --> Utf8 Class Initialized
INFO - 2018-04-07 05:54:18 --> URI Class Initialized
INFO - 2018-04-07 05:54:18 --> Router Class Initialized
INFO - 2018-04-07 05:54:18 --> Output Class Initialized
INFO - 2018-04-07 05:54:18 --> Security Class Initialized
DEBUG - 2018-04-07 05:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:54:18 --> Input Class Initialized
INFO - 2018-04-07 05:54:18 --> Language Class Initialized
ERROR - 2018-04-07 05:54:18 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 05:54:20 --> Config Class Initialized
INFO - 2018-04-07 05:54:20 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:54:20 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:54:20 --> Utf8 Class Initialized
INFO - 2018-04-07 05:54:20 --> URI Class Initialized
INFO - 2018-04-07 05:54:20 --> Router Class Initialized
INFO - 2018-04-07 05:54:20 --> Output Class Initialized
INFO - 2018-04-07 05:54:20 --> Security Class Initialized
DEBUG - 2018-04-07 05:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:54:20 --> Input Class Initialized
INFO - 2018-04-07 05:54:20 --> Language Class Initialized
INFO - 2018-04-07 05:54:20 --> Loader Class Initialized
INFO - 2018-04-07 05:54:20 --> Helper loaded: url_helper
INFO - 2018-04-07 05:54:20 --> Helper loaded: file_helper
INFO - 2018-04-07 05:54:20 --> Helper loaded: date_helper
INFO - 2018-04-07 05:54:20 --> Database Driver Class Initialized
DEBUG - 2018-04-07 05:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 05:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 05:54:20 --> Controller Class Initialized
INFO - 2018-04-07 05:54:20 --> Model Class Initialized
INFO - 2018-04-07 05:54:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 05:54:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 05:54:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 05:54:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 05:54:20 --> Final output sent to browser
DEBUG - 2018-04-07 05:54:20 --> Total execution time: 0.3008
INFO - 2018-04-07 05:59:53 --> Config Class Initialized
INFO - 2018-04-07 05:59:53 --> Hooks Class Initialized
DEBUG - 2018-04-07 05:59:53 --> UTF-8 Support Enabled
INFO - 2018-04-07 05:59:53 --> Utf8 Class Initialized
INFO - 2018-04-07 05:59:53 --> URI Class Initialized
INFO - 2018-04-07 05:59:53 --> Router Class Initialized
INFO - 2018-04-07 05:59:53 --> Output Class Initialized
INFO - 2018-04-07 05:59:53 --> Security Class Initialized
DEBUG - 2018-04-07 05:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 05:59:53 --> Input Class Initialized
INFO - 2018-04-07 05:59:53 --> Language Class Initialized
ERROR - 2018-04-07 05:59:53 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 06:01:37 --> Config Class Initialized
INFO - 2018-04-07 06:01:37 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:01:37 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:01:37 --> Utf8 Class Initialized
INFO - 2018-04-07 06:01:37 --> URI Class Initialized
INFO - 2018-04-07 06:01:37 --> Router Class Initialized
INFO - 2018-04-07 06:01:37 --> Output Class Initialized
INFO - 2018-04-07 06:01:37 --> Security Class Initialized
DEBUG - 2018-04-07 06:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:01:37 --> Input Class Initialized
INFO - 2018-04-07 06:01:37 --> Language Class Initialized
ERROR - 2018-04-07 06:01:37 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 06:01:38 --> Config Class Initialized
INFO - 2018-04-07 06:01:38 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:01:39 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:01:39 --> Utf8 Class Initialized
INFO - 2018-04-07 06:01:39 --> URI Class Initialized
INFO - 2018-04-07 06:01:39 --> Router Class Initialized
INFO - 2018-04-07 06:01:39 --> Output Class Initialized
INFO - 2018-04-07 06:01:39 --> Security Class Initialized
DEBUG - 2018-04-07 06:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:01:39 --> Input Class Initialized
INFO - 2018-04-07 06:01:39 --> Language Class Initialized
ERROR - 2018-04-07 06:01:39 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 06:01:40 --> Config Class Initialized
INFO - 2018-04-07 06:01:40 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:01:40 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:01:40 --> Utf8 Class Initialized
INFO - 2018-04-07 06:01:40 --> URI Class Initialized
INFO - 2018-04-07 06:01:40 --> Router Class Initialized
INFO - 2018-04-07 06:01:40 --> Output Class Initialized
INFO - 2018-04-07 06:01:40 --> Security Class Initialized
DEBUG - 2018-04-07 06:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:01:40 --> Input Class Initialized
INFO - 2018-04-07 06:01:40 --> Language Class Initialized
INFO - 2018-04-07 06:01:40 --> Loader Class Initialized
INFO - 2018-04-07 06:01:40 --> Helper loaded: url_helper
INFO - 2018-04-07 06:01:40 --> Helper loaded: file_helper
INFO - 2018-04-07 06:01:40 --> Helper loaded: date_helper
INFO - 2018-04-07 06:01:40 --> Database Driver Class Initialized
DEBUG - 2018-04-07 06:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 06:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 06:01:40 --> Controller Class Initialized
INFO - 2018-04-07 06:01:40 --> Model Class Initialized
INFO - 2018-04-07 06:01:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 06:01:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 06:01:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 06:01:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 06:01:40 --> Final output sent to browser
DEBUG - 2018-04-07 06:01:40 --> Total execution time: 0.3255
INFO - 2018-04-07 06:01:42 --> Config Class Initialized
INFO - 2018-04-07 06:01:42 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:01:42 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:01:42 --> Utf8 Class Initialized
INFO - 2018-04-07 06:01:42 --> URI Class Initialized
INFO - 2018-04-07 06:01:42 --> Router Class Initialized
INFO - 2018-04-07 06:01:42 --> Output Class Initialized
INFO - 2018-04-07 06:01:42 --> Security Class Initialized
DEBUG - 2018-04-07 06:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:01:42 --> Input Class Initialized
INFO - 2018-04-07 06:01:42 --> Language Class Initialized
ERROR - 2018-04-07 06:01:42 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 06:02:16 --> Config Class Initialized
INFO - 2018-04-07 06:02:16 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:02:16 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:02:16 --> Utf8 Class Initialized
INFO - 2018-04-07 06:02:16 --> URI Class Initialized
INFO - 2018-04-07 06:02:16 --> Router Class Initialized
INFO - 2018-04-07 06:02:16 --> Output Class Initialized
INFO - 2018-04-07 06:02:16 --> Security Class Initialized
DEBUG - 2018-04-07 06:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:02:16 --> Input Class Initialized
INFO - 2018-04-07 06:02:16 --> Language Class Initialized
ERROR - 2018-04-07 06:02:16 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 06:02:17 --> Config Class Initialized
INFO - 2018-04-07 06:02:17 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:02:17 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:02:17 --> Utf8 Class Initialized
INFO - 2018-04-07 06:02:17 --> URI Class Initialized
INFO - 2018-04-07 06:02:17 --> Router Class Initialized
INFO - 2018-04-07 06:02:17 --> Output Class Initialized
INFO - 2018-04-07 06:02:17 --> Security Class Initialized
DEBUG - 2018-04-07 06:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:02:17 --> Input Class Initialized
INFO - 2018-04-07 06:02:17 --> Language Class Initialized
INFO - 2018-04-07 06:02:17 --> Loader Class Initialized
INFO - 2018-04-07 06:02:17 --> Helper loaded: url_helper
INFO - 2018-04-07 06:02:17 --> Helper loaded: file_helper
INFO - 2018-04-07 06:02:17 --> Helper loaded: date_helper
INFO - 2018-04-07 06:02:17 --> Database Driver Class Initialized
DEBUG - 2018-04-07 06:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 06:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 06:02:17 --> Controller Class Initialized
INFO - 2018-04-07 06:02:17 --> Model Class Initialized
INFO - 2018-04-07 06:02:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 06:02:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 06:02:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 06:02:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 06:02:17 --> Final output sent to browser
DEBUG - 2018-04-07 06:02:17 --> Total execution time: 0.3522
INFO - 2018-04-07 06:02:19 --> Config Class Initialized
INFO - 2018-04-07 06:02:19 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:02:19 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:02:19 --> Utf8 Class Initialized
INFO - 2018-04-07 06:02:19 --> URI Class Initialized
INFO - 2018-04-07 06:02:19 --> Router Class Initialized
INFO - 2018-04-07 06:02:19 --> Output Class Initialized
INFO - 2018-04-07 06:02:19 --> Security Class Initialized
DEBUG - 2018-04-07 06:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:02:19 --> Input Class Initialized
INFO - 2018-04-07 06:02:19 --> Language Class Initialized
ERROR - 2018-04-07 06:02:19 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 06:03:44 --> Config Class Initialized
INFO - 2018-04-07 06:03:44 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:03:44 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:03:44 --> Utf8 Class Initialized
INFO - 2018-04-07 06:03:44 --> URI Class Initialized
INFO - 2018-04-07 06:03:44 --> Router Class Initialized
INFO - 2018-04-07 06:03:44 --> Output Class Initialized
INFO - 2018-04-07 06:03:44 --> Security Class Initialized
DEBUG - 2018-04-07 06:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:03:44 --> Input Class Initialized
INFO - 2018-04-07 06:03:44 --> Language Class Initialized
INFO - 2018-04-07 06:03:45 --> Loader Class Initialized
INFO - 2018-04-07 06:03:45 --> Helper loaded: url_helper
INFO - 2018-04-07 06:03:45 --> Helper loaded: file_helper
INFO - 2018-04-07 06:03:45 --> Helper loaded: date_helper
INFO - 2018-04-07 06:03:45 --> Database Driver Class Initialized
DEBUG - 2018-04-07 06:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 06:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 06:03:45 --> Controller Class Initialized
INFO - 2018-04-07 06:03:45 --> Model Class Initialized
INFO - 2018-04-07 06:03:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 06:03:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 06:03:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 06:03:45 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 06:03:45 --> Final output sent to browser
DEBUG - 2018-04-07 06:03:45 --> Total execution time: 0.3141
INFO - 2018-04-07 06:03:50 --> Config Class Initialized
INFO - 2018-04-07 06:03:50 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:03:50 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:03:50 --> Utf8 Class Initialized
INFO - 2018-04-07 06:03:50 --> URI Class Initialized
INFO - 2018-04-07 06:03:50 --> Router Class Initialized
INFO - 2018-04-07 06:03:50 --> Output Class Initialized
INFO - 2018-04-07 06:03:50 --> Security Class Initialized
DEBUG - 2018-04-07 06:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:03:50 --> Input Class Initialized
INFO - 2018-04-07 06:03:50 --> Language Class Initialized
ERROR - 2018-04-07 06:03:50 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 06:04:35 --> Config Class Initialized
INFO - 2018-04-07 06:04:35 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:04:35 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:04:35 --> Utf8 Class Initialized
INFO - 2018-04-07 06:04:35 --> URI Class Initialized
INFO - 2018-04-07 06:04:35 --> Router Class Initialized
INFO - 2018-04-07 06:04:35 --> Output Class Initialized
INFO - 2018-04-07 06:04:35 --> Security Class Initialized
DEBUG - 2018-04-07 06:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:04:35 --> Input Class Initialized
INFO - 2018-04-07 06:04:35 --> Language Class Initialized
INFO - 2018-04-07 06:04:35 --> Loader Class Initialized
INFO - 2018-04-07 06:04:35 --> Helper loaded: url_helper
INFO - 2018-04-07 06:04:35 --> Helper loaded: file_helper
INFO - 2018-04-07 06:04:35 --> Helper loaded: date_helper
INFO - 2018-04-07 06:04:35 --> Database Driver Class Initialized
DEBUG - 2018-04-07 06:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 06:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 06:04:35 --> Controller Class Initialized
INFO - 2018-04-07 06:04:35 --> Model Class Initialized
INFO - 2018-04-07 06:04:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 06:04:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 06:04:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 06:04:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 06:04:35 --> Final output sent to browser
DEBUG - 2018-04-07 06:04:35 --> Total execution time: 0.6135
INFO - 2018-04-07 06:04:37 --> Config Class Initialized
INFO - 2018-04-07 06:04:37 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:04:37 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:04:37 --> Utf8 Class Initialized
INFO - 2018-04-07 06:04:37 --> URI Class Initialized
INFO - 2018-04-07 06:04:37 --> Router Class Initialized
INFO - 2018-04-07 06:04:37 --> Output Class Initialized
INFO - 2018-04-07 06:04:37 --> Security Class Initialized
DEBUG - 2018-04-07 06:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:04:37 --> Input Class Initialized
INFO - 2018-04-07 06:04:37 --> Language Class Initialized
INFO - 2018-04-07 06:04:37 --> Loader Class Initialized
INFO - 2018-04-07 06:04:37 --> Helper loaded: url_helper
INFO - 2018-04-07 06:04:37 --> Helper loaded: file_helper
INFO - 2018-04-07 06:04:37 --> Helper loaded: date_helper
INFO - 2018-04-07 06:04:37 --> Database Driver Class Initialized
DEBUG - 2018-04-07 06:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 06:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 06:04:37 --> Controller Class Initialized
INFO - 2018-04-07 06:04:37 --> Model Class Initialized
INFO - 2018-04-07 06:05:29 --> Config Class Initialized
INFO - 2018-04-07 06:05:29 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:05:29 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:05:29 --> Utf8 Class Initialized
INFO - 2018-04-07 06:05:29 --> URI Class Initialized
INFO - 2018-04-07 06:05:29 --> Router Class Initialized
INFO - 2018-04-07 06:05:29 --> Output Class Initialized
INFO - 2018-04-07 06:05:29 --> Security Class Initialized
DEBUG - 2018-04-07 06:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:05:29 --> Input Class Initialized
INFO - 2018-04-07 06:05:29 --> Language Class Initialized
INFO - 2018-04-07 06:05:29 --> Loader Class Initialized
INFO - 2018-04-07 06:05:29 --> Helper loaded: url_helper
INFO - 2018-04-07 06:05:29 --> Helper loaded: file_helper
INFO - 2018-04-07 06:05:29 --> Helper loaded: date_helper
INFO - 2018-04-07 06:05:29 --> Database Driver Class Initialized
DEBUG - 2018-04-07 06:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 06:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 06:05:29 --> Controller Class Initialized
INFO - 2018-04-07 06:05:29 --> Model Class Initialized
INFO - 2018-04-07 06:05:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 06:05:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 06:05:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 06:05:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 06:05:29 --> Final output sent to browser
DEBUG - 2018-04-07 06:05:29 --> Total execution time: 0.3204
INFO - 2018-04-07 06:05:31 --> Config Class Initialized
INFO - 2018-04-07 06:05:31 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:05:31 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:05:31 --> Utf8 Class Initialized
INFO - 2018-04-07 06:05:31 --> URI Class Initialized
INFO - 2018-04-07 06:05:31 --> Router Class Initialized
INFO - 2018-04-07 06:05:31 --> Output Class Initialized
INFO - 2018-04-07 06:05:31 --> Security Class Initialized
DEBUG - 2018-04-07 06:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:05:31 --> Input Class Initialized
INFO - 2018-04-07 06:05:31 --> Language Class Initialized
INFO - 2018-04-07 06:05:31 --> Loader Class Initialized
INFO - 2018-04-07 06:05:31 --> Helper loaded: url_helper
INFO - 2018-04-07 06:05:31 --> Helper loaded: file_helper
INFO - 2018-04-07 06:05:31 --> Helper loaded: date_helper
INFO - 2018-04-07 06:05:31 --> Database Driver Class Initialized
DEBUG - 2018-04-07 06:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 06:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 06:05:31 --> Controller Class Initialized
INFO - 2018-04-07 06:05:31 --> Model Class Initialized
INFO - 2018-04-07 06:07:38 --> Config Class Initialized
INFO - 2018-04-07 06:07:38 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:07:38 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:07:38 --> Utf8 Class Initialized
INFO - 2018-04-07 06:07:38 --> URI Class Initialized
INFO - 2018-04-07 06:07:38 --> Router Class Initialized
INFO - 2018-04-07 06:07:38 --> Output Class Initialized
INFO - 2018-04-07 06:07:38 --> Security Class Initialized
DEBUG - 2018-04-07 06:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:07:38 --> Input Class Initialized
INFO - 2018-04-07 06:07:38 --> Language Class Initialized
INFO - 2018-04-07 06:07:38 --> Loader Class Initialized
INFO - 2018-04-07 06:07:38 --> Helper loaded: url_helper
INFO - 2018-04-07 06:07:38 --> Helper loaded: file_helper
INFO - 2018-04-07 06:07:38 --> Helper loaded: date_helper
INFO - 2018-04-07 06:07:38 --> Database Driver Class Initialized
DEBUG - 2018-04-07 06:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 06:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 06:07:39 --> Controller Class Initialized
INFO - 2018-04-07 06:07:39 --> Model Class Initialized
INFO - 2018-04-07 06:07:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 06:07:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 06:07:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 06:07:39 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 06:07:39 --> Final output sent to browser
DEBUG - 2018-04-07 06:07:39 --> Total execution time: 0.3290
INFO - 2018-04-07 06:07:40 --> Config Class Initialized
INFO - 2018-04-07 06:07:40 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:07:40 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:07:40 --> Utf8 Class Initialized
INFO - 2018-04-07 06:07:40 --> URI Class Initialized
INFO - 2018-04-07 06:07:40 --> Router Class Initialized
INFO - 2018-04-07 06:07:40 --> Output Class Initialized
INFO - 2018-04-07 06:07:40 --> Security Class Initialized
DEBUG - 2018-04-07 06:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:07:40 --> Input Class Initialized
INFO - 2018-04-07 06:07:40 --> Language Class Initialized
INFO - 2018-04-07 06:07:40 --> Loader Class Initialized
INFO - 2018-04-07 06:07:40 --> Helper loaded: url_helper
INFO - 2018-04-07 06:07:40 --> Helper loaded: file_helper
INFO - 2018-04-07 06:07:40 --> Helper loaded: date_helper
INFO - 2018-04-07 06:07:40 --> Database Driver Class Initialized
DEBUG - 2018-04-07 06:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 06:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 06:07:40 --> Controller Class Initialized
INFO - 2018-04-07 06:07:40 --> Model Class Initialized
INFO - 2018-04-07 06:07:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 06:07:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 06:07:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 06:07:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 06:07:40 --> Final output sent to browser
DEBUG - 2018-04-07 06:07:41 --> Total execution time: 0.3863
INFO - 2018-04-07 06:12:22 --> Config Class Initialized
INFO - 2018-04-07 06:12:22 --> Hooks Class Initialized
DEBUG - 2018-04-07 06:12:22 --> UTF-8 Support Enabled
INFO - 2018-04-07 06:12:22 --> Utf8 Class Initialized
INFO - 2018-04-07 06:12:22 --> URI Class Initialized
INFO - 2018-04-07 06:12:22 --> Router Class Initialized
INFO - 2018-04-07 06:12:22 --> Output Class Initialized
INFO - 2018-04-07 06:12:22 --> Security Class Initialized
DEBUG - 2018-04-07 06:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 06:12:22 --> Input Class Initialized
INFO - 2018-04-07 06:12:22 --> Language Class Initialized
INFO - 2018-04-07 06:12:22 --> Loader Class Initialized
INFO - 2018-04-07 06:12:22 --> Helper loaded: url_helper
INFO - 2018-04-07 06:12:22 --> Helper loaded: file_helper
INFO - 2018-04-07 06:12:22 --> Helper loaded: date_helper
INFO - 2018-04-07 06:12:22 --> Database Driver Class Initialized
DEBUG - 2018-04-07 06:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 06:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 06:12:22 --> Controller Class Initialized
INFO - 2018-04-07 06:12:22 --> Model Class Initialized
INFO - 2018-04-07 06:12:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 06:12:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 06:12:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 06:12:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 06:12:22 --> Final output sent to browser
DEBUG - 2018-04-07 06:12:22 --> Total execution time: 0.3376
INFO - 2018-04-07 09:13:05 --> Config Class Initialized
INFO - 2018-04-07 09:13:05 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:13:05 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:13:05 --> Utf8 Class Initialized
INFO - 2018-04-07 09:13:05 --> URI Class Initialized
INFO - 2018-04-07 09:13:05 --> Router Class Initialized
INFO - 2018-04-07 09:13:05 --> Output Class Initialized
INFO - 2018-04-07 09:13:05 --> Security Class Initialized
DEBUG - 2018-04-07 09:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:13:05 --> Input Class Initialized
INFO - 2018-04-07 09:13:05 --> Language Class Initialized
ERROR - 2018-04-07 09:13:05 --> 404 Page Not Found: Stud_controller/editInfo
INFO - 2018-04-07 09:13:08 --> Config Class Initialized
INFO - 2018-04-07 09:13:08 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:13:08 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:13:08 --> Utf8 Class Initialized
INFO - 2018-04-07 09:13:08 --> URI Class Initialized
INFO - 2018-04-07 09:13:08 --> Router Class Initialized
INFO - 2018-04-07 09:13:08 --> Output Class Initialized
INFO - 2018-04-07 09:13:08 --> Security Class Initialized
DEBUG - 2018-04-07 09:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:13:08 --> Input Class Initialized
INFO - 2018-04-07 09:13:08 --> Language Class Initialized
INFO - 2018-04-07 09:13:08 --> Loader Class Initialized
INFO - 2018-04-07 09:13:08 --> Helper loaded: url_helper
INFO - 2018-04-07 09:13:08 --> Helper loaded: file_helper
INFO - 2018-04-07 09:13:08 --> Helper loaded: date_helper
INFO - 2018-04-07 09:13:08 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:13:08 --> Controller Class Initialized
INFO - 2018-04-07 09:13:08 --> Model Class Initialized
INFO - 2018-04-07 09:13:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:13:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 09:13:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:13:08 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:13:08 --> Final output sent to browser
DEBUG - 2018-04-07 09:13:08 --> Total execution time: 0.3916
INFO - 2018-04-07 09:16:06 --> Config Class Initialized
INFO - 2018-04-07 09:16:06 --> Config Class Initialized
INFO - 2018-04-07 09:16:06 --> Hooks Class Initialized
INFO - 2018-04-07 09:16:06 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:16:06 --> UTF-8 Support Enabled
DEBUG - 2018-04-07 09:16:06 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:16:06 --> Utf8 Class Initialized
INFO - 2018-04-07 09:16:06 --> Utf8 Class Initialized
INFO - 2018-04-07 09:16:06 --> URI Class Initialized
INFO - 2018-04-07 09:16:06 --> URI Class Initialized
INFO - 2018-04-07 09:16:06 --> Router Class Initialized
INFO - 2018-04-07 09:16:06 --> Router Class Initialized
INFO - 2018-04-07 09:16:06 --> Output Class Initialized
INFO - 2018-04-07 09:16:06 --> Output Class Initialized
INFO - 2018-04-07 09:16:06 --> Security Class Initialized
INFO - 2018-04-07 09:16:06 --> Security Class Initialized
DEBUG - 2018-04-07 09:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-04-07 09:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:16:06 --> Input Class Initialized
INFO - 2018-04-07 09:16:06 --> Input Class Initialized
INFO - 2018-04-07 09:16:06 --> Language Class Initialized
INFO - 2018-04-07 09:16:06 --> Language Class Initialized
ERROR - 2018-04-07 09:16:06 --> 404 Page Not Found: Assets/js
ERROR - 2018-04-07 09:16:06 --> 404 Page Not Found: Assets/js
INFO - 2018-04-07 09:16:06 --> Config Class Initialized
INFO - 2018-04-07 09:16:06 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:16:06 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:16:06 --> Utf8 Class Initialized
INFO - 2018-04-07 09:16:06 --> URI Class Initialized
INFO - 2018-04-07 09:16:06 --> Router Class Initialized
INFO - 2018-04-07 09:16:06 --> Output Class Initialized
INFO - 2018-04-07 09:16:06 --> Security Class Initialized
DEBUG - 2018-04-07 09:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:16:06 --> Input Class Initialized
INFO - 2018-04-07 09:16:06 --> Language Class Initialized
ERROR - 2018-04-07 09:16:06 --> 404 Page Not Found: Assets/css
INFO - 2018-04-07 09:17:49 --> Config Class Initialized
INFO - 2018-04-07 09:17:49 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:17:49 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:17:49 --> Utf8 Class Initialized
INFO - 2018-04-07 09:17:49 --> URI Class Initialized
INFO - 2018-04-07 09:17:49 --> Router Class Initialized
INFO - 2018-04-07 09:17:49 --> Output Class Initialized
INFO - 2018-04-07 09:17:49 --> Security Class Initialized
DEBUG - 2018-04-07 09:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:17:50 --> Input Class Initialized
INFO - 2018-04-07 09:17:50 --> Language Class Initialized
INFO - 2018-04-07 09:17:50 --> Loader Class Initialized
INFO - 2018-04-07 09:17:50 --> Helper loaded: url_helper
INFO - 2018-04-07 09:17:50 --> Helper loaded: file_helper
INFO - 2018-04-07 09:17:50 --> Helper loaded: date_helper
INFO - 2018-04-07 09:17:50 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:17:50 --> Controller Class Initialized
INFO - 2018-04-07 09:17:50 --> Model Class Initialized
INFO - 2018-04-07 09:17:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:17:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:17:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:17:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:17:50 --> Final output sent to browser
DEBUG - 2018-04-07 09:17:50 --> Total execution time: 0.3379
INFO - 2018-04-07 09:17:54 --> Config Class Initialized
INFO - 2018-04-07 09:17:55 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:17:55 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:17:55 --> Utf8 Class Initialized
INFO - 2018-04-07 09:17:55 --> URI Class Initialized
INFO - 2018-04-07 09:17:55 --> Router Class Initialized
INFO - 2018-04-07 09:17:55 --> Output Class Initialized
INFO - 2018-04-07 09:17:55 --> Security Class Initialized
DEBUG - 2018-04-07 09:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:17:55 --> Input Class Initialized
INFO - 2018-04-07 09:17:55 --> Language Class Initialized
INFO - 2018-04-07 09:17:55 --> Loader Class Initialized
INFO - 2018-04-07 09:17:55 --> Helper loaded: url_helper
INFO - 2018-04-07 09:17:55 --> Helper loaded: file_helper
INFO - 2018-04-07 09:17:55 --> Helper loaded: date_helper
INFO - 2018-04-07 09:17:55 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:17:55 --> Controller Class Initialized
INFO - 2018-04-07 09:17:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 09:17:55 --> Final output sent to browser
DEBUG - 2018-04-07 09:17:55 --> Total execution time: 0.2858
INFO - 2018-04-07 09:18:00 --> Config Class Initialized
INFO - 2018-04-07 09:18:00 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:18:00 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:18:00 --> Utf8 Class Initialized
INFO - 2018-04-07 09:18:00 --> URI Class Initialized
INFO - 2018-04-07 09:18:00 --> Router Class Initialized
INFO - 2018-04-07 09:18:00 --> Output Class Initialized
INFO - 2018-04-07 09:18:00 --> Security Class Initialized
DEBUG - 2018-04-07 09:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:18:00 --> Input Class Initialized
INFO - 2018-04-07 09:18:00 --> Language Class Initialized
INFO - 2018-04-07 09:18:00 --> Loader Class Initialized
INFO - 2018-04-07 09:18:00 --> Helper loaded: url_helper
INFO - 2018-04-07 09:18:00 --> Helper loaded: file_helper
INFO - 2018-04-07 09:18:00 --> Helper loaded: date_helper
INFO - 2018-04-07 09:18:00 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:18:00 --> Controller Class Initialized
INFO - 2018-04-07 09:18:00 --> Model Class Initialized
INFO - 2018-04-07 09:18:00 --> Final output sent to browser
DEBUG - 2018-04-07 09:18:00 --> Total execution time: 0.2964
INFO - 2018-04-07 09:18:00 --> Config Class Initialized
INFO - 2018-04-07 09:18:00 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:18:00 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:18:00 --> Utf8 Class Initialized
INFO - 2018-04-07 09:18:00 --> URI Class Initialized
INFO - 2018-04-07 09:18:00 --> Router Class Initialized
INFO - 2018-04-07 09:18:00 --> Output Class Initialized
INFO - 2018-04-07 09:18:00 --> Security Class Initialized
DEBUG - 2018-04-07 09:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:18:00 --> Input Class Initialized
INFO - 2018-04-07 09:18:00 --> Language Class Initialized
INFO - 2018-04-07 09:18:01 --> Loader Class Initialized
INFO - 2018-04-07 09:18:01 --> Helper loaded: url_helper
INFO - 2018-04-07 09:18:01 --> Helper loaded: file_helper
INFO - 2018-04-07 09:18:01 --> Helper loaded: date_helper
INFO - 2018-04-07 09:18:01 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:18:01 --> Controller Class Initialized
INFO - 2018-04-07 09:18:01 --> Model Class Initialized
INFO - 2018-04-07 09:18:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:18:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:18:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:18:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:18:01 --> Final output sent to browser
DEBUG - 2018-04-07 09:18:01 --> Total execution time: 0.3094
INFO - 2018-04-07 09:18:07 --> Config Class Initialized
INFO - 2018-04-07 09:18:07 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:18:07 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:18:07 --> Utf8 Class Initialized
INFO - 2018-04-07 09:18:07 --> URI Class Initialized
INFO - 2018-04-07 09:18:07 --> Router Class Initialized
INFO - 2018-04-07 09:18:07 --> Output Class Initialized
INFO - 2018-04-07 09:18:07 --> Security Class Initialized
DEBUG - 2018-04-07 09:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:18:07 --> Input Class Initialized
INFO - 2018-04-07 09:18:07 --> Language Class Initialized
INFO - 2018-04-07 09:18:07 --> Loader Class Initialized
INFO - 2018-04-07 09:18:07 --> Helper loaded: url_helper
INFO - 2018-04-07 09:18:07 --> Helper loaded: file_helper
INFO - 2018-04-07 09:18:07 --> Helper loaded: date_helper
INFO - 2018-04-07 09:18:07 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:18:07 --> Controller Class Initialized
INFO - 2018-04-07 09:18:07 --> Model Class Initialized
INFO - 2018-04-07 09:18:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:18:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:18:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:18:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:18:07 --> Final output sent to browser
DEBUG - 2018-04-07 09:18:07 --> Total execution time: 0.3299
INFO - 2018-04-07 09:18:25 --> Config Class Initialized
INFO - 2018-04-07 09:18:25 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:18:25 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:18:25 --> Utf8 Class Initialized
INFO - 2018-04-07 09:18:25 --> URI Class Initialized
INFO - 2018-04-07 09:18:26 --> Router Class Initialized
INFO - 2018-04-07 09:18:26 --> Output Class Initialized
INFO - 2018-04-07 09:18:26 --> Security Class Initialized
DEBUG - 2018-04-07 09:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:18:26 --> Input Class Initialized
INFO - 2018-04-07 09:18:26 --> Language Class Initialized
INFO - 2018-04-07 09:18:26 --> Loader Class Initialized
INFO - 2018-04-07 09:18:26 --> Helper loaded: url_helper
INFO - 2018-04-07 09:18:26 --> Helper loaded: file_helper
INFO - 2018-04-07 09:18:26 --> Helper loaded: date_helper
INFO - 2018-04-07 09:18:26 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:18:26 --> Controller Class Initialized
INFO - 2018-04-07 09:18:26 --> Model Class Initialized
INFO - 2018-04-07 09:18:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:18:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:18:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:18:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:18:26 --> Final output sent to browser
DEBUG - 2018-04-07 09:18:26 --> Total execution time: 0.5949
INFO - 2018-04-07 09:18:40 --> Config Class Initialized
INFO - 2018-04-07 09:18:40 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:18:40 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:18:40 --> Utf8 Class Initialized
INFO - 2018-04-07 09:18:40 --> URI Class Initialized
INFO - 2018-04-07 09:18:40 --> Router Class Initialized
INFO - 2018-04-07 09:18:40 --> Output Class Initialized
INFO - 2018-04-07 09:18:40 --> Security Class Initialized
DEBUG - 2018-04-07 09:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:18:40 --> Input Class Initialized
INFO - 2018-04-07 09:18:40 --> Language Class Initialized
INFO - 2018-04-07 09:18:40 --> Loader Class Initialized
INFO - 2018-04-07 09:18:40 --> Helper loaded: url_helper
INFO - 2018-04-07 09:18:40 --> Helper loaded: file_helper
INFO - 2018-04-07 09:18:40 --> Helper loaded: date_helper
INFO - 2018-04-07 09:18:40 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:18:40 --> Controller Class Initialized
INFO - 2018-04-07 09:18:40 --> Model Class Initialized
INFO - 2018-04-07 09:18:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:18:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:18:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:18:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:18:40 --> Final output sent to browser
DEBUG - 2018-04-07 09:18:40 --> Total execution time: 0.3151
INFO - 2018-04-07 09:18:57 --> Config Class Initialized
INFO - 2018-04-07 09:18:57 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:18:57 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:18:57 --> Utf8 Class Initialized
INFO - 2018-04-07 09:18:57 --> URI Class Initialized
INFO - 2018-04-07 09:18:57 --> Router Class Initialized
INFO - 2018-04-07 09:18:57 --> Output Class Initialized
INFO - 2018-04-07 09:18:57 --> Security Class Initialized
DEBUG - 2018-04-07 09:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:18:57 --> Input Class Initialized
INFO - 2018-04-07 09:18:57 --> Language Class Initialized
INFO - 2018-04-07 09:18:57 --> Loader Class Initialized
INFO - 2018-04-07 09:18:57 --> Helper loaded: url_helper
INFO - 2018-04-07 09:18:57 --> Helper loaded: file_helper
INFO - 2018-04-07 09:18:57 --> Helper loaded: date_helper
INFO - 2018-04-07 09:18:57 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:18:57 --> Controller Class Initialized
INFO - 2018-04-07 09:18:57 --> Model Class Initialized
INFO - 2018-04-07 09:18:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:18:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:18:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:18:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:18:57 --> Final output sent to browser
DEBUG - 2018-04-07 09:18:57 --> Total execution time: 0.3302
INFO - 2018-04-07 09:19:09 --> Config Class Initialized
INFO - 2018-04-07 09:19:09 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:19:09 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:19:09 --> Utf8 Class Initialized
INFO - 2018-04-07 09:19:09 --> URI Class Initialized
INFO - 2018-04-07 09:19:09 --> Router Class Initialized
INFO - 2018-04-07 09:19:09 --> Output Class Initialized
INFO - 2018-04-07 09:19:09 --> Security Class Initialized
DEBUG - 2018-04-07 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:19:09 --> Input Class Initialized
INFO - 2018-04-07 09:19:09 --> Language Class Initialized
INFO - 2018-04-07 09:19:09 --> Loader Class Initialized
INFO - 2018-04-07 09:19:09 --> Helper loaded: url_helper
INFO - 2018-04-07 09:19:09 --> Helper loaded: file_helper
INFO - 2018-04-07 09:19:09 --> Helper loaded: date_helper
INFO - 2018-04-07 09:19:09 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:19:09 --> Controller Class Initialized
INFO - 2018-04-07 09:19:09 --> Model Class Initialized
INFO - 2018-04-07 09:19:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:19:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:19:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:19:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:19:09 --> Final output sent to browser
DEBUG - 2018-04-07 09:19:09 --> Total execution time: 0.3289
INFO - 2018-04-07 09:19:21 --> Config Class Initialized
INFO - 2018-04-07 09:19:21 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:19:21 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:19:21 --> Utf8 Class Initialized
INFO - 2018-04-07 09:19:21 --> URI Class Initialized
INFO - 2018-04-07 09:19:21 --> Router Class Initialized
INFO - 2018-04-07 09:19:21 --> Output Class Initialized
INFO - 2018-04-07 09:19:21 --> Security Class Initialized
DEBUG - 2018-04-07 09:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:19:21 --> Input Class Initialized
INFO - 2018-04-07 09:19:21 --> Language Class Initialized
INFO - 2018-04-07 09:19:21 --> Loader Class Initialized
INFO - 2018-04-07 09:19:21 --> Helper loaded: url_helper
INFO - 2018-04-07 09:19:21 --> Helper loaded: file_helper
INFO - 2018-04-07 09:19:21 --> Helper loaded: date_helper
INFO - 2018-04-07 09:19:21 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:19:21 --> Controller Class Initialized
INFO - 2018-04-07 09:19:21 --> Model Class Initialized
INFO - 2018-04-07 09:19:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:19:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:19:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:19:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:19:21 --> Final output sent to browser
DEBUG - 2018-04-07 09:19:22 --> Total execution time: 0.3275
INFO - 2018-04-07 09:19:43 --> Config Class Initialized
INFO - 2018-04-07 09:19:43 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:19:43 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:19:43 --> Utf8 Class Initialized
INFO - 2018-04-07 09:19:43 --> URI Class Initialized
INFO - 2018-04-07 09:19:43 --> Router Class Initialized
INFO - 2018-04-07 09:19:43 --> Output Class Initialized
INFO - 2018-04-07 09:19:43 --> Security Class Initialized
DEBUG - 2018-04-07 09:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:19:43 --> Input Class Initialized
INFO - 2018-04-07 09:19:43 --> Language Class Initialized
INFO - 2018-04-07 09:19:43 --> Loader Class Initialized
INFO - 2018-04-07 09:19:43 --> Helper loaded: url_helper
INFO - 2018-04-07 09:19:43 --> Helper loaded: file_helper
INFO - 2018-04-07 09:19:43 --> Helper loaded: date_helper
INFO - 2018-04-07 09:19:43 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:19:43 --> Controller Class Initialized
INFO - 2018-04-07 09:19:43 --> Model Class Initialized
INFO - 2018-04-07 09:19:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:19:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 09:19:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:19:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:19:43 --> Final output sent to browser
DEBUG - 2018-04-07 09:19:43 --> Total execution time: 0.3179
INFO - 2018-04-07 09:20:16 --> Config Class Initialized
INFO - 2018-04-07 09:20:16 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:20:16 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:20:16 --> Utf8 Class Initialized
INFO - 2018-04-07 09:20:16 --> URI Class Initialized
INFO - 2018-04-07 09:20:16 --> Router Class Initialized
INFO - 2018-04-07 09:20:16 --> Output Class Initialized
INFO - 2018-04-07 09:20:16 --> Security Class Initialized
DEBUG - 2018-04-07 09:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:20:16 --> Input Class Initialized
INFO - 2018-04-07 09:20:16 --> Language Class Initialized
INFO - 2018-04-07 09:20:16 --> Loader Class Initialized
INFO - 2018-04-07 09:20:16 --> Helper loaded: url_helper
INFO - 2018-04-07 09:20:16 --> Helper loaded: file_helper
INFO - 2018-04-07 09:20:16 --> Helper loaded: date_helper
INFO - 2018-04-07 09:20:16 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:20:16 --> Controller Class Initialized
INFO - 2018-04-07 09:20:16 --> Model Class Initialized
INFO - 2018-04-07 09:20:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:20:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 09:20:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:20:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:20:16 --> Final output sent to browser
DEBUG - 2018-04-07 09:20:16 --> Total execution time: 0.3436
INFO - 2018-04-07 09:20:28 --> Config Class Initialized
INFO - 2018-04-07 09:20:28 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:20:28 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:20:28 --> Utf8 Class Initialized
INFO - 2018-04-07 09:20:28 --> URI Class Initialized
INFO - 2018-04-07 09:20:28 --> Router Class Initialized
INFO - 2018-04-07 09:20:28 --> Output Class Initialized
INFO - 2018-04-07 09:20:28 --> Security Class Initialized
DEBUG - 2018-04-07 09:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:20:28 --> Input Class Initialized
INFO - 2018-04-07 09:20:28 --> Language Class Initialized
INFO - 2018-04-07 09:20:28 --> Loader Class Initialized
INFO - 2018-04-07 09:20:28 --> Helper loaded: url_helper
INFO - 2018-04-07 09:20:29 --> Helper loaded: file_helper
INFO - 2018-04-07 09:20:29 --> Helper loaded: date_helper
INFO - 2018-04-07 09:20:29 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:20:29 --> Controller Class Initialized
INFO - 2018-04-07 09:20:29 --> Model Class Initialized
INFO - 2018-04-07 09:20:29 --> Final output sent to browser
DEBUG - 2018-04-07 09:20:29 --> Total execution time: 0.2791
INFO - 2018-04-07 09:20:32 --> Config Class Initialized
INFO - 2018-04-07 09:20:32 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:20:32 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:20:32 --> Utf8 Class Initialized
INFO - 2018-04-07 09:20:32 --> URI Class Initialized
INFO - 2018-04-07 09:20:32 --> Router Class Initialized
INFO - 2018-04-07 09:20:32 --> Output Class Initialized
INFO - 2018-04-07 09:20:32 --> Security Class Initialized
DEBUG - 2018-04-07 09:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:20:32 --> Input Class Initialized
INFO - 2018-04-07 09:20:32 --> Language Class Initialized
INFO - 2018-04-07 09:20:32 --> Loader Class Initialized
INFO - 2018-04-07 09:20:32 --> Helper loaded: url_helper
INFO - 2018-04-07 09:20:32 --> Helper loaded: file_helper
INFO - 2018-04-07 09:20:32 --> Helper loaded: date_helper
INFO - 2018-04-07 09:20:32 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:20:32 --> Controller Class Initialized
INFO - 2018-04-07 09:20:32 --> Model Class Initialized
INFO - 2018-04-07 09:20:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:20:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 09:20:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:20:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:20:32 --> Final output sent to browser
DEBUG - 2018-04-07 09:20:32 --> Total execution time: 0.5173
INFO - 2018-04-07 09:20:33 --> Config Class Initialized
INFO - 2018-04-07 09:20:33 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:20:33 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:20:33 --> Utf8 Class Initialized
INFO - 2018-04-07 09:20:33 --> URI Class Initialized
INFO - 2018-04-07 09:20:33 --> Router Class Initialized
INFO - 2018-04-07 09:20:33 --> Output Class Initialized
INFO - 2018-04-07 09:20:33 --> Security Class Initialized
DEBUG - 2018-04-07 09:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:20:33 --> Input Class Initialized
INFO - 2018-04-07 09:20:33 --> Language Class Initialized
INFO - 2018-04-07 09:20:33 --> Loader Class Initialized
INFO - 2018-04-07 09:20:33 --> Helper loaded: url_helper
INFO - 2018-04-07 09:20:33 --> Helper loaded: file_helper
INFO - 2018-04-07 09:20:33 --> Helper loaded: date_helper
INFO - 2018-04-07 09:20:33 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:20:33 --> Controller Class Initialized
INFO - 2018-04-07 09:20:33 --> Model Class Initialized
INFO - 2018-04-07 09:20:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:20:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:20:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:20:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:20:33 --> Final output sent to browser
DEBUG - 2018-04-07 09:20:33 --> Total execution time: 0.3309
INFO - 2018-04-07 09:20:36 --> Config Class Initialized
INFO - 2018-04-07 09:20:36 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:20:36 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:20:36 --> Utf8 Class Initialized
INFO - 2018-04-07 09:20:37 --> URI Class Initialized
INFO - 2018-04-07 09:20:37 --> Router Class Initialized
INFO - 2018-04-07 09:20:37 --> Output Class Initialized
INFO - 2018-04-07 09:20:37 --> Security Class Initialized
DEBUG - 2018-04-07 09:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:20:37 --> Input Class Initialized
INFO - 2018-04-07 09:20:37 --> Language Class Initialized
INFO - 2018-04-07 09:20:37 --> Loader Class Initialized
INFO - 2018-04-07 09:20:37 --> Helper loaded: url_helper
INFO - 2018-04-07 09:20:37 --> Helper loaded: file_helper
INFO - 2018-04-07 09:20:37 --> Helper loaded: date_helper
INFO - 2018-04-07 09:20:37 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:20:37 --> Controller Class Initialized
INFO - 2018-04-07 09:20:37 --> Model Class Initialized
INFO - 2018-04-07 09:20:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:20:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:20:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:20:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:20:37 --> Final output sent to browser
DEBUG - 2018-04-07 09:20:37 --> Total execution time: 0.3299
INFO - 2018-04-07 09:20:40 --> Config Class Initialized
INFO - 2018-04-07 09:20:40 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:20:40 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:20:40 --> Utf8 Class Initialized
INFO - 2018-04-07 09:20:40 --> URI Class Initialized
INFO - 2018-04-07 09:20:40 --> Router Class Initialized
INFO - 2018-04-07 09:20:40 --> Output Class Initialized
INFO - 2018-04-07 09:20:40 --> Security Class Initialized
DEBUG - 2018-04-07 09:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:20:40 --> Input Class Initialized
INFO - 2018-04-07 09:20:40 --> Language Class Initialized
INFO - 2018-04-07 09:20:40 --> Loader Class Initialized
INFO - 2018-04-07 09:20:40 --> Helper loaded: url_helper
INFO - 2018-04-07 09:20:40 --> Helper loaded: file_helper
INFO - 2018-04-07 09:20:40 --> Helper loaded: date_helper
INFO - 2018-04-07 09:20:40 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:20:40 --> Controller Class Initialized
INFO - 2018-04-07 09:20:40 --> Model Class Initialized
INFO - 2018-04-07 09:20:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:20:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 09:20:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:20:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:20:40 --> Final output sent to browser
DEBUG - 2018-04-07 09:20:40 --> Total execution time: 0.3320
INFO - 2018-04-07 09:22:05 --> Config Class Initialized
INFO - 2018-04-07 09:22:05 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:22:05 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:22:05 --> Utf8 Class Initialized
INFO - 2018-04-07 09:22:05 --> URI Class Initialized
INFO - 2018-04-07 09:22:05 --> Router Class Initialized
INFO - 2018-04-07 09:22:05 --> Output Class Initialized
INFO - 2018-04-07 09:22:05 --> Security Class Initialized
DEBUG - 2018-04-07 09:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:22:05 --> Input Class Initialized
INFO - 2018-04-07 09:22:05 --> Language Class Initialized
INFO - 2018-04-07 09:22:05 --> Loader Class Initialized
INFO - 2018-04-07 09:22:05 --> Helper loaded: url_helper
INFO - 2018-04-07 09:22:05 --> Helper loaded: file_helper
INFO - 2018-04-07 09:22:05 --> Helper loaded: date_helper
INFO - 2018-04-07 09:22:05 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:22:05 --> Controller Class Initialized
INFO - 2018-04-07 09:22:05 --> Model Class Initialized
INFO - 2018-04-07 09:22:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:22:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:22:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:22:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:22:05 --> Final output sent to browser
DEBUG - 2018-04-07 09:22:05 --> Total execution time: 0.3412
INFO - 2018-04-07 09:25:25 --> Config Class Initialized
INFO - 2018-04-07 09:25:25 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:25:25 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:25:25 --> Utf8 Class Initialized
INFO - 2018-04-07 09:25:25 --> URI Class Initialized
INFO - 2018-04-07 09:25:25 --> Router Class Initialized
INFO - 2018-04-07 09:25:25 --> Output Class Initialized
INFO - 2018-04-07 09:25:25 --> Security Class Initialized
DEBUG - 2018-04-07 09:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:25:25 --> Input Class Initialized
INFO - 2018-04-07 09:25:25 --> Language Class Initialized
INFO - 2018-04-07 09:25:25 --> Loader Class Initialized
INFO - 2018-04-07 09:25:25 --> Helper loaded: url_helper
INFO - 2018-04-07 09:25:25 --> Helper loaded: file_helper
INFO - 2018-04-07 09:25:25 --> Helper loaded: date_helper
INFO - 2018-04-07 09:25:25 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:25:25 --> Controller Class Initialized
INFO - 2018-04-07 09:25:25 --> Model Class Initialized
INFO - 2018-04-07 09:25:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:25:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:25:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:25:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:25:25 --> Final output sent to browser
DEBUG - 2018-04-07 09:25:25 --> Total execution time: 0.3819
INFO - 2018-04-07 09:25:27 --> Config Class Initialized
INFO - 2018-04-07 09:25:27 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:25:27 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:25:27 --> Utf8 Class Initialized
INFO - 2018-04-07 09:25:27 --> URI Class Initialized
INFO - 2018-04-07 09:25:27 --> Router Class Initialized
INFO - 2018-04-07 09:25:27 --> Output Class Initialized
INFO - 2018-04-07 09:25:27 --> Security Class Initialized
DEBUG - 2018-04-07 09:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:25:27 --> Input Class Initialized
INFO - 2018-04-07 09:25:27 --> Language Class Initialized
INFO - 2018-04-07 09:25:27 --> Loader Class Initialized
INFO - 2018-04-07 09:25:27 --> Helper loaded: url_helper
INFO - 2018-04-07 09:25:27 --> Helper loaded: file_helper
INFO - 2018-04-07 09:25:27 --> Helper loaded: date_helper
INFO - 2018-04-07 09:25:27 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:25:27 --> Controller Class Initialized
INFO - 2018-04-07 09:25:27 --> Model Class Initialized
INFO - 2018-04-07 09:25:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-07 09:25:27 --> Severity: Notice --> Undefined property: stdClass::$birthdate G:\xampp\htdocs\codeigniter\application\views\user\show.php 34
INFO - 2018-04-07 09:25:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 09:25:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:25:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:25:27 --> Final output sent to browser
DEBUG - 2018-04-07 09:25:27 --> Total execution time: 0.4712
INFO - 2018-04-07 09:27:40 --> Config Class Initialized
INFO - 2018-04-07 09:27:40 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:27:40 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:27:40 --> Utf8 Class Initialized
INFO - 2018-04-07 09:27:40 --> URI Class Initialized
INFO - 2018-04-07 09:27:40 --> Router Class Initialized
INFO - 2018-04-07 09:27:40 --> Output Class Initialized
INFO - 2018-04-07 09:27:40 --> Security Class Initialized
DEBUG - 2018-04-07 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:27:40 --> Input Class Initialized
INFO - 2018-04-07 09:27:40 --> Language Class Initialized
INFO - 2018-04-07 09:27:40 --> Loader Class Initialized
INFO - 2018-04-07 09:27:40 --> Helper loaded: url_helper
INFO - 2018-04-07 09:27:40 --> Helper loaded: file_helper
INFO - 2018-04-07 09:27:40 --> Helper loaded: date_helper
INFO - 2018-04-07 09:27:40 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:27:40 --> Controller Class Initialized
INFO - 2018-04-07 09:27:40 --> Model Class Initialized
INFO - 2018-04-07 09:27:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-07 09:27:40 --> Severity: Notice --> Undefined property: stdClass::$birthdate G:\xampp\htdocs\codeigniter\application\views\user\show.php 34
INFO - 2018-04-07 09:27:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 09:27:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:27:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:27:40 --> Final output sent to browser
DEBUG - 2018-04-07 09:27:40 --> Total execution time: 0.3545
INFO - 2018-04-07 09:27:44 --> Config Class Initialized
INFO - 2018-04-07 09:27:44 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:27:44 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:27:44 --> Utf8 Class Initialized
INFO - 2018-04-07 09:27:44 --> URI Class Initialized
INFO - 2018-04-07 09:27:44 --> Router Class Initialized
INFO - 2018-04-07 09:27:44 --> Output Class Initialized
INFO - 2018-04-07 09:27:44 --> Security Class Initialized
DEBUG - 2018-04-07 09:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:27:44 --> Input Class Initialized
INFO - 2018-04-07 09:27:44 --> Language Class Initialized
INFO - 2018-04-07 09:27:44 --> Loader Class Initialized
INFO - 2018-04-07 09:27:44 --> Helper loaded: url_helper
INFO - 2018-04-07 09:27:44 --> Helper loaded: file_helper
INFO - 2018-04-07 09:27:44 --> Helper loaded: date_helper
INFO - 2018-04-07 09:27:44 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:27:44 --> Controller Class Initialized
INFO - 2018-04-07 09:27:44 --> Model Class Initialized
INFO - 2018-04-07 09:27:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-07 09:27:44 --> Severity: Notice --> Undefined property: stdClass::$birthdate G:\xampp\htdocs\codeigniter\application\views\user\show.php 34
INFO - 2018-04-07 09:27:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 09:27:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:27:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:27:44 --> Final output sent to browser
DEBUG - 2018-04-07 09:27:44 --> Total execution time: 0.3611
INFO - 2018-04-07 09:27:51 --> Config Class Initialized
INFO - 2018-04-07 09:27:51 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:27:51 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:27:51 --> Utf8 Class Initialized
INFO - 2018-04-07 09:27:51 --> URI Class Initialized
INFO - 2018-04-07 09:27:51 --> Router Class Initialized
INFO - 2018-04-07 09:27:51 --> Output Class Initialized
INFO - 2018-04-07 09:27:51 --> Security Class Initialized
DEBUG - 2018-04-07 09:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:27:51 --> Input Class Initialized
INFO - 2018-04-07 09:27:51 --> Language Class Initialized
INFO - 2018-04-07 09:27:51 --> Loader Class Initialized
INFO - 2018-04-07 09:27:51 --> Helper loaded: url_helper
INFO - 2018-04-07 09:27:51 --> Helper loaded: file_helper
INFO - 2018-04-07 09:27:51 --> Helper loaded: date_helper
INFO - 2018-04-07 09:27:51 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:27:51 --> Controller Class Initialized
INFO - 2018-04-07 09:27:51 --> Model Class Initialized
INFO - 2018-04-07 09:27:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:27:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:27:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:27:52 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:27:52 --> Final output sent to browser
DEBUG - 2018-04-07 09:27:52 --> Total execution time: 0.3403
INFO - 2018-04-07 09:27:55 --> Config Class Initialized
INFO - 2018-04-07 09:27:55 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:27:55 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:27:55 --> Utf8 Class Initialized
INFO - 2018-04-07 09:27:55 --> URI Class Initialized
INFO - 2018-04-07 09:27:55 --> Router Class Initialized
INFO - 2018-04-07 09:27:55 --> Output Class Initialized
INFO - 2018-04-07 09:27:55 --> Security Class Initialized
DEBUG - 2018-04-07 09:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:27:55 --> Input Class Initialized
INFO - 2018-04-07 09:27:55 --> Language Class Initialized
INFO - 2018-04-07 09:27:55 --> Loader Class Initialized
INFO - 2018-04-07 09:27:55 --> Helper loaded: url_helper
INFO - 2018-04-07 09:27:55 --> Helper loaded: file_helper
INFO - 2018-04-07 09:27:55 --> Helper loaded: date_helper
INFO - 2018-04-07 09:27:55 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:27:55 --> Controller Class Initialized
INFO - 2018-04-07 09:27:55 --> Model Class Initialized
INFO - 2018-04-07 09:27:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:27:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:27:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:27:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:27:55 --> Final output sent to browser
DEBUG - 2018-04-07 09:27:55 --> Total execution time: 0.3545
INFO - 2018-04-07 09:28:00 --> Config Class Initialized
INFO - 2018-04-07 09:28:00 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:28:00 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:28:00 --> Utf8 Class Initialized
INFO - 2018-04-07 09:28:00 --> URI Class Initialized
INFO - 2018-04-07 09:28:00 --> Router Class Initialized
INFO - 2018-04-07 09:28:00 --> Output Class Initialized
INFO - 2018-04-07 09:28:00 --> Security Class Initialized
DEBUG - 2018-04-07 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:28:00 --> Input Class Initialized
INFO - 2018-04-07 09:28:00 --> Language Class Initialized
INFO - 2018-04-07 09:28:00 --> Loader Class Initialized
INFO - 2018-04-07 09:28:00 --> Helper loaded: url_helper
INFO - 2018-04-07 09:28:00 --> Helper loaded: file_helper
INFO - 2018-04-07 09:28:00 --> Helper loaded: date_helper
INFO - 2018-04-07 09:28:00 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:28:00 --> Controller Class Initialized
INFO - 2018-04-07 09:28:00 --> Model Class Initialized
INFO - 2018-04-07 09:28:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-07 09:28:00 --> Severity: Notice --> Undefined property: stdClass::$birthdate G:\xampp\htdocs\codeigniter\application\views\user\show.php 34
INFO - 2018-04-07 09:28:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 09:28:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:28:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:28:00 --> Final output sent to browser
DEBUG - 2018-04-07 09:28:00 --> Total execution time: 0.3521
INFO - 2018-04-07 09:28:57 --> Config Class Initialized
INFO - 2018-04-07 09:28:57 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:28:57 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:28:57 --> Utf8 Class Initialized
INFO - 2018-04-07 09:28:57 --> URI Class Initialized
INFO - 2018-04-07 09:28:57 --> Router Class Initialized
INFO - 2018-04-07 09:28:57 --> Output Class Initialized
INFO - 2018-04-07 09:28:57 --> Security Class Initialized
DEBUG - 2018-04-07 09:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:28:57 --> Input Class Initialized
INFO - 2018-04-07 09:28:57 --> Language Class Initialized
INFO - 2018-04-07 09:28:57 --> Loader Class Initialized
INFO - 2018-04-07 09:28:57 --> Helper loaded: url_helper
INFO - 2018-04-07 09:28:57 --> Helper loaded: file_helper
INFO - 2018-04-07 09:28:57 --> Helper loaded: date_helper
INFO - 2018-04-07 09:28:57 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:28:57 --> Controller Class Initialized
INFO - 2018-04-07 09:28:57 --> Model Class Initialized
INFO - 2018-04-07 09:28:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:28:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 09:28:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:28:57 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:28:57 --> Final output sent to browser
DEBUG - 2018-04-07 09:28:57 --> Total execution time: 0.3579
INFO - 2018-04-07 09:29:50 --> Config Class Initialized
INFO - 2018-04-07 09:29:50 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:29:50 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:29:50 --> Utf8 Class Initialized
INFO - 2018-04-07 09:29:50 --> URI Class Initialized
INFO - 2018-04-07 09:29:50 --> Router Class Initialized
INFO - 2018-04-07 09:29:50 --> Output Class Initialized
INFO - 2018-04-07 09:29:50 --> Security Class Initialized
DEBUG - 2018-04-07 09:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:29:50 --> Input Class Initialized
INFO - 2018-04-07 09:29:50 --> Language Class Initialized
INFO - 2018-04-07 09:29:50 --> Loader Class Initialized
INFO - 2018-04-07 09:29:50 --> Helper loaded: url_helper
INFO - 2018-04-07 09:29:50 --> Helper loaded: file_helper
INFO - 2018-04-07 09:29:50 --> Helper loaded: date_helper
INFO - 2018-04-07 09:29:50 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:29:50 --> Controller Class Initialized
INFO - 2018-04-07 09:29:50 --> Model Class Initialized
INFO - 2018-04-07 09:29:50 --> Final output sent to browser
DEBUG - 2018-04-07 09:29:50 --> Total execution time: 0.2967
INFO - 2018-04-07 09:29:54 --> Config Class Initialized
INFO - 2018-04-07 09:29:54 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:29:54 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:29:54 --> Utf8 Class Initialized
INFO - 2018-04-07 09:29:54 --> URI Class Initialized
INFO - 2018-04-07 09:29:54 --> Router Class Initialized
INFO - 2018-04-07 09:29:54 --> Output Class Initialized
INFO - 2018-04-07 09:29:54 --> Security Class Initialized
DEBUG - 2018-04-07 09:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:29:54 --> Input Class Initialized
INFO - 2018-04-07 09:29:54 --> Language Class Initialized
INFO - 2018-04-07 09:29:54 --> Loader Class Initialized
INFO - 2018-04-07 09:29:54 --> Helper loaded: url_helper
INFO - 2018-04-07 09:29:54 --> Helper loaded: file_helper
INFO - 2018-04-07 09:29:54 --> Helper loaded: date_helper
INFO - 2018-04-07 09:29:54 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:29:54 --> Controller Class Initialized
INFO - 2018-04-07 09:29:54 --> Model Class Initialized
INFO - 2018-04-07 09:29:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:29:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 09:29:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:29:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:29:54 --> Final output sent to browser
DEBUG - 2018-04-07 09:29:54 --> Total execution time: 0.6103
INFO - 2018-04-07 09:32:34 --> Config Class Initialized
INFO - 2018-04-07 09:32:34 --> Hooks Class Initialized
DEBUG - 2018-04-07 09:32:34 --> UTF-8 Support Enabled
INFO - 2018-04-07 09:32:34 --> Utf8 Class Initialized
INFO - 2018-04-07 09:32:34 --> URI Class Initialized
INFO - 2018-04-07 09:32:34 --> Router Class Initialized
INFO - 2018-04-07 09:32:34 --> Output Class Initialized
INFO - 2018-04-07 09:32:34 --> Security Class Initialized
DEBUG - 2018-04-07 09:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 09:32:34 --> Input Class Initialized
INFO - 2018-04-07 09:32:34 --> Language Class Initialized
INFO - 2018-04-07 09:32:34 --> Loader Class Initialized
INFO - 2018-04-07 09:32:34 --> Helper loaded: url_helper
INFO - 2018-04-07 09:32:34 --> Helper loaded: file_helper
INFO - 2018-04-07 09:32:34 --> Helper loaded: date_helper
INFO - 2018-04-07 09:32:34 --> Database Driver Class Initialized
DEBUG - 2018-04-07 09:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 09:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 09:32:34 --> Controller Class Initialized
INFO - 2018-04-07 09:32:34 --> Model Class Initialized
INFO - 2018-04-07 09:32:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 09:32:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 09:32:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 09:32:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 09:32:34 --> Final output sent to browser
DEBUG - 2018-04-07 09:32:34 --> Total execution time: 0.3598
INFO - 2018-04-07 10:04:05 --> Config Class Initialized
INFO - 2018-04-07 10:04:05 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:04:05 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:04:05 --> Utf8 Class Initialized
INFO - 2018-04-07 10:04:05 --> URI Class Initialized
INFO - 2018-04-07 10:04:05 --> Router Class Initialized
INFO - 2018-04-07 10:04:05 --> Output Class Initialized
INFO - 2018-04-07 10:04:05 --> Security Class Initialized
DEBUG - 2018-04-07 10:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:04:05 --> Input Class Initialized
INFO - 2018-04-07 10:04:05 --> Language Class Initialized
INFO - 2018-04-07 10:04:05 --> Loader Class Initialized
INFO - 2018-04-07 10:04:05 --> Helper loaded: url_helper
INFO - 2018-04-07 10:04:05 --> Helper loaded: file_helper
INFO - 2018-04-07 10:04:05 --> Helper loaded: date_helper
INFO - 2018-04-07 10:04:05 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:04:05 --> Controller Class Initialized
DEBUG - 2018-04-07 10:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-07 10:04:05 --> Config Class Initialized
INFO - 2018-04-07 10:04:05 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:04:05 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:04:05 --> Utf8 Class Initialized
INFO - 2018-04-07 10:04:05 --> URI Class Initialized
INFO - 2018-04-07 10:04:05 --> Router Class Initialized
INFO - 2018-04-07 10:04:05 --> Output Class Initialized
INFO - 2018-04-07 10:04:05 --> Security Class Initialized
DEBUG - 2018-04-07 10:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:04:05 --> Input Class Initialized
INFO - 2018-04-07 10:04:05 --> Language Class Initialized
INFO - 2018-04-07 10:04:05 --> Loader Class Initialized
INFO - 2018-04-07 10:04:05 --> Helper loaded: url_helper
INFO - 2018-04-07 10:04:05 --> Helper loaded: file_helper
INFO - 2018-04-07 10:04:05 --> Helper loaded: date_helper
INFO - 2018-04-07 10:04:05 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:04:05 --> Controller Class Initialized
INFO - 2018-04-07 10:04:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 10:04:05 --> Final output sent to browser
DEBUG - 2018-04-07 10:04:06 --> Total execution time: 0.2908
INFO - 2018-04-07 10:04:09 --> Config Class Initialized
INFO - 2018-04-07 10:04:09 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:04:09 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:04:09 --> Utf8 Class Initialized
INFO - 2018-04-07 10:04:09 --> URI Class Initialized
INFO - 2018-04-07 10:04:09 --> Router Class Initialized
INFO - 2018-04-07 10:04:09 --> Output Class Initialized
INFO - 2018-04-07 10:04:09 --> Security Class Initialized
DEBUG - 2018-04-07 10:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:04:09 --> Input Class Initialized
INFO - 2018-04-07 10:04:09 --> Language Class Initialized
INFO - 2018-04-07 10:04:09 --> Loader Class Initialized
INFO - 2018-04-07 10:04:09 --> Helper loaded: url_helper
INFO - 2018-04-07 10:04:09 --> Helper loaded: file_helper
INFO - 2018-04-07 10:04:09 --> Helper loaded: date_helper
INFO - 2018-04-07 10:04:09 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:04:09 --> Controller Class Initialized
INFO - 2018-04-07 10:04:09 --> Model Class Initialized
INFO - 2018-04-07 10:04:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 10:04:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 10:04:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 10:04:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 10:04:09 --> Final output sent to browser
DEBUG - 2018-04-07 10:04:09 --> Total execution time: 0.3560
INFO - 2018-04-07 10:04:12 --> Config Class Initialized
INFO - 2018-04-07 10:04:12 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:04:12 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:04:12 --> Utf8 Class Initialized
INFO - 2018-04-07 10:04:12 --> URI Class Initialized
INFO - 2018-04-07 10:04:12 --> Router Class Initialized
INFO - 2018-04-07 10:04:12 --> Output Class Initialized
INFO - 2018-04-07 10:04:12 --> Security Class Initialized
DEBUG - 2018-04-07 10:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:04:12 --> Input Class Initialized
INFO - 2018-04-07 10:04:12 --> Language Class Initialized
INFO - 2018-04-07 10:04:12 --> Loader Class Initialized
INFO - 2018-04-07 10:04:12 --> Helper loaded: url_helper
INFO - 2018-04-07 10:04:12 --> Helper loaded: file_helper
INFO - 2018-04-07 10:04:12 --> Helper loaded: date_helper
INFO - 2018-04-07 10:04:12 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:04:12 --> Controller Class Initialized
INFO - 2018-04-07 10:04:12 --> Model Class Initialized
INFO - 2018-04-07 10:04:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 10:04:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 10:04:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 10:04:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 10:04:12 --> Final output sent to browser
DEBUG - 2018-04-07 10:04:12 --> Total execution time: 0.3497
INFO - 2018-04-07 10:04:17 --> Config Class Initialized
INFO - 2018-04-07 10:04:17 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:04:17 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:04:17 --> Utf8 Class Initialized
INFO - 2018-04-07 10:04:17 --> URI Class Initialized
INFO - 2018-04-07 10:04:17 --> Router Class Initialized
INFO - 2018-04-07 10:04:17 --> Output Class Initialized
INFO - 2018-04-07 10:04:17 --> Security Class Initialized
DEBUG - 2018-04-07 10:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:04:17 --> Input Class Initialized
INFO - 2018-04-07 10:04:17 --> Language Class Initialized
INFO - 2018-04-07 10:04:17 --> Loader Class Initialized
INFO - 2018-04-07 10:04:17 --> Helper loaded: url_helper
INFO - 2018-04-07 10:04:17 --> Helper loaded: file_helper
INFO - 2018-04-07 10:04:17 --> Helper loaded: date_helper
INFO - 2018-04-07 10:04:17 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:04:17 --> Controller Class Initialized
INFO - 2018-04-07 10:04:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 10:04:17 --> Final output sent to browser
DEBUG - 2018-04-07 10:04:17 --> Total execution time: 0.3031
INFO - 2018-04-07 10:04:24 --> Config Class Initialized
INFO - 2018-04-07 10:04:24 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:04:24 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:04:24 --> Utf8 Class Initialized
INFO - 2018-04-07 10:04:24 --> URI Class Initialized
INFO - 2018-04-07 10:04:24 --> Router Class Initialized
INFO - 2018-04-07 10:04:24 --> Output Class Initialized
INFO - 2018-04-07 10:04:24 --> Security Class Initialized
DEBUG - 2018-04-07 10:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:04:24 --> Input Class Initialized
INFO - 2018-04-07 10:04:24 --> Language Class Initialized
INFO - 2018-04-07 10:04:24 --> Loader Class Initialized
INFO - 2018-04-07 10:04:24 --> Helper loaded: url_helper
INFO - 2018-04-07 10:04:24 --> Helper loaded: file_helper
INFO - 2018-04-07 10:04:24 --> Helper loaded: date_helper
INFO - 2018-04-07 10:04:24 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:04:24 --> Controller Class Initialized
INFO - 2018-04-07 10:04:24 --> Model Class Initialized
INFO - 2018-04-07 10:04:24 --> Final output sent to browser
DEBUG - 2018-04-07 10:04:24 --> Total execution time: 0.3084
INFO - 2018-04-07 10:04:24 --> Config Class Initialized
INFO - 2018-04-07 10:04:24 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:04:24 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:04:24 --> Utf8 Class Initialized
INFO - 2018-04-07 10:04:24 --> URI Class Initialized
INFO - 2018-04-07 10:04:24 --> Router Class Initialized
INFO - 2018-04-07 10:04:24 --> Output Class Initialized
INFO - 2018-04-07 10:04:24 --> Security Class Initialized
DEBUG - 2018-04-07 10:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:04:24 --> Input Class Initialized
INFO - 2018-04-07 10:04:24 --> Language Class Initialized
INFO - 2018-04-07 10:04:24 --> Loader Class Initialized
INFO - 2018-04-07 10:04:24 --> Helper loaded: url_helper
INFO - 2018-04-07 10:04:24 --> Helper loaded: file_helper
INFO - 2018-04-07 10:04:24 --> Helper loaded: date_helper
INFO - 2018-04-07 10:04:24 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:04:24 --> Controller Class Initialized
INFO - 2018-04-07 10:04:25 --> Model Class Initialized
INFO - 2018-04-07 10:04:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 10:04:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 10:04:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 10:04:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 10:04:25 --> Final output sent to browser
DEBUG - 2018-04-07 10:04:25 --> Total execution time: 0.3455
INFO - 2018-04-07 10:04:28 --> Config Class Initialized
INFO - 2018-04-07 10:04:28 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:04:28 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:04:28 --> Utf8 Class Initialized
INFO - 2018-04-07 10:04:28 --> URI Class Initialized
INFO - 2018-04-07 10:04:28 --> Router Class Initialized
INFO - 2018-04-07 10:04:28 --> Output Class Initialized
INFO - 2018-04-07 10:04:28 --> Security Class Initialized
DEBUG - 2018-04-07 10:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:04:28 --> Input Class Initialized
INFO - 2018-04-07 10:04:28 --> Language Class Initialized
INFO - 2018-04-07 10:04:28 --> Loader Class Initialized
INFO - 2018-04-07 10:04:28 --> Helper loaded: url_helper
INFO - 2018-04-07 10:04:28 --> Helper loaded: file_helper
INFO - 2018-04-07 10:04:28 --> Helper loaded: date_helper
INFO - 2018-04-07 10:04:28 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:04:28 --> Controller Class Initialized
INFO - 2018-04-07 10:04:28 --> Model Class Initialized
INFO - 2018-04-07 10:04:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 10:04:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-07 10:04:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 10:04:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 10:04:28 --> Final output sent to browser
DEBUG - 2018-04-07 10:04:28 --> Total execution time: 0.3550
INFO - 2018-04-07 10:04:41 --> Config Class Initialized
INFO - 2018-04-07 10:04:41 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:04:41 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:04:41 --> Utf8 Class Initialized
INFO - 2018-04-07 10:04:41 --> URI Class Initialized
INFO - 2018-04-07 10:04:41 --> Router Class Initialized
INFO - 2018-04-07 10:04:41 --> Output Class Initialized
INFO - 2018-04-07 10:04:41 --> Security Class Initialized
DEBUG - 2018-04-07 10:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:04:41 --> Input Class Initialized
INFO - 2018-04-07 10:04:41 --> Language Class Initialized
INFO - 2018-04-07 10:04:41 --> Loader Class Initialized
INFO - 2018-04-07 10:04:41 --> Helper loaded: url_helper
INFO - 2018-04-07 10:04:41 --> Helper loaded: file_helper
INFO - 2018-04-07 10:04:41 --> Helper loaded: date_helper
INFO - 2018-04-07 10:04:41 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:04:41 --> Controller Class Initialized
INFO - 2018-04-07 10:04:41 --> Model Class Initialized
INFO - 2018-04-07 10:04:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 10:04:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 10:04:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 10:04:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 10:04:41 --> Final output sent to browser
DEBUG - 2018-04-07 10:04:42 --> Total execution time: 0.3505
INFO - 2018-04-07 10:33:38 --> Config Class Initialized
INFO - 2018-04-07 10:33:38 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:33:38 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:33:38 --> Utf8 Class Initialized
INFO - 2018-04-07 10:33:38 --> URI Class Initialized
INFO - 2018-04-07 10:33:38 --> Router Class Initialized
INFO - 2018-04-07 10:33:38 --> Output Class Initialized
INFO - 2018-04-07 10:33:38 --> Security Class Initialized
DEBUG - 2018-04-07 10:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:33:38 --> Input Class Initialized
INFO - 2018-04-07 10:33:38 --> Language Class Initialized
INFO - 2018-04-07 10:33:38 --> Loader Class Initialized
INFO - 2018-04-07 10:33:38 --> Helper loaded: url_helper
INFO - 2018-04-07 10:33:38 --> Helper loaded: file_helper
INFO - 2018-04-07 10:33:38 --> Helper loaded: date_helper
INFO - 2018-04-07 10:33:38 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:33:38 --> Controller Class Initialized
INFO - 2018-04-07 10:33:39 --> Config Class Initialized
INFO - 2018-04-07 10:33:39 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:33:39 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:33:39 --> Utf8 Class Initialized
INFO - 2018-04-07 10:33:39 --> URI Class Initialized
INFO - 2018-04-07 10:33:39 --> Router Class Initialized
INFO - 2018-04-07 10:33:39 --> Output Class Initialized
INFO - 2018-04-07 10:33:39 --> Security Class Initialized
DEBUG - 2018-04-07 10:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:33:39 --> Input Class Initialized
INFO - 2018-04-07 10:33:40 --> Language Class Initialized
INFO - 2018-04-07 10:33:40 --> Loader Class Initialized
INFO - 2018-04-07 10:33:40 --> Helper loaded: url_helper
INFO - 2018-04-07 10:33:40 --> Helper loaded: file_helper
INFO - 2018-04-07 10:33:40 --> Helper loaded: date_helper
INFO - 2018-04-07 10:33:40 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:33:40 --> Controller Class Initialized
INFO - 2018-04-07 10:33:40 --> Config Class Initialized
INFO - 2018-04-07 10:33:40 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:33:40 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:33:40 --> Utf8 Class Initialized
INFO - 2018-04-07 10:33:40 --> URI Class Initialized
INFO - 2018-04-07 10:33:40 --> Router Class Initialized
INFO - 2018-04-07 10:33:40 --> Output Class Initialized
INFO - 2018-04-07 10:33:40 --> Security Class Initialized
DEBUG - 2018-04-07 10:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:33:40 --> Input Class Initialized
INFO - 2018-04-07 10:33:40 --> Language Class Initialized
INFO - 2018-04-07 10:33:40 --> Loader Class Initialized
INFO - 2018-04-07 10:33:40 --> Helper loaded: url_helper
INFO - 2018-04-07 10:33:40 --> Helper loaded: file_helper
INFO - 2018-04-07 10:33:40 --> Helper loaded: date_helper
INFO - 2018-04-07 10:33:40 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:33:40 --> Controller Class Initialized
INFO - 2018-04-07 10:33:40 --> Model Class Initialized
INFO - 2018-04-07 10:33:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 10:33:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 10:33:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 10:33:40 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 10:33:40 --> Final output sent to browser
DEBUG - 2018-04-07 10:33:40 --> Total execution time: 0.4134
INFO - 2018-04-07 10:33:42 --> Config Class Initialized
INFO - 2018-04-07 10:33:42 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:33:42 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:33:42 --> Utf8 Class Initialized
INFO - 2018-04-07 10:33:42 --> URI Class Initialized
INFO - 2018-04-07 10:33:42 --> Router Class Initialized
INFO - 2018-04-07 10:33:42 --> Output Class Initialized
INFO - 2018-04-07 10:33:42 --> Security Class Initialized
DEBUG - 2018-04-07 10:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:33:42 --> Input Class Initialized
INFO - 2018-04-07 10:33:42 --> Language Class Initialized
INFO - 2018-04-07 10:33:42 --> Loader Class Initialized
INFO - 2018-04-07 10:33:42 --> Helper loaded: url_helper
INFO - 2018-04-07 10:33:42 --> Helper loaded: file_helper
INFO - 2018-04-07 10:33:42 --> Helper loaded: date_helper
INFO - 2018-04-07 10:33:42 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:33:42 --> Controller Class Initialized
INFO - 2018-04-07 10:33:42 --> Model Class Initialized
INFO - 2018-04-07 10:33:42 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 10:33:42 --> Final output sent to browser
DEBUG - 2018-04-07 10:33:42 --> Total execution time: 0.3596
INFO - 2018-04-07 10:33:56 --> Config Class Initialized
INFO - 2018-04-07 10:33:56 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:33:56 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:33:56 --> Utf8 Class Initialized
INFO - 2018-04-07 10:33:56 --> URI Class Initialized
INFO - 2018-04-07 10:33:56 --> Router Class Initialized
INFO - 2018-04-07 10:33:56 --> Output Class Initialized
INFO - 2018-04-07 10:33:56 --> Security Class Initialized
DEBUG - 2018-04-07 10:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:33:56 --> Input Class Initialized
INFO - 2018-04-07 10:33:56 --> Language Class Initialized
INFO - 2018-04-07 10:33:56 --> Loader Class Initialized
INFO - 2018-04-07 10:33:56 --> Helper loaded: url_helper
INFO - 2018-04-07 10:33:56 --> Helper loaded: file_helper
INFO - 2018-04-07 10:33:56 --> Helper loaded: date_helper
INFO - 2018-04-07 10:33:56 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:33:56 --> Controller Class Initialized
INFO - 2018-04-07 10:34:01 --> Config Class Initialized
INFO - 2018-04-07 10:34:01 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:34:01 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:34:01 --> Utf8 Class Initialized
INFO - 2018-04-07 10:34:01 --> URI Class Initialized
INFO - 2018-04-07 10:34:01 --> Router Class Initialized
INFO - 2018-04-07 10:34:01 --> Output Class Initialized
INFO - 2018-04-07 10:34:01 --> Security Class Initialized
DEBUG - 2018-04-07 10:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:34:01 --> Input Class Initialized
INFO - 2018-04-07 10:34:01 --> Language Class Initialized
INFO - 2018-04-07 10:34:01 --> Loader Class Initialized
INFO - 2018-04-07 10:34:01 --> Helper loaded: url_helper
INFO - 2018-04-07 10:34:01 --> Helper loaded: file_helper
INFO - 2018-04-07 10:34:01 --> Helper loaded: date_helper
INFO - 2018-04-07 10:34:01 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:34:01 --> Controller Class Initialized
INFO - 2018-04-07 10:34:01 --> Model Class Initialized
INFO - 2018-04-07 10:34:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 10:34:01 --> Final output sent to browser
DEBUG - 2018-04-07 10:34:01 --> Total execution time: 0.3340
INFO - 2018-04-07 10:34:09 --> Config Class Initialized
INFO - 2018-04-07 10:34:09 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:34:09 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:34:09 --> Utf8 Class Initialized
INFO - 2018-04-07 10:34:09 --> URI Class Initialized
INFO - 2018-04-07 10:34:09 --> Router Class Initialized
INFO - 2018-04-07 10:34:09 --> Output Class Initialized
INFO - 2018-04-07 10:34:09 --> Security Class Initialized
DEBUG - 2018-04-07 10:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:34:09 --> Input Class Initialized
INFO - 2018-04-07 10:34:09 --> Language Class Initialized
INFO - 2018-04-07 10:34:09 --> Loader Class Initialized
INFO - 2018-04-07 10:34:09 --> Helper loaded: url_helper
INFO - 2018-04-07 10:34:09 --> Helper loaded: file_helper
INFO - 2018-04-07 10:34:09 --> Helper loaded: date_helper
INFO - 2018-04-07 10:34:09 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:34:09 --> Controller Class Initialized
INFO - 2018-04-07 10:34:09 --> Model Class Initialized
INFO - 2018-04-07 10:34:09 --> Final output sent to browser
DEBUG - 2018-04-07 10:34:09 --> Total execution time: 0.3074
INFO - 2018-04-07 10:34:09 --> Config Class Initialized
INFO - 2018-04-07 10:34:09 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:34:09 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:34:09 --> Utf8 Class Initialized
INFO - 2018-04-07 10:34:09 --> URI Class Initialized
INFO - 2018-04-07 10:34:09 --> Router Class Initialized
INFO - 2018-04-07 10:34:09 --> Output Class Initialized
INFO - 2018-04-07 10:34:09 --> Security Class Initialized
DEBUG - 2018-04-07 10:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:34:09 --> Input Class Initialized
INFO - 2018-04-07 10:34:09 --> Language Class Initialized
INFO - 2018-04-07 10:34:09 --> Loader Class Initialized
INFO - 2018-04-07 10:34:09 --> Helper loaded: url_helper
INFO - 2018-04-07 10:34:09 --> Helper loaded: file_helper
INFO - 2018-04-07 10:34:09 --> Helper loaded: date_helper
INFO - 2018-04-07 10:34:09 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:34:09 --> Controller Class Initialized
INFO - 2018-04-07 10:34:09 --> Model Class Initialized
INFO - 2018-04-07 10:34:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-07 10:34:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-07 10:34:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-07 10:34:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-07 10:34:09 --> Final output sent to browser
DEBUG - 2018-04-07 10:34:09 --> Total execution time: 0.3460
INFO - 2018-04-07 10:34:12 --> Config Class Initialized
INFO - 2018-04-07 10:34:12 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:34:12 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:34:12 --> Utf8 Class Initialized
INFO - 2018-04-07 10:34:12 --> URI Class Initialized
INFO - 2018-04-07 10:34:12 --> Router Class Initialized
INFO - 2018-04-07 10:34:12 --> Output Class Initialized
INFO - 2018-04-07 10:34:12 --> Security Class Initialized
DEBUG - 2018-04-07 10:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:34:12 --> Input Class Initialized
INFO - 2018-04-07 10:34:12 --> Language Class Initialized
INFO - 2018-04-07 10:34:12 --> Loader Class Initialized
INFO - 2018-04-07 10:34:12 --> Helper loaded: url_helper
INFO - 2018-04-07 10:34:12 --> Helper loaded: file_helper
INFO - 2018-04-07 10:34:12 --> Helper loaded: date_helper
INFO - 2018-04-07 10:34:12 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:34:12 --> Controller Class Initialized
INFO - 2018-04-07 10:34:12 --> Model Class Initialized
INFO - 2018-04-07 10:34:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 10:34:12 --> Final output sent to browser
DEBUG - 2018-04-07 10:34:12 --> Total execution time: 0.3235
INFO - 2018-04-07 10:34:13 --> Config Class Initialized
INFO - 2018-04-07 10:34:13 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:34:13 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:34:13 --> Utf8 Class Initialized
INFO - 2018-04-07 10:34:13 --> URI Class Initialized
INFO - 2018-04-07 10:34:13 --> Router Class Initialized
INFO - 2018-04-07 10:34:13 --> Output Class Initialized
INFO - 2018-04-07 10:34:13 --> Security Class Initialized
DEBUG - 2018-04-07 10:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:34:13 --> Input Class Initialized
INFO - 2018-04-07 10:34:13 --> Language Class Initialized
INFO - 2018-04-07 10:34:13 --> Loader Class Initialized
INFO - 2018-04-07 10:34:13 --> Helper loaded: url_helper
INFO - 2018-04-07 10:34:13 --> Helper loaded: file_helper
INFO - 2018-04-07 10:34:13 --> Helper loaded: date_helper
INFO - 2018-04-07 10:34:13 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:34:14 --> Controller Class Initialized
INFO - 2018-04-07 10:34:14 --> Model Class Initialized
INFO - 2018-04-07 10:34:14 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 10:34:14 --> Final output sent to browser
DEBUG - 2018-04-07 10:34:14 --> Total execution time: 0.3802
INFO - 2018-04-07 10:34:17 --> Config Class Initialized
INFO - 2018-04-07 10:34:17 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:34:17 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:34:17 --> Utf8 Class Initialized
INFO - 2018-04-07 10:34:17 --> URI Class Initialized
INFO - 2018-04-07 10:34:17 --> Router Class Initialized
INFO - 2018-04-07 10:34:17 --> Output Class Initialized
INFO - 2018-04-07 10:34:17 --> Security Class Initialized
DEBUG - 2018-04-07 10:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:34:17 --> Input Class Initialized
INFO - 2018-04-07 10:34:17 --> Language Class Initialized
INFO - 2018-04-07 10:34:17 --> Loader Class Initialized
INFO - 2018-04-07 10:34:17 --> Helper loaded: url_helper
INFO - 2018-04-07 10:34:17 --> Helper loaded: file_helper
INFO - 2018-04-07 10:34:17 --> Helper loaded: date_helper
INFO - 2018-04-07 10:34:17 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:34:17 --> Controller Class Initialized
INFO - 2018-04-07 10:34:21 --> Config Class Initialized
INFO - 2018-04-07 10:34:21 --> Hooks Class Initialized
DEBUG - 2018-04-07 10:34:21 --> UTF-8 Support Enabled
INFO - 2018-04-07 10:34:21 --> Utf8 Class Initialized
INFO - 2018-04-07 10:34:21 --> URI Class Initialized
INFO - 2018-04-07 10:34:21 --> Router Class Initialized
INFO - 2018-04-07 10:34:21 --> Output Class Initialized
INFO - 2018-04-07 10:34:21 --> Security Class Initialized
DEBUG - 2018-04-07 10:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 10:34:21 --> Input Class Initialized
INFO - 2018-04-07 10:34:21 --> Language Class Initialized
INFO - 2018-04-07 10:34:21 --> Loader Class Initialized
INFO - 2018-04-07 10:34:22 --> Helper loaded: url_helper
INFO - 2018-04-07 10:34:22 --> Helper loaded: file_helper
INFO - 2018-04-07 10:34:22 --> Helper loaded: date_helper
INFO - 2018-04-07 10:34:22 --> Database Driver Class Initialized
DEBUG - 2018-04-07 10:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 10:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 10:34:22 --> Controller Class Initialized
INFO - 2018-04-07 10:34:22 --> Model Class Initialized
INFO - 2018-04-07 10:34:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 10:34:22 --> Final output sent to browser
DEBUG - 2018-04-07 10:34:22 --> Total execution time: 0.3630
INFO - 2018-04-07 20:02:24 --> Config Class Initialized
INFO - 2018-04-07 20:02:24 --> Hooks Class Initialized
DEBUG - 2018-04-07 20:02:25 --> UTF-8 Support Enabled
INFO - 2018-04-07 20:02:25 --> Utf8 Class Initialized
INFO - 2018-04-07 20:02:25 --> URI Class Initialized
INFO - 2018-04-07 20:02:25 --> Router Class Initialized
INFO - 2018-04-07 20:02:25 --> Output Class Initialized
INFO - 2018-04-07 20:02:25 --> Security Class Initialized
DEBUG - 2018-04-07 20:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-07 20:02:25 --> Input Class Initialized
INFO - 2018-04-07 20:02:25 --> Language Class Initialized
INFO - 2018-04-07 20:02:25 --> Loader Class Initialized
INFO - 2018-04-07 20:02:25 --> Helper loaded: url_helper
INFO - 2018-04-07 20:02:25 --> Helper loaded: file_helper
INFO - 2018-04-07 20:02:26 --> Helper loaded: date_helper
INFO - 2018-04-07 20:02:26 --> Database Driver Class Initialized
DEBUG - 2018-04-07 20:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-07 20:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-07 20:02:26 --> Controller Class Initialized
INFO - 2018-04-07 20:02:26 --> Model Class Initialized
INFO - 2018-04-07 20:02:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-07 20:02:26 --> Final output sent to browser
DEBUG - 2018-04-07 20:02:26 --> Total execution time: 2.4496
