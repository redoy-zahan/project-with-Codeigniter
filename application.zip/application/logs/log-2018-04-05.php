<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-05 05:54:00 --> Config Class Initialized
INFO - 2018-04-05 05:54:00 --> Hooks Class Initialized
DEBUG - 2018-04-05 05:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-05 05:54:00 --> Utf8 Class Initialized
INFO - 2018-04-05 05:54:01 --> URI Class Initialized
DEBUG - 2018-04-05 05:54:01 --> No URI present. Default controller set.
INFO - 2018-04-05 05:54:01 --> Router Class Initialized
INFO - 2018-04-05 05:54:01 --> Output Class Initialized
INFO - 2018-04-05 05:54:01 --> Security Class Initialized
DEBUG - 2018-04-05 05:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 05:54:01 --> Input Class Initialized
INFO - 2018-04-05 05:54:01 --> Language Class Initialized
INFO - 2018-04-05 05:54:01 --> Loader Class Initialized
INFO - 2018-04-05 05:54:01 --> Helper loaded: url_helper
INFO - 2018-04-05 05:54:01 --> Helper loaded: file_helper
INFO - 2018-04-05 05:54:01 --> Helper loaded: date_helper
INFO - 2018-04-05 05:54:01 --> Database Driver Class Initialized
DEBUG - 2018-04-05 05:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 05:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 05:54:02 --> Controller Class Initialized
INFO - 2018-04-05 05:54:02 --> Config Class Initialized
INFO - 2018-04-05 05:54:02 --> Hooks Class Initialized
DEBUG - 2018-04-05 05:54:02 --> UTF-8 Support Enabled
INFO - 2018-04-05 05:54:02 --> Utf8 Class Initialized
INFO - 2018-04-05 05:54:02 --> URI Class Initialized
INFO - 2018-04-05 05:54:02 --> Router Class Initialized
INFO - 2018-04-05 05:54:02 --> Output Class Initialized
INFO - 2018-04-05 05:54:02 --> Security Class Initialized
DEBUG - 2018-04-05 05:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-05 05:54:02 --> Input Class Initialized
INFO - 2018-04-05 05:54:02 --> Language Class Initialized
INFO - 2018-04-05 05:54:02 --> Loader Class Initialized
INFO - 2018-04-05 05:54:02 --> Helper loaded: url_helper
INFO - 2018-04-05 05:54:02 --> Helper loaded: file_helper
INFO - 2018-04-05 05:54:02 --> Helper loaded: date_helper
INFO - 2018-04-05 05:54:02 --> Database Driver Class Initialized
DEBUG - 2018-04-05 05:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-05 05:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-05 05:54:02 --> Controller Class Initialized
INFO - 2018-04-05 05:54:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-05 05:54:02 --> Final output sent to browser
DEBUG - 2018-04-05 05:54:02 --> Total execution time: 0.3304
