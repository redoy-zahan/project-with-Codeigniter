<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-03 01:41:34 --> Config Class Initialized
INFO - 2018-04-03 01:41:34 --> Hooks Class Initialized
DEBUG - 2018-04-03 01:41:34 --> UTF-8 Support Enabled
INFO - 2018-04-03 01:41:34 --> Utf8 Class Initialized
INFO - 2018-04-03 01:41:34 --> URI Class Initialized
DEBUG - 2018-04-03 01:41:34 --> No URI present. Default controller set.
INFO - 2018-04-03 01:41:34 --> Router Class Initialized
INFO - 2018-04-03 01:41:35 --> Output Class Initialized
INFO - 2018-04-03 01:41:35 --> Security Class Initialized
DEBUG - 2018-04-03 01:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 01:41:35 --> Input Class Initialized
INFO - 2018-04-03 01:41:35 --> Language Class Initialized
INFO - 2018-04-03 01:41:35 --> Loader Class Initialized
INFO - 2018-04-03 01:41:35 --> Helper loaded: url_helper
INFO - 2018-04-03 01:41:35 --> Helper loaded: file_helper
INFO - 2018-04-03 01:41:35 --> Helper loaded: date_helper
INFO - 2018-04-03 01:41:36 --> Database Driver Class Initialized
DEBUG - 2018-04-03 01:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 01:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 01:41:36 --> Controller Class Initialized
INFO - 2018-04-03 01:41:36 --> Config Class Initialized
INFO - 2018-04-03 01:41:36 --> Hooks Class Initialized
DEBUG - 2018-04-03 01:41:36 --> UTF-8 Support Enabled
INFO - 2018-04-03 01:41:36 --> Utf8 Class Initialized
INFO - 2018-04-03 01:41:36 --> URI Class Initialized
INFO - 2018-04-03 01:41:36 --> Router Class Initialized
INFO - 2018-04-03 01:41:36 --> Output Class Initialized
INFO - 2018-04-03 01:41:36 --> Security Class Initialized
DEBUG - 2018-04-03 01:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 01:41:37 --> Input Class Initialized
INFO - 2018-04-03 01:41:37 --> Language Class Initialized
INFO - 2018-04-03 01:41:37 --> Loader Class Initialized
INFO - 2018-04-03 01:41:37 --> Helper loaded: url_helper
INFO - 2018-04-03 01:41:37 --> Helper loaded: file_helper
INFO - 2018-04-03 01:41:37 --> Helper loaded: date_helper
INFO - 2018-04-03 01:41:37 --> Database Driver Class Initialized
DEBUG - 2018-04-03 01:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 01:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 01:41:37 --> Controller Class Initialized
INFO - 2018-04-03 01:41:37 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-03 01:41:37 --> Final output sent to browser
DEBUG - 2018-04-03 01:41:37 --> Total execution time: 0.4327
INFO - 2018-04-03 01:41:51 --> Config Class Initialized
INFO - 2018-04-03 01:41:51 --> Hooks Class Initialized
DEBUG - 2018-04-03 01:41:51 --> UTF-8 Support Enabled
INFO - 2018-04-03 01:41:51 --> Utf8 Class Initialized
INFO - 2018-04-03 01:41:51 --> URI Class Initialized
INFO - 2018-04-03 01:41:51 --> Router Class Initialized
INFO - 2018-04-03 01:41:51 --> Output Class Initialized
INFO - 2018-04-03 01:41:51 --> Security Class Initialized
DEBUG - 2018-04-03 01:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 01:41:51 --> Input Class Initialized
INFO - 2018-04-03 01:41:51 --> Language Class Initialized
INFO - 2018-04-03 01:41:51 --> Loader Class Initialized
INFO - 2018-04-03 01:41:51 --> Helper loaded: url_helper
INFO - 2018-04-03 01:41:51 --> Helper loaded: file_helper
INFO - 2018-04-03 01:41:51 --> Helper loaded: date_helper
INFO - 2018-04-03 01:41:51 --> Database Driver Class Initialized
DEBUG - 2018-04-03 01:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 01:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 01:41:51 --> Controller Class Initialized
INFO - 2018-04-03 01:41:51 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/registration.php
INFO - 2018-04-03 01:41:51 --> Final output sent to browser
DEBUG - 2018-04-03 01:41:51 --> Total execution time: 0.4390
INFO - 2018-04-03 01:44:27 --> Config Class Initialized
INFO - 2018-04-03 01:44:27 --> Hooks Class Initialized
DEBUG - 2018-04-03 01:44:27 --> UTF-8 Support Enabled
INFO - 2018-04-03 01:44:27 --> Utf8 Class Initialized
INFO - 2018-04-03 01:44:27 --> URI Class Initialized
INFO - 2018-04-03 01:44:27 --> Router Class Initialized
INFO - 2018-04-03 01:44:27 --> Output Class Initialized
INFO - 2018-04-03 01:44:27 --> Security Class Initialized
DEBUG - 2018-04-03 01:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-03 01:44:27 --> Input Class Initialized
INFO - 2018-04-03 01:44:27 --> Language Class Initialized
INFO - 2018-04-03 01:44:27 --> Loader Class Initialized
INFO - 2018-04-03 01:44:27 --> Helper loaded: url_helper
INFO - 2018-04-03 01:44:27 --> Helper loaded: file_helper
INFO - 2018-04-03 01:44:27 --> Helper loaded: date_helper
INFO - 2018-04-03 01:44:27 --> Database Driver Class Initialized
DEBUG - 2018-04-03 01:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-03 01:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-03 01:44:27 --> Controller Class Initialized
INFO - 2018-04-03 01:44:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-03 01:44:27 --> Final output sent to browser
DEBUG - 2018-04-03 01:44:27 --> Total execution time: 0.2376
