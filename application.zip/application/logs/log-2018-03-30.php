<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-30 17:42:30 --> Config Class Initialized
INFO - 2018-03-30 17:42:30 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:42:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:42:30 --> Utf8 Class Initialized
INFO - 2018-03-30 17:42:31 --> URI Class Initialized
DEBUG - 2018-03-30 17:42:31 --> No URI present. Default controller set.
INFO - 2018-03-30 17:42:31 --> Router Class Initialized
INFO - 2018-03-30 17:42:31 --> Output Class Initialized
INFO - 2018-03-30 17:42:31 --> Security Class Initialized
DEBUG - 2018-03-30 17:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:42:31 --> Input Class Initialized
INFO - 2018-03-30 17:42:31 --> Language Class Initialized
INFO - 2018-03-30 17:42:31 --> Loader Class Initialized
INFO - 2018-03-30 17:42:31 --> Helper loaded: url_helper
INFO - 2018-03-30 17:42:31 --> Helper loaded: file_helper
INFO - 2018-03-30 17:42:31 --> Helper loaded: date_helper
INFO - 2018-03-30 17:42:31 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:42:32 --> Controller Class Initialized
INFO - 2018-03-30 17:42:32 --> Config Class Initialized
INFO - 2018-03-30 17:42:32 --> Config Class Initialized
INFO - 2018-03-30 17:42:32 --> Hooks Class Initialized
INFO - 2018-03-30 17:42:32 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:42:32 --> UTF-8 Support Enabled
DEBUG - 2018-03-30 17:42:32 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:42:32 --> Utf8 Class Initialized
INFO - 2018-03-30 17:42:32 --> Utf8 Class Initialized
INFO - 2018-03-30 17:42:32 --> URI Class Initialized
INFO - 2018-03-30 17:42:32 --> URI Class Initialized
DEBUG - 2018-03-30 17:42:32 --> No URI present. Default controller set.
INFO - 2018-03-30 17:42:32 --> Router Class Initialized
INFO - 2018-03-30 17:42:32 --> Router Class Initialized
INFO - 2018-03-30 17:42:32 --> Output Class Initialized
INFO - 2018-03-30 17:42:32 --> Output Class Initialized
INFO - 2018-03-30 17:42:32 --> Security Class Initialized
DEBUG - 2018-03-30 17:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:42:32 --> Security Class Initialized
INFO - 2018-03-30 17:42:32 --> Input Class Initialized
DEBUG - 2018-03-30 17:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:42:32 --> Input Class Initialized
INFO - 2018-03-30 17:42:32 --> Language Class Initialized
INFO - 2018-03-30 17:42:32 --> Language Class Initialized
INFO - 2018-03-30 17:42:32 --> Loader Class Initialized
INFO - 2018-03-30 17:42:32 --> Helper loaded: url_helper
INFO - 2018-03-30 17:42:32 --> Loader Class Initialized
INFO - 2018-03-30 17:42:32 --> Helper loaded: file_helper
INFO - 2018-03-30 17:42:32 --> Helper loaded: url_helper
INFO - 2018-03-30 17:42:32 --> Helper loaded: file_helper
INFO - 2018-03-30 17:42:32 --> Helper loaded: date_helper
INFO - 2018-03-30 17:42:32 --> Helper loaded: date_helper
INFO - 2018-03-30 17:42:32 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:42:32 --> Database Driver Class Initialized
INFO - 2018-03-30 17:42:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-03-30 17:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:42:32 --> Controller Class Initialized
INFO - 2018-03-30 17:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:42:32 --> Controller Class Initialized
INFO - 2018-03-30 17:42:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\login/login.php
INFO - 2018-03-30 17:42:32 --> Final output sent to browser
DEBUG - 2018-03-30 17:42:32 --> Total execution time: 0.2162
INFO - 2018-03-30 17:42:32 --> Config Class Initialized
INFO - 2018-03-30 17:42:32 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:42:32 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:42:32 --> Utf8 Class Initialized
INFO - 2018-03-30 17:42:32 --> URI Class Initialized
INFO - 2018-03-30 17:42:32 --> Router Class Initialized
INFO - 2018-03-30 17:42:32 --> Output Class Initialized
INFO - 2018-03-30 17:42:32 --> Security Class Initialized
DEBUG - 2018-03-30 17:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:42:32 --> Input Class Initialized
INFO - 2018-03-30 17:42:32 --> Language Class Initialized
INFO - 2018-03-30 17:42:32 --> Loader Class Initialized
INFO - 2018-03-30 17:42:32 --> Helper loaded: url_helper
INFO - 2018-03-30 17:42:32 --> Helper loaded: file_helper
INFO - 2018-03-30 17:42:32 --> Helper loaded: date_helper
INFO - 2018-03-30 17:42:32 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:42:32 --> Controller Class Initialized
INFO - 2018-03-30 17:42:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\login/login.php
INFO - 2018-03-30 17:42:32 --> Final output sent to browser
DEBUG - 2018-03-30 17:42:32 --> Total execution time: 0.2256
INFO - 2018-03-30 17:57:35 --> Config Class Initialized
INFO - 2018-03-30 17:57:35 --> Hooks Class Initialized
DEBUG - 2018-03-30 17:57:35 --> UTF-8 Support Enabled
INFO - 2018-03-30 17:57:35 --> Utf8 Class Initialized
INFO - 2018-03-30 17:57:35 --> URI Class Initialized
INFO - 2018-03-30 17:57:35 --> Router Class Initialized
INFO - 2018-03-30 17:57:35 --> Output Class Initialized
INFO - 2018-03-30 17:57:35 --> Security Class Initialized
DEBUG - 2018-03-30 17:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 17:57:36 --> Input Class Initialized
INFO - 2018-03-30 17:57:36 --> Language Class Initialized
INFO - 2018-03-30 17:57:36 --> Loader Class Initialized
INFO - 2018-03-30 17:57:36 --> Helper loaded: url_helper
INFO - 2018-03-30 17:57:36 --> Helper loaded: file_helper
INFO - 2018-03-30 17:57:36 --> Helper loaded: date_helper
INFO - 2018-03-30 17:57:36 --> Database Driver Class Initialized
DEBUG - 2018-03-30 17:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 17:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 17:57:36 --> Controller Class Initialized
INFO - 2018-03-30 18:04:59 --> Config Class Initialized
INFO - 2018-03-30 18:04:59 --> Hooks Class Initialized
DEBUG - 2018-03-30 18:05:00 --> UTF-8 Support Enabled
INFO - 2018-03-30 18:05:00 --> Utf8 Class Initialized
INFO - 2018-03-30 18:05:00 --> URI Class Initialized
INFO - 2018-03-30 18:05:00 --> Router Class Initialized
INFO - 2018-03-30 18:05:00 --> Output Class Initialized
INFO - 2018-03-30 18:05:00 --> Security Class Initialized
DEBUG - 2018-03-30 18:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 18:05:00 --> Input Class Initialized
INFO - 2018-03-30 18:05:00 --> Language Class Initialized
INFO - 2018-03-30 18:05:00 --> Loader Class Initialized
INFO - 2018-03-30 18:05:00 --> Helper loaded: url_helper
INFO - 2018-03-30 18:05:00 --> Helper loaded: file_helper
INFO - 2018-03-30 18:05:00 --> Helper loaded: date_helper
INFO - 2018-03-30 18:05:00 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:05:00 --> Controller Class Initialized
INFO - 2018-03-30 18:46:26 --> Config Class Initialized
INFO - 2018-03-30 18:46:26 --> Hooks Class Initialized
DEBUG - 2018-03-30 18:46:26 --> UTF-8 Support Enabled
INFO - 2018-03-30 18:46:26 --> Utf8 Class Initialized
INFO - 2018-03-30 18:46:26 --> URI Class Initialized
INFO - 2018-03-30 18:46:26 --> Router Class Initialized
INFO - 2018-03-30 18:46:26 --> Output Class Initialized
INFO - 2018-03-30 18:46:26 --> Security Class Initialized
DEBUG - 2018-03-30 18:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 18:46:26 --> Input Class Initialized
INFO - 2018-03-30 18:46:26 --> Language Class Initialized
INFO - 2018-03-30 18:46:26 --> Loader Class Initialized
INFO - 2018-03-30 18:46:26 --> Helper loaded: url_helper
INFO - 2018-03-30 18:46:27 --> Helper loaded: file_helper
INFO - 2018-03-30 18:46:27 --> Helper loaded: date_helper
INFO - 2018-03-30 18:46:27 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:46:27 --> Controller Class Initialized
INFO - 2018-03-30 18:46:32 --> Config Class Initialized
INFO - 2018-03-30 18:46:32 --> Hooks Class Initialized
DEBUG - 2018-03-30 18:46:32 --> UTF-8 Support Enabled
INFO - 2018-03-30 18:46:32 --> Utf8 Class Initialized
INFO - 2018-03-30 18:46:32 --> URI Class Initialized
DEBUG - 2018-03-30 18:46:32 --> No URI present. Default controller set.
INFO - 2018-03-30 18:46:32 --> Router Class Initialized
INFO - 2018-03-30 18:46:32 --> Output Class Initialized
INFO - 2018-03-30 18:46:32 --> Security Class Initialized
DEBUG - 2018-03-30 18:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 18:46:32 --> Input Class Initialized
INFO - 2018-03-30 18:46:32 --> Language Class Initialized
INFO - 2018-03-30 18:46:32 --> Loader Class Initialized
INFO - 2018-03-30 18:46:32 --> Helper loaded: url_helper
INFO - 2018-03-30 18:46:32 --> Helper loaded: file_helper
INFO - 2018-03-30 18:46:32 --> Helper loaded: date_helper
INFO - 2018-03-30 18:46:32 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:46:32 --> Controller Class Initialized
INFO - 2018-03-30 18:46:32 --> Config Class Initialized
INFO - 2018-03-30 18:46:32 --> Hooks Class Initialized
DEBUG - 2018-03-30 18:46:32 --> UTF-8 Support Enabled
INFO - 2018-03-30 18:46:32 --> Utf8 Class Initialized
INFO - 2018-03-30 18:46:32 --> URI Class Initialized
INFO - 2018-03-30 18:46:32 --> Router Class Initialized
INFO - 2018-03-30 18:46:32 --> Output Class Initialized
INFO - 2018-03-30 18:46:32 --> Security Class Initialized
DEBUG - 2018-03-30 18:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 18:46:32 --> Input Class Initialized
INFO - 2018-03-30 18:46:32 --> Language Class Initialized
INFO - 2018-03-30 18:46:32 --> Loader Class Initialized
INFO - 2018-03-30 18:46:32 --> Helper loaded: url_helper
INFO - 2018-03-30 18:46:32 --> Helper loaded: file_helper
INFO - 2018-03-30 18:46:32 --> Helper loaded: date_helper
INFO - 2018-03-30 18:46:32 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:46:32 --> Controller Class Initialized
INFO - 2018-03-30 18:47:07 --> Config Class Initialized
INFO - 2018-03-30 18:47:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 18:47:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 18:47:07 --> Utf8 Class Initialized
INFO - 2018-03-30 18:47:07 --> URI Class Initialized
INFO - 2018-03-30 18:47:07 --> Router Class Initialized
INFO - 2018-03-30 18:47:07 --> Output Class Initialized
INFO - 2018-03-30 18:47:07 --> Security Class Initialized
DEBUG - 2018-03-30 18:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 18:47:07 --> Input Class Initialized
INFO - 2018-03-30 18:47:07 --> Language Class Initialized
INFO - 2018-03-30 18:47:07 --> Loader Class Initialized
INFO - 2018-03-30 18:47:07 --> Helper loaded: url_helper
INFO - 2018-03-30 18:47:07 --> Helper loaded: file_helper
INFO - 2018-03-30 18:47:07 --> Helper loaded: date_helper
INFO - 2018-03-30 18:47:07 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:47:07 --> Controller Class Initialized
INFO - 2018-03-30 18:47:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-03-30 18:47:07 --> Final output sent to browser
DEBUG - 2018-03-30 18:47:07 --> Total execution time: 0.2500
INFO - 2018-03-30 18:54:58 --> Config Class Initialized
INFO - 2018-03-30 18:54:59 --> Hooks Class Initialized
DEBUG - 2018-03-30 18:54:59 --> UTF-8 Support Enabled
INFO - 2018-03-30 18:54:59 --> Utf8 Class Initialized
INFO - 2018-03-30 18:54:59 --> URI Class Initialized
INFO - 2018-03-30 18:54:59 --> Router Class Initialized
INFO - 2018-03-30 18:54:59 --> Output Class Initialized
INFO - 2018-03-30 18:54:59 --> Security Class Initialized
DEBUG - 2018-03-30 18:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 18:54:59 --> Input Class Initialized
INFO - 2018-03-30 18:54:59 --> Language Class Initialized
INFO - 2018-03-30 18:54:59 --> Loader Class Initialized
INFO - 2018-03-30 18:54:59 --> Helper loaded: url_helper
INFO - 2018-03-30 18:54:59 --> Helper loaded: file_helper
INFO - 2018-03-30 18:54:59 --> Helper loaded: date_helper
INFO - 2018-03-30 18:54:59 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:54:59 --> Controller Class Initialized
INFO - 2018-03-30 18:54:59 --> Model Class Initialized
INFO - 2018-03-30 18:55:33 --> Config Class Initialized
INFO - 2018-03-30 18:55:33 --> Hooks Class Initialized
DEBUG - 2018-03-30 18:55:33 --> UTF-8 Support Enabled
INFO - 2018-03-30 18:55:33 --> Utf8 Class Initialized
INFO - 2018-03-30 18:55:33 --> URI Class Initialized
INFO - 2018-03-30 18:55:33 --> Router Class Initialized
INFO - 2018-03-30 18:55:33 --> Output Class Initialized
INFO - 2018-03-30 18:55:34 --> Security Class Initialized
DEBUG - 2018-03-30 18:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 18:55:34 --> Input Class Initialized
INFO - 2018-03-30 18:55:34 --> Language Class Initialized
INFO - 2018-03-30 18:55:34 --> Loader Class Initialized
INFO - 2018-03-30 18:55:34 --> Helper loaded: url_helper
INFO - 2018-03-30 18:55:34 --> Helper loaded: file_helper
INFO - 2018-03-30 18:55:34 --> Helper loaded: date_helper
INFO - 2018-03-30 18:55:34 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:55:34 --> Controller Class Initialized
INFO - 2018-03-30 18:55:34 --> Model Class Initialized
INFO - 2018-03-30 18:56:28 --> Config Class Initialized
INFO - 2018-03-30 18:56:28 --> Hooks Class Initialized
DEBUG - 2018-03-30 18:56:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 18:56:29 --> Utf8 Class Initialized
INFO - 2018-03-30 18:56:29 --> URI Class Initialized
INFO - 2018-03-30 18:56:29 --> Router Class Initialized
INFO - 2018-03-30 18:56:29 --> Output Class Initialized
INFO - 2018-03-30 18:56:29 --> Security Class Initialized
DEBUG - 2018-03-30 18:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 18:56:29 --> Input Class Initialized
INFO - 2018-03-30 18:56:29 --> Language Class Initialized
INFO - 2018-03-30 18:56:29 --> Loader Class Initialized
INFO - 2018-03-30 18:56:29 --> Helper loaded: url_helper
INFO - 2018-03-30 18:56:29 --> Helper loaded: file_helper
INFO - 2018-03-30 18:56:29 --> Helper loaded: date_helper
INFO - 2018-03-30 18:56:29 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:56:29 --> Controller Class Initialized
INFO - 2018-03-30 18:56:29 --> Model Class Initialized
INFO - 2018-03-30 18:57:26 --> Config Class Initialized
INFO - 2018-03-30 18:57:26 --> Hooks Class Initialized
DEBUG - 2018-03-30 18:57:26 --> UTF-8 Support Enabled
INFO - 2018-03-30 18:57:26 --> Utf8 Class Initialized
INFO - 2018-03-30 18:57:26 --> URI Class Initialized
INFO - 2018-03-30 18:57:26 --> Router Class Initialized
INFO - 2018-03-30 18:57:26 --> Output Class Initialized
INFO - 2018-03-30 18:57:26 --> Security Class Initialized
DEBUG - 2018-03-30 18:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 18:57:26 --> Input Class Initialized
INFO - 2018-03-30 18:57:26 --> Language Class Initialized
INFO - 2018-03-30 18:57:26 --> Loader Class Initialized
INFO - 2018-03-30 18:57:26 --> Helper loaded: url_helper
INFO - 2018-03-30 18:57:26 --> Helper loaded: file_helper
INFO - 2018-03-30 18:57:26 --> Helper loaded: date_helper
INFO - 2018-03-30 18:57:26 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:57:26 --> Controller Class Initialized
INFO - 2018-03-30 18:57:26 --> Model Class Initialized
INFO - 2018-03-30 18:58:20 --> Config Class Initialized
INFO - 2018-03-30 18:58:20 --> Hooks Class Initialized
DEBUG - 2018-03-30 18:58:20 --> UTF-8 Support Enabled
INFO - 2018-03-30 18:58:20 --> Utf8 Class Initialized
INFO - 2018-03-30 18:58:20 --> URI Class Initialized
INFO - 2018-03-30 18:58:20 --> Router Class Initialized
INFO - 2018-03-30 18:58:20 --> Output Class Initialized
INFO - 2018-03-30 18:58:20 --> Security Class Initialized
DEBUG - 2018-03-30 18:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 18:58:20 --> Input Class Initialized
INFO - 2018-03-30 18:58:20 --> Language Class Initialized
INFO - 2018-03-30 18:58:20 --> Loader Class Initialized
INFO - 2018-03-30 18:58:20 --> Helper loaded: url_helper
INFO - 2018-03-30 18:58:20 --> Helper loaded: file_helper
INFO - 2018-03-30 18:58:20 --> Helper loaded: date_helper
INFO - 2018-03-30 18:58:20 --> Database Driver Class Initialized
DEBUG - 2018-03-30 18:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 18:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 18:58:20 --> Controller Class Initialized
INFO - 2018-03-30 18:58:20 --> Model Class Initialized
INFO - 2018-03-30 19:01:31 --> Config Class Initialized
INFO - 2018-03-30 19:01:31 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:01:31 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:01:31 --> Utf8 Class Initialized
INFO - 2018-03-30 19:01:31 --> URI Class Initialized
INFO - 2018-03-30 19:01:31 --> Router Class Initialized
INFO - 2018-03-30 19:01:31 --> Output Class Initialized
INFO - 2018-03-30 19:01:31 --> Security Class Initialized
DEBUG - 2018-03-30 19:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:01:31 --> Input Class Initialized
INFO - 2018-03-30 19:01:31 --> Language Class Initialized
INFO - 2018-03-30 19:01:31 --> Loader Class Initialized
INFO - 2018-03-30 19:01:31 --> Helper loaded: url_helper
INFO - 2018-03-30 19:01:31 --> Helper loaded: file_helper
INFO - 2018-03-30 19:01:31 --> Helper loaded: date_helper
INFO - 2018-03-30 19:01:31 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:01:31 --> Controller Class Initialized
ERROR - 2018-03-30 19:01:31 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' G:\xampp\htdocs\codeigniter\application\models\User_Model.php 34
INFO - 2018-03-30 19:01:52 --> Config Class Initialized
INFO - 2018-03-30 19:01:52 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:01:52 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:01:52 --> Utf8 Class Initialized
INFO - 2018-03-30 19:01:52 --> URI Class Initialized
INFO - 2018-03-30 19:01:52 --> Router Class Initialized
INFO - 2018-03-30 19:01:52 --> Output Class Initialized
INFO - 2018-03-30 19:01:52 --> Security Class Initialized
DEBUG - 2018-03-30 19:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:01:52 --> Input Class Initialized
INFO - 2018-03-30 19:01:52 --> Language Class Initialized
INFO - 2018-03-30 19:01:52 --> Loader Class Initialized
INFO - 2018-03-30 19:01:52 --> Helper loaded: url_helper
INFO - 2018-03-30 19:01:52 --> Helper loaded: file_helper
INFO - 2018-03-30 19:01:52 --> Helper loaded: date_helper
INFO - 2018-03-30 19:01:52 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:01:52 --> Controller Class Initialized
INFO - 2018-03-30 19:01:52 --> Model Class Initialized
ERROR - 2018-03-30 19:01:52 --> Query error: Table 'codeigniter.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `email` = 'redoy@gmail.com'
AND `password` = '123456'
INFO - 2018-03-30 19:01:52 --> Language file loaded: language/english/db_lang.php
INFO - 2018-03-30 19:02:15 --> Config Class Initialized
INFO - 2018-03-30 19:02:15 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:02:15 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:02:15 --> Utf8 Class Initialized
INFO - 2018-03-30 19:02:15 --> URI Class Initialized
INFO - 2018-03-30 19:02:15 --> Router Class Initialized
INFO - 2018-03-30 19:02:15 --> Output Class Initialized
INFO - 2018-03-30 19:02:15 --> Security Class Initialized
DEBUG - 2018-03-30 19:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:02:15 --> Input Class Initialized
INFO - 2018-03-30 19:02:15 --> Language Class Initialized
INFO - 2018-03-30 19:02:15 --> Loader Class Initialized
INFO - 2018-03-30 19:02:15 --> Helper loaded: url_helper
INFO - 2018-03-30 19:02:15 --> Helper loaded: file_helper
INFO - 2018-03-30 19:02:15 --> Helper loaded: date_helper
INFO - 2018-03-30 19:02:15 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:02:16 --> Controller Class Initialized
INFO - 2018-03-30 19:02:16 --> Model Class Initialized
INFO - 2018-03-30 19:03:22 --> Config Class Initialized
INFO - 2018-03-30 19:03:22 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:03:22 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:03:22 --> Utf8 Class Initialized
INFO - 2018-03-30 19:03:22 --> URI Class Initialized
INFO - 2018-03-30 19:03:22 --> Router Class Initialized
INFO - 2018-03-30 19:03:22 --> Output Class Initialized
INFO - 2018-03-30 19:03:22 --> Security Class Initialized
DEBUG - 2018-03-30 19:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:03:22 --> Input Class Initialized
INFO - 2018-03-30 19:03:22 --> Language Class Initialized
INFO - 2018-03-30 19:03:22 --> Loader Class Initialized
INFO - 2018-03-30 19:03:22 --> Helper loaded: url_helper
INFO - 2018-03-30 19:03:22 --> Helper loaded: file_helper
INFO - 2018-03-30 19:03:22 --> Helper loaded: date_helper
INFO - 2018-03-30 19:03:22 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:03:22 --> Controller Class Initialized
INFO - 2018-03-30 19:03:22 --> Model Class Initialized
ERROR - 2018-03-30 19:03:22 --> Severity: Notice --> Undefined index: user_name G:\xampp\htdocs\codeigniter\application\controllers\Auth_Controller.php 44
INFO - 2018-03-30 19:04:04 --> Config Class Initialized
INFO - 2018-03-30 19:04:04 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:04:04 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:04:04 --> Utf8 Class Initialized
INFO - 2018-03-30 19:04:04 --> URI Class Initialized
INFO - 2018-03-30 19:04:04 --> Router Class Initialized
INFO - 2018-03-30 19:04:04 --> Output Class Initialized
INFO - 2018-03-30 19:04:04 --> Security Class Initialized
DEBUG - 2018-03-30 19:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:04:04 --> Input Class Initialized
INFO - 2018-03-30 19:04:04 --> Language Class Initialized
INFO - 2018-03-30 19:04:04 --> Loader Class Initialized
INFO - 2018-03-30 19:04:04 --> Helper loaded: url_helper
INFO - 2018-03-30 19:04:04 --> Helper loaded: file_helper
INFO - 2018-03-30 19:04:04 --> Helper loaded: date_helper
INFO - 2018-03-30 19:04:04 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:04:04 --> Controller Class Initialized
INFO - 2018-03-30 19:04:04 --> Model Class Initialized
INFO - 2018-03-30 19:29:25 --> Config Class Initialized
INFO - 2018-03-30 19:29:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:29:25 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:29:25 --> Utf8 Class Initialized
INFO - 2018-03-30 19:29:25 --> URI Class Initialized
INFO - 2018-03-30 19:29:25 --> Router Class Initialized
INFO - 2018-03-30 19:29:25 --> Output Class Initialized
INFO - 2018-03-30 19:29:25 --> Security Class Initialized
DEBUG - 2018-03-30 19:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:29:25 --> Input Class Initialized
INFO - 2018-03-30 19:29:25 --> Language Class Initialized
INFO - 2018-03-30 19:29:25 --> Loader Class Initialized
INFO - 2018-03-30 19:29:25 --> Helper loaded: url_helper
INFO - 2018-03-30 19:29:25 --> Helper loaded: file_helper
INFO - 2018-03-30 19:29:25 --> Helper loaded: date_helper
INFO - 2018-03-30 19:29:25 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:29:25 --> Controller Class Initialized
INFO - 2018-03-30 19:29:25 --> Model Class Initialized
ERROR - 2018-03-30 19:29:25 --> Severity: Notice --> Undefined property: stdClass::$name G:\xampp\htdocs\codeigniter\application\controllers\Auth_Controller.php 51
INFO - 2018-03-30 19:29:25 --> Final output sent to browser
DEBUG - 2018-03-30 19:29:25 --> Total execution time: 0.2583
INFO - 2018-03-30 19:29:25 --> Config Class Initialized
INFO - 2018-03-30 19:29:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:29:25 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:29:25 --> Utf8 Class Initialized
INFO - 2018-03-30 19:29:25 --> URI Class Initialized
INFO - 2018-03-30 19:29:25 --> Router Class Initialized
INFO - 2018-03-30 19:29:25 --> Output Class Initialized
INFO - 2018-03-30 19:29:25 --> Security Class Initialized
DEBUG - 2018-03-30 19:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:29:25 --> Input Class Initialized
INFO - 2018-03-30 19:29:25 --> Language Class Initialized
INFO - 2018-03-30 19:29:25 --> Loader Class Initialized
INFO - 2018-03-30 19:29:25 --> Helper loaded: url_helper
INFO - 2018-03-30 19:29:25 --> Helper loaded: file_helper
INFO - 2018-03-30 19:29:25 --> Helper loaded: date_helper
INFO - 2018-03-30 19:29:25 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:29:25 --> Controller Class Initialized
INFO - 2018-03-30 19:29:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-03-30 19:29:25 --> Final output sent to browser
DEBUG - 2018-03-30 19:29:25 --> Total execution time: 0.2356
INFO - 2018-03-30 19:33:07 --> Config Class Initialized
INFO - 2018-03-30 19:33:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:33:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:33:07 --> Utf8 Class Initialized
INFO - 2018-03-30 19:33:07 --> URI Class Initialized
INFO - 2018-03-30 19:33:07 --> Router Class Initialized
INFO - 2018-03-30 19:33:07 --> Output Class Initialized
INFO - 2018-03-30 19:33:07 --> Security Class Initialized
DEBUG - 2018-03-30 19:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:33:07 --> Input Class Initialized
INFO - 2018-03-30 19:33:07 --> Language Class Initialized
INFO - 2018-03-30 19:33:07 --> Loader Class Initialized
INFO - 2018-03-30 19:33:07 --> Helper loaded: url_helper
INFO - 2018-03-30 19:33:07 --> Helper loaded: file_helper
INFO - 2018-03-30 19:33:07 --> Helper loaded: date_helper
INFO - 2018-03-30 19:33:07 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:33:07 --> Controller Class Initialized
INFO - 2018-03-30 19:33:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-03-30 19:33:07 --> Final output sent to browser
DEBUG - 2018-03-30 19:33:07 --> Total execution time: 0.2468
INFO - 2018-03-30 19:35:23 --> Config Class Initialized
INFO - 2018-03-30 19:35:23 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:35:23 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:35:23 --> Utf8 Class Initialized
INFO - 2018-03-30 19:35:23 --> URI Class Initialized
INFO - 2018-03-30 19:35:23 --> Router Class Initialized
INFO - 2018-03-30 19:35:23 --> Output Class Initialized
INFO - 2018-03-30 19:35:23 --> Security Class Initialized
DEBUG - 2018-03-30 19:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:35:23 --> Input Class Initialized
INFO - 2018-03-30 19:35:23 --> Language Class Initialized
INFO - 2018-03-30 19:35:23 --> Loader Class Initialized
INFO - 2018-03-30 19:35:23 --> Helper loaded: url_helper
INFO - 2018-03-30 19:35:23 --> Helper loaded: file_helper
INFO - 2018-03-30 19:35:23 --> Helper loaded: date_helper
INFO - 2018-03-30 19:35:23 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:35:23 --> Controller Class Initialized
INFO - 2018-03-30 19:35:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-03-30 19:35:23 --> Final output sent to browser
DEBUG - 2018-03-30 19:35:23 --> Total execution time: 0.2517
INFO - 2018-03-30 19:35:27 --> Config Class Initialized
INFO - 2018-03-30 19:35:27 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:35:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:35:27 --> Utf8 Class Initialized
INFO - 2018-03-30 19:35:27 --> URI Class Initialized
INFO - 2018-03-30 19:35:27 --> Router Class Initialized
INFO - 2018-03-30 19:35:27 --> Output Class Initialized
INFO - 2018-03-30 19:35:27 --> Security Class Initialized
DEBUG - 2018-03-30 19:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:35:27 --> Input Class Initialized
INFO - 2018-03-30 19:35:27 --> Language Class Initialized
INFO - 2018-03-30 19:35:27 --> Loader Class Initialized
INFO - 2018-03-30 19:35:27 --> Helper loaded: url_helper
INFO - 2018-03-30 19:35:27 --> Helper loaded: file_helper
INFO - 2018-03-30 19:35:27 --> Helper loaded: date_helper
INFO - 2018-03-30 19:35:27 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:35:27 --> Controller Class Initialized
INFO - 2018-03-30 19:35:27 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-03-30 19:35:27 --> Final output sent to browser
DEBUG - 2018-03-30 19:35:27 --> Total execution time: 0.2382
INFO - 2018-03-30 19:37:31 --> Config Class Initialized
INFO - 2018-03-30 19:37:32 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:37:32 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:37:32 --> Utf8 Class Initialized
INFO - 2018-03-30 19:37:32 --> URI Class Initialized
INFO - 2018-03-30 19:37:32 --> Router Class Initialized
INFO - 2018-03-30 19:37:32 --> Output Class Initialized
INFO - 2018-03-30 19:37:32 --> Security Class Initialized
DEBUG - 2018-03-30 19:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:37:32 --> Input Class Initialized
INFO - 2018-03-30 19:37:32 --> Language Class Initialized
INFO - 2018-03-30 19:37:32 --> Loader Class Initialized
INFO - 2018-03-30 19:37:32 --> Helper loaded: url_helper
INFO - 2018-03-30 19:37:32 --> Helper loaded: file_helper
INFO - 2018-03-30 19:37:32 --> Helper loaded: date_helper
INFO - 2018-03-30 19:37:32 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:37:32 --> Controller Class Initialized
DEBUG - 2018-03-30 19:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:37:32 --> Config Class Initialized
INFO - 2018-03-30 19:37:32 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:37:32 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:37:32 --> Utf8 Class Initialized
INFO - 2018-03-30 19:37:32 --> URI Class Initialized
INFO - 2018-03-30 19:37:32 --> Router Class Initialized
INFO - 2018-03-30 19:37:32 --> Output Class Initialized
INFO - 2018-03-30 19:37:32 --> Security Class Initialized
DEBUG - 2018-03-30 19:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:37:32 --> Input Class Initialized
INFO - 2018-03-30 19:37:32 --> Language Class Initialized
INFO - 2018-03-30 19:37:32 --> Loader Class Initialized
INFO - 2018-03-30 19:37:32 --> Helper loaded: url_helper
INFO - 2018-03-30 19:37:32 --> Helper loaded: file_helper
INFO - 2018-03-30 19:37:32 --> Helper loaded: date_helper
INFO - 2018-03-30 19:37:32 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:37:32 --> Controller Class Initialized
INFO - 2018-03-30 19:37:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-03-30 19:37:32 --> Final output sent to browser
DEBUG - 2018-03-30 19:37:32 --> Total execution time: 0.2368
INFO - 2018-03-30 19:37:43 --> Config Class Initialized
INFO - 2018-03-30 19:37:43 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:37:43 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:37:43 --> Utf8 Class Initialized
INFO - 2018-03-30 19:37:43 --> URI Class Initialized
INFO - 2018-03-30 19:37:43 --> Router Class Initialized
INFO - 2018-03-30 19:37:43 --> Output Class Initialized
INFO - 2018-03-30 19:37:43 --> Security Class Initialized
DEBUG - 2018-03-30 19:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:37:43 --> Input Class Initialized
INFO - 2018-03-30 19:37:43 --> Language Class Initialized
INFO - 2018-03-30 19:37:43 --> Loader Class Initialized
INFO - 2018-03-30 19:37:43 --> Helper loaded: url_helper
INFO - 2018-03-30 19:37:43 --> Helper loaded: file_helper
INFO - 2018-03-30 19:37:43 --> Helper loaded: date_helper
INFO - 2018-03-30 19:37:43 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:37:43 --> Controller Class Initialized
INFO - 2018-03-30 19:37:43 --> Model Class Initialized
ERROR - 2018-03-30 19:37:43 --> Severity: Notice --> Undefined property: stdClass::$name G:\xampp\htdocs\codeigniter\application\controllers\Auth_Controller.php 51
INFO - 2018-03-30 19:37:43 --> Final output sent to browser
DEBUG - 2018-03-30 19:37:43 --> Total execution time: 0.2652
INFO - 2018-03-30 19:37:44 --> Config Class Initialized
INFO - 2018-03-30 19:37:44 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:37:44 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:37:44 --> Utf8 Class Initialized
INFO - 2018-03-30 19:37:44 --> URI Class Initialized
INFO - 2018-03-30 19:37:44 --> Router Class Initialized
INFO - 2018-03-30 19:37:44 --> Output Class Initialized
INFO - 2018-03-30 19:37:44 --> Security Class Initialized
DEBUG - 2018-03-30 19:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:37:44 --> Input Class Initialized
INFO - 2018-03-30 19:37:44 --> Language Class Initialized
INFO - 2018-03-30 19:37:44 --> Loader Class Initialized
INFO - 2018-03-30 19:37:44 --> Helper loaded: url_helper
INFO - 2018-03-30 19:37:44 --> Helper loaded: file_helper
INFO - 2018-03-30 19:37:44 --> Helper loaded: date_helper
INFO - 2018-03-30 19:37:44 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:37:44 --> Controller Class Initialized
INFO - 2018-03-30 19:37:44 --> Config Class Initialized
INFO - 2018-03-30 19:37:44 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:37:44 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:37:44 --> Utf8 Class Initialized
INFO - 2018-03-30 19:37:44 --> URI Class Initialized
INFO - 2018-03-30 19:37:44 --> Router Class Initialized
INFO - 2018-03-30 19:37:44 --> Output Class Initialized
INFO - 2018-03-30 19:37:44 --> Security Class Initialized
DEBUG - 2018-03-30 19:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:37:44 --> Input Class Initialized
INFO - 2018-03-30 19:37:44 --> Language Class Initialized
INFO - 2018-03-30 19:37:44 --> Loader Class Initialized
INFO - 2018-03-30 19:37:44 --> Helper loaded: url_helper
INFO - 2018-03-30 19:37:44 --> Helper loaded: file_helper
INFO - 2018-03-30 19:37:44 --> Helper loaded: date_helper
INFO - 2018-03-30 19:37:44 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:37:44 --> Controller Class Initialized
INFO - 2018-03-30 19:37:44 --> Model Class Initialized
INFO - 2018-03-30 19:37:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-03-30 19:37:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/dashboard.php
INFO - 2018-03-30 19:37:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-03-30 19:37:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-03-30 19:37:44 --> Final output sent to browser
DEBUG - 2018-03-30 19:37:44 --> Total execution time: 0.3294
INFO - 2018-03-30 19:39:01 --> Config Class Initialized
INFO - 2018-03-30 19:39:01 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:39:01 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:39:01 --> Utf8 Class Initialized
INFO - 2018-03-30 19:39:01 --> URI Class Initialized
INFO - 2018-03-30 19:39:01 --> Router Class Initialized
INFO - 2018-03-30 19:39:01 --> Output Class Initialized
INFO - 2018-03-30 19:39:01 --> Security Class Initialized
DEBUG - 2018-03-30 19:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:39:01 --> Input Class Initialized
INFO - 2018-03-30 19:39:01 --> Language Class Initialized
INFO - 2018-03-30 19:39:01 --> Loader Class Initialized
INFO - 2018-03-30 19:39:01 --> Helper loaded: url_helper
INFO - 2018-03-30 19:39:01 --> Helper loaded: file_helper
INFO - 2018-03-30 19:39:01 --> Helper loaded: date_helper
INFO - 2018-03-30 19:39:02 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:39:02 --> Controller Class Initialized
DEBUG - 2018-03-30 19:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:39:02 --> Config Class Initialized
INFO - 2018-03-30 19:39:02 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:39:02 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:39:02 --> Utf8 Class Initialized
INFO - 2018-03-30 19:39:02 --> URI Class Initialized
INFO - 2018-03-30 19:39:02 --> Router Class Initialized
INFO - 2018-03-30 19:39:02 --> Output Class Initialized
INFO - 2018-03-30 19:39:02 --> Security Class Initialized
DEBUG - 2018-03-30 19:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:39:02 --> Input Class Initialized
INFO - 2018-03-30 19:39:02 --> Language Class Initialized
INFO - 2018-03-30 19:39:02 --> Loader Class Initialized
INFO - 2018-03-30 19:39:02 --> Helper loaded: url_helper
INFO - 2018-03-30 19:39:02 --> Helper loaded: file_helper
INFO - 2018-03-30 19:39:02 --> Helper loaded: date_helper
INFO - 2018-03-30 19:39:02 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:39:02 --> Controller Class Initialized
INFO - 2018-03-30 19:39:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-03-30 19:39:02 --> Final output sent to browser
DEBUG - 2018-03-30 19:39:02 --> Total execution time: 0.2437
INFO - 2018-03-30 19:39:13 --> Config Class Initialized
INFO - 2018-03-30 19:39:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:39:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:39:13 --> Utf8 Class Initialized
INFO - 2018-03-30 19:39:13 --> URI Class Initialized
INFO - 2018-03-30 19:39:13 --> Router Class Initialized
INFO - 2018-03-30 19:39:13 --> Output Class Initialized
INFO - 2018-03-30 19:39:13 --> Security Class Initialized
DEBUG - 2018-03-30 19:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:39:13 --> Input Class Initialized
INFO - 2018-03-30 19:39:13 --> Language Class Initialized
INFO - 2018-03-30 19:39:13 --> Loader Class Initialized
INFO - 2018-03-30 19:39:13 --> Helper loaded: url_helper
INFO - 2018-03-30 19:39:13 --> Helper loaded: file_helper
INFO - 2018-03-30 19:39:13 --> Helper loaded: date_helper
INFO - 2018-03-30 19:39:13 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:39:13 --> Controller Class Initialized
INFO - 2018-03-30 19:39:13 --> Model Class Initialized
ERROR - 2018-03-30 19:39:13 --> Severity: Notice --> Undefined property: stdClass::$name G:\xampp\htdocs\codeigniter\application\controllers\Auth_Controller.php 51
INFO - 2018-03-30 19:39:13 --> Final output sent to browser
DEBUG - 2018-03-30 19:39:13 --> Total execution time: 0.2646
INFO - 2018-03-30 19:39:13 --> Config Class Initialized
INFO - 2018-03-30 19:39:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:39:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:39:13 --> Utf8 Class Initialized
INFO - 2018-03-30 19:39:13 --> URI Class Initialized
INFO - 2018-03-30 19:39:13 --> Router Class Initialized
INFO - 2018-03-30 19:39:13 --> Output Class Initialized
INFO - 2018-03-30 19:39:13 --> Security Class Initialized
DEBUG - 2018-03-30 19:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:39:13 --> Input Class Initialized
INFO - 2018-03-30 19:39:13 --> Language Class Initialized
INFO - 2018-03-30 19:39:13 --> Loader Class Initialized
INFO - 2018-03-30 19:39:13 --> Helper loaded: url_helper
INFO - 2018-03-30 19:39:13 --> Helper loaded: file_helper
INFO - 2018-03-30 19:39:13 --> Helper loaded: date_helper
INFO - 2018-03-30 19:39:13 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:39:13 --> Controller Class Initialized
INFO - 2018-03-30 19:39:13 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\welcome_message.php
INFO - 2018-03-30 19:39:14 --> Final output sent to browser
DEBUG - 2018-03-30 19:39:14 --> Total execution time: 0.2441
INFO - 2018-03-30 19:39:54 --> Config Class Initialized
INFO - 2018-03-30 19:39:54 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:39:54 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:39:54 --> Utf8 Class Initialized
INFO - 2018-03-30 19:39:54 --> URI Class Initialized
INFO - 2018-03-30 19:39:54 --> Router Class Initialized
INFO - 2018-03-30 19:39:54 --> Output Class Initialized
INFO - 2018-03-30 19:39:54 --> Security Class Initialized
DEBUG - 2018-03-30 19:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:39:54 --> Input Class Initialized
INFO - 2018-03-30 19:39:54 --> Language Class Initialized
ERROR - 2018-03-30 19:39:54 --> 404 Page Not Found: Subject_Controller/create_subject_view
INFO - 2018-03-30 19:42:21 --> Config Class Initialized
INFO - 2018-03-30 19:42:21 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:42:21 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:42:21 --> Utf8 Class Initialized
INFO - 2018-03-30 19:42:21 --> URI Class Initialized
INFO - 2018-03-30 19:42:21 --> Router Class Initialized
INFO - 2018-03-30 19:42:21 --> Output Class Initialized
INFO - 2018-03-30 19:42:21 --> Security Class Initialized
DEBUG - 2018-03-30 19:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:42:21 --> Input Class Initialized
INFO - 2018-03-30 19:42:21 --> Language Class Initialized
INFO - 2018-03-30 19:42:21 --> Loader Class Initialized
INFO - 2018-03-30 19:42:22 --> Helper loaded: url_helper
INFO - 2018-03-30 19:42:22 --> Helper loaded: file_helper
INFO - 2018-03-30 19:42:22 --> Helper loaded: date_helper
INFO - 2018-03-30 19:42:22 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:42:22 --> Controller Class Initialized
DEBUG - 2018-03-30 19:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:42:22 --> Config Class Initialized
INFO - 2018-03-30 19:42:22 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:42:22 --> Utf8 Class Initialized
INFO - 2018-03-30 19:42:22 --> URI Class Initialized
INFO - 2018-03-30 19:42:22 --> Router Class Initialized
INFO - 2018-03-30 19:42:22 --> Output Class Initialized
INFO - 2018-03-30 19:42:22 --> Security Class Initialized
DEBUG - 2018-03-30 19:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:42:22 --> Input Class Initialized
INFO - 2018-03-30 19:42:22 --> Language Class Initialized
INFO - 2018-03-30 19:42:22 --> Loader Class Initialized
INFO - 2018-03-30 19:42:22 --> Helper loaded: url_helper
INFO - 2018-03-30 19:42:22 --> Helper loaded: file_helper
INFO - 2018-03-30 19:42:22 --> Helper loaded: date_helper
INFO - 2018-03-30 19:42:22 --> Database Driver Class Initialized
DEBUG - 2018-03-30 19:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-03-30 19:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:42:22 --> Controller Class Initialized
INFO - 2018-03-30 19:42:22 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-03-30 19:42:22 --> Final output sent to browser
DEBUG - 2018-03-30 19:42:22 --> Total execution time: 0.2432
INFO - 2018-03-30 19:42:22 --> Config Class Initialized
INFO - 2018-03-30 19:42:22 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:42:22 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:42:22 --> Utf8 Class Initialized
INFO - 2018-03-30 19:42:22 --> URI Class Initialized
INFO - 2018-03-30 19:42:22 --> Router Class Initialized
INFO - 2018-03-30 19:42:22 --> Output Class Initialized
INFO - 2018-03-30 19:42:22 --> Security Class Initialized
DEBUG - 2018-03-30 19:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:42:22 --> Input Class Initialized
INFO - 2018-03-30 19:42:22 --> Language Class Initialized
ERROR - 2018-03-30 19:42:22 --> 404 Page Not Found: Assets/css
