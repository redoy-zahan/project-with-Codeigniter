<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-08 05:23:46 --> Config Class Initialized
INFO - 2018-04-08 05:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:23:47 --> Utf8 Class Initialized
INFO - 2018-04-08 05:23:47 --> URI Class Initialized
INFO - 2018-04-08 05:23:47 --> Router Class Initialized
INFO - 2018-04-08 05:23:47 --> Output Class Initialized
INFO - 2018-04-08 05:23:47 --> Security Class Initialized
DEBUG - 2018-04-08 05:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:23:47 --> Input Class Initialized
INFO - 2018-04-08 05:23:47 --> Language Class Initialized
INFO - 2018-04-08 05:23:47 --> Loader Class Initialized
INFO - 2018-04-08 05:23:47 --> Helper loaded: url_helper
INFO - 2018-04-08 05:23:47 --> Helper loaded: file_helper
INFO - 2018-04-08 05:23:47 --> Helper loaded: date_helper
INFO - 2018-04-08 05:23:47 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:23:48 --> Controller Class Initialized
INFO - 2018-04-08 05:24:06 --> Config Class Initialized
INFO - 2018-04-08 05:24:06 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:24:06 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:24:06 --> Utf8 Class Initialized
INFO - 2018-04-08 05:24:06 --> URI Class Initialized
INFO - 2018-04-08 05:24:06 --> Router Class Initialized
INFO - 2018-04-08 05:24:06 --> Output Class Initialized
INFO - 2018-04-08 05:24:06 --> Security Class Initialized
DEBUG - 2018-04-08 05:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:24:06 --> Input Class Initialized
INFO - 2018-04-08 05:24:06 --> Language Class Initialized
INFO - 2018-04-08 05:24:06 --> Loader Class Initialized
INFO - 2018-04-08 05:24:06 --> Helper loaded: url_helper
INFO - 2018-04-08 05:24:06 --> Helper loaded: file_helper
INFO - 2018-04-08 05:24:06 --> Helper loaded: date_helper
INFO - 2018-04-08 05:24:07 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:24:07 --> Controller Class Initialized
INFO - 2018-04-08 05:24:07 --> Model Class Initialized
INFO - 2018-04-08 05:24:07 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 05:24:07 --> Final output sent to browser
DEBUG - 2018-04-08 05:24:07 --> Total execution time: 0.8046
INFO - 2018-04-08 05:27:00 --> Config Class Initialized
INFO - 2018-04-08 05:27:00 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:27:00 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:27:00 --> Utf8 Class Initialized
INFO - 2018-04-08 05:27:00 --> URI Class Initialized
INFO - 2018-04-08 05:27:00 --> Router Class Initialized
INFO - 2018-04-08 05:27:00 --> Output Class Initialized
INFO - 2018-04-08 05:27:00 --> Security Class Initialized
DEBUG - 2018-04-08 05:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:27:00 --> Input Class Initialized
INFO - 2018-04-08 05:27:00 --> Language Class Initialized
INFO - 2018-04-08 05:27:00 --> Loader Class Initialized
INFO - 2018-04-08 05:27:00 --> Helper loaded: url_helper
INFO - 2018-04-08 05:27:00 --> Helper loaded: file_helper
INFO - 2018-04-08 05:27:00 --> Helper loaded: date_helper
INFO - 2018-04-08 05:27:01 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:27:01 --> Controller Class Initialized
INFO - 2018-04-08 05:27:03 --> Config Class Initialized
INFO - 2018-04-08 05:27:03 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:27:03 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:27:03 --> Utf8 Class Initialized
INFO - 2018-04-08 05:27:03 --> URI Class Initialized
INFO - 2018-04-08 05:27:03 --> Router Class Initialized
INFO - 2018-04-08 05:27:03 --> Output Class Initialized
INFO - 2018-04-08 05:27:03 --> Security Class Initialized
DEBUG - 2018-04-08 05:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:27:03 --> Input Class Initialized
INFO - 2018-04-08 05:27:03 --> Language Class Initialized
INFO - 2018-04-08 05:27:03 --> Loader Class Initialized
INFO - 2018-04-08 05:27:03 --> Helper loaded: url_helper
INFO - 2018-04-08 05:27:03 --> Helper loaded: file_helper
INFO - 2018-04-08 05:27:03 --> Helper loaded: date_helper
INFO - 2018-04-08 05:27:03 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:27:03 --> Controller Class Initialized
INFO - 2018-04-08 05:27:03 --> Model Class Initialized
INFO - 2018-04-08 05:27:03 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 05:27:03 --> Final output sent to browser
DEBUG - 2018-04-08 05:27:03 --> Total execution time: 0.2507
INFO - 2018-04-08 05:27:10 --> Config Class Initialized
INFO - 2018-04-08 05:27:10 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:27:10 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:27:10 --> Utf8 Class Initialized
INFO - 2018-04-08 05:27:10 --> URI Class Initialized
INFO - 2018-04-08 05:27:10 --> Router Class Initialized
INFO - 2018-04-08 05:27:10 --> Output Class Initialized
INFO - 2018-04-08 05:27:10 --> Security Class Initialized
DEBUG - 2018-04-08 05:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:27:10 --> Input Class Initialized
INFO - 2018-04-08 05:27:10 --> Language Class Initialized
INFO - 2018-04-08 05:27:10 --> Loader Class Initialized
INFO - 2018-04-08 05:27:10 --> Helper loaded: url_helper
INFO - 2018-04-08 05:27:10 --> Helper loaded: file_helper
INFO - 2018-04-08 05:27:10 --> Helper loaded: date_helper
INFO - 2018-04-08 05:27:10 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:27:10 --> Controller Class Initialized
INFO - 2018-04-08 05:27:10 --> Model Class Initialized
INFO - 2018-04-08 05:27:10 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 05:27:10 --> Final output sent to browser
DEBUG - 2018-04-08 05:27:10 --> Total execution time: 0.2459
INFO - 2018-04-08 05:27:16 --> Config Class Initialized
INFO - 2018-04-08 05:27:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:27:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:27:16 --> Utf8 Class Initialized
INFO - 2018-04-08 05:27:16 --> URI Class Initialized
INFO - 2018-04-08 05:27:16 --> Router Class Initialized
INFO - 2018-04-08 05:27:16 --> Output Class Initialized
INFO - 2018-04-08 05:27:16 --> Security Class Initialized
DEBUG - 2018-04-08 05:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:27:16 --> Input Class Initialized
INFO - 2018-04-08 05:27:16 --> Language Class Initialized
INFO - 2018-04-08 05:27:16 --> Loader Class Initialized
INFO - 2018-04-08 05:27:16 --> Helper loaded: url_helper
INFO - 2018-04-08 05:27:16 --> Helper loaded: file_helper
INFO - 2018-04-08 05:27:16 --> Helper loaded: date_helper
INFO - 2018-04-08 05:27:16 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:27:16 --> Controller Class Initialized
INFO - 2018-04-08 05:27:17 --> Model Class Initialized
INFO - 2018-04-08 05:27:17 --> Final output sent to browser
DEBUG - 2018-04-08 05:27:17 --> Total execution time: 0.2303
INFO - 2018-04-08 05:27:17 --> Config Class Initialized
INFO - 2018-04-08 05:27:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:27:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:27:17 --> Utf8 Class Initialized
INFO - 2018-04-08 05:27:17 --> URI Class Initialized
INFO - 2018-04-08 05:27:17 --> Router Class Initialized
INFO - 2018-04-08 05:27:17 --> Output Class Initialized
INFO - 2018-04-08 05:27:17 --> Security Class Initialized
DEBUG - 2018-04-08 05:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:27:17 --> Input Class Initialized
INFO - 2018-04-08 05:27:17 --> Language Class Initialized
INFO - 2018-04-08 05:27:17 --> Loader Class Initialized
INFO - 2018-04-08 05:27:17 --> Helper loaded: url_helper
INFO - 2018-04-08 05:27:17 --> Helper loaded: file_helper
INFO - 2018-04-08 05:27:17 --> Helper loaded: date_helper
INFO - 2018-04-08 05:27:17 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:27:17 --> Controller Class Initialized
INFO - 2018-04-08 05:27:17 --> Model Class Initialized
INFO - 2018-04-08 05:27:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 05:27:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 05:27:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 05:27:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 05:27:17 --> Final output sent to browser
DEBUG - 2018-04-08 05:27:17 --> Total execution time: 0.2909
INFO - 2018-04-08 05:27:17 --> Config Class Initialized
INFO - 2018-04-08 05:27:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:27:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:27:17 --> Utf8 Class Initialized
INFO - 2018-04-08 05:27:17 --> URI Class Initialized
INFO - 2018-04-08 05:27:17 --> Router Class Initialized
INFO - 2018-04-08 05:27:17 --> Output Class Initialized
INFO - 2018-04-08 05:27:17 --> Security Class Initialized
DEBUG - 2018-04-08 05:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:27:17 --> Input Class Initialized
INFO - 2018-04-08 05:27:17 --> Language Class Initialized
ERROR - 2018-04-08 05:27:17 --> 404 Page Not Found: Assets/img
INFO - 2018-04-08 05:28:56 --> Config Class Initialized
INFO - 2018-04-08 05:28:56 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:28:56 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:28:56 --> Utf8 Class Initialized
INFO - 2018-04-08 05:28:56 --> URI Class Initialized
INFO - 2018-04-08 05:28:56 --> Router Class Initialized
INFO - 2018-04-08 05:28:56 --> Output Class Initialized
INFO - 2018-04-08 05:28:56 --> Security Class Initialized
DEBUG - 2018-04-08 05:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:28:56 --> Input Class Initialized
INFO - 2018-04-08 05:28:56 --> Language Class Initialized
INFO - 2018-04-08 05:28:56 --> Loader Class Initialized
INFO - 2018-04-08 05:28:56 --> Helper loaded: url_helper
INFO - 2018-04-08 05:28:56 --> Helper loaded: file_helper
INFO - 2018-04-08 05:28:56 --> Helper loaded: date_helper
INFO - 2018-04-08 05:28:56 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:28:56 --> Controller Class Initialized
INFO - 2018-04-08 05:28:56 --> Model Class Initialized
INFO - 2018-04-08 05:28:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 05:28:56 --> Final output sent to browser
DEBUG - 2018-04-08 05:28:56 --> Total execution time: 0.2685
INFO - 2018-04-08 05:31:50 --> Config Class Initialized
INFO - 2018-04-08 05:31:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:31:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:31:50 --> Utf8 Class Initialized
INFO - 2018-04-08 05:31:50 --> URI Class Initialized
INFO - 2018-04-08 05:31:50 --> Router Class Initialized
INFO - 2018-04-08 05:31:50 --> Output Class Initialized
INFO - 2018-04-08 05:31:50 --> Security Class Initialized
DEBUG - 2018-04-08 05:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:31:50 --> Input Class Initialized
INFO - 2018-04-08 05:31:50 --> Language Class Initialized
INFO - 2018-04-08 05:31:50 --> Loader Class Initialized
INFO - 2018-04-08 05:31:50 --> Helper loaded: url_helper
INFO - 2018-04-08 05:31:50 --> Helper loaded: file_helper
INFO - 2018-04-08 05:31:50 --> Helper loaded: date_helper
INFO - 2018-04-08 05:31:50 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:31:50 --> Controller Class Initialized
INFO - 2018-04-08 05:31:50 --> Model Class Initialized
INFO - 2018-04-08 05:31:50 --> Final output sent to browser
DEBUG - 2018-04-08 05:31:50 --> Total execution time: 0.2534
INFO - 2018-04-08 05:31:50 --> Config Class Initialized
INFO - 2018-04-08 05:31:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:31:51 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:31:51 --> Utf8 Class Initialized
INFO - 2018-04-08 05:31:51 --> URI Class Initialized
INFO - 2018-04-08 05:31:51 --> Router Class Initialized
INFO - 2018-04-08 05:31:51 --> Output Class Initialized
INFO - 2018-04-08 05:31:51 --> Security Class Initialized
DEBUG - 2018-04-08 05:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:31:51 --> Input Class Initialized
INFO - 2018-04-08 05:31:51 --> Language Class Initialized
ERROR - 2018-04-08 05:31:51 --> Severity: Notice --> Undefined property: Stud_Controller::$load G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 12
ERROR - 2018-04-08 05:31:51 --> Severity: error --> Exception: Call to a member function model() on null G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 12
INFO - 2018-04-08 05:32:17 --> Config Class Initialized
INFO - 2018-04-08 05:32:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:32:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:32:17 --> Utf8 Class Initialized
INFO - 2018-04-08 05:32:17 --> URI Class Initialized
INFO - 2018-04-08 05:32:17 --> Router Class Initialized
INFO - 2018-04-08 05:32:17 --> Output Class Initialized
INFO - 2018-04-08 05:32:17 --> Security Class Initialized
DEBUG - 2018-04-08 05:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:32:17 --> Input Class Initialized
INFO - 2018-04-08 05:32:17 --> Language Class Initialized
INFO - 2018-04-08 05:32:17 --> Loader Class Initialized
INFO - 2018-04-08 05:32:17 --> Helper loaded: url_helper
INFO - 2018-04-08 05:32:17 --> Helper loaded: file_helper
INFO - 2018-04-08 05:32:17 --> Helper loaded: date_helper
INFO - 2018-04-08 05:32:17 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:32:17 --> Controller Class Initialized
INFO - 2018-04-08 05:32:17 --> Model Class Initialized
INFO - 2018-04-08 05:32:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 05:32:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 05:32:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 05:32:18 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 05:32:18 --> Final output sent to browser
DEBUG - 2018-04-08 05:32:18 --> Total execution time: 0.2933
INFO - 2018-04-08 05:53:50 --> Config Class Initialized
INFO - 2018-04-08 05:53:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:53:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:53:50 --> Utf8 Class Initialized
INFO - 2018-04-08 05:53:50 --> URI Class Initialized
INFO - 2018-04-08 05:53:50 --> Router Class Initialized
INFO - 2018-04-08 05:53:50 --> Output Class Initialized
INFO - 2018-04-08 05:53:50 --> Security Class Initialized
DEBUG - 2018-04-08 05:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:53:50 --> Input Class Initialized
INFO - 2018-04-08 05:53:50 --> Language Class Initialized
INFO - 2018-04-08 05:53:50 --> Loader Class Initialized
INFO - 2018-04-08 05:53:50 --> Helper loaded: url_helper
INFO - 2018-04-08 05:53:50 --> Helper loaded: file_helper
INFO - 2018-04-08 05:53:50 --> Helper loaded: date_helper
INFO - 2018-04-08 05:53:50 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:53:50 --> Controller Class Initialized
INFO - 2018-04-08 05:53:50 --> Model Class Initialized
INFO - 2018-04-08 05:53:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 05:53:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 05:53:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 05:53:50 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 05:53:50 --> Final output sent to browser
DEBUG - 2018-04-08 05:53:50 --> Total execution time: 0.3072
INFO - 2018-04-08 05:53:55 --> Config Class Initialized
INFO - 2018-04-08 05:53:55 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:53:55 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:53:55 --> Utf8 Class Initialized
INFO - 2018-04-08 05:53:55 --> URI Class Initialized
INFO - 2018-04-08 05:53:55 --> Router Class Initialized
INFO - 2018-04-08 05:53:55 --> Output Class Initialized
INFO - 2018-04-08 05:53:55 --> Security Class Initialized
DEBUG - 2018-04-08 05:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:53:55 --> Input Class Initialized
INFO - 2018-04-08 05:53:55 --> Language Class Initialized
INFO - 2018-04-08 05:53:55 --> Loader Class Initialized
INFO - 2018-04-08 05:53:55 --> Helper loaded: url_helper
INFO - 2018-04-08 05:53:55 --> Helper loaded: file_helper
INFO - 2018-04-08 05:53:55 --> Helper loaded: date_helper
INFO - 2018-04-08 05:53:55 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:53:55 --> Controller Class Initialized
INFO - 2018-04-08 05:53:55 --> Model Class Initialized
INFO - 2018-04-08 05:53:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 05:53:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-08 05:53:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 05:53:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 05:53:55 --> Final output sent to browser
DEBUG - 2018-04-08 05:53:55 --> Total execution time: 0.4856
INFO - 2018-04-08 05:53:59 --> Config Class Initialized
INFO - 2018-04-08 05:53:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:53:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:53:59 --> Utf8 Class Initialized
INFO - 2018-04-08 05:53:59 --> URI Class Initialized
INFO - 2018-04-08 05:53:59 --> Router Class Initialized
INFO - 2018-04-08 05:53:59 --> Output Class Initialized
INFO - 2018-04-08 05:53:59 --> Security Class Initialized
DEBUG - 2018-04-08 05:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:53:59 --> Input Class Initialized
INFO - 2018-04-08 05:53:59 --> Language Class Initialized
INFO - 2018-04-08 05:53:59 --> Loader Class Initialized
INFO - 2018-04-08 05:53:59 --> Helper loaded: url_helper
INFO - 2018-04-08 05:53:59 --> Helper loaded: file_helper
INFO - 2018-04-08 05:53:59 --> Helper loaded: date_helper
INFO - 2018-04-08 05:53:59 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:54:00 --> Controller Class Initialized
INFO - 2018-04-08 05:54:00 --> Model Class Initialized
INFO - 2018-04-08 05:54:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 05:54:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 05:54:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 05:54:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 05:54:00 --> Final output sent to browser
DEBUG - 2018-04-08 05:54:00 --> Total execution time: 0.3074
INFO - 2018-04-08 05:54:26 --> Config Class Initialized
INFO - 2018-04-08 05:54:26 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:54:26 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:54:26 --> Utf8 Class Initialized
INFO - 2018-04-08 05:54:26 --> URI Class Initialized
INFO - 2018-04-08 05:54:26 --> Router Class Initialized
INFO - 2018-04-08 05:54:26 --> Output Class Initialized
INFO - 2018-04-08 05:54:26 --> Security Class Initialized
DEBUG - 2018-04-08 05:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:54:26 --> Input Class Initialized
INFO - 2018-04-08 05:54:26 --> Language Class Initialized
INFO - 2018-04-08 05:54:26 --> Loader Class Initialized
INFO - 2018-04-08 05:54:26 --> Helper loaded: url_helper
INFO - 2018-04-08 05:54:26 --> Helper loaded: file_helper
INFO - 2018-04-08 05:54:26 --> Helper loaded: date_helper
INFO - 2018-04-08 05:54:26 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:54:26 --> Controller Class Initialized
INFO - 2018-04-08 05:54:26 --> Model Class Initialized
INFO - 2018-04-08 05:54:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 05:54:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 05:54:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 05:54:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 05:54:26 --> Final output sent to browser
DEBUG - 2018-04-08 05:54:26 --> Total execution time: 0.2895
INFO - 2018-04-08 05:54:41 --> Config Class Initialized
INFO - 2018-04-08 05:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:54:41 --> Utf8 Class Initialized
INFO - 2018-04-08 05:54:41 --> URI Class Initialized
INFO - 2018-04-08 05:54:41 --> Router Class Initialized
INFO - 2018-04-08 05:54:41 --> Output Class Initialized
INFO - 2018-04-08 05:54:41 --> Security Class Initialized
DEBUG - 2018-04-08 05:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:54:41 --> Input Class Initialized
INFO - 2018-04-08 05:54:41 --> Language Class Initialized
INFO - 2018-04-08 05:54:41 --> Loader Class Initialized
INFO - 2018-04-08 05:54:41 --> Helper loaded: url_helper
INFO - 2018-04-08 05:54:41 --> Helper loaded: file_helper
INFO - 2018-04-08 05:54:41 --> Helper loaded: date_helper
INFO - 2018-04-08 05:54:41 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:54:41 --> Controller Class Initialized
INFO - 2018-04-08 05:54:41 --> Model Class Initialized
INFO - 2018-04-08 05:54:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 05:54:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 05:54:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 05:54:41 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 05:54:41 --> Final output sent to browser
DEBUG - 2018-04-08 05:54:41 --> Total execution time: 0.2961
INFO - 2018-04-08 05:55:58 --> Config Class Initialized
INFO - 2018-04-08 05:55:58 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:55:58 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:55:58 --> Utf8 Class Initialized
INFO - 2018-04-08 05:55:58 --> URI Class Initialized
INFO - 2018-04-08 05:55:58 --> Router Class Initialized
INFO - 2018-04-08 05:55:58 --> Output Class Initialized
INFO - 2018-04-08 05:55:58 --> Security Class Initialized
DEBUG - 2018-04-08 05:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:55:58 --> Input Class Initialized
INFO - 2018-04-08 05:55:58 --> Language Class Initialized
INFO - 2018-04-08 05:55:58 --> Loader Class Initialized
INFO - 2018-04-08 05:55:58 --> Helper loaded: url_helper
INFO - 2018-04-08 05:55:58 --> Helper loaded: file_helper
INFO - 2018-04-08 05:55:58 --> Helper loaded: date_helper
INFO - 2018-04-08 05:55:58 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:55:58 --> Controller Class Initialized
INFO - 2018-04-08 05:55:58 --> Model Class Initialized
INFO - 2018-04-08 05:55:58 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 05:55:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 05:55:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 05:55:59 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 05:55:59 --> Final output sent to browser
DEBUG - 2018-04-08 05:55:59 --> Total execution time: 0.2898
INFO - 2018-04-08 05:56:09 --> Config Class Initialized
INFO - 2018-04-08 05:56:09 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:56:09 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:56:09 --> Utf8 Class Initialized
INFO - 2018-04-08 05:56:09 --> URI Class Initialized
INFO - 2018-04-08 05:56:09 --> Router Class Initialized
INFO - 2018-04-08 05:56:09 --> Output Class Initialized
INFO - 2018-04-08 05:56:09 --> Security Class Initialized
DEBUG - 2018-04-08 05:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:56:09 --> Input Class Initialized
INFO - 2018-04-08 05:56:09 --> Language Class Initialized
INFO - 2018-04-08 05:56:09 --> Loader Class Initialized
INFO - 2018-04-08 05:56:09 --> Helper loaded: url_helper
INFO - 2018-04-08 05:56:09 --> Helper loaded: file_helper
INFO - 2018-04-08 05:56:09 --> Helper loaded: date_helper
INFO - 2018-04-08 05:56:09 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:56:09 --> Controller Class Initialized
INFO - 2018-04-08 05:56:09 --> Model Class Initialized
INFO - 2018-04-08 05:56:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 05:56:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 05:56:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 05:56:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 05:56:09 --> Final output sent to browser
DEBUG - 2018-04-08 05:56:09 --> Total execution time: 0.2943
INFO - 2018-04-08 05:57:09 --> Config Class Initialized
INFO - 2018-04-08 05:57:09 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:57:09 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:57:09 --> Utf8 Class Initialized
INFO - 2018-04-08 05:57:09 --> URI Class Initialized
INFO - 2018-04-08 05:57:09 --> Router Class Initialized
INFO - 2018-04-08 05:57:09 --> Output Class Initialized
INFO - 2018-04-08 05:57:09 --> Security Class Initialized
DEBUG - 2018-04-08 05:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:57:09 --> Input Class Initialized
INFO - 2018-04-08 05:57:09 --> Language Class Initialized
INFO - 2018-04-08 05:57:09 --> Loader Class Initialized
INFO - 2018-04-08 05:57:09 --> Helper loaded: url_helper
INFO - 2018-04-08 05:57:09 --> Helper loaded: file_helper
INFO - 2018-04-08 05:57:09 --> Helper loaded: date_helper
INFO - 2018-04-08 05:57:09 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:57:09 --> Controller Class Initialized
DEBUG - 2018-04-08 05:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 05:57:09 --> Config Class Initialized
INFO - 2018-04-08 05:57:09 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:57:09 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:57:09 --> Utf8 Class Initialized
INFO - 2018-04-08 05:57:09 --> URI Class Initialized
INFO - 2018-04-08 05:57:09 --> Router Class Initialized
INFO - 2018-04-08 05:57:09 --> Output Class Initialized
INFO - 2018-04-08 05:57:09 --> Security Class Initialized
DEBUG - 2018-04-08 05:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:57:09 --> Input Class Initialized
INFO - 2018-04-08 05:57:09 --> Language Class Initialized
INFO - 2018-04-08 05:57:09 --> Loader Class Initialized
INFO - 2018-04-08 05:57:09 --> Helper loaded: url_helper
INFO - 2018-04-08 05:57:09 --> Helper loaded: file_helper
INFO - 2018-04-08 05:57:09 --> Helper loaded: date_helper
INFO - 2018-04-08 05:57:09 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:57:09 --> Controller Class Initialized
INFO - 2018-04-08 05:57:09 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 05:57:09 --> Final output sent to browser
DEBUG - 2018-04-08 05:57:09 --> Total execution time: 0.2400
INFO - 2018-04-08 05:57:14 --> Config Class Initialized
INFO - 2018-04-08 05:57:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:57:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:57:14 --> Utf8 Class Initialized
INFO - 2018-04-08 05:57:14 --> URI Class Initialized
INFO - 2018-04-08 05:57:14 --> Router Class Initialized
INFO - 2018-04-08 05:57:14 --> Output Class Initialized
INFO - 2018-04-08 05:57:14 --> Security Class Initialized
DEBUG - 2018-04-08 05:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:57:14 --> Input Class Initialized
INFO - 2018-04-08 05:57:14 --> Language Class Initialized
INFO - 2018-04-08 05:57:14 --> Loader Class Initialized
INFO - 2018-04-08 05:57:14 --> Helper loaded: url_helper
INFO - 2018-04-08 05:57:14 --> Helper loaded: file_helper
INFO - 2018-04-08 05:57:14 --> Helper loaded: date_helper
INFO - 2018-04-08 05:57:14 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:57:14 --> Controller Class Initialized
INFO - 2018-04-08 05:57:16 --> Config Class Initialized
INFO - 2018-04-08 05:57:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 05:57:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 05:57:16 --> Utf8 Class Initialized
INFO - 2018-04-08 05:57:16 --> URI Class Initialized
INFO - 2018-04-08 05:57:16 --> Router Class Initialized
INFO - 2018-04-08 05:57:16 --> Output Class Initialized
INFO - 2018-04-08 05:57:16 --> Security Class Initialized
DEBUG - 2018-04-08 05:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 05:57:16 --> Input Class Initialized
INFO - 2018-04-08 05:57:16 --> Language Class Initialized
INFO - 2018-04-08 05:57:16 --> Loader Class Initialized
INFO - 2018-04-08 05:57:16 --> Helper loaded: url_helper
INFO - 2018-04-08 05:57:16 --> Helper loaded: file_helper
INFO - 2018-04-08 05:57:16 --> Helper loaded: date_helper
INFO - 2018-04-08 05:57:16 --> Database Driver Class Initialized
DEBUG - 2018-04-08 05:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 05:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 05:57:17 --> Controller Class Initialized
INFO - 2018-04-08 05:57:17 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 05:57:17 --> Final output sent to browser
DEBUG - 2018-04-08 05:57:17 --> Total execution time: 0.2585
INFO - 2018-04-08 08:06:42 --> Config Class Initialized
INFO - 2018-04-08 08:06:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:06:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:06:42 --> Utf8 Class Initialized
INFO - 2018-04-08 08:06:42 --> URI Class Initialized
INFO - 2018-04-08 08:06:42 --> Router Class Initialized
INFO - 2018-04-08 08:06:42 --> Output Class Initialized
INFO - 2018-04-08 08:06:42 --> Security Class Initialized
DEBUG - 2018-04-08 08:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:06:42 --> Input Class Initialized
INFO - 2018-04-08 08:06:42 --> Language Class Initialized
INFO - 2018-04-08 08:06:42 --> Loader Class Initialized
INFO - 2018-04-08 08:06:42 --> Helper loaded: url_helper
INFO - 2018-04-08 08:06:42 --> Helper loaded: file_helper
INFO - 2018-04-08 08:06:42 --> Helper loaded: date_helper
INFO - 2018-04-08 08:06:42 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:06:42 --> Controller Class Initialized
INFO - 2018-04-08 08:06:42 --> Model Class Initialized
INFO - 2018-04-08 08:06:42 --> Final output sent to browser
DEBUG - 2018-04-08 08:06:42 --> Total execution time: 0.2600
INFO - 2018-04-08 08:06:42 --> Config Class Initialized
INFO - 2018-04-08 08:06:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:06:43 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:06:43 --> Utf8 Class Initialized
INFO - 2018-04-08 08:06:43 --> URI Class Initialized
INFO - 2018-04-08 08:06:43 --> Router Class Initialized
INFO - 2018-04-08 08:06:43 --> Output Class Initialized
INFO - 2018-04-08 08:06:43 --> Security Class Initialized
DEBUG - 2018-04-08 08:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:06:43 --> Input Class Initialized
INFO - 2018-04-08 08:06:43 --> Language Class Initialized
INFO - 2018-04-08 08:06:43 --> Loader Class Initialized
INFO - 2018-04-08 08:06:43 --> Helper loaded: url_helper
INFO - 2018-04-08 08:06:43 --> Helper loaded: file_helper
INFO - 2018-04-08 08:06:43 --> Helper loaded: date_helper
INFO - 2018-04-08 08:06:43 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:06:43 --> Controller Class Initialized
INFO - 2018-04-08 08:06:43 --> Model Class Initialized
INFO - 2018-04-08 08:06:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 08:06:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 08:06:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 08:06:43 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 08:06:43 --> Final output sent to browser
DEBUG - 2018-04-08 08:06:43 --> Total execution time: 0.3399
INFO - 2018-04-08 08:07:11 --> Config Class Initialized
INFO - 2018-04-08 08:07:11 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:11 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:11 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:11 --> URI Class Initialized
INFO - 2018-04-08 08:07:11 --> Router Class Initialized
INFO - 2018-04-08 08:07:11 --> Output Class Initialized
INFO - 2018-04-08 08:07:11 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:11 --> Input Class Initialized
INFO - 2018-04-08 08:07:11 --> Language Class Initialized
INFO - 2018-04-08 08:07:11 --> Loader Class Initialized
INFO - 2018-04-08 08:07:11 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:11 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:11 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:11 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:11 --> Controller Class Initialized
INFO - 2018-04-08 08:07:11 --> Model Class Initialized
INFO - 2018-04-08 08:07:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 08:07:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 08:07:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 08:07:11 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 08:07:11 --> Final output sent to browser
DEBUG - 2018-04-08 08:07:11 --> Total execution time: 0.3165
INFO - 2018-04-08 08:07:16 --> Config Class Initialized
INFO - 2018-04-08 08:07:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:16 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:16 --> URI Class Initialized
INFO - 2018-04-08 08:07:16 --> Router Class Initialized
INFO - 2018-04-08 08:07:16 --> Output Class Initialized
INFO - 2018-04-08 08:07:16 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:16 --> Input Class Initialized
INFO - 2018-04-08 08:07:16 --> Language Class Initialized
INFO - 2018-04-08 08:07:16 --> Loader Class Initialized
INFO - 2018-04-08 08:07:16 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:16 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:16 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:16 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:16 --> Controller Class Initialized
INFO - 2018-04-08 08:07:16 --> Model Class Initialized
INFO - 2018-04-08 08:07:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 08:07:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 08:07:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 08:07:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 08:07:16 --> Final output sent to browser
DEBUG - 2018-04-08 08:07:16 --> Total execution time: 0.3029
INFO - 2018-04-08 08:07:18 --> Config Class Initialized
INFO - 2018-04-08 08:07:18 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:18 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:18 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:18 --> URI Class Initialized
INFO - 2018-04-08 08:07:18 --> Router Class Initialized
INFO - 2018-04-08 08:07:18 --> Output Class Initialized
INFO - 2018-04-08 08:07:18 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:18 --> Input Class Initialized
INFO - 2018-04-08 08:07:18 --> Language Class Initialized
INFO - 2018-04-08 08:07:18 --> Loader Class Initialized
INFO - 2018-04-08 08:07:18 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:18 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:18 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:18 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:18 --> Controller Class Initialized
INFO - 2018-04-08 08:07:18 --> Config Class Initialized
INFO - 2018-04-08 08:07:18 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:19 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:19 --> URI Class Initialized
INFO - 2018-04-08 08:07:19 --> Router Class Initialized
INFO - 2018-04-08 08:07:19 --> Output Class Initialized
INFO - 2018-04-08 08:07:19 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:19 --> Input Class Initialized
INFO - 2018-04-08 08:07:19 --> Language Class Initialized
INFO - 2018-04-08 08:07:19 --> Loader Class Initialized
INFO - 2018-04-08 08:07:19 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:19 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:19 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:19 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:19 --> Controller Class Initialized
INFO - 2018-04-08 08:07:19 --> Model Class Initialized
INFO - 2018-04-08 08:07:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 08:07:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 08:07:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 08:07:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 08:07:19 --> Final output sent to browser
DEBUG - 2018-04-08 08:07:19 --> Total execution time: 0.2955
INFO - 2018-04-08 08:07:21 --> Config Class Initialized
INFO - 2018-04-08 08:07:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:21 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:21 --> URI Class Initialized
INFO - 2018-04-08 08:07:21 --> Router Class Initialized
INFO - 2018-04-08 08:07:21 --> Output Class Initialized
INFO - 2018-04-08 08:07:21 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:21 --> Input Class Initialized
INFO - 2018-04-08 08:07:21 --> Language Class Initialized
INFO - 2018-04-08 08:07:21 --> Loader Class Initialized
INFO - 2018-04-08 08:07:21 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:21 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:21 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:21 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:21 --> Controller Class Initialized
INFO - 2018-04-08 08:07:21 --> Model Class Initialized
INFO - 2018-04-08 08:07:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 08:07:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 08:07:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 08:07:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 08:07:21 --> Final output sent to browser
DEBUG - 2018-04-08 08:07:21 --> Total execution time: 0.3041
INFO - 2018-04-08 08:07:22 --> Config Class Initialized
INFO - 2018-04-08 08:07:22 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:22 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:22 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:22 --> URI Class Initialized
INFO - 2018-04-08 08:07:22 --> Router Class Initialized
INFO - 2018-04-08 08:07:22 --> Output Class Initialized
INFO - 2018-04-08 08:07:22 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:23 --> Input Class Initialized
INFO - 2018-04-08 08:07:23 --> Language Class Initialized
INFO - 2018-04-08 08:07:23 --> Loader Class Initialized
INFO - 2018-04-08 08:07:23 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:23 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:23 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:23 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:23 --> Controller Class Initialized
INFO - 2018-04-08 08:07:23 --> Model Class Initialized
INFO - 2018-04-08 08:07:23 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 08:07:23 --> Final output sent to browser
DEBUG - 2018-04-08 08:07:23 --> Total execution time: 0.3160
INFO - 2018-04-08 08:07:28 --> Config Class Initialized
INFO - 2018-04-08 08:07:28 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:28 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:28 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:28 --> URI Class Initialized
INFO - 2018-04-08 08:07:28 --> Router Class Initialized
INFO - 2018-04-08 08:07:28 --> Output Class Initialized
INFO - 2018-04-08 08:07:28 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:29 --> Input Class Initialized
INFO - 2018-04-08 08:07:29 --> Language Class Initialized
INFO - 2018-04-08 08:07:29 --> Loader Class Initialized
INFO - 2018-04-08 08:07:29 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:29 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:29 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:29 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:29 --> Controller Class Initialized
INFO - 2018-04-08 08:07:29 --> Model Class Initialized
INFO - 2018-04-08 08:07:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 08:07:29 --> Final output sent to browser
DEBUG - 2018-04-08 08:07:29 --> Total execution time: 0.3087
INFO - 2018-04-08 08:07:37 --> Config Class Initialized
INFO - 2018-04-08 08:07:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:37 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:37 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:37 --> URI Class Initialized
INFO - 2018-04-08 08:07:37 --> Router Class Initialized
INFO - 2018-04-08 08:07:37 --> Output Class Initialized
INFO - 2018-04-08 08:07:37 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:37 --> Input Class Initialized
INFO - 2018-04-08 08:07:37 --> Language Class Initialized
INFO - 2018-04-08 08:07:37 --> Loader Class Initialized
INFO - 2018-04-08 08:07:37 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:37 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:37 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:37 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:37 --> Controller Class Initialized
INFO - 2018-04-08 08:07:37 --> Model Class Initialized
INFO - 2018-04-08 08:07:37 --> Final output sent to browser
DEBUG - 2018-04-08 08:07:37 --> Total execution time: 0.2563
INFO - 2018-04-08 08:07:37 --> Config Class Initialized
INFO - 2018-04-08 08:07:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:38 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:38 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:38 --> URI Class Initialized
INFO - 2018-04-08 08:07:38 --> Router Class Initialized
INFO - 2018-04-08 08:07:38 --> Output Class Initialized
INFO - 2018-04-08 08:07:38 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:38 --> Input Class Initialized
INFO - 2018-04-08 08:07:38 --> Language Class Initialized
INFO - 2018-04-08 08:07:38 --> Loader Class Initialized
INFO - 2018-04-08 08:07:38 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:38 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:38 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:38 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:38 --> Controller Class Initialized
INFO - 2018-04-08 08:07:38 --> Model Class Initialized
INFO - 2018-04-08 08:07:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 08:07:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 08:07:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 08:07:38 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 08:07:38 --> Final output sent to browser
DEBUG - 2018-04-08 08:07:38 --> Total execution time: 0.2943
INFO - 2018-04-08 08:07:47 --> Config Class Initialized
INFO - 2018-04-08 08:07:47 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:47 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:47 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:47 --> URI Class Initialized
INFO - 2018-04-08 08:07:47 --> Router Class Initialized
INFO - 2018-04-08 08:07:47 --> Output Class Initialized
INFO - 2018-04-08 08:07:47 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:47 --> Input Class Initialized
INFO - 2018-04-08 08:07:47 --> Language Class Initialized
INFO - 2018-04-08 08:07:47 --> Loader Class Initialized
INFO - 2018-04-08 08:07:47 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:47 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:47 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:47 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:48 --> Controller Class Initialized
INFO - 2018-04-08 08:07:48 --> Model Class Initialized
INFO - 2018-04-08 08:07:48 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 08:07:48 --> Final output sent to browser
DEBUG - 2018-04-08 08:07:48 --> Total execution time: 0.3264
INFO - 2018-04-08 08:07:53 --> Config Class Initialized
INFO - 2018-04-08 08:07:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:53 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:53 --> URI Class Initialized
DEBUG - 2018-04-08 08:07:53 --> No URI present. Default controller set.
INFO - 2018-04-08 08:07:53 --> Router Class Initialized
INFO - 2018-04-08 08:07:53 --> Output Class Initialized
INFO - 2018-04-08 08:07:53 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:53 --> Input Class Initialized
INFO - 2018-04-08 08:07:53 --> Language Class Initialized
INFO - 2018-04-08 08:07:53 --> Loader Class Initialized
INFO - 2018-04-08 08:07:53 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:53 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:53 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:53 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:53 --> Controller Class Initialized
INFO - 2018-04-08 08:07:54 --> Config Class Initialized
INFO - 2018-04-08 08:07:54 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:07:54 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:07:54 --> Utf8 Class Initialized
INFO - 2018-04-08 08:07:54 --> URI Class Initialized
INFO - 2018-04-08 08:07:54 --> Router Class Initialized
INFO - 2018-04-08 08:07:54 --> Output Class Initialized
INFO - 2018-04-08 08:07:54 --> Security Class Initialized
DEBUG - 2018-04-08 08:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:07:54 --> Input Class Initialized
INFO - 2018-04-08 08:07:54 --> Language Class Initialized
INFO - 2018-04-08 08:07:54 --> Loader Class Initialized
INFO - 2018-04-08 08:07:54 --> Helper loaded: url_helper
INFO - 2018-04-08 08:07:54 --> Helper loaded: file_helper
INFO - 2018-04-08 08:07:54 --> Helper loaded: date_helper
INFO - 2018-04-08 08:07:54 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:07:54 --> Controller Class Initialized
INFO - 2018-04-08 08:07:54 --> Model Class Initialized
INFO - 2018-04-08 08:07:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 08:07:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 08:07:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 08:07:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 08:07:54 --> Final output sent to browser
DEBUG - 2018-04-08 08:07:54 --> Total execution time: 0.2943
INFO - 2018-04-08 08:52:13 --> Config Class Initialized
INFO - 2018-04-08 08:52:13 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:52:13 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:52:13 --> Utf8 Class Initialized
INFO - 2018-04-08 08:52:14 --> URI Class Initialized
DEBUG - 2018-04-08 08:52:14 --> No URI present. Default controller set.
INFO - 2018-04-08 08:52:14 --> Router Class Initialized
INFO - 2018-04-08 08:52:14 --> Output Class Initialized
INFO - 2018-04-08 08:52:14 --> Security Class Initialized
DEBUG - 2018-04-08 08:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:52:14 --> Input Class Initialized
INFO - 2018-04-08 08:52:14 --> Language Class Initialized
INFO - 2018-04-08 08:52:15 --> Loader Class Initialized
INFO - 2018-04-08 08:52:15 --> Helper loaded: url_helper
INFO - 2018-04-08 08:52:15 --> Helper loaded: file_helper
INFO - 2018-04-08 08:52:15 --> Helper loaded: date_helper
INFO - 2018-04-08 08:52:15 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:52:16 --> Controller Class Initialized
INFO - 2018-04-08 08:52:16 --> Config Class Initialized
INFO - 2018-04-08 08:52:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:52:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:52:16 --> Utf8 Class Initialized
INFO - 2018-04-08 08:52:16 --> URI Class Initialized
INFO - 2018-04-08 08:52:16 --> Router Class Initialized
INFO - 2018-04-08 08:52:16 --> Output Class Initialized
INFO - 2018-04-08 08:52:16 --> Security Class Initialized
DEBUG - 2018-04-08 08:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:52:16 --> Input Class Initialized
INFO - 2018-04-08 08:52:16 --> Language Class Initialized
INFO - 2018-04-08 08:52:16 --> Loader Class Initialized
INFO - 2018-04-08 08:52:16 --> Helper loaded: url_helper
INFO - 2018-04-08 08:52:16 --> Helper loaded: file_helper
INFO - 2018-04-08 08:52:16 --> Helper loaded: date_helper
INFO - 2018-04-08 08:52:16 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:52:16 --> Controller Class Initialized
INFO - 2018-04-08 08:52:16 --> Model Class Initialized
INFO - 2018-04-08 08:52:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 08:52:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 08:52:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 08:52:16 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 08:52:16 --> Final output sent to browser
DEBUG - 2018-04-08 08:52:16 --> Total execution time: 0.6797
INFO - 2018-04-08 08:52:29 --> Config Class Initialized
INFO - 2018-04-08 08:52:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 08:52:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 08:52:29 --> Utf8 Class Initialized
INFO - 2018-04-08 08:52:29 --> URI Class Initialized
INFO - 2018-04-08 08:52:29 --> Router Class Initialized
INFO - 2018-04-08 08:52:29 --> Output Class Initialized
INFO - 2018-04-08 08:52:29 --> Security Class Initialized
DEBUG - 2018-04-08 08:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 08:52:29 --> Input Class Initialized
INFO - 2018-04-08 08:52:29 --> Language Class Initialized
INFO - 2018-04-08 08:52:29 --> Loader Class Initialized
INFO - 2018-04-08 08:52:29 --> Helper loaded: url_helper
INFO - 2018-04-08 08:52:29 --> Helper loaded: file_helper
INFO - 2018-04-08 08:52:29 --> Helper loaded: date_helper
INFO - 2018-04-08 08:52:29 --> Database Driver Class Initialized
DEBUG - 2018-04-08 08:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 08:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 08:52:29 --> Controller Class Initialized
INFO - 2018-04-08 08:52:29 --> Model Class Initialized
INFO - 2018-04-08 08:52:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 08:52:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-08 08:52:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 08:52:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 08:52:29 --> Final output sent to browser
DEBUG - 2018-04-08 08:52:29 --> Total execution time: 0.3788
INFO - 2018-04-08 10:32:47 --> Config Class Initialized
INFO - 2018-04-08 10:32:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 10:32:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 10:32:48 --> Utf8 Class Initialized
INFO - 2018-04-08 10:32:48 --> URI Class Initialized
DEBUG - 2018-04-08 10:32:48 --> No URI present. Default controller set.
INFO - 2018-04-08 10:32:48 --> Router Class Initialized
INFO - 2018-04-08 10:32:48 --> Output Class Initialized
INFO - 2018-04-08 10:32:48 --> Security Class Initialized
DEBUG - 2018-04-08 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 10:32:48 --> Input Class Initialized
INFO - 2018-04-08 10:32:48 --> Language Class Initialized
INFO - 2018-04-08 10:32:48 --> Loader Class Initialized
INFO - 2018-04-08 10:32:48 --> Helper loaded: url_helper
INFO - 2018-04-08 10:32:48 --> Helper loaded: file_helper
INFO - 2018-04-08 10:32:48 --> Helper loaded: date_helper
INFO - 2018-04-08 10:32:48 --> Database Driver Class Initialized
DEBUG - 2018-04-08 10:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 10:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 10:32:48 --> Controller Class Initialized
INFO - 2018-04-08 10:32:48 --> Config Class Initialized
INFO - 2018-04-08 10:32:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 10:32:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 10:32:48 --> Utf8 Class Initialized
INFO - 2018-04-08 10:32:48 --> URI Class Initialized
INFO - 2018-04-08 10:32:48 --> Router Class Initialized
INFO - 2018-04-08 10:32:48 --> Output Class Initialized
INFO - 2018-04-08 10:32:48 --> Security Class Initialized
DEBUG - 2018-04-08 10:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 10:32:48 --> Input Class Initialized
INFO - 2018-04-08 10:32:48 --> Language Class Initialized
INFO - 2018-04-08 10:32:48 --> Loader Class Initialized
INFO - 2018-04-08 10:32:48 --> Helper loaded: url_helper
INFO - 2018-04-08 10:32:48 --> Helper loaded: file_helper
INFO - 2018-04-08 10:32:48 --> Helper loaded: date_helper
INFO - 2018-04-08 10:32:49 --> Database Driver Class Initialized
DEBUG - 2018-04-08 10:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 10:32:49 --> Controller Class Initialized
INFO - 2018-04-08 10:32:49 --> Model Class Initialized
INFO - 2018-04-08 10:32:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 10:32:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 10:32:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 10:32:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 10:32:49 --> Final output sent to browser
DEBUG - 2018-04-08 10:32:49 --> Total execution time: 0.6855
INFO - 2018-04-08 10:33:02 --> Config Class Initialized
INFO - 2018-04-08 10:33:02 --> Hooks Class Initialized
DEBUG - 2018-04-08 10:33:02 --> UTF-8 Support Enabled
INFO - 2018-04-08 10:33:02 --> Utf8 Class Initialized
INFO - 2018-04-08 10:33:02 --> URI Class Initialized
INFO - 2018-04-08 10:33:02 --> Router Class Initialized
INFO - 2018-04-08 10:33:02 --> Output Class Initialized
INFO - 2018-04-08 10:33:02 --> Security Class Initialized
DEBUG - 2018-04-08 10:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 10:33:02 --> Input Class Initialized
INFO - 2018-04-08 10:33:02 --> Language Class Initialized
INFO - 2018-04-08 10:33:02 --> Loader Class Initialized
INFO - 2018-04-08 10:33:02 --> Helper loaded: url_helper
INFO - 2018-04-08 10:33:02 --> Helper loaded: file_helper
INFO - 2018-04-08 10:33:02 --> Helper loaded: date_helper
INFO - 2018-04-08 10:33:02 --> Database Driver Class Initialized
DEBUG - 2018-04-08 10:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 10:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 10:33:02 --> Controller Class Initialized
INFO - 2018-04-08 10:33:02 --> Model Class Initialized
INFO - 2018-04-08 10:33:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 10:33:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-08 10:33:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 10:33:02 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 10:33:02 --> Final output sent to browser
DEBUG - 2018-04-08 10:33:02 --> Total execution time: 0.3707
INFO - 2018-04-08 10:53:55 --> Config Class Initialized
INFO - 2018-04-08 10:53:55 --> Hooks Class Initialized
DEBUG - 2018-04-08 10:53:55 --> UTF-8 Support Enabled
INFO - 2018-04-08 10:53:55 --> Utf8 Class Initialized
INFO - 2018-04-08 10:53:55 --> URI Class Initialized
INFO - 2018-04-08 10:53:55 --> Router Class Initialized
INFO - 2018-04-08 10:53:55 --> Output Class Initialized
INFO - 2018-04-08 10:53:55 --> Security Class Initialized
DEBUG - 2018-04-08 10:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 10:53:55 --> Input Class Initialized
INFO - 2018-04-08 10:53:55 --> Language Class Initialized
INFO - 2018-04-08 10:53:55 --> Loader Class Initialized
INFO - 2018-04-08 10:53:55 --> Helper loaded: url_helper
INFO - 2018-04-08 10:53:55 --> Helper loaded: file_helper
INFO - 2018-04-08 10:53:55 --> Helper loaded: date_helper
INFO - 2018-04-08 10:53:55 --> Database Driver Class Initialized
DEBUG - 2018-04-08 10:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 10:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 10:53:55 --> Controller Class Initialized
INFO - 2018-04-08 10:53:55 --> Model Class Initialized
INFO - 2018-04-08 10:53:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
ERROR - 2018-04-08 10:53:55 --> Severity: Notice --> Undefined variable: user_info G:\xampp\htdocs\codeigniter\application\views\user\show.php 13
ERROR - 2018-04-08 10:53:55 --> Severity: Warning --> Invalid argument supplied for foreach() G:\xampp\htdocs\codeigniter\application\views\user\show.php 13
INFO - 2018-04-08 10:53:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-08 10:53:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 10:53:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 10:53:55 --> Final output sent to browser
DEBUG - 2018-04-08 10:53:55 --> Total execution time: 0.4917
INFO - 2018-04-08 10:54:26 --> Config Class Initialized
INFO - 2018-04-08 10:54:26 --> Hooks Class Initialized
DEBUG - 2018-04-08 10:54:26 --> UTF-8 Support Enabled
INFO - 2018-04-08 10:54:26 --> Utf8 Class Initialized
INFO - 2018-04-08 10:54:26 --> URI Class Initialized
INFO - 2018-04-08 10:54:26 --> Router Class Initialized
INFO - 2018-04-08 10:54:26 --> Output Class Initialized
INFO - 2018-04-08 10:54:26 --> Security Class Initialized
DEBUG - 2018-04-08 10:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 10:54:26 --> Input Class Initialized
INFO - 2018-04-08 10:54:26 --> Language Class Initialized
INFO - 2018-04-08 10:54:26 --> Loader Class Initialized
INFO - 2018-04-08 10:54:26 --> Helper loaded: url_helper
INFO - 2018-04-08 10:54:26 --> Helper loaded: file_helper
INFO - 2018-04-08 10:54:26 --> Helper loaded: date_helper
INFO - 2018-04-08 10:54:26 --> Database Driver Class Initialized
DEBUG - 2018-04-08 10:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 10:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 10:54:26 --> Controller Class Initialized
INFO - 2018-04-08 10:54:26 --> Model Class Initialized
INFO - 2018-04-08 10:54:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 10:54:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-08 10:54:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 10:54:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 10:54:26 --> Final output sent to browser
DEBUG - 2018-04-08 10:54:26 --> Total execution time: 0.3232
INFO - 2018-04-08 20:12:27 --> Config Class Initialized
INFO - 2018-04-08 20:12:27 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:12:27 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:12:27 --> Utf8 Class Initialized
INFO - 2018-04-08 20:12:27 --> URI Class Initialized
DEBUG - 2018-04-08 20:12:27 --> No URI present. Default controller set.
INFO - 2018-04-08 20:12:27 --> Router Class Initialized
INFO - 2018-04-08 20:12:27 --> Output Class Initialized
INFO - 2018-04-08 20:12:27 --> Security Class Initialized
DEBUG - 2018-04-08 20:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:12:27 --> Input Class Initialized
INFO - 2018-04-08 20:12:27 --> Language Class Initialized
INFO - 2018-04-08 20:12:27 --> Loader Class Initialized
INFO - 2018-04-08 20:12:27 --> Helper loaded: url_helper
INFO - 2018-04-08 20:12:27 --> Helper loaded: file_helper
INFO - 2018-04-08 20:12:27 --> Helper loaded: date_helper
INFO - 2018-04-08 20:12:28 --> Database Driver Class Initialized
DEBUG - 2018-04-08 20:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 20:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:12:28 --> Controller Class Initialized
INFO - 2018-04-08 20:12:28 --> Config Class Initialized
INFO - 2018-04-08 20:12:28 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:12:28 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:12:28 --> Utf8 Class Initialized
INFO - 2018-04-08 20:12:28 --> URI Class Initialized
INFO - 2018-04-08 20:12:28 --> Router Class Initialized
INFO - 2018-04-08 20:12:28 --> Output Class Initialized
INFO - 2018-04-08 20:12:28 --> Security Class Initialized
DEBUG - 2018-04-08 20:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:12:28 --> Input Class Initialized
INFO - 2018-04-08 20:12:28 --> Language Class Initialized
INFO - 2018-04-08 20:12:28 --> Loader Class Initialized
INFO - 2018-04-08 20:12:28 --> Helper loaded: url_helper
INFO - 2018-04-08 20:12:28 --> Helper loaded: file_helper
INFO - 2018-04-08 20:12:28 --> Helper loaded: date_helper
INFO - 2018-04-08 20:12:28 --> Database Driver Class Initialized
DEBUG - 2018-04-08 20:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 20:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:12:29 --> Controller Class Initialized
INFO - 2018-04-08 20:12:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 20:12:29 --> Final output sent to browser
DEBUG - 2018-04-08 20:12:29 --> Total execution time: 0.4471
INFO - 2018-04-08 20:12:43 --> Config Class Initialized
INFO - 2018-04-08 20:12:43 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:12:43 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:12:43 --> Utf8 Class Initialized
INFO - 2018-04-08 20:12:43 --> URI Class Initialized
INFO - 2018-04-08 20:12:43 --> Router Class Initialized
INFO - 2018-04-08 20:12:43 --> Output Class Initialized
INFO - 2018-04-08 20:12:43 --> Security Class Initialized
DEBUG - 2018-04-08 20:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:12:43 --> Input Class Initialized
INFO - 2018-04-08 20:12:43 --> Language Class Initialized
INFO - 2018-04-08 20:12:43 --> Loader Class Initialized
INFO - 2018-04-08 20:12:43 --> Helper loaded: url_helper
INFO - 2018-04-08 20:12:43 --> Helper loaded: file_helper
INFO - 2018-04-08 20:12:43 --> Helper loaded: date_helper
INFO - 2018-04-08 20:12:43 --> Database Driver Class Initialized
DEBUG - 2018-04-08 20:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 20:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:12:43 --> Controller Class Initialized
INFO - 2018-04-08 20:12:44 --> Model Class Initialized
INFO - 2018-04-08 20:12:44 --> Final output sent to browser
DEBUG - 2018-04-08 20:12:44 --> Total execution time: 0.5924
INFO - 2018-04-08 20:12:44 --> Config Class Initialized
INFO - 2018-04-08 20:12:44 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:12:44 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:12:44 --> Utf8 Class Initialized
INFO - 2018-04-08 20:12:44 --> URI Class Initialized
INFO - 2018-04-08 20:12:44 --> Router Class Initialized
INFO - 2018-04-08 20:12:44 --> Output Class Initialized
INFO - 2018-04-08 20:12:44 --> Security Class Initialized
DEBUG - 2018-04-08 20:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:12:44 --> Input Class Initialized
INFO - 2018-04-08 20:12:44 --> Language Class Initialized
ERROR - 2018-04-08 20:12:44 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 58
INFO - 2018-04-08 20:16:11 --> Config Class Initialized
INFO - 2018-04-08 20:16:11 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:16:11 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:16:11 --> Utf8 Class Initialized
INFO - 2018-04-08 20:16:11 --> URI Class Initialized
INFO - 2018-04-08 20:16:11 --> Router Class Initialized
INFO - 2018-04-08 20:16:11 --> Output Class Initialized
INFO - 2018-04-08 20:16:11 --> Security Class Initialized
DEBUG - 2018-04-08 20:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:16:11 --> Input Class Initialized
INFO - 2018-04-08 20:16:11 --> Language Class Initialized
INFO - 2018-04-08 20:16:11 --> Loader Class Initialized
INFO - 2018-04-08 20:16:11 --> Helper loaded: url_helper
INFO - 2018-04-08 20:16:11 --> Helper loaded: file_helper
INFO - 2018-04-08 20:16:11 --> Helper loaded: date_helper
INFO - 2018-04-08 20:16:11 --> Database Driver Class Initialized
DEBUG - 2018-04-08 20:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 20:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:16:12 --> Controller Class Initialized
ERROR - 2018-04-08 20:16:12 --> Severity: error --> Exception: syntax error, unexpected '*' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 34
INFO - 2018-04-08 20:17:00 --> Config Class Initialized
INFO - 2018-04-08 20:17:00 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:17:01 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:17:01 --> Utf8 Class Initialized
INFO - 2018-04-08 20:17:01 --> URI Class Initialized
INFO - 2018-04-08 20:17:01 --> Router Class Initialized
INFO - 2018-04-08 20:17:01 --> Output Class Initialized
INFO - 2018-04-08 20:17:01 --> Security Class Initialized
DEBUG - 2018-04-08 20:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:17:01 --> Input Class Initialized
INFO - 2018-04-08 20:17:01 --> Language Class Initialized
INFO - 2018-04-08 20:17:01 --> Loader Class Initialized
INFO - 2018-04-08 20:17:01 --> Helper loaded: url_helper
INFO - 2018-04-08 20:17:01 --> Helper loaded: file_helper
INFO - 2018-04-08 20:17:01 --> Helper loaded: date_helper
INFO - 2018-04-08 20:17:01 --> Database Driver Class Initialized
DEBUG - 2018-04-08 20:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 20:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:17:01 --> Controller Class Initialized
INFO - 2018-04-08 20:17:01 --> Model Class Initialized
INFO - 2018-04-08 20:17:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 20:17:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 20:17:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 20:17:01 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 20:17:01 --> Final output sent to browser
DEBUG - 2018-04-08 20:17:01 --> Total execution time: 0.4153
INFO - 2018-04-08 20:17:01 --> Config Class Initialized
INFO - 2018-04-08 20:17:01 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:17:01 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:17:01 --> Utf8 Class Initialized
INFO - 2018-04-08 20:17:01 --> URI Class Initialized
INFO - 2018-04-08 20:17:01 --> Router Class Initialized
INFO - 2018-04-08 20:17:01 --> Output Class Initialized
INFO - 2018-04-08 20:17:01 --> Security Class Initialized
DEBUG - 2018-04-08 20:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:17:01 --> Input Class Initialized
INFO - 2018-04-08 20:17:01 --> Language Class Initialized
ERROR - 2018-04-08 20:17:01 --> 404 Page Not Found: Assets/img
INFO - 2018-04-08 20:22:53 --> Config Class Initialized
INFO - 2018-04-08 20:22:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:22:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:22:53 --> Utf8 Class Initialized
INFO - 2018-04-08 20:22:53 --> URI Class Initialized
INFO - 2018-04-08 20:22:53 --> Router Class Initialized
INFO - 2018-04-08 20:22:53 --> Output Class Initialized
INFO - 2018-04-08 20:22:53 --> Security Class Initialized
DEBUG - 2018-04-08 20:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:22:53 --> Input Class Initialized
INFO - 2018-04-08 20:22:53 --> Language Class Initialized
INFO - 2018-04-08 20:22:53 --> Loader Class Initialized
INFO - 2018-04-08 20:22:53 --> Helper loaded: url_helper
INFO - 2018-04-08 20:22:53 --> Helper loaded: file_helper
INFO - 2018-04-08 20:22:53 --> Helper loaded: date_helper
INFO - 2018-04-08 20:22:53 --> Database Driver Class Initialized
DEBUG - 2018-04-08 20:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 20:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:22:54 --> Controller Class Initialized
INFO - 2018-04-08 20:22:54 --> Model Class Initialized
INFO - 2018-04-08 20:22:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 20:22:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-08 20:22:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 20:22:54 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 20:22:54 --> Final output sent to browser
DEBUG - 2018-04-08 20:22:54 --> Total execution time: 0.5495
INFO - 2018-04-08 20:41:59 --> Config Class Initialized
INFO - 2018-04-08 20:41:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:41:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:41:59 --> Utf8 Class Initialized
INFO - 2018-04-08 20:41:59 --> URI Class Initialized
DEBUG - 2018-04-08 20:41:59 --> No URI present. Default controller set.
INFO - 2018-04-08 20:41:59 --> Router Class Initialized
INFO - 2018-04-08 20:41:59 --> Output Class Initialized
INFO - 2018-04-08 20:41:59 --> Security Class Initialized
DEBUG - 2018-04-08 20:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:41:59 --> Input Class Initialized
INFO - 2018-04-08 20:41:59 --> Language Class Initialized
INFO - 2018-04-08 20:41:59 --> Loader Class Initialized
INFO - 2018-04-08 20:42:00 --> Helper loaded: url_helper
INFO - 2018-04-08 20:42:00 --> Helper loaded: file_helper
INFO - 2018-04-08 20:42:00 --> Helper loaded: date_helper
INFO - 2018-04-08 20:42:00 --> Database Driver Class Initialized
DEBUG - 2018-04-08 20:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 20:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:42:00 --> Controller Class Initialized
INFO - 2018-04-08 20:42:00 --> Config Class Initialized
INFO - 2018-04-08 20:42:00 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:42:00 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:42:00 --> Utf8 Class Initialized
INFO - 2018-04-08 20:42:00 --> URI Class Initialized
INFO - 2018-04-08 20:42:00 --> Router Class Initialized
INFO - 2018-04-08 20:42:00 --> Output Class Initialized
INFO - 2018-04-08 20:42:00 --> Security Class Initialized
DEBUG - 2018-04-08 20:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:42:00 --> Input Class Initialized
INFO - 2018-04-08 20:42:00 --> Language Class Initialized
ERROR - 2018-04-08 20:42:00 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 58
INFO - 2018-04-08 20:42:36 --> Config Class Initialized
INFO - 2018-04-08 20:42:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:42:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:42:36 --> Utf8 Class Initialized
INFO - 2018-04-08 20:42:36 --> URI Class Initialized
DEBUG - 2018-04-08 20:42:36 --> No URI present. Default controller set.
INFO - 2018-04-08 20:42:36 --> Router Class Initialized
INFO - 2018-04-08 20:42:36 --> Output Class Initialized
INFO - 2018-04-08 20:42:36 --> Security Class Initialized
DEBUG - 2018-04-08 20:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:42:36 --> Input Class Initialized
INFO - 2018-04-08 20:42:36 --> Language Class Initialized
INFO - 2018-04-08 20:42:36 --> Loader Class Initialized
INFO - 2018-04-08 20:42:36 --> Helper loaded: url_helper
INFO - 2018-04-08 20:42:36 --> Helper loaded: file_helper
INFO - 2018-04-08 20:42:36 --> Helper loaded: date_helper
INFO - 2018-04-08 20:42:36 --> Database Driver Class Initialized
DEBUG - 2018-04-08 20:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 20:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:42:36 --> Controller Class Initialized
INFO - 2018-04-08 20:42:36 --> Config Class Initialized
INFO - 2018-04-08 20:42:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:42:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:42:36 --> Utf8 Class Initialized
INFO - 2018-04-08 20:42:36 --> URI Class Initialized
INFO - 2018-04-08 20:42:36 --> Router Class Initialized
INFO - 2018-04-08 20:42:36 --> Output Class Initialized
INFO - 2018-04-08 20:42:36 --> Security Class Initialized
DEBUG - 2018-04-08 20:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:42:36 --> Input Class Initialized
INFO - 2018-04-08 20:42:36 --> Language Class Initialized
ERROR - 2018-04-08 20:42:36 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 58
INFO - 2018-04-08 20:44:27 --> Config Class Initialized
INFO - 2018-04-08 20:44:27 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:44:27 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:44:27 --> Utf8 Class Initialized
INFO - 2018-04-08 20:44:27 --> URI Class Initialized
INFO - 2018-04-08 20:44:27 --> Router Class Initialized
INFO - 2018-04-08 20:44:27 --> Output Class Initialized
INFO - 2018-04-08 20:44:27 --> Security Class Initialized
DEBUG - 2018-04-08 20:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:44:27 --> Input Class Initialized
INFO - 2018-04-08 20:44:27 --> Language Class Initialized
ERROR - 2018-04-08 20:44:27 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 56
INFO - 2018-04-08 20:45:47 --> Config Class Initialized
INFO - 2018-04-08 20:45:47 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:45:47 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:45:47 --> Utf8 Class Initialized
INFO - 2018-04-08 20:45:47 --> URI Class Initialized
INFO - 2018-04-08 20:45:47 --> Router Class Initialized
INFO - 2018-04-08 20:45:47 --> Output Class Initialized
INFO - 2018-04-08 20:45:47 --> Security Class Initialized
DEBUG - 2018-04-08 20:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:45:47 --> Input Class Initialized
INFO - 2018-04-08 20:45:48 --> Language Class Initialized
ERROR - 2018-04-08 20:45:48 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 55
INFO - 2018-04-08 20:47:48 --> Config Class Initialized
INFO - 2018-04-08 20:47:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:47:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:47:48 --> Utf8 Class Initialized
INFO - 2018-04-08 20:47:48 --> URI Class Initialized
INFO - 2018-04-08 20:47:48 --> Router Class Initialized
INFO - 2018-04-08 20:47:48 --> Output Class Initialized
INFO - 2018-04-08 20:47:48 --> Security Class Initialized
DEBUG - 2018-04-08 20:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:47:48 --> Input Class Initialized
INFO - 2018-04-08 20:47:48 --> Language Class Initialized
ERROR - 2018-04-08 20:47:48 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 55
INFO - 2018-04-08 20:47:51 --> Config Class Initialized
INFO - 2018-04-08 20:47:51 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:47:51 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:47:51 --> Utf8 Class Initialized
INFO - 2018-04-08 20:47:51 --> URI Class Initialized
INFO - 2018-04-08 20:47:51 --> Router Class Initialized
INFO - 2018-04-08 20:47:51 --> Output Class Initialized
INFO - 2018-04-08 20:47:51 --> Security Class Initialized
DEBUG - 2018-04-08 20:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:47:51 --> Input Class Initialized
INFO - 2018-04-08 20:47:51 --> Language Class Initialized
ERROR - 2018-04-08 20:47:51 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 55
INFO - 2018-04-08 20:48:50 --> Config Class Initialized
INFO - 2018-04-08 20:48:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:48:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:48:50 --> Utf8 Class Initialized
INFO - 2018-04-08 20:48:50 --> URI Class Initialized
INFO - 2018-04-08 20:48:50 --> Router Class Initialized
INFO - 2018-04-08 20:48:50 --> Output Class Initialized
INFO - 2018-04-08 20:48:50 --> Security Class Initialized
DEBUG - 2018-04-08 20:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:48:50 --> Input Class Initialized
INFO - 2018-04-08 20:48:50 --> Language Class Initialized
ERROR - 2018-04-08 20:48:50 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 57
INFO - 2018-04-08 20:50:38 --> Config Class Initialized
INFO - 2018-04-08 20:50:38 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:50:38 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:50:38 --> Utf8 Class Initialized
INFO - 2018-04-08 20:50:38 --> URI Class Initialized
INFO - 2018-04-08 20:50:38 --> Router Class Initialized
INFO - 2018-04-08 20:50:38 --> Output Class Initialized
INFO - 2018-04-08 20:50:38 --> Security Class Initialized
DEBUG - 2018-04-08 20:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:50:38 --> Input Class Initialized
INFO - 2018-04-08 20:50:38 --> Language Class Initialized
ERROR - 2018-04-08 20:50:38 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 20:54:06 --> Config Class Initialized
INFO - 2018-04-08 20:54:06 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:54:06 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:54:06 --> Utf8 Class Initialized
INFO - 2018-04-08 20:54:06 --> URI Class Initialized
INFO - 2018-04-08 20:54:06 --> Router Class Initialized
INFO - 2018-04-08 20:54:06 --> Output Class Initialized
INFO - 2018-04-08 20:54:06 --> Security Class Initialized
DEBUG - 2018-04-08 20:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:54:06 --> Input Class Initialized
INFO - 2018-04-08 20:54:06 --> Language Class Initialized
ERROR - 2018-04-08 20:54:06 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 20:54:09 --> Config Class Initialized
INFO - 2018-04-08 20:54:09 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:54:09 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:54:09 --> Utf8 Class Initialized
INFO - 2018-04-08 20:54:09 --> URI Class Initialized
INFO - 2018-04-08 20:54:09 --> Router Class Initialized
INFO - 2018-04-08 20:54:09 --> Output Class Initialized
INFO - 2018-04-08 20:54:09 --> Security Class Initialized
DEBUG - 2018-04-08 20:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:54:09 --> Input Class Initialized
INFO - 2018-04-08 20:54:09 --> Language Class Initialized
ERROR - 2018-04-08 20:54:09 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 20:54:32 --> Config Class Initialized
INFO - 2018-04-08 20:54:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:54:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:54:33 --> Utf8 Class Initialized
INFO - 2018-04-08 20:54:33 --> URI Class Initialized
INFO - 2018-04-08 20:54:33 --> Router Class Initialized
INFO - 2018-04-08 20:54:33 --> Output Class Initialized
INFO - 2018-04-08 20:54:33 --> Security Class Initialized
DEBUG - 2018-04-08 20:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:54:33 --> Input Class Initialized
INFO - 2018-04-08 20:54:33 --> Language Class Initialized
ERROR - 2018-04-08 20:54:33 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 20:55:42 --> Config Class Initialized
INFO - 2018-04-08 20:55:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:55:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:55:42 --> Utf8 Class Initialized
INFO - 2018-04-08 20:55:42 --> URI Class Initialized
INFO - 2018-04-08 20:55:42 --> Router Class Initialized
INFO - 2018-04-08 20:55:42 --> Output Class Initialized
INFO - 2018-04-08 20:55:42 --> Security Class Initialized
DEBUG - 2018-04-08 20:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:55:42 --> Input Class Initialized
INFO - 2018-04-08 20:55:42 --> Language Class Initialized
ERROR - 2018-04-08 20:55:42 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 20:56:34 --> Config Class Initialized
INFO - 2018-04-08 20:56:34 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:56:34 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:56:34 --> Utf8 Class Initialized
INFO - 2018-04-08 20:56:34 --> URI Class Initialized
INFO - 2018-04-08 20:56:34 --> Router Class Initialized
INFO - 2018-04-08 20:56:34 --> Output Class Initialized
INFO - 2018-04-08 20:56:34 --> Security Class Initialized
DEBUG - 2018-04-08 20:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:56:34 --> Input Class Initialized
INFO - 2018-04-08 20:56:34 --> Language Class Initialized
ERROR - 2018-04-08 20:56:34 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 20:57:03 --> Config Class Initialized
INFO - 2018-04-08 20:57:03 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:57:03 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:57:03 --> Utf8 Class Initialized
INFO - 2018-04-08 20:57:03 --> URI Class Initialized
INFO - 2018-04-08 20:57:03 --> Router Class Initialized
INFO - 2018-04-08 20:57:03 --> Output Class Initialized
INFO - 2018-04-08 20:57:03 --> Security Class Initialized
DEBUG - 2018-04-08 20:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:57:03 --> Input Class Initialized
INFO - 2018-04-08 20:57:03 --> Language Class Initialized
ERROR - 2018-04-08 20:57:03 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 20:57:49 --> Config Class Initialized
INFO - 2018-04-08 20:57:49 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:57:49 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:57:49 --> Utf8 Class Initialized
INFO - 2018-04-08 20:57:49 --> URI Class Initialized
INFO - 2018-04-08 20:57:49 --> Router Class Initialized
INFO - 2018-04-08 20:57:49 --> Output Class Initialized
INFO - 2018-04-08 20:57:49 --> Security Class Initialized
DEBUG - 2018-04-08 20:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:57:49 --> Input Class Initialized
INFO - 2018-04-08 20:57:49 --> Language Class Initialized
ERROR - 2018-04-08 20:57:49 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 20:57:56 --> Config Class Initialized
INFO - 2018-04-08 20:57:56 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:57:56 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:57:56 --> Utf8 Class Initialized
INFO - 2018-04-08 20:57:56 --> URI Class Initialized
INFO - 2018-04-08 20:57:56 --> Router Class Initialized
INFO - 2018-04-08 20:57:56 --> Output Class Initialized
INFO - 2018-04-08 20:57:56 --> Security Class Initialized
DEBUG - 2018-04-08 20:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:57:56 --> Input Class Initialized
INFO - 2018-04-08 20:57:56 --> Language Class Initialized
ERROR - 2018-04-08 20:57:56 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 20:58:12 --> Config Class Initialized
INFO - 2018-04-08 20:58:13 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:58:13 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:58:13 --> Utf8 Class Initialized
INFO - 2018-04-08 20:58:13 --> URI Class Initialized
INFO - 2018-04-08 20:58:13 --> Router Class Initialized
INFO - 2018-04-08 20:58:13 --> Output Class Initialized
INFO - 2018-04-08 20:58:13 --> Security Class Initialized
DEBUG - 2018-04-08 20:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:58:13 --> Input Class Initialized
INFO - 2018-04-08 20:58:13 --> Language Class Initialized
ERROR - 2018-04-08 20:58:13 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 20:59:14 --> Config Class Initialized
INFO - 2018-04-08 20:59:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:59:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:59:14 --> Utf8 Class Initialized
INFO - 2018-04-08 20:59:14 --> URI Class Initialized
INFO - 2018-04-08 20:59:14 --> Router Class Initialized
INFO - 2018-04-08 20:59:14 --> Output Class Initialized
INFO - 2018-04-08 20:59:14 --> Security Class Initialized
DEBUG - 2018-04-08 20:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:59:14 --> Input Class Initialized
INFO - 2018-04-08 20:59:14 --> Language Class Initialized
ERROR - 2018-04-08 20:59:14 --> Severity: error --> Exception: syntax error, unexpected '$update' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 21:00:05 --> Config Class Initialized
INFO - 2018-04-08 21:00:05 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:00:05 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:00:05 --> Utf8 Class Initialized
INFO - 2018-04-08 21:00:05 --> URI Class Initialized
INFO - 2018-04-08 21:00:05 --> Router Class Initialized
INFO - 2018-04-08 21:00:05 --> Output Class Initialized
INFO - 2018-04-08 21:00:05 --> Security Class Initialized
DEBUG - 2018-04-08 21:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:00:05 --> Input Class Initialized
INFO - 2018-04-08 21:00:05 --> Language Class Initialized
ERROR - 2018-04-08 21:00:05 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 68
INFO - 2018-04-08 21:19:03 --> Config Class Initialized
INFO - 2018-04-08 21:19:03 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:19:03 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:19:03 --> Utf8 Class Initialized
INFO - 2018-04-08 21:19:03 --> URI Class Initialized
INFO - 2018-04-08 21:19:03 --> Router Class Initialized
INFO - 2018-04-08 21:19:03 --> Output Class Initialized
INFO - 2018-04-08 21:19:03 --> Security Class Initialized
DEBUG - 2018-04-08 21:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:19:03 --> Input Class Initialized
INFO - 2018-04-08 21:19:03 --> Language Class Initialized
INFO - 2018-04-08 21:19:03 --> Loader Class Initialized
INFO - 2018-04-08 21:19:03 --> Helper loaded: url_helper
INFO - 2018-04-08 21:19:03 --> Helper loaded: file_helper
INFO - 2018-04-08 21:19:03 --> Helper loaded: date_helper
INFO - 2018-04-08 21:19:03 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:19:03 --> Controller Class Initialized
ERROR - 2018-04-08 21:19:03 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-08 21:20:04 --> Config Class Initialized
INFO - 2018-04-08 21:20:04 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:20:04 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:20:04 --> Utf8 Class Initialized
INFO - 2018-04-08 21:20:04 --> URI Class Initialized
INFO - 2018-04-08 21:20:04 --> Router Class Initialized
INFO - 2018-04-08 21:20:04 --> Output Class Initialized
INFO - 2018-04-08 21:20:04 --> Security Class Initialized
DEBUG - 2018-04-08 21:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:20:04 --> Input Class Initialized
INFO - 2018-04-08 21:20:04 --> Language Class Initialized
INFO - 2018-04-08 21:20:04 --> Loader Class Initialized
INFO - 2018-04-08 21:20:04 --> Helper loaded: url_helper
INFO - 2018-04-08 21:20:04 --> Helper loaded: file_helper
INFO - 2018-04-08 21:20:05 --> Helper loaded: date_helper
INFO - 2018-04-08 21:20:05 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:20:05 --> Controller Class Initialized
INFO - 2018-04-08 21:20:05 --> Model Class Initialized
INFO - 2018-04-08 21:20:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:20:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:20:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:20:05 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:20:05 --> Final output sent to browser
DEBUG - 2018-04-08 21:20:05 --> Total execution time: 0.3586
INFO - 2018-04-08 21:20:12 --> Config Class Initialized
INFO - 2018-04-08 21:20:12 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:20:12 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:20:12 --> Utf8 Class Initialized
INFO - 2018-04-08 21:20:12 --> URI Class Initialized
INFO - 2018-04-08 21:20:12 --> Router Class Initialized
INFO - 2018-04-08 21:20:12 --> Output Class Initialized
INFO - 2018-04-08 21:20:12 --> Security Class Initialized
DEBUG - 2018-04-08 21:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:20:12 --> Input Class Initialized
INFO - 2018-04-08 21:20:12 --> Language Class Initialized
INFO - 2018-04-08 21:20:12 --> Loader Class Initialized
INFO - 2018-04-08 21:20:12 --> Helper loaded: url_helper
INFO - 2018-04-08 21:20:12 --> Helper loaded: file_helper
INFO - 2018-04-08 21:20:12 --> Helper loaded: date_helper
INFO - 2018-04-08 21:20:12 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:20:12 --> Controller Class Initialized
DEBUG - 2018-04-08 21:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:20:12 --> Config Class Initialized
INFO - 2018-04-08 21:20:12 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:20:12 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:20:12 --> Utf8 Class Initialized
INFO - 2018-04-08 21:20:12 --> URI Class Initialized
INFO - 2018-04-08 21:20:12 --> Router Class Initialized
INFO - 2018-04-08 21:20:12 --> Output Class Initialized
INFO - 2018-04-08 21:20:12 --> Security Class Initialized
DEBUG - 2018-04-08 21:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:20:12 --> Input Class Initialized
INFO - 2018-04-08 21:20:12 --> Language Class Initialized
INFO - 2018-04-08 21:20:12 --> Loader Class Initialized
INFO - 2018-04-08 21:20:12 --> Helper loaded: url_helper
INFO - 2018-04-08 21:20:12 --> Helper loaded: file_helper
INFO - 2018-04-08 21:20:12 --> Helper loaded: date_helper
INFO - 2018-04-08 21:20:12 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:20:12 --> Controller Class Initialized
INFO - 2018-04-08 21:20:12 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 21:20:12 --> Final output sent to browser
DEBUG - 2018-04-08 21:20:12 --> Total execution time: 0.2803
INFO - 2018-04-08 21:20:21 --> Config Class Initialized
INFO - 2018-04-08 21:20:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:20:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:20:21 --> Utf8 Class Initialized
INFO - 2018-04-08 21:20:21 --> URI Class Initialized
INFO - 2018-04-08 21:20:21 --> Router Class Initialized
INFO - 2018-04-08 21:20:21 --> Output Class Initialized
INFO - 2018-04-08 21:20:21 --> Security Class Initialized
DEBUG - 2018-04-08 21:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:20:21 --> Input Class Initialized
INFO - 2018-04-08 21:20:21 --> Language Class Initialized
INFO - 2018-04-08 21:20:21 --> Loader Class Initialized
INFO - 2018-04-08 21:20:21 --> Helper loaded: url_helper
INFO - 2018-04-08 21:20:21 --> Helper loaded: file_helper
INFO - 2018-04-08 21:20:21 --> Helper loaded: date_helper
INFO - 2018-04-08 21:20:21 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:20:21 --> Controller Class Initialized
INFO - 2018-04-08 21:20:21 --> Model Class Initialized
INFO - 2018-04-08 21:20:21 --> Final output sent to browser
DEBUG - 2018-04-08 21:20:21 --> Total execution time: 0.2965
INFO - 2018-04-08 21:20:21 --> Config Class Initialized
INFO - 2018-04-08 21:20:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:20:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:20:21 --> Utf8 Class Initialized
INFO - 2018-04-08 21:20:21 --> URI Class Initialized
INFO - 2018-04-08 21:20:21 --> Router Class Initialized
INFO - 2018-04-08 21:20:21 --> Output Class Initialized
INFO - 2018-04-08 21:20:21 --> Security Class Initialized
DEBUG - 2018-04-08 21:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:20:21 --> Input Class Initialized
INFO - 2018-04-08 21:20:21 --> Language Class Initialized
INFO - 2018-04-08 21:20:21 --> Loader Class Initialized
INFO - 2018-04-08 21:20:21 --> Helper loaded: url_helper
INFO - 2018-04-08 21:20:21 --> Helper loaded: file_helper
INFO - 2018-04-08 21:20:21 --> Helper loaded: date_helper
INFO - 2018-04-08 21:20:21 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:20:21 --> Controller Class Initialized
INFO - 2018-04-08 21:20:21 --> Model Class Initialized
INFO - 2018-04-08 21:20:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:20:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:20:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:20:21 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:20:21 --> Final output sent to browser
DEBUG - 2018-04-08 21:20:21 --> Total execution time: 0.3420
INFO - 2018-04-08 21:33:25 --> Config Class Initialized
INFO - 2018-04-08 21:33:25 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:33:25 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:33:25 --> Utf8 Class Initialized
INFO - 2018-04-08 21:33:25 --> URI Class Initialized
INFO - 2018-04-08 21:33:25 --> Router Class Initialized
INFO - 2018-04-08 21:33:25 --> Output Class Initialized
INFO - 2018-04-08 21:33:25 --> Security Class Initialized
DEBUG - 2018-04-08 21:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:33:25 --> Input Class Initialized
INFO - 2018-04-08 21:33:25 --> Language Class Initialized
INFO - 2018-04-08 21:33:25 --> Loader Class Initialized
INFO - 2018-04-08 21:33:25 --> Helper loaded: url_helper
INFO - 2018-04-08 21:33:25 --> Helper loaded: file_helper
INFO - 2018-04-08 21:33:25 --> Helper loaded: date_helper
INFO - 2018-04-08 21:33:25 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:33:25 --> Controller Class Initialized
INFO - 2018-04-08 21:33:25 --> Model Class Initialized
INFO - 2018-04-08 21:33:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:33:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:33:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:33:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:33:25 --> Final output sent to browser
DEBUG - 2018-04-08 21:33:25 --> Total execution time: 0.4131
INFO - 2018-04-08 21:33:27 --> Config Class Initialized
INFO - 2018-04-08 21:33:27 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:33:27 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:33:27 --> Utf8 Class Initialized
INFO - 2018-04-08 21:33:27 --> URI Class Initialized
INFO - 2018-04-08 21:33:27 --> Router Class Initialized
INFO - 2018-04-08 21:33:27 --> Output Class Initialized
INFO - 2018-04-08 21:33:27 --> Security Class Initialized
DEBUG - 2018-04-08 21:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:33:27 --> Input Class Initialized
INFO - 2018-04-08 21:33:27 --> Language Class Initialized
INFO - 2018-04-08 21:33:27 --> Loader Class Initialized
INFO - 2018-04-08 21:33:27 --> Helper loaded: url_helper
INFO - 2018-04-08 21:33:27 --> Helper loaded: file_helper
INFO - 2018-04-08 21:33:27 --> Helper loaded: date_helper
INFO - 2018-04-08 21:33:27 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:33:27 --> Controller Class Initialized
INFO - 2018-04-08 21:33:28 --> Config Class Initialized
INFO - 2018-04-08 21:33:28 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:33:28 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:33:28 --> Utf8 Class Initialized
INFO - 2018-04-08 21:33:28 --> URI Class Initialized
INFO - 2018-04-08 21:33:28 --> Router Class Initialized
INFO - 2018-04-08 21:33:28 --> Output Class Initialized
INFO - 2018-04-08 21:33:28 --> Security Class Initialized
DEBUG - 2018-04-08 21:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:33:28 --> Input Class Initialized
INFO - 2018-04-08 21:33:28 --> Language Class Initialized
INFO - 2018-04-08 21:33:28 --> Loader Class Initialized
INFO - 2018-04-08 21:33:28 --> Helper loaded: url_helper
INFO - 2018-04-08 21:33:28 --> Helper loaded: file_helper
INFO - 2018-04-08 21:33:28 --> Helper loaded: date_helper
INFO - 2018-04-08 21:33:28 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:33:28 --> Controller Class Initialized
INFO - 2018-04-08 21:33:28 --> Model Class Initialized
INFO - 2018-04-08 21:33:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:33:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:33:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:33:28 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:33:28 --> Final output sent to browser
DEBUG - 2018-04-08 21:33:28 --> Total execution time: 0.3322
INFO - 2018-04-08 21:33:29 --> Config Class Initialized
INFO - 2018-04-08 21:33:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:33:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:33:29 --> Utf8 Class Initialized
INFO - 2018-04-08 21:33:29 --> URI Class Initialized
INFO - 2018-04-08 21:33:29 --> Router Class Initialized
INFO - 2018-04-08 21:33:29 --> Output Class Initialized
INFO - 2018-04-08 21:33:29 --> Security Class Initialized
DEBUG - 2018-04-08 21:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:33:29 --> Input Class Initialized
INFO - 2018-04-08 21:33:29 --> Language Class Initialized
INFO - 2018-04-08 21:33:29 --> Loader Class Initialized
INFO - 2018-04-08 21:33:29 --> Helper loaded: url_helper
INFO - 2018-04-08 21:33:29 --> Helper loaded: file_helper
INFO - 2018-04-08 21:33:29 --> Helper loaded: date_helper
INFO - 2018-04-08 21:33:29 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:33:29 --> Controller Class Initialized
INFO - 2018-04-08 21:33:29 --> Model Class Initialized
INFO - 2018-04-08 21:33:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:33:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:33:29 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:33:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:33:30 --> Final output sent to browser
DEBUG - 2018-04-08 21:33:30 --> Total execution time: 0.4015
INFO - 2018-04-08 21:33:34 --> Config Class Initialized
INFO - 2018-04-08 21:33:34 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:33:34 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:33:34 --> Utf8 Class Initialized
INFO - 2018-04-08 21:33:34 --> URI Class Initialized
INFO - 2018-04-08 21:33:34 --> Router Class Initialized
INFO - 2018-04-08 21:33:34 --> Output Class Initialized
INFO - 2018-04-08 21:33:34 --> Security Class Initialized
DEBUG - 2018-04-08 21:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:33:34 --> Input Class Initialized
INFO - 2018-04-08 21:33:34 --> Language Class Initialized
INFO - 2018-04-08 21:33:34 --> Loader Class Initialized
INFO - 2018-04-08 21:33:34 --> Helper loaded: url_helper
INFO - 2018-04-08 21:33:34 --> Helper loaded: file_helper
INFO - 2018-04-08 21:33:34 --> Helper loaded: date_helper
INFO - 2018-04-08 21:33:34 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:33:34 --> Controller Class Initialized
DEBUG - 2018-04-08 21:33:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:33:34 --> Config Class Initialized
INFO - 2018-04-08 21:33:34 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:33:34 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:33:34 --> Utf8 Class Initialized
INFO - 2018-04-08 21:33:34 --> URI Class Initialized
INFO - 2018-04-08 21:33:34 --> Router Class Initialized
INFO - 2018-04-08 21:33:34 --> Output Class Initialized
INFO - 2018-04-08 21:33:35 --> Security Class Initialized
DEBUG - 2018-04-08 21:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:33:35 --> Input Class Initialized
INFO - 2018-04-08 21:33:35 --> Language Class Initialized
INFO - 2018-04-08 21:33:35 --> Loader Class Initialized
INFO - 2018-04-08 21:33:35 --> Helper loaded: url_helper
INFO - 2018-04-08 21:33:35 --> Helper loaded: file_helper
INFO - 2018-04-08 21:33:35 --> Helper loaded: date_helper
INFO - 2018-04-08 21:33:35 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:33:35 --> Controller Class Initialized
INFO - 2018-04-08 21:33:35 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 21:33:35 --> Final output sent to browser
DEBUG - 2018-04-08 21:33:35 --> Total execution time: 0.2839
INFO - 2018-04-08 21:33:43 --> Config Class Initialized
INFO - 2018-04-08 21:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:33:43 --> Utf8 Class Initialized
INFO - 2018-04-08 21:33:43 --> URI Class Initialized
INFO - 2018-04-08 21:33:43 --> Router Class Initialized
INFO - 2018-04-08 21:33:43 --> Output Class Initialized
INFO - 2018-04-08 21:33:43 --> Security Class Initialized
DEBUG - 2018-04-08 21:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:33:43 --> Input Class Initialized
INFO - 2018-04-08 21:33:43 --> Language Class Initialized
INFO - 2018-04-08 21:33:43 --> Loader Class Initialized
INFO - 2018-04-08 21:33:43 --> Helper loaded: url_helper
INFO - 2018-04-08 21:33:43 --> Helper loaded: file_helper
INFO - 2018-04-08 21:33:43 --> Helper loaded: date_helper
INFO - 2018-04-08 21:33:43 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:33:43 --> Controller Class Initialized
INFO - 2018-04-08 21:33:43 --> Model Class Initialized
INFO - 2018-04-08 21:33:43 --> Final output sent to browser
DEBUG - 2018-04-08 21:33:43 --> Total execution time: 0.2923
INFO - 2018-04-08 21:33:43 --> Config Class Initialized
INFO - 2018-04-08 21:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:33:43 --> Utf8 Class Initialized
INFO - 2018-04-08 21:33:43 --> URI Class Initialized
INFO - 2018-04-08 21:33:43 --> Router Class Initialized
INFO - 2018-04-08 21:33:43 --> Output Class Initialized
INFO - 2018-04-08 21:33:43 --> Security Class Initialized
DEBUG - 2018-04-08 21:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:33:44 --> Input Class Initialized
INFO - 2018-04-08 21:33:44 --> Language Class Initialized
INFO - 2018-04-08 21:33:44 --> Loader Class Initialized
INFO - 2018-04-08 21:33:44 --> Helper loaded: url_helper
INFO - 2018-04-08 21:33:44 --> Helper loaded: file_helper
INFO - 2018-04-08 21:33:44 --> Helper loaded: date_helper
INFO - 2018-04-08 21:33:44 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:33:44 --> Controller Class Initialized
INFO - 2018-04-08 21:33:44 --> Model Class Initialized
INFO - 2018-04-08 21:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:33:44 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:33:44 --> Final output sent to browser
DEBUG - 2018-04-08 21:33:44 --> Total execution time: 0.3436
INFO - 2018-04-08 21:33:46 --> Config Class Initialized
INFO - 2018-04-08 21:33:46 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:33:46 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:33:46 --> Utf8 Class Initialized
INFO - 2018-04-08 21:33:46 --> URI Class Initialized
INFO - 2018-04-08 21:33:46 --> Router Class Initialized
INFO - 2018-04-08 21:33:46 --> Output Class Initialized
INFO - 2018-04-08 21:33:46 --> Security Class Initialized
DEBUG - 2018-04-08 21:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:33:46 --> Input Class Initialized
INFO - 2018-04-08 21:33:46 --> Language Class Initialized
INFO - 2018-04-08 21:33:46 --> Loader Class Initialized
INFO - 2018-04-08 21:33:46 --> Helper loaded: url_helper
INFO - 2018-04-08 21:33:46 --> Helper loaded: file_helper
INFO - 2018-04-08 21:33:46 --> Helper loaded: date_helper
INFO - 2018-04-08 21:33:46 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:33:46 --> Controller Class Initialized
INFO - 2018-04-08 21:33:46 --> Model Class Initialized
INFO - 2018-04-08 21:33:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:33:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-08 21:33:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:33:46 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:33:46 --> Final output sent to browser
DEBUG - 2018-04-08 21:33:46 --> Total execution time: 0.3587
INFO - 2018-04-08 21:35:36 --> Config Class Initialized
INFO - 2018-04-08 21:35:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:35:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:35:36 --> Utf8 Class Initialized
INFO - 2018-04-08 21:35:36 --> URI Class Initialized
INFO - 2018-04-08 21:35:36 --> Router Class Initialized
INFO - 2018-04-08 21:35:36 --> Output Class Initialized
INFO - 2018-04-08 21:35:36 --> Security Class Initialized
DEBUG - 2018-04-08 21:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:35:36 --> Input Class Initialized
INFO - 2018-04-08 21:35:36 --> Language Class Initialized
INFO - 2018-04-08 21:35:36 --> Loader Class Initialized
INFO - 2018-04-08 21:35:36 --> Helper loaded: url_helper
INFO - 2018-04-08 21:35:36 --> Helper loaded: file_helper
INFO - 2018-04-08 21:35:36 --> Helper loaded: date_helper
INFO - 2018-04-08 21:35:36 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:35:36 --> Controller Class Initialized
INFO - 2018-04-08 21:35:36 --> Model Class Initialized
INFO - 2018-04-08 21:35:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:35:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:35:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:35:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:35:36 --> Final output sent to browser
DEBUG - 2018-04-08 21:35:36 --> Total execution time: 0.3630
INFO - 2018-04-08 21:36:18 --> Config Class Initialized
INFO - 2018-04-08 21:36:18 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:36:18 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:36:18 --> Utf8 Class Initialized
INFO - 2018-04-08 21:36:18 --> URI Class Initialized
INFO - 2018-04-08 21:36:18 --> Router Class Initialized
INFO - 2018-04-08 21:36:18 --> Output Class Initialized
INFO - 2018-04-08 21:36:18 --> Security Class Initialized
DEBUG - 2018-04-08 21:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:36:18 --> Input Class Initialized
INFO - 2018-04-08 21:36:18 --> Language Class Initialized
INFO - 2018-04-08 21:36:18 --> Loader Class Initialized
INFO - 2018-04-08 21:36:18 --> Helper loaded: url_helper
INFO - 2018-04-08 21:36:18 --> Helper loaded: file_helper
INFO - 2018-04-08 21:36:18 --> Helper loaded: date_helper
INFO - 2018-04-08 21:36:18 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:36:18 --> Controller Class Initialized
INFO - 2018-04-08 21:36:18 --> Config Class Initialized
INFO - 2018-04-08 21:36:18 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:36:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:36:19 --> Utf8 Class Initialized
INFO - 2018-04-08 21:36:19 --> URI Class Initialized
INFO - 2018-04-08 21:36:19 --> Router Class Initialized
INFO - 2018-04-08 21:36:19 --> Output Class Initialized
INFO - 2018-04-08 21:36:19 --> Security Class Initialized
DEBUG - 2018-04-08 21:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:36:19 --> Input Class Initialized
INFO - 2018-04-08 21:36:19 --> Language Class Initialized
INFO - 2018-04-08 21:36:19 --> Loader Class Initialized
INFO - 2018-04-08 21:36:19 --> Helper loaded: url_helper
INFO - 2018-04-08 21:36:19 --> Helper loaded: file_helper
INFO - 2018-04-08 21:36:19 --> Helper loaded: date_helper
INFO - 2018-04-08 21:36:19 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:36:19 --> Controller Class Initialized
INFO - 2018-04-08 21:36:19 --> Model Class Initialized
INFO - 2018-04-08 21:36:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:36:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:36:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:36:19 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:36:19 --> Final output sent to browser
DEBUG - 2018-04-08 21:36:19 --> Total execution time: 0.3448
INFO - 2018-04-08 21:36:24 --> Config Class Initialized
INFO - 2018-04-08 21:36:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:36:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:36:24 --> Utf8 Class Initialized
INFO - 2018-04-08 21:36:24 --> URI Class Initialized
INFO - 2018-04-08 21:36:24 --> Router Class Initialized
INFO - 2018-04-08 21:36:24 --> Output Class Initialized
INFO - 2018-04-08 21:36:24 --> Security Class Initialized
DEBUG - 2018-04-08 21:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:36:24 --> Input Class Initialized
INFO - 2018-04-08 21:36:24 --> Language Class Initialized
INFO - 2018-04-08 21:36:24 --> Loader Class Initialized
INFO - 2018-04-08 21:36:24 --> Helper loaded: url_helper
INFO - 2018-04-08 21:36:24 --> Helper loaded: file_helper
INFO - 2018-04-08 21:36:24 --> Helper loaded: date_helper
INFO - 2018-04-08 21:36:24 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:36:24 --> Controller Class Initialized
DEBUG - 2018-04-08 21:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:36:24 --> Config Class Initialized
INFO - 2018-04-08 21:36:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:36:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:36:24 --> Utf8 Class Initialized
INFO - 2018-04-08 21:36:24 --> URI Class Initialized
INFO - 2018-04-08 21:36:24 --> Router Class Initialized
INFO - 2018-04-08 21:36:24 --> Output Class Initialized
INFO - 2018-04-08 21:36:25 --> Security Class Initialized
DEBUG - 2018-04-08 21:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:36:25 --> Input Class Initialized
INFO - 2018-04-08 21:36:25 --> Language Class Initialized
INFO - 2018-04-08 21:36:25 --> Loader Class Initialized
INFO - 2018-04-08 21:36:25 --> Helper loaded: url_helper
INFO - 2018-04-08 21:36:25 --> Helper loaded: file_helper
INFO - 2018-04-08 21:36:25 --> Helper loaded: date_helper
INFO - 2018-04-08 21:36:25 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:36:25 --> Controller Class Initialized
INFO - 2018-04-08 21:36:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 21:36:25 --> Final output sent to browser
DEBUG - 2018-04-08 21:36:25 --> Total execution time: 0.2908
INFO - 2018-04-08 21:36:33 --> Config Class Initialized
INFO - 2018-04-08 21:36:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:36:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:36:33 --> Utf8 Class Initialized
INFO - 2018-04-08 21:36:33 --> URI Class Initialized
INFO - 2018-04-08 21:36:33 --> Router Class Initialized
INFO - 2018-04-08 21:36:33 --> Output Class Initialized
INFO - 2018-04-08 21:36:33 --> Security Class Initialized
DEBUG - 2018-04-08 21:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:36:33 --> Input Class Initialized
INFO - 2018-04-08 21:36:33 --> Language Class Initialized
INFO - 2018-04-08 21:36:33 --> Loader Class Initialized
INFO - 2018-04-08 21:36:33 --> Helper loaded: url_helper
INFO - 2018-04-08 21:36:33 --> Helper loaded: file_helper
INFO - 2018-04-08 21:36:33 --> Helper loaded: date_helper
INFO - 2018-04-08 21:36:33 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:36:33 --> Controller Class Initialized
INFO - 2018-04-08 21:36:33 --> Model Class Initialized
INFO - 2018-04-08 21:36:33 --> Final output sent to browser
DEBUG - 2018-04-08 21:36:33 --> Total execution time: 0.2949
INFO - 2018-04-08 21:36:33 --> Config Class Initialized
INFO - 2018-04-08 21:36:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:36:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:36:33 --> Utf8 Class Initialized
INFO - 2018-04-08 21:36:33 --> URI Class Initialized
INFO - 2018-04-08 21:36:33 --> Router Class Initialized
INFO - 2018-04-08 21:36:33 --> Output Class Initialized
INFO - 2018-04-08 21:36:33 --> Security Class Initialized
DEBUG - 2018-04-08 21:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:36:33 --> Input Class Initialized
INFO - 2018-04-08 21:36:33 --> Language Class Initialized
INFO - 2018-04-08 21:36:33 --> Loader Class Initialized
INFO - 2018-04-08 21:36:33 --> Helper loaded: url_helper
INFO - 2018-04-08 21:36:33 --> Helper loaded: file_helper
INFO - 2018-04-08 21:36:33 --> Helper loaded: date_helper
INFO - 2018-04-08 21:36:33 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:36:33 --> Controller Class Initialized
INFO - 2018-04-08 21:36:33 --> Config Class Initialized
INFO - 2018-04-08 21:36:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:36:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:36:33 --> Utf8 Class Initialized
INFO - 2018-04-08 21:36:33 --> URI Class Initialized
INFO - 2018-04-08 21:36:33 --> Router Class Initialized
INFO - 2018-04-08 21:36:33 --> Output Class Initialized
INFO - 2018-04-08 21:36:33 --> Security Class Initialized
DEBUG - 2018-04-08 21:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:36:34 --> Input Class Initialized
INFO - 2018-04-08 21:36:34 --> Language Class Initialized
INFO - 2018-04-08 21:36:34 --> Loader Class Initialized
INFO - 2018-04-08 21:36:34 --> Helper loaded: url_helper
INFO - 2018-04-08 21:36:34 --> Helper loaded: file_helper
INFO - 2018-04-08 21:36:34 --> Helper loaded: date_helper
INFO - 2018-04-08 21:36:34 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:36:34 --> Controller Class Initialized
INFO - 2018-04-08 21:36:34 --> Model Class Initialized
INFO - 2018-04-08 21:36:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:36:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:36:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:36:34 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:36:34 --> Final output sent to browser
DEBUG - 2018-04-08 21:36:34 --> Total execution time: 0.3463
INFO - 2018-04-08 21:36:36 --> Config Class Initialized
INFO - 2018-04-08 21:36:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:36:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:36:36 --> Utf8 Class Initialized
INFO - 2018-04-08 21:36:36 --> URI Class Initialized
INFO - 2018-04-08 21:36:36 --> Router Class Initialized
INFO - 2018-04-08 21:36:36 --> Output Class Initialized
INFO - 2018-04-08 21:36:36 --> Security Class Initialized
DEBUG - 2018-04-08 21:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:36:36 --> Input Class Initialized
INFO - 2018-04-08 21:36:36 --> Language Class Initialized
INFO - 2018-04-08 21:36:36 --> Loader Class Initialized
INFO - 2018-04-08 21:36:36 --> Helper loaded: url_helper
INFO - 2018-04-08 21:36:36 --> Helper loaded: file_helper
INFO - 2018-04-08 21:36:36 --> Helper loaded: date_helper
INFO - 2018-04-08 21:36:36 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:36:36 --> Controller Class Initialized
INFO - 2018-04-08 21:36:36 --> Model Class Initialized
INFO - 2018-04-08 21:36:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:36:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/show.php
INFO - 2018-04-08 21:36:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:36:36 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:36:36 --> Final output sent to browser
DEBUG - 2018-04-08 21:36:36 --> Total execution time: 0.3626
INFO - 2018-04-08 21:54:29 --> Config Class Initialized
INFO - 2018-04-08 21:54:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:54:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:54:29 --> Utf8 Class Initialized
INFO - 2018-04-08 21:54:30 --> URI Class Initialized
INFO - 2018-04-08 21:54:30 --> Router Class Initialized
INFO - 2018-04-08 21:54:30 --> Output Class Initialized
INFO - 2018-04-08 21:54:30 --> Security Class Initialized
DEBUG - 2018-04-08 21:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:54:30 --> Input Class Initialized
INFO - 2018-04-08 21:54:30 --> Language Class Initialized
INFO - 2018-04-08 21:54:30 --> Loader Class Initialized
INFO - 2018-04-08 21:54:30 --> Helper loaded: url_helper
INFO - 2018-04-08 21:54:30 --> Helper loaded: file_helper
INFO - 2018-04-08 21:54:30 --> Helper loaded: date_helper
INFO - 2018-04-08 21:54:30 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:54:30 --> Controller Class Initialized
DEBUG - 2018-04-08 21:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:54:30 --> Config Class Initialized
INFO - 2018-04-08 21:54:30 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:54:30 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:54:30 --> Utf8 Class Initialized
INFO - 2018-04-08 21:54:30 --> URI Class Initialized
INFO - 2018-04-08 21:54:30 --> Router Class Initialized
INFO - 2018-04-08 21:54:30 --> Output Class Initialized
INFO - 2018-04-08 21:54:30 --> Security Class Initialized
DEBUG - 2018-04-08 21:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:54:30 --> Input Class Initialized
INFO - 2018-04-08 21:54:30 --> Language Class Initialized
INFO - 2018-04-08 21:54:30 --> Loader Class Initialized
INFO - 2018-04-08 21:54:30 --> Helper loaded: url_helper
INFO - 2018-04-08 21:54:30 --> Helper loaded: file_helper
INFO - 2018-04-08 21:54:30 --> Helper loaded: date_helper
INFO - 2018-04-08 21:54:30 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:54:30 --> Controller Class Initialized
INFO - 2018-04-08 21:54:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 21:54:30 --> Final output sent to browser
DEBUG - 2018-04-08 21:54:30 --> Total execution time: 0.2884
INFO - 2018-04-08 21:54:38 --> Config Class Initialized
INFO - 2018-04-08 21:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:54:38 --> Utf8 Class Initialized
INFO - 2018-04-08 21:54:38 --> URI Class Initialized
INFO - 2018-04-08 21:54:38 --> Router Class Initialized
INFO - 2018-04-08 21:54:38 --> Output Class Initialized
INFO - 2018-04-08 21:54:38 --> Security Class Initialized
DEBUG - 2018-04-08 21:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:54:38 --> Input Class Initialized
INFO - 2018-04-08 21:54:38 --> Language Class Initialized
INFO - 2018-04-08 21:54:38 --> Loader Class Initialized
INFO - 2018-04-08 21:54:38 --> Helper loaded: url_helper
INFO - 2018-04-08 21:54:38 --> Helper loaded: file_helper
INFO - 2018-04-08 21:54:38 --> Helper loaded: date_helper
INFO - 2018-04-08 21:54:38 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:54:38 --> Controller Class Initialized
INFO - 2018-04-08 21:54:38 --> Model Class Initialized
INFO - 2018-04-08 21:54:38 --> Final output sent to browser
DEBUG - 2018-04-08 21:54:38 --> Total execution time: 0.3056
INFO - 2018-04-08 21:54:38 --> Config Class Initialized
INFO - 2018-04-08 21:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:54:38 --> Utf8 Class Initialized
INFO - 2018-04-08 21:54:38 --> URI Class Initialized
INFO - 2018-04-08 21:54:38 --> Router Class Initialized
INFO - 2018-04-08 21:54:38 --> Output Class Initialized
INFO - 2018-04-08 21:54:38 --> Security Class Initialized
DEBUG - 2018-04-08 21:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:54:38 --> Input Class Initialized
INFO - 2018-04-08 21:54:38 --> Language Class Initialized
ERROR - 2018-04-08 21:54:38 --> 404 Page Not Found: Register_Controller/index
INFO - 2018-04-08 21:55:19 --> Config Class Initialized
INFO - 2018-04-08 21:55:19 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:55:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:55:19 --> Utf8 Class Initialized
INFO - 2018-04-08 21:55:19 --> URI Class Initialized
INFO - 2018-04-08 21:55:20 --> Router Class Initialized
INFO - 2018-04-08 21:55:20 --> Output Class Initialized
INFO - 2018-04-08 21:55:20 --> Security Class Initialized
DEBUG - 2018-04-08 21:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:55:20 --> Input Class Initialized
INFO - 2018-04-08 21:55:20 --> Language Class Initialized
INFO - 2018-04-08 21:55:20 --> Loader Class Initialized
INFO - 2018-04-08 21:55:20 --> Helper loaded: url_helper
INFO - 2018-04-08 21:55:20 --> Helper loaded: file_helper
INFO - 2018-04-08 21:55:20 --> Helper loaded: date_helper
INFO - 2018-04-08 21:55:20 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:55:20 --> Controller Class Initialized
INFO - 2018-04-08 21:55:20 --> Config Class Initialized
INFO - 2018-04-08 21:55:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:55:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:55:20 --> Utf8 Class Initialized
INFO - 2018-04-08 21:55:20 --> URI Class Initialized
INFO - 2018-04-08 21:55:20 --> Router Class Initialized
INFO - 2018-04-08 21:55:20 --> Output Class Initialized
INFO - 2018-04-08 21:55:20 --> Security Class Initialized
DEBUG - 2018-04-08 21:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:55:20 --> Input Class Initialized
INFO - 2018-04-08 21:55:20 --> Language Class Initialized
INFO - 2018-04-08 21:55:20 --> Loader Class Initialized
INFO - 2018-04-08 21:55:20 --> Helper loaded: url_helper
INFO - 2018-04-08 21:55:20 --> Helper loaded: file_helper
INFO - 2018-04-08 21:55:20 --> Helper loaded: date_helper
INFO - 2018-04-08 21:55:20 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:55:20 --> Controller Class Initialized
INFO - 2018-04-08 21:55:20 --> Model Class Initialized
INFO - 2018-04-08 21:55:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:55:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:55:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:55:20 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:55:20 --> Final output sent to browser
DEBUG - 2018-04-08 21:55:20 --> Total execution time: 0.3489
INFO - 2018-04-08 21:55:24 --> Config Class Initialized
INFO - 2018-04-08 21:55:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:55:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:55:24 --> Utf8 Class Initialized
INFO - 2018-04-08 21:55:24 --> URI Class Initialized
INFO - 2018-04-08 21:55:24 --> Router Class Initialized
INFO - 2018-04-08 21:55:24 --> Output Class Initialized
INFO - 2018-04-08 21:55:24 --> Security Class Initialized
DEBUG - 2018-04-08 21:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:55:24 --> Input Class Initialized
INFO - 2018-04-08 21:55:24 --> Language Class Initialized
INFO - 2018-04-08 21:55:24 --> Loader Class Initialized
INFO - 2018-04-08 21:55:24 --> Helper loaded: url_helper
INFO - 2018-04-08 21:55:24 --> Helper loaded: file_helper
INFO - 2018-04-08 21:55:24 --> Helper loaded: date_helper
INFO - 2018-04-08 21:55:24 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:55:24 --> Controller Class Initialized
DEBUG - 2018-04-08 21:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:55:24 --> Config Class Initialized
INFO - 2018-04-08 21:55:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:55:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:55:24 --> Utf8 Class Initialized
INFO - 2018-04-08 21:55:24 --> URI Class Initialized
INFO - 2018-04-08 21:55:24 --> Router Class Initialized
INFO - 2018-04-08 21:55:24 --> Output Class Initialized
INFO - 2018-04-08 21:55:24 --> Security Class Initialized
DEBUG - 2018-04-08 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:55:25 --> Input Class Initialized
INFO - 2018-04-08 21:55:25 --> Language Class Initialized
INFO - 2018-04-08 21:55:25 --> Loader Class Initialized
INFO - 2018-04-08 21:55:25 --> Helper loaded: url_helper
INFO - 2018-04-08 21:55:25 --> Helper loaded: file_helper
INFO - 2018-04-08 21:55:25 --> Helper loaded: date_helper
INFO - 2018-04-08 21:55:25 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:55:25 --> Controller Class Initialized
INFO - 2018-04-08 21:55:25 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 21:55:25 --> Final output sent to browser
DEBUG - 2018-04-08 21:55:25 --> Total execution time: 0.2932
INFO - 2018-04-08 21:55:31 --> Config Class Initialized
INFO - 2018-04-08 21:55:31 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:55:31 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:55:31 --> Utf8 Class Initialized
INFO - 2018-04-08 21:55:31 --> URI Class Initialized
INFO - 2018-04-08 21:55:31 --> Router Class Initialized
INFO - 2018-04-08 21:55:31 --> Output Class Initialized
INFO - 2018-04-08 21:55:31 --> Security Class Initialized
DEBUG - 2018-04-08 21:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:55:31 --> Input Class Initialized
INFO - 2018-04-08 21:55:31 --> Language Class Initialized
INFO - 2018-04-08 21:55:31 --> Loader Class Initialized
INFO - 2018-04-08 21:55:31 --> Helper loaded: url_helper
INFO - 2018-04-08 21:55:31 --> Helper loaded: file_helper
INFO - 2018-04-08 21:55:31 --> Helper loaded: date_helper
INFO - 2018-04-08 21:55:31 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:55:31 --> Controller Class Initialized
INFO - 2018-04-08 21:55:31 --> Model Class Initialized
INFO - 2018-04-08 21:55:31 --> Final output sent to browser
DEBUG - 2018-04-08 21:55:31 --> Total execution time: 0.2977
INFO - 2018-04-08 21:55:31 --> Config Class Initialized
INFO - 2018-04-08 21:55:31 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:55:31 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:55:31 --> Utf8 Class Initialized
INFO - 2018-04-08 21:55:31 --> URI Class Initialized
INFO - 2018-04-08 21:55:31 --> Router Class Initialized
INFO - 2018-04-08 21:55:31 --> Output Class Initialized
INFO - 2018-04-08 21:55:31 --> Security Class Initialized
DEBUG - 2018-04-08 21:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:55:31 --> Input Class Initialized
INFO - 2018-04-08 21:55:31 --> Language Class Initialized
INFO - 2018-04-08 21:55:31 --> Loader Class Initialized
INFO - 2018-04-08 21:55:31 --> Helper loaded: url_helper
INFO - 2018-04-08 21:55:31 --> Helper loaded: file_helper
INFO - 2018-04-08 21:55:31 --> Helper loaded: date_helper
INFO - 2018-04-08 21:55:31 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:55:31 --> Controller Class Initialized
INFO - 2018-04-08 21:55:31 --> Model Class Initialized
INFO - 2018-04-08 21:55:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:55:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:55:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:55:32 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:55:32 --> Final output sent to browser
DEBUG - 2018-04-08 21:55:32 --> Total execution time: 0.3451
INFO - 2018-04-08 21:56:33 --> Config Class Initialized
INFO - 2018-04-08 21:56:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:56:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:56:33 --> Utf8 Class Initialized
INFO - 2018-04-08 21:56:33 --> URI Class Initialized
INFO - 2018-04-08 21:56:33 --> Router Class Initialized
INFO - 2018-04-08 21:56:33 --> Output Class Initialized
INFO - 2018-04-08 21:56:33 --> Security Class Initialized
DEBUG - 2018-04-08 21:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:56:33 --> Input Class Initialized
INFO - 2018-04-08 21:56:33 --> Language Class Initialized
INFO - 2018-04-08 21:56:33 --> Loader Class Initialized
INFO - 2018-04-08 21:56:33 --> Helper loaded: url_helper
INFO - 2018-04-08 21:56:33 --> Helper loaded: file_helper
INFO - 2018-04-08 21:56:33 --> Helper loaded: date_helper
INFO - 2018-04-08 21:56:33 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:56:33 --> Controller Class Initialized
INFO - 2018-04-08 21:57:17 --> Config Class Initialized
INFO - 2018-04-08 21:57:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:57:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:57:17 --> Utf8 Class Initialized
INFO - 2018-04-08 21:57:17 --> URI Class Initialized
INFO - 2018-04-08 21:57:17 --> Router Class Initialized
INFO - 2018-04-08 21:57:17 --> Output Class Initialized
INFO - 2018-04-08 21:57:17 --> Security Class Initialized
DEBUG - 2018-04-08 21:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:57:17 --> Input Class Initialized
INFO - 2018-04-08 21:57:17 --> Language Class Initialized
INFO - 2018-04-08 21:57:17 --> Loader Class Initialized
INFO - 2018-04-08 21:57:17 --> Helper loaded: url_helper
INFO - 2018-04-08 21:57:17 --> Helper loaded: file_helper
INFO - 2018-04-08 21:57:17 --> Helper loaded: date_helper
INFO - 2018-04-08 21:57:18 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:57:18 --> Controller Class Initialized
INFO - 2018-04-08 21:57:20 --> Config Class Initialized
INFO - 2018-04-08 21:57:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:57:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:57:20 --> Utf8 Class Initialized
INFO - 2018-04-08 21:57:20 --> URI Class Initialized
INFO - 2018-04-08 21:57:20 --> Router Class Initialized
INFO - 2018-04-08 21:57:20 --> Output Class Initialized
INFO - 2018-04-08 21:57:20 --> Security Class Initialized
DEBUG - 2018-04-08 21:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:57:20 --> Input Class Initialized
INFO - 2018-04-08 21:57:20 --> Language Class Initialized
INFO - 2018-04-08 21:57:20 --> Loader Class Initialized
INFO - 2018-04-08 21:57:20 --> Helper loaded: url_helper
INFO - 2018-04-08 21:57:20 --> Helper loaded: file_helper
INFO - 2018-04-08 21:57:20 --> Helper loaded: date_helper
INFO - 2018-04-08 21:57:20 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:57:20 --> Controller Class Initialized
INFO - 2018-04-08 21:57:24 --> Config Class Initialized
INFO - 2018-04-08 21:57:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:57:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:57:24 --> Utf8 Class Initialized
INFO - 2018-04-08 21:57:24 --> URI Class Initialized
INFO - 2018-04-08 21:57:24 --> Router Class Initialized
INFO - 2018-04-08 21:57:24 --> Output Class Initialized
INFO - 2018-04-08 21:57:24 --> Security Class Initialized
DEBUG - 2018-04-08 21:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:57:24 --> Input Class Initialized
INFO - 2018-04-08 21:57:24 --> Language Class Initialized
INFO - 2018-04-08 21:57:24 --> Loader Class Initialized
INFO - 2018-04-08 21:57:24 --> Helper loaded: url_helper
INFO - 2018-04-08 21:57:24 --> Helper loaded: file_helper
INFO - 2018-04-08 21:57:24 --> Helper loaded: date_helper
INFO - 2018-04-08 21:57:24 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:57:24 --> Controller Class Initialized
INFO - 2018-04-08 21:57:24 --> Model Class Initialized
INFO - 2018-04-08 21:57:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:57:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:57:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:57:24 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:57:24 --> Final output sent to browser
DEBUG - 2018-04-08 21:57:24 --> Total execution time: 0.3695
INFO - 2018-04-08 21:57:25 --> Config Class Initialized
INFO - 2018-04-08 21:57:25 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:57:25 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:57:25 --> Utf8 Class Initialized
INFO - 2018-04-08 21:57:25 --> URI Class Initialized
INFO - 2018-04-08 21:57:25 --> Router Class Initialized
INFO - 2018-04-08 21:57:25 --> Output Class Initialized
INFO - 2018-04-08 21:57:25 --> Security Class Initialized
DEBUG - 2018-04-08 21:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:57:25 --> Input Class Initialized
INFO - 2018-04-08 21:57:25 --> Language Class Initialized
INFO - 2018-04-08 21:57:25 --> Loader Class Initialized
INFO - 2018-04-08 21:57:25 --> Helper loaded: url_helper
INFO - 2018-04-08 21:57:25 --> Helper loaded: file_helper
INFO - 2018-04-08 21:57:25 --> Helper loaded: date_helper
INFO - 2018-04-08 21:57:26 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:57:26 --> Controller Class Initialized
INFO - 2018-04-08 21:57:26 --> Config Class Initialized
INFO - 2018-04-08 21:57:26 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:57:26 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:57:26 --> Utf8 Class Initialized
INFO - 2018-04-08 21:57:26 --> URI Class Initialized
INFO - 2018-04-08 21:57:26 --> Router Class Initialized
INFO - 2018-04-08 21:57:26 --> Output Class Initialized
INFO - 2018-04-08 21:57:26 --> Security Class Initialized
DEBUG - 2018-04-08 21:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:57:26 --> Input Class Initialized
INFO - 2018-04-08 21:57:26 --> Language Class Initialized
INFO - 2018-04-08 21:57:26 --> Loader Class Initialized
INFO - 2018-04-08 21:57:26 --> Helper loaded: url_helper
INFO - 2018-04-08 21:57:26 --> Helper loaded: file_helper
INFO - 2018-04-08 21:57:26 --> Helper loaded: date_helper
INFO - 2018-04-08 21:57:26 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:57:26 --> Controller Class Initialized
INFO - 2018-04-08 21:57:26 --> Model Class Initialized
INFO - 2018-04-08 21:57:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 21:57:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 21:57:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 21:57:26 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 21:57:26 --> Final output sent to browser
DEBUG - 2018-04-08 21:57:26 --> Total execution time: 0.3671
INFO - 2018-04-08 21:57:29 --> Config Class Initialized
INFO - 2018-04-08 21:57:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:57:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:57:29 --> Utf8 Class Initialized
INFO - 2018-04-08 21:57:29 --> URI Class Initialized
INFO - 2018-04-08 21:57:29 --> Router Class Initialized
INFO - 2018-04-08 21:57:29 --> Output Class Initialized
INFO - 2018-04-08 21:57:29 --> Security Class Initialized
DEBUG - 2018-04-08 21:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:57:29 --> Input Class Initialized
INFO - 2018-04-08 21:57:29 --> Language Class Initialized
INFO - 2018-04-08 21:57:29 --> Loader Class Initialized
INFO - 2018-04-08 21:57:29 --> Helper loaded: url_helper
INFO - 2018-04-08 21:57:29 --> Helper loaded: file_helper
INFO - 2018-04-08 21:57:29 --> Helper loaded: date_helper
INFO - 2018-04-08 21:57:29 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:57:29 --> Controller Class Initialized
DEBUG - 2018-04-08 21:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:57:29 --> Config Class Initialized
INFO - 2018-04-08 21:57:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:57:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:57:29 --> Utf8 Class Initialized
INFO - 2018-04-08 21:57:29 --> URI Class Initialized
INFO - 2018-04-08 21:57:29 --> Router Class Initialized
INFO - 2018-04-08 21:57:29 --> Output Class Initialized
INFO - 2018-04-08 21:57:29 --> Security Class Initialized
DEBUG - 2018-04-08 21:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:57:30 --> Input Class Initialized
INFO - 2018-04-08 21:57:30 --> Language Class Initialized
INFO - 2018-04-08 21:57:30 --> Loader Class Initialized
INFO - 2018-04-08 21:57:30 --> Helper loaded: url_helper
INFO - 2018-04-08 21:57:30 --> Helper loaded: file_helper
INFO - 2018-04-08 21:57:30 --> Helper loaded: date_helper
INFO - 2018-04-08 21:57:30 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:57:30 --> Controller Class Initialized
INFO - 2018-04-08 21:57:30 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 21:57:30 --> Final output sent to browser
DEBUG - 2018-04-08 21:57:30 --> Total execution time: 0.3018
INFO - 2018-04-08 21:57:32 --> Config Class Initialized
INFO - 2018-04-08 21:57:32 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:57:32 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:57:32 --> Utf8 Class Initialized
INFO - 2018-04-08 21:57:32 --> URI Class Initialized
INFO - 2018-04-08 21:57:32 --> Router Class Initialized
INFO - 2018-04-08 21:57:32 --> Output Class Initialized
INFO - 2018-04-08 21:57:32 --> Security Class Initialized
DEBUG - 2018-04-08 21:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:57:32 --> Input Class Initialized
INFO - 2018-04-08 21:57:32 --> Language Class Initialized
INFO - 2018-04-08 21:57:32 --> Loader Class Initialized
INFO - 2018-04-08 21:57:32 --> Helper loaded: url_helper
INFO - 2018-04-08 21:57:32 --> Helper loaded: file_helper
INFO - 2018-04-08 21:57:32 --> Helper loaded: date_helper
INFO - 2018-04-08 21:57:32 --> Database Driver Class Initialized
DEBUG - 2018-04-08 21:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 21:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:57:32 --> Controller Class Initialized
INFO - 2018-04-08 22:11:32 --> Config Class Initialized
INFO - 2018-04-08 22:11:32 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:11:32 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:11:32 --> Utf8 Class Initialized
INFO - 2018-04-08 22:11:32 --> URI Class Initialized
DEBUG - 2018-04-08 22:11:32 --> No URI present. Default controller set.
INFO - 2018-04-08 22:11:32 --> Router Class Initialized
INFO - 2018-04-08 22:11:32 --> Output Class Initialized
INFO - 2018-04-08 22:11:32 --> Security Class Initialized
DEBUG - 2018-04-08 22:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:11:32 --> Input Class Initialized
INFO - 2018-04-08 22:11:32 --> Language Class Initialized
INFO - 2018-04-08 22:11:32 --> Loader Class Initialized
INFO - 2018-04-08 22:11:32 --> Helper loaded: url_helper
INFO - 2018-04-08 22:11:32 --> Helper loaded: file_helper
INFO - 2018-04-08 22:11:32 --> Helper loaded: date_helper
INFO - 2018-04-08 22:11:32 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:11:32 --> Controller Class Initialized
INFO - 2018-04-08 22:11:32 --> Config Class Initialized
INFO - 2018-04-08 22:11:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:11:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:11:33 --> Utf8 Class Initialized
INFO - 2018-04-08 22:11:33 --> URI Class Initialized
INFO - 2018-04-08 22:11:33 --> Router Class Initialized
INFO - 2018-04-08 22:11:33 --> Output Class Initialized
INFO - 2018-04-08 22:11:33 --> Security Class Initialized
DEBUG - 2018-04-08 22:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:11:33 --> Input Class Initialized
INFO - 2018-04-08 22:11:33 --> Language Class Initialized
INFO - 2018-04-08 22:11:33 --> Loader Class Initialized
INFO - 2018-04-08 22:11:33 --> Helper loaded: url_helper
INFO - 2018-04-08 22:11:33 --> Helper loaded: file_helper
INFO - 2018-04-08 22:11:33 --> Helper loaded: date_helper
INFO - 2018-04-08 22:11:33 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:11:33 --> Controller Class Initialized
INFO - 2018-04-08 22:11:33 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 22:11:33 --> Final output sent to browser
DEBUG - 2018-04-08 22:11:33 --> Total execution time: 0.3548
INFO - 2018-04-08 22:11:48 --> Config Class Initialized
INFO - 2018-04-08 22:11:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:11:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:11:48 --> Utf8 Class Initialized
INFO - 2018-04-08 22:11:48 --> URI Class Initialized
INFO - 2018-04-08 22:11:48 --> Router Class Initialized
INFO - 2018-04-08 22:11:48 --> Output Class Initialized
INFO - 2018-04-08 22:11:48 --> Security Class Initialized
DEBUG - 2018-04-08 22:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:11:48 --> Input Class Initialized
INFO - 2018-04-08 22:11:48 --> Language Class Initialized
INFO - 2018-04-08 22:11:48 --> Loader Class Initialized
INFO - 2018-04-08 22:11:49 --> Helper loaded: url_helper
INFO - 2018-04-08 22:11:49 --> Helper loaded: file_helper
INFO - 2018-04-08 22:11:49 --> Helper loaded: date_helper
INFO - 2018-04-08 22:11:49 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:11:49 --> Controller Class Initialized
INFO - 2018-04-08 22:11:49 --> Model Class Initialized
INFO - 2018-04-08 22:11:49 --> Final output sent to browser
DEBUG - 2018-04-08 22:11:49 --> Total execution time: 0.3744
INFO - 2018-04-08 22:11:49 --> Config Class Initialized
INFO - 2018-04-08 22:11:49 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:11:49 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:11:49 --> Utf8 Class Initialized
INFO - 2018-04-08 22:11:49 --> URI Class Initialized
INFO - 2018-04-08 22:11:49 --> Router Class Initialized
INFO - 2018-04-08 22:11:49 --> Output Class Initialized
INFO - 2018-04-08 22:11:49 --> Security Class Initialized
DEBUG - 2018-04-08 22:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:11:49 --> Input Class Initialized
INFO - 2018-04-08 22:11:49 --> Language Class Initialized
INFO - 2018-04-08 22:11:49 --> Loader Class Initialized
INFO - 2018-04-08 22:11:49 --> Helper loaded: url_helper
INFO - 2018-04-08 22:11:49 --> Helper loaded: file_helper
INFO - 2018-04-08 22:11:49 --> Helper loaded: date_helper
INFO - 2018-04-08 22:11:49 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:11:49 --> Controller Class Initialized
INFO - 2018-04-08 22:11:49 --> Model Class Initialized
INFO - 2018-04-08 22:11:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 22:11:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 22:11:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 22:11:49 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 22:11:49 --> Final output sent to browser
DEBUG - 2018-04-08 22:11:49 --> Total execution time: 0.4418
INFO - 2018-04-08 22:11:55 --> Config Class Initialized
INFO - 2018-04-08 22:11:55 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:11:55 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:11:55 --> Utf8 Class Initialized
INFO - 2018-04-08 22:11:55 --> URI Class Initialized
INFO - 2018-04-08 22:11:55 --> Router Class Initialized
INFO - 2018-04-08 22:11:55 --> Output Class Initialized
INFO - 2018-04-08 22:11:55 --> Security Class Initialized
DEBUG - 2018-04-08 22:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:11:55 --> Input Class Initialized
INFO - 2018-04-08 22:11:55 --> Language Class Initialized
INFO - 2018-04-08 22:11:55 --> Loader Class Initialized
INFO - 2018-04-08 22:11:55 --> Helper loaded: url_helper
INFO - 2018-04-08 22:11:55 --> Helper loaded: file_helper
INFO - 2018-04-08 22:11:55 --> Helper loaded: date_helper
INFO - 2018-04-08 22:11:55 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:11:55 --> Controller Class Initialized
INFO - 2018-04-08 22:11:55 --> Config Class Initialized
INFO - 2018-04-08 22:11:55 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:11:55 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:11:55 --> Utf8 Class Initialized
INFO - 2018-04-08 22:11:55 --> URI Class Initialized
INFO - 2018-04-08 22:11:55 --> Router Class Initialized
INFO - 2018-04-08 22:11:55 --> Output Class Initialized
INFO - 2018-04-08 22:11:55 --> Security Class Initialized
DEBUG - 2018-04-08 22:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:11:55 --> Input Class Initialized
INFO - 2018-04-08 22:11:55 --> Language Class Initialized
INFO - 2018-04-08 22:11:55 --> Loader Class Initialized
INFO - 2018-04-08 22:11:55 --> Helper loaded: url_helper
INFO - 2018-04-08 22:11:55 --> Helper loaded: file_helper
INFO - 2018-04-08 22:11:55 --> Helper loaded: date_helper
INFO - 2018-04-08 22:11:55 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:11:55 --> Controller Class Initialized
INFO - 2018-04-08 22:11:55 --> Model Class Initialized
INFO - 2018-04-08 22:11:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/header.php
INFO - 2018-04-08 22:11:55 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/user.php
INFO - 2018-04-08 22:11:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/footer.php
INFO - 2018-04-08 22:11:56 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\layout_student/index.php
INFO - 2018-04-08 22:11:56 --> Final output sent to browser
DEBUG - 2018-04-08 22:11:56 --> Total execution time: 0.4655
INFO - 2018-04-08 22:11:59 --> Config Class Initialized
INFO - 2018-04-08 22:11:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:11:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:11:59 --> Utf8 Class Initialized
INFO - 2018-04-08 22:11:59 --> URI Class Initialized
INFO - 2018-04-08 22:11:59 --> Router Class Initialized
INFO - 2018-04-08 22:11:59 --> Output Class Initialized
INFO - 2018-04-08 22:11:59 --> Security Class Initialized
DEBUG - 2018-04-08 22:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:11:59 --> Input Class Initialized
INFO - 2018-04-08 22:11:59 --> Language Class Initialized
INFO - 2018-04-08 22:11:59 --> Loader Class Initialized
INFO - 2018-04-08 22:11:59 --> Helper loaded: url_helper
INFO - 2018-04-08 22:11:59 --> Helper loaded: file_helper
INFO - 2018-04-08 22:11:59 --> Helper loaded: date_helper
INFO - 2018-04-08 22:11:59 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:11:59 --> Controller Class Initialized
DEBUG - 2018-04-08 22:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 22:11:59 --> Config Class Initialized
INFO - 2018-04-08 22:11:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:11:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:11:59 --> Utf8 Class Initialized
INFO - 2018-04-08 22:11:59 --> URI Class Initialized
INFO - 2018-04-08 22:11:59 --> Router Class Initialized
INFO - 2018-04-08 22:11:59 --> Output Class Initialized
INFO - 2018-04-08 22:11:59 --> Security Class Initialized
DEBUG - 2018-04-08 22:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:11:59 --> Input Class Initialized
INFO - 2018-04-08 22:11:59 --> Language Class Initialized
INFO - 2018-04-08 22:11:59 --> Loader Class Initialized
INFO - 2018-04-08 22:11:59 --> Helper loaded: url_helper
INFO - 2018-04-08 22:11:59 --> Helper loaded: file_helper
INFO - 2018-04-08 22:12:00 --> Helper loaded: date_helper
INFO - 2018-04-08 22:12:00 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:12:00 --> Controller Class Initialized
INFO - 2018-04-08 22:12:00 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 22:12:00 --> Final output sent to browser
DEBUG - 2018-04-08 22:12:00 --> Total execution time: 0.4129
INFO - 2018-04-08 22:12:01 --> Config Class Initialized
INFO - 2018-04-08 22:12:01 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:12:02 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:12:02 --> Utf8 Class Initialized
INFO - 2018-04-08 22:12:02 --> URI Class Initialized
INFO - 2018-04-08 22:12:02 --> Router Class Initialized
INFO - 2018-04-08 22:12:02 --> Output Class Initialized
INFO - 2018-04-08 22:12:02 --> Security Class Initialized
DEBUG - 2018-04-08 22:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:12:02 --> Input Class Initialized
INFO - 2018-04-08 22:12:02 --> Language Class Initialized
INFO - 2018-04-08 22:12:02 --> Loader Class Initialized
INFO - 2018-04-08 22:12:02 --> Helper loaded: url_helper
INFO - 2018-04-08 22:12:02 --> Helper loaded: file_helper
INFO - 2018-04-08 22:12:02 --> Helper loaded: date_helper
INFO - 2018-04-08 22:12:02 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:12:02 --> Controller Class Initialized
INFO - 2018-04-08 22:12:04 --> Config Class Initialized
INFO - 2018-04-08 22:12:04 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:12:04 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:12:04 --> Utf8 Class Initialized
INFO - 2018-04-08 22:12:04 --> URI Class Initialized
INFO - 2018-04-08 22:12:04 --> Router Class Initialized
INFO - 2018-04-08 22:12:04 --> Output Class Initialized
INFO - 2018-04-08 22:12:04 --> Security Class Initialized
DEBUG - 2018-04-08 22:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:12:04 --> Input Class Initialized
INFO - 2018-04-08 22:12:04 --> Language Class Initialized
INFO - 2018-04-08 22:12:04 --> Loader Class Initialized
INFO - 2018-04-08 22:12:04 --> Helper loaded: url_helper
INFO - 2018-04-08 22:12:04 --> Helper loaded: file_helper
INFO - 2018-04-08 22:12:04 --> Helper loaded: date_helper
INFO - 2018-04-08 22:12:04 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:12:04 --> Controller Class Initialized
INFO - 2018-04-08 22:12:04 --> File loaded: G:\xampp\htdocs\codeigniter\application\views\user/login.php
INFO - 2018-04-08 22:12:04 --> Final output sent to browser
DEBUG - 2018-04-08 22:12:04 --> Total execution time: 0.4989
INFO - 2018-04-08 22:13:21 --> Config Class Initialized
INFO - 2018-04-08 22:13:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:13:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:13:21 --> Utf8 Class Initialized
INFO - 2018-04-08 22:13:21 --> URI Class Initialized
INFO - 2018-04-08 22:13:21 --> Router Class Initialized
INFO - 2018-04-08 22:13:21 --> Output Class Initialized
INFO - 2018-04-08 22:13:21 --> Security Class Initialized
DEBUG - 2018-04-08 22:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:13:21 --> Input Class Initialized
INFO - 2018-04-08 22:13:21 --> Language Class Initialized
INFO - 2018-04-08 22:13:21 --> Loader Class Initialized
INFO - 2018-04-08 22:13:21 --> Helper loaded: url_helper
INFO - 2018-04-08 22:13:21 --> Helper loaded: file_helper
INFO - 2018-04-08 22:13:21 --> Helper loaded: date_helper
INFO - 2018-04-08 22:13:21 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:13:21 --> Controller Class Initialized
INFO - 2018-04-08 22:13:21 --> Model Class Initialized
INFO - 2018-04-08 22:13:21 --> Final output sent to browser
DEBUG - 2018-04-08 22:13:21 --> Total execution time: 0.3418
INFO - 2018-04-08 22:13:21 --> Config Class Initialized
INFO - 2018-04-08 22:13:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:13:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:13:21 --> Utf8 Class Initialized
INFO - 2018-04-08 22:13:21 --> URI Class Initialized
INFO - 2018-04-08 22:13:21 --> Router Class Initialized
INFO - 2018-04-08 22:13:21 --> Output Class Initialized
INFO - 2018-04-08 22:13:21 --> Security Class Initialized
DEBUG - 2018-04-08 22:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:13:21 --> Input Class Initialized
INFO - 2018-04-08 22:13:21 --> Language Class Initialized
ERROR - 2018-04-08 22:13:21 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 55
INFO - 2018-04-08 22:13:51 --> Config Class Initialized
INFO - 2018-04-08 22:13:51 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:13:51 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:13:51 --> Utf8 Class Initialized
INFO - 2018-04-08 22:13:51 --> URI Class Initialized
INFO - 2018-04-08 22:13:51 --> Router Class Initialized
INFO - 2018-04-08 22:13:51 --> Output Class Initialized
INFO - 2018-04-08 22:13:51 --> Security Class Initialized
DEBUG - 2018-04-08 22:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:13:51 --> Input Class Initialized
INFO - 2018-04-08 22:13:51 --> Language Class Initialized
ERROR - 2018-04-08 22:13:51 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 82
INFO - 2018-04-08 22:14:12 --> Config Class Initialized
INFO - 2018-04-08 22:14:12 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:14:12 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:14:12 --> Utf8 Class Initialized
INFO - 2018-04-08 22:14:12 --> URI Class Initialized
INFO - 2018-04-08 22:14:12 --> Router Class Initialized
INFO - 2018-04-08 22:14:12 --> Output Class Initialized
INFO - 2018-04-08 22:14:12 --> Security Class Initialized
DEBUG - 2018-04-08 22:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:14:12 --> Input Class Initialized
INFO - 2018-04-08 22:14:12 --> Language Class Initialized
INFO - 2018-04-08 22:14:12 --> Loader Class Initialized
INFO - 2018-04-08 22:14:12 --> Helper loaded: url_helper
INFO - 2018-04-08 22:14:12 --> Helper loaded: file_helper
INFO - 2018-04-08 22:14:12 --> Helper loaded: date_helper
INFO - 2018-04-08 22:14:12 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:14:12 --> Controller Class Initialized
ERROR - 2018-04-08 22:14:12 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-08 22:18:07 --> Config Class Initialized
INFO - 2018-04-08 22:18:07 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:18:07 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:18:07 --> Utf8 Class Initialized
INFO - 2018-04-08 22:18:07 --> URI Class Initialized
INFO - 2018-04-08 22:18:07 --> Router Class Initialized
INFO - 2018-04-08 22:18:07 --> Output Class Initialized
INFO - 2018-04-08 22:18:07 --> Security Class Initialized
DEBUG - 2018-04-08 22:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:18:07 --> Input Class Initialized
INFO - 2018-04-08 22:18:07 --> Language Class Initialized
INFO - 2018-04-08 22:18:07 --> Loader Class Initialized
INFO - 2018-04-08 22:18:07 --> Helper loaded: url_helper
INFO - 2018-04-08 22:18:07 --> Helper loaded: file_helper
INFO - 2018-04-08 22:18:07 --> Helper loaded: date_helper
INFO - 2018-04-08 22:18:07 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:18:07 --> Controller Class Initialized
ERROR - 2018-04-08 22:18:07 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-08 22:21:17 --> Config Class Initialized
INFO - 2018-04-08 22:21:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:21:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:21:17 --> Utf8 Class Initialized
INFO - 2018-04-08 22:21:17 --> URI Class Initialized
INFO - 2018-04-08 22:21:17 --> Router Class Initialized
INFO - 2018-04-08 22:21:17 --> Output Class Initialized
INFO - 2018-04-08 22:21:17 --> Security Class Initialized
DEBUG - 2018-04-08 22:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:21:17 --> Input Class Initialized
INFO - 2018-04-08 22:21:17 --> Language Class Initialized
INFO - 2018-04-08 22:21:17 --> Loader Class Initialized
INFO - 2018-04-08 22:21:17 --> Helper loaded: url_helper
INFO - 2018-04-08 22:21:17 --> Helper loaded: file_helper
INFO - 2018-04-08 22:21:17 --> Helper loaded: date_helper
INFO - 2018-04-08 22:21:17 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:21:17 --> Controller Class Initialized
ERROR - 2018-04-08 22:21:17 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-08 22:23:05 --> Config Class Initialized
INFO - 2018-04-08 22:23:05 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:23:05 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:23:05 --> Utf8 Class Initialized
INFO - 2018-04-08 22:23:05 --> URI Class Initialized
INFO - 2018-04-08 22:23:05 --> Router Class Initialized
INFO - 2018-04-08 22:23:05 --> Output Class Initialized
INFO - 2018-04-08 22:23:05 --> Security Class Initialized
DEBUG - 2018-04-08 22:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:23:05 --> Input Class Initialized
INFO - 2018-04-08 22:23:05 --> Language Class Initialized
INFO - 2018-04-08 22:23:05 --> Loader Class Initialized
INFO - 2018-04-08 22:23:05 --> Helper loaded: url_helper
INFO - 2018-04-08 22:23:05 --> Helper loaded: file_helper
INFO - 2018-04-08 22:23:05 --> Helper loaded: date_helper
INFO - 2018-04-08 22:23:05 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:23:05 --> Controller Class Initialized
ERROR - 2018-04-08 22:23:05 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-08 22:23:10 --> Config Class Initialized
INFO - 2018-04-08 22:23:10 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:23:10 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:23:10 --> Utf8 Class Initialized
INFO - 2018-04-08 22:23:10 --> URI Class Initialized
INFO - 2018-04-08 22:23:10 --> Router Class Initialized
INFO - 2018-04-08 22:23:10 --> Output Class Initialized
INFO - 2018-04-08 22:23:10 --> Security Class Initialized
DEBUG - 2018-04-08 22:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:23:10 --> Input Class Initialized
INFO - 2018-04-08 22:23:10 --> Language Class Initialized
INFO - 2018-04-08 22:23:10 --> Loader Class Initialized
INFO - 2018-04-08 22:23:10 --> Helper loaded: url_helper
INFO - 2018-04-08 22:23:10 --> Helper loaded: file_helper
INFO - 2018-04-08 22:23:10 --> Helper loaded: date_helper
INFO - 2018-04-08 22:23:10 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:23:10 --> Controller Class Initialized
ERROR - 2018-04-08 22:23:10 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-08 22:23:15 --> Config Class Initialized
INFO - 2018-04-08 22:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:23:15 --> Utf8 Class Initialized
INFO - 2018-04-08 22:23:15 --> URI Class Initialized
INFO - 2018-04-08 22:23:15 --> Router Class Initialized
INFO - 2018-04-08 22:23:15 --> Output Class Initialized
INFO - 2018-04-08 22:23:15 --> Security Class Initialized
DEBUG - 2018-04-08 22:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:23:15 --> Input Class Initialized
INFO - 2018-04-08 22:23:15 --> Language Class Initialized
INFO - 2018-04-08 22:23:15 --> Loader Class Initialized
INFO - 2018-04-08 22:23:15 --> Helper loaded: url_helper
INFO - 2018-04-08 22:23:15 --> Helper loaded: file_helper
INFO - 2018-04-08 22:23:15 --> Helper loaded: date_helper
INFO - 2018-04-08 22:23:15 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:23:15 --> Controller Class Initialized
ERROR - 2018-04-08 22:23:15 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-08 22:23:33 --> Config Class Initialized
INFO - 2018-04-08 22:23:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:23:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:23:33 --> Utf8 Class Initialized
INFO - 2018-04-08 22:23:33 --> URI Class Initialized
INFO - 2018-04-08 22:23:33 --> Router Class Initialized
INFO - 2018-04-08 22:23:33 --> Output Class Initialized
INFO - 2018-04-08 22:23:33 --> Security Class Initialized
DEBUG - 2018-04-08 22:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:23:33 --> Input Class Initialized
INFO - 2018-04-08 22:23:33 --> Language Class Initialized
INFO - 2018-04-08 22:23:33 --> Loader Class Initialized
INFO - 2018-04-08 22:23:33 --> Helper loaded: url_helper
INFO - 2018-04-08 22:23:33 --> Helper loaded: file_helper
INFO - 2018-04-08 22:23:33 --> Helper loaded: date_helper
INFO - 2018-04-08 22:23:33 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:23:33 --> Controller Class Initialized
ERROR - 2018-04-08 22:23:33 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-08 22:24:47 --> Config Class Initialized
INFO - 2018-04-08 22:24:47 --> Hooks Class Initialized
DEBUG - 2018-04-08 22:24:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 22:24:48 --> Utf8 Class Initialized
INFO - 2018-04-08 22:24:48 --> URI Class Initialized
INFO - 2018-04-08 22:24:48 --> Router Class Initialized
INFO - 2018-04-08 22:24:48 --> Output Class Initialized
INFO - 2018-04-08 22:24:48 --> Security Class Initialized
DEBUG - 2018-04-08 22:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 22:24:48 --> Input Class Initialized
INFO - 2018-04-08 22:24:48 --> Language Class Initialized
INFO - 2018-04-08 22:24:48 --> Loader Class Initialized
INFO - 2018-04-08 22:24:48 --> Helper loaded: url_helper
INFO - 2018-04-08 22:24:48 --> Helper loaded: file_helper
INFO - 2018-04-08 22:24:48 --> Helper loaded: date_helper
INFO - 2018-04-08 22:24:48 --> Database Driver Class Initialized
DEBUG - 2018-04-08 22:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-04-08 22:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 22:24:48 --> Controller Class Initialized
ERROR - 2018-04-08 22:24:48 --> Severity: error --> Exception: syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' G:\xampp\htdocs\codeigniter\application\models\Stud_Model.php 37
INFO - 2018-04-08 23:35:54 --> Config Class Initialized
INFO - 2018-04-08 23:35:54 --> Hooks Class Initialized
DEBUG - 2018-04-08 23:35:54 --> UTF-8 Support Enabled
INFO - 2018-04-08 23:35:54 --> Utf8 Class Initialized
INFO - 2018-04-08 23:35:54 --> URI Class Initialized
INFO - 2018-04-08 23:35:54 --> Router Class Initialized
INFO - 2018-04-08 23:35:54 --> Output Class Initialized
INFO - 2018-04-08 23:35:54 --> Security Class Initialized
DEBUG - 2018-04-08 23:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 23:35:54 --> Input Class Initialized
INFO - 2018-04-08 23:35:54 --> Language Class Initialized
ERROR - 2018-04-08 23:35:54 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) G:\xampp\htdocs\codeigniter\application\controllers\Stud_Controller.php 82
