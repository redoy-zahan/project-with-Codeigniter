<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-12-16 08:39:06 --> Config Class Initialized
INFO - 2017-12-16 08:39:06 --> Hooks Class Initialized
DEBUG - 2017-12-16 08:39:06 --> UTF-8 Support Enabled
INFO - 2017-12-16 08:39:06 --> Utf8 Class Initialized
INFO - 2017-12-16 08:39:06 --> URI Class Initialized
DEBUG - 2017-12-16 08:39:06 --> No URI present. Default controller set.
INFO - 2017-12-16 08:39:06 --> Router Class Initialized
INFO - 2017-12-16 08:39:06 --> Output Class Initialized
INFO - 2017-12-16 08:39:06 --> Security Class Initialized
DEBUG - 2017-12-16 08:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 08:39:06 --> Input Class Initialized
INFO - 2017-12-16 08:39:06 --> Language Class Initialized
INFO - 2017-12-16 08:39:06 --> Loader Class Initialized
INFO - 2017-12-16 08:39:06 --> Helper loaded: url_helper
INFO - 2017-12-16 08:39:06 --> Helper loaded: file_helper
INFO - 2017-12-16 08:39:06 --> Helper loaded: date_helper
INFO - 2017-12-16 08:39:06 --> Database Driver Class Initialized
DEBUG - 2017-12-16 08:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 08:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 08:39:06 --> Controller Class Initialized
INFO - 2017-12-16 08:39:07 --> Config Class Initialized
INFO - 2017-12-16 08:39:07 --> Hooks Class Initialized
DEBUG - 2017-12-16 08:39:07 --> UTF-8 Support Enabled
INFO - 2017-12-16 08:39:07 --> Utf8 Class Initialized
INFO - 2017-12-16 08:39:07 --> URI Class Initialized
INFO - 2017-12-16 08:39:07 --> Router Class Initialized
INFO - 2017-12-16 08:39:07 --> Output Class Initialized
INFO - 2017-12-16 08:39:07 --> Security Class Initialized
DEBUG - 2017-12-16 08:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 08:39:07 --> Input Class Initialized
INFO - 2017-12-16 08:39:07 --> Language Class Initialized
INFO - 2017-12-16 08:39:07 --> Loader Class Initialized
INFO - 2017-12-16 08:39:07 --> Helper loaded: url_helper
INFO - 2017-12-16 08:39:07 --> Helper loaded: file_helper
INFO - 2017-12-16 08:39:07 --> Helper loaded: date_helper
INFO - 2017-12-16 08:39:07 --> Database Driver Class Initialized
DEBUG - 2017-12-16 08:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 08:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 08:39:07 --> Controller Class Initialized
INFO - 2017-12-16 08:39:07 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-12-16 08:39:07 --> Final output sent to browser
DEBUG - 2017-12-16 08:39:07 --> Total execution time: 0.0379
INFO - 2017-12-16 08:39:22 --> Config Class Initialized
INFO - 2017-12-16 08:39:22 --> Hooks Class Initialized
DEBUG - 2017-12-16 08:39:22 --> UTF-8 Support Enabled
INFO - 2017-12-16 08:39:22 --> Utf8 Class Initialized
INFO - 2017-12-16 08:39:22 --> URI Class Initialized
INFO - 2017-12-16 08:39:22 --> Router Class Initialized
INFO - 2017-12-16 08:39:22 --> Output Class Initialized
INFO - 2017-12-16 08:39:22 --> Security Class Initialized
DEBUG - 2017-12-16 08:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-12-16 08:39:22 --> Input Class Initialized
INFO - 2017-12-16 08:39:22 --> Language Class Initialized
INFO - 2017-12-16 08:39:22 --> Loader Class Initialized
INFO - 2017-12-16 08:39:22 --> Helper loaded: url_helper
INFO - 2017-12-16 08:39:22 --> Helper loaded: file_helper
INFO - 2017-12-16 08:39:22 --> Helper loaded: date_helper
INFO - 2017-12-16 08:39:22 --> Database Driver Class Initialized
DEBUG - 2017-12-16 08:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-12-16 08:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-12-16 08:39:22 --> Controller Class Initialized
INFO - 2017-12-16 08:39:22 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-12-16 08:39:22 --> Final output sent to browser
DEBUG - 2017-12-16 08:39:22 --> Total execution time: 0.0190
