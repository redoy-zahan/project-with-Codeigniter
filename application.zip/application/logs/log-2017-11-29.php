<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-11-29 14:30:52 --> Config Class Initialized
INFO - 2017-11-29 14:30:52 --> Hooks Class Initialized
DEBUG - 2017-11-29 14:30:52 --> UTF-8 Support Enabled
INFO - 2017-11-29 14:30:52 --> Utf8 Class Initialized
INFO - 2017-11-29 14:30:52 --> URI Class Initialized
DEBUG - 2017-11-29 14:30:52 --> No URI present. Default controller set.
INFO - 2017-11-29 14:30:52 --> Router Class Initialized
INFO - 2017-11-29 14:30:52 --> Output Class Initialized
INFO - 2017-11-29 14:30:52 --> Security Class Initialized
DEBUG - 2017-11-29 14:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-29 14:30:52 --> Input Class Initialized
INFO - 2017-11-29 14:30:52 --> Language Class Initialized
INFO - 2017-11-29 14:30:52 --> Loader Class Initialized
INFO - 2017-11-29 14:30:52 --> Helper loaded: url_helper
INFO - 2017-11-29 14:30:52 --> Helper loaded: file_helper
INFO - 2017-11-29 14:30:52 --> Helper loaded: date_helper
INFO - 2017-11-29 14:30:52 --> Database Driver Class Initialized
DEBUG - 2017-11-29 14:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-29 14:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-29 14:30:52 --> Controller Class Initialized
INFO - 2017-11-29 14:30:52 --> Config Class Initialized
INFO - 2017-11-29 14:30:52 --> Hooks Class Initialized
DEBUG - 2017-11-29 14:30:52 --> UTF-8 Support Enabled
INFO - 2017-11-29 14:30:52 --> Utf8 Class Initialized
INFO - 2017-11-29 14:30:52 --> URI Class Initialized
INFO - 2017-11-29 14:30:52 --> Router Class Initialized
INFO - 2017-11-29 14:30:52 --> Output Class Initialized
INFO - 2017-11-29 14:30:52 --> Security Class Initialized
DEBUG - 2017-11-29 14:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-29 14:30:52 --> Input Class Initialized
INFO - 2017-11-29 14:30:52 --> Language Class Initialized
INFO - 2017-11-29 14:30:52 --> Loader Class Initialized
INFO - 2017-11-29 14:30:52 --> Helper loaded: url_helper
INFO - 2017-11-29 14:30:52 --> Helper loaded: file_helper
INFO - 2017-11-29 14:30:52 --> Helper loaded: date_helper
INFO - 2017-11-29 14:30:52 --> Database Driver Class Initialized
DEBUG - 2017-11-29 14:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-29 14:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-29 14:30:52 --> Controller Class Initialized
INFO - 2017-11-29 14:30:52 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-11-29 14:30:52 --> Final output sent to browser
DEBUG - 2017-11-29 14:30:52 --> Total execution time: 0.0557
INFO - 2017-11-29 14:31:04 --> Config Class Initialized
INFO - 2017-11-29 14:31:04 --> Hooks Class Initialized
DEBUG - 2017-11-29 14:31:04 --> UTF-8 Support Enabled
INFO - 2017-11-29 14:31:04 --> Utf8 Class Initialized
INFO - 2017-11-29 14:31:04 --> URI Class Initialized
INFO - 2017-11-29 14:31:04 --> Router Class Initialized
INFO - 2017-11-29 14:31:04 --> Output Class Initialized
INFO - 2017-11-29 14:31:04 --> Security Class Initialized
DEBUG - 2017-11-29 14:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-29 14:31:04 --> Input Class Initialized
INFO - 2017-11-29 14:31:04 --> Language Class Initialized
INFO - 2017-11-29 14:31:04 --> Loader Class Initialized
INFO - 2017-11-29 14:31:04 --> Helper loaded: url_helper
INFO - 2017-11-29 14:31:04 --> Helper loaded: file_helper
INFO - 2017-11-29 14:31:04 --> Helper loaded: date_helper
INFO - 2017-11-29 14:31:04 --> Database Driver Class Initialized
DEBUG - 2017-11-29 14:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-29 14:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-29 14:31:04 --> Controller Class Initialized
INFO - 2017-11-29 14:31:05 --> Model Class Initialized
INFO - 2017-11-29 14:31:05 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-11-29 14:31:05 --> Final output sent to browser
DEBUG - 2017-11-29 14:31:05 --> Total execution time: 0.2090
INFO - 2017-11-29 14:31:20 --> Config Class Initialized
INFO - 2017-11-29 14:31:20 --> Hooks Class Initialized
DEBUG - 2017-11-29 14:31:20 --> UTF-8 Support Enabled
INFO - 2017-11-29 14:31:20 --> Utf8 Class Initialized
INFO - 2017-11-29 14:31:20 --> URI Class Initialized
INFO - 2017-11-29 14:31:20 --> Router Class Initialized
INFO - 2017-11-29 14:31:20 --> Output Class Initialized
INFO - 2017-11-29 14:31:20 --> Security Class Initialized
DEBUG - 2017-11-29 14:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-29 14:31:20 --> Input Class Initialized
INFO - 2017-11-29 14:31:20 --> Language Class Initialized
INFO - 2017-11-29 14:31:20 --> Loader Class Initialized
INFO - 2017-11-29 14:31:20 --> Helper loaded: url_helper
INFO - 2017-11-29 14:31:20 --> Helper loaded: file_helper
INFO - 2017-11-29 14:31:20 --> Helper loaded: date_helper
INFO - 2017-11-29 14:31:20 --> Database Driver Class Initialized
DEBUG - 2017-11-29 14:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-11-29 14:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-29 14:31:20 --> Controller Class Initialized
INFO - 2017-11-29 14:31:20 --> Model Class Initialized
INFO - 2017-11-29 14:31:20 --> File loaded: /home/thestudytown/public_html/mcq/application/views/login/login.php
INFO - 2017-11-29 14:31:20 --> Final output sent to browser
DEBUG - 2017-11-29 14:31:20 --> Total execution time: 0.0359
