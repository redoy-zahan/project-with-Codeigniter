<?php 
/**
* All student Task:
*/
class Stud_Model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}

	public function userInfo($id){
		$this->db->select('*');
		$this->db->where('id', $id);
		$user = $this->db->get('user');
		return $user->result();


	}

	public function show_user_info($id){
		
		$this->db->select('*');
		$this->db->where('id', $id);
		$user = $this->db->get('user');
		return $user->result();
		
	}

	public function update_info($id, $data)
	{
		$this->db->where('id', $id);	
		$update = $this->db->update('user', $data);
		//var_dump($update);
		//exit();
		return $update;

	}

#end class breacket:
}