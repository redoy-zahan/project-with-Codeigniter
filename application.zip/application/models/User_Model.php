<?php
/**
* 
*/
class User_Model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();

	}
#check user access and if user valid, will give access to user:
	public function userLogin($email, $password){
		$this->db->select('email, password');
		$this->db->where('email',$email);	
		$this->db->where('password',$password);
		$this->db->from('user');
		$query = $this->db->get();
		return $query->num_rows();

	}

#retriving all information about user to store in session:
	public function userData($email){
		 
		$this->db->select('*');
		$this->db->where('email',$email);	
		$this->db->from('user');
		$query = $this->db->get();
		return $query->result();
		
	}

	public function registerData($data){
		$insert = $this->db->insert('user', $data);
		/*var_dump($insert);
		exit();*/
		if ($insert) {
			return true;
		}
		return false;
	}


	

}