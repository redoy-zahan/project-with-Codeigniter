<?php 
/**
* 
*/
class Admin_Model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
		
	}

	public function delete_data($id, $table){
		$this->db->where('id', $id);
   		return $this->db->delete($table); 
	}
	

	public function get_all_user(){
		$this->db->select('*');
		$this->db->where('user_type', 2);
		$user = $this->db->get('user');
		return $user->result();

	}

	public function userDelate($id)
	{
		$this->db->where('id', $id);
		$delate = $this->db->delete('user');

		return $delate;
	}




}