<?php 
/**
* Student Base Controller:
*/
abstract class Student_Controller extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	var $template  = array();
    var $data      = array();
   //Load layout    
   public function layout() {
     // making temlate and send data to view.
	    $this->template['header']=$this->load->view('layout_student/header', 
	    $this->data, true);
	    /*$this->template['left'] = $this->load->view('layout_student/left', 
	    $this->data, true);*/
	    $this->template['middle']= $this->load->view($this->middle, 
	    $this->data, true);
	    $this->template['footer']= $this->load->view('layout_student/footer',
	    $this->data, true);
	    
	    $this->load->view('layout_student/index', $this->template);
   }


#for all message alert:
	

#for redirect smoothly:
	public function Fredirect($url, $delay = 0) {
	    try {
	      if (!headers_sent() && $delay == 0) {
	        ob_end_clean();
	        header("Location: " . $url);
	      }
	      // Performs a redirect once headers have been sent
	      echo "<meta http-equiv=\"Refresh\" content=\" ". $delay . "; URL=" . $url . "\">";
	      exit();
	    } catch (Exception $err) {
	      return $err->getMessage();
	    }

    }





#sms send function and sms api:
	

	



#End Class bracket:	
}