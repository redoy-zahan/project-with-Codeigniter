<?php 
trait Common_Function_Trait{

	public function delete_by_trait($id, $table){
		$this->load->model('Common_Model');
	  return $this->Common_Model->delete_data($id, $table);

	}





#end trait bracket:	
}