<?php 
/**
* All admin task goes from here...Admin Base Controller:
*/
abstract class Admin_Controller extends CI_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	}

	 //set the class variable.
   public $template  = array();
   public $data      = array();
   //Load layout    
   public function layout() {
     // making temlate and send data to view.
	    $this->template['header']=$this->load->view('layout_admin/header', 
	    $this->data, true);
	    //$this->template['left'] = $this->load->view('layout_admin/left', 
	   // $this->data, true);
	    $this->template['middle']= $this->load->view($this->middle, 
	    $this->data, true);
	    $this->template['footer']= $this->load->view('layout_admin/footer',
	    $this->data, true);
	    $this->load->view('layout_admin/index', $this->template);
   }


#check if it admin:
public function checkUser(){
		/*$this->session->unset_userdata('id');*/
		if ($this->session->userdata('logged_in')==false){

			$url =base_url("Auth_Controller/index");
			$this->Fredirect($url);

		}elseif($this->session->userdata('userType')==2) {
			$url =base_url("Stud_Controller/index");
			$this->Fredirect($url);
			

		}
		

	}

#super admin:
	public function super_admin(){
		if ($this->session->userdata('userType')==2) {
			$url =base_url("Welcome");
			$this->Fredirect($url);
			
		}
	}


#for all message alert:
	

#for redirect smoothly:
	public function Fredirect($url, $delay = 0) {
	    try {
	      if (!headers_sent() && $delay == 0) {
	        ob_end_clean();
	        header("Location: " . $url);
	      }
	      // Performs a redirect once headers have been sent
	      echo "<meta http-equiv=\"Refresh\" content=\" ". $delay . "; URL=" . $url . "\">";
	      exit();
	    } catch (Exception $err) {
	      return $err->getMessage();
	    }

    }

	   




	
}