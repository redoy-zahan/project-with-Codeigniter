<!DOCTYPE html>
<html>
<head>
	<title>BLOOD DONATE</title>
	<link rel="stylesheet" href="<?php echo base_url ('assets/css/bootstrap.min.css')?>">
	<link rel="stylesheet" href="<?php echo base_url ('assets/css/style.css')?>">
	<link rel="stylesheet" href="<?php echo base_url ('assets/css/fontawesome.min.css')?>">

	
</head>

<body>

	  <header>
		<div class="logo">
			<img src="<?php echo base_url('assets/img/images.jpg')?>" style="width: 100px;margin-left: 227px;">
			<div class="site-title">Blood Bank BD</div>
		</div>
	</header>

<body>
 <?php //if($left) echo $left ;?>
 <?php if($header) echo $header ;?>
 <?php if($middle) echo $middle ;?>
 <?php if($footer) echo $footer ;?>
</body>
</html>