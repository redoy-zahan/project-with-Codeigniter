
<nav class="navbar navbar-light " style="background-color: #DAA520;">
	<a class="navbar-brand" href="#"></a>
	<ul>
		<li><a href="<?php echo base_url('/');?>"><span class="fa fa-home"></span>Home</a></li>
	<li><a href="<?php echo base_url('Home/donate');?>"><span class="fa fa-why"></span>Why Donate Blood?</a></li>
	<li><a href=" <?php echo base_url('Home/need');?>"><span class="fa fa-need"></span>Why Need Blood?</a></li>
	<li><a href= "<?php echo base_url('Home/contact');?>">Contact Us</a></li>
	

	<?php if ($this->session->userdata('logged_in')==true) { ?> 

		<li><a href="<?php echo base_url('Welcome');?>">My Account</a></li>
		<li><a href="<?php echo base_url('Auth_Controller/logout');?>"><span class="fa fa-register"></span>Logout</a></li>

	<?php } else { ?>

		<li><a href="<?php echo base_url('Register/index');?>"><span class="fa fa-register"></span>Register</a></li>
		<li><a href="<?php echo base_url('Auth_Controller/index');?>">Login</a></li>

	<?php } ?>
</ul>
</nav>

