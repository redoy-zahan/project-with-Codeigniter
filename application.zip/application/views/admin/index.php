<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel ="stylesheet" href="css/bootstrap.min.css">


   <div class=" col-sm-2 col-md-2 "> </div>
   <div class=" col-sm-7 col-md-7 " >
   <?php if($this->session->flashdata('msg') != '') { ?>
          <div class="alert alert-<?php echo $this->session->flashdata('alert')?>"><?php echo $this->session->flashdata('msg');?></div>

    <?php } ?> 
  <div class="panel panel-info">
    <div class="panel-heading">
      <h3 class="panel-title">User List</h3>
    </div>
    <div class="panel-body">
        
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Country</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              <?php foreach($allUsers as $allUser) { ?>
              <tr>
                <td><?php echo $allUser->name?></td>
                <td><?php echo $allUser->email?></td>
                <td><?php echo $allUser->phone?></td>
                <td><?php echo $allUser->country?></td>

                <td>
                    <a href="<?php echo base_url('Welcome/deleteUser/').base64_encode($allUser->id); ?>" class="btn btn-warning" >Delete</a>
                </td>
              </tr>

              <?php } ?>
             
            </tbody>
          </table>
      </div>
      <div class="panel-footer"></div>
    </div>
    </div>
    <div class="col-sm-3 col-md-3"></div>
                    
           
       

      