<section style="margin-top: 20px;">
<div class="container">

		<div class="columleft">

			<div style=" no-repeat  right; width:487px; height:250px;">
				<div style="padding: 35px 35px 0px 35px">
			
				<div><font style="font: bold 24px times new roman;color:#1C6177;">Are you ready to save a life?</font><br><font style="color:#1C6177;" class="bigtxt"><b>Are you ready to registered donors on Blood Bank BD?</b></font></div>
				<div style="padding:50px 120px 0px 0px;"><font style="color:#1C6177;" class="bigtxt">Blood Bank BD a non-profit, non-commercial interface was born out of our social commitment and our desire to use the power of the Internet to help common people. <br><br>
				<b>Want to save a life?</b>
				<br>Then Please Register & save life
			</font>

				
				</div>
			</div>
		</div>
	</div>
</div>

</section>