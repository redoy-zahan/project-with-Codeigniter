<!DOCTYPE html>


	 <div class=" col-sm-2 col-md-2 "> </div>
   <div class=" col-sm-7 col-md-7 " >
   
    
  <div class="panel panel-danger">
    <div class="panel-heading">
      <h3 class="panel-title">Why Donate Blood</h3>
    </div>
    <div class="panel-body">
        
          Blood is the living fluid that all life is based on. Blood is composed of 60% liquid part and 40% solid part. The liquid part called Plasma, made up of 90% water and 10% nutrients, hormones, etc. is easily replenished by food, medicines, etc. But the solid part that contains RBC (red blood cells), WBC (white blood cells) and Platelets take valuable time to be replaced if lost.

          This is where you come in. The time taken by a patient's body to replace it could cost his/her life. Sometimes the body might not be in a condition to replace it at all.

          As you know blood cannot be harvested it can only be donated. This means only you can save a life that needs blood.

          Every year India requires 40 million units of 250cc blood out of which only a meager 500,000 of blood units are available.
      </div>
      <div class="panel-footer"></div>
    </div>
    </div>
    <div class="col-sm-3 col-md-3"></div>
                    
           



 
</div>
</section>

</body>
</html>