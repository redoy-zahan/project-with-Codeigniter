

	<section id="contact">
            
            <div class="contact-section">            <div class="container">
                <form>
                    <div class="col-md-6 form-line">
                        <div class="form-group">
                            <label for="exampleInputUsername">Your name</label>
                            <input type="text" class="form-control" id="" placeholder=" Enter Name" style="width:70%"
                            color="green">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail">Email Address</label>
                            <input type="email" class="form-control" id="exampleInputEmail" placeholder=" Enter Email id" style="width:70%">
                        </div>  
                        <div class="form-group">
                            <label for="telephone">Mobile No.</label>
                            <input type="tel" class="form-control" id="telephone" placeholder=" Enter mobile no." style="width:70%">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for ="description"> Message</label>
                            <textarea  class="form-control" id="description" placeholder="Enter Your Message" style="width:70%; height:400%">
                        
                            </textarea>
                        </div>
                            <div>

                            <button type="button" class="btn btn-warning">  Send Message </button>
                        </div>
                        
                    </div>
                </form>
            </div>
        </section>
           



 
					
				
		
			
		
</div>
</section>

