<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Log In</title>

    <!-- Bootstrap Core CSS -->
<link href="<?php echo base_url('assets/css/bootstrap.css');?>" rel="stylesheet">
    
    <!-- Custom CSS -->
    <!-- Custom Fonts -->
</head>
<body>
<style type="text/css">
    .config{
    margin-top: 15px;
}
</style>
     <!-- Page Content -->
    <div class="container" style="margin-top: 100px;">
        <!-- Marketing Icons Section -->
        <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">   

            <?php echo ($this->session->flashdata('message'));?>

    <div class="panel panel-default">
        <div class="panel-heading">
         <h4><i class="fa fa-fw fa-check"></i>Login Here</h4>
        </div>
        <div style="color:red;"><?php if (isset($msg)) {echo $msg;} ?></div>
        <div class="panel-body clearfix">
<form action="<?php echo base_url('Auth_Controller/loginUser');?>" method="post">

        <div class="config">
        <label>Email</label>
    <input class="form-control" type="text" required="1" name="email">
        </div>

         <div class="config">
        <label>Password</label>
    <input class="form-control" type="password" name="password" required="1">
    </select>
        </div>

        <div style="clear:both;"></div>  
        <div class="panel-footer"> 
       <button type="submit" name="login" style="border: none;height:30px;width: 100px;margin-left:-12px;" class="btn btn-primary">Login</button>   
        </div>
		</form>
	</div></div>	


    <!-- Bootstrap Core JavaScript -->
   