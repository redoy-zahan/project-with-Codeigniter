    <html>
    <head>
        <title>Register</title>
       <meta charset="utf-8">
         <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel ="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">
    </head>
    <body>
    <header>
        <div class="collapse navbar-collapse">
        <div class="navbar-nav">

          
        </div>
      </div>
      </header>

    <div class="container" style="margin-left: 20%;">
        <form class="form-horizontal" method="post" action="<?php echo base_url('Register/registerUser')?>">
            <h2 style="text-align: center; padding: 33px; margin-right: 60%;">Registration Form</h2>


            <span style="text-align: center;"><?php if (isset($_GET['msg'])) {
                echo $_GET['msg'];
                 }  ?>
            </span>

            <div class="form-group">
                <label for="firstName" class="col-sm-3 control-label">Name</label>
                <div class="col-sm-9">
                <input type="text"  placeholder=" Name" name="name" id="name" class="form-control" autofocus="" style="width: 50%;">                        
                </div>
            </div>

            <div class="form-group">
                <label for="email" class="col-sm-3 control-label">Email</label>
                <div class="col-sm-9">
                    <input type="email" id="email" placeholder="Email"  name="email" class="form-control" 
                    style="width:50%;">
                </div>
                 <div class="form-group">
                <label for="Phone" class="col-sm-3 control-label">Phone</label>
                <div class="col-sm-9">
                    <input type="Phone" name="phone" id="phone" placeholder="+088" class="form-control"  style="width: 50%;">
                </div>
            </div>
            </div>
            <div class="form-group">
                <label for="userName" class="col-sm-3 control-label">user Name </label>
                <div class="col-sm-9">
                    <input type="text" id="user_name" placeholder="user name"  name="user_name" class="form-control" 
                    style="width:50%;">
                </div>
            </div>
            
            
            <div class="form-group">
                <label for="birthDate" class="col-sm-3 control-label">Date of Birth</label>
                <div class="col-sm-9">
                    <input type="date" id="birthDate" name="dob" class="form-control"  style="width: 50%;">
                </div>

                <div class="form-group">
                <label for="weight" class="col-sm-3 control-label">weight</label>
                <div class="col-sm-9">
                    <input type="text" id="weight" name="weight" placeholder="weight" class="form-control"  style="width: 50%;">
                </div>
            </div>


            <div class="form-group">
                <label for="blood group" class="col-sm-3 control-label">Blood Group</label>
                <div class="col-sm-9">
                    <select id="blood group" name="blood_group" class="form-control"  style="width: 50%;">
                        <option>select group</option>
                        <option>A+</option>
                        <option>A-</option>
                        <option>B+</option>
                        <option>B-</option>
                        <option>O+</option>
                        <option>O-</option>
                        <option>AB+</option>
                        <option>AB-</option>
                    </select>
                </div>
            </div>

             <div class="form-group">
                <label for="country" class="col-sm-3 control-label">country</label>
                <div class="col-sm-9">
                    <select id="country" name="country" class="form-control"  style="width: 50%;">
                        <option>select </option>
                        <option>Bangladesh</option>
                        <option>India</option>
                        <option>Pakistan</option>
                        <option>Nepal</option>
                        <option>Bhutan</option>
                        <option>Srilanka</option>
                        <option>Maldip</option>
                        <option>Afganistan</option>
                    </select>
                </div>
            </div> 

            <div class="form-group">
                <label class="control-label col-sm-3">Gender</label>
                <div class="col-sm-6">
                    <div class="row">
                        <div class="col-sm-4">
                            <label class="radio-inline">
                                <input type="radio" name="gender" id="femaleRadio" value="Female">Female
                            </label>
                        </div>
                        <div class="col-sm-4">
                            <label class="radio-inline">
                                <input type="radio" name="gender" id="maleRadio" value="Male">Male
                            </label>
                        </div>
                       
                     </div>
            </div> <!-- /.form-group -->
            
            
            <div class="form-group">
                <div class="col-sm-9 col-sm-offset-3">
                    <button type="submit" value="1" name="register" class="btn btn-primary btn-block" style="width: 50%;">Register</button>
                </div>
            </div>
        </form> <!-- /form -->
    </div> <!-- ./container -->
    </form>
    </body>
    </html>