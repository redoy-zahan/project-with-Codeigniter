        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad" >
   
   
          <div class="panel panel-info">
            <div class="panel-heading">
              <h3 class="panel-title">Update Information</h3>

            </div>

            <form action ="<?php echo base_url('Stud_controller/updateInfo'); ?>" method="post">

            <div class="panel-body">
              <div class="row">
                <div class="col-md-3 col-lg-3 " align="center"> <img  src="<?php echo base_url('assets/img')?>/download.png"  style="width:80%"> </div>

                <?php foreach($user_info as $dt):?>

                <input type="hidden" name="user_id" value="<?php echo $dt->id?>">
                
                <div class=" col-md-9 col-lg-9 "> 

                  <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo $dt->name?>">
                  </div>
                  
                   <div class="form-group">
                    <label for="email">Email</label>
                    <input type="Email" name="email" class="form-control" value="<?php echo $dt->email?>">
                  </div>
                  
                   <div class="form-group">
                    <label for="Phone">Phone Number</label>
                    <input type="text" name="phone" class="form-control" value="<?php echo $dt->phone?>">
                  </div>
                  
                   <div class="form-group">
                    <label for="birthdate">Date of Birth</label>
                    <input type="date" name="dob" class="form-control" value="<?php echo $dt->dob?>">
                  </div>
                  
                   <div class="form-group">
                    <label for="gender">Gender</label>
                    <input type="text" name="gender" class="form-control" value="<?php echo $dt->gender?>">
                  </div>

                  <div class="form-group">
                    <label for="country">Country</label>
                    <input type="text" name="country" class="form-control" value="<?php echo $dt->country?>">
                  </div>
                  
  
                </div>
              </div>

  <div class="panel-footer"  style="text-align: center;">
    <button type="submit"  class="btn btn-primary" name="update" value="1">Update</button>

  </div>
</form>

   <?php endforeach;?>
</div></div></div>