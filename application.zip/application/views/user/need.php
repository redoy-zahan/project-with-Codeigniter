
 <div class=" col-sm-2 col-md-2 "> </div>
 <div class=" col-sm-7 col-md-7 " >
 
  
<div class="panel panel-danger">
  <div class="panel-heading">
    <h3 class="panel-title">Who Need Blood</h3>
  </div>
  <div class="panel-body">
      
       <h4>Who needs blood?</h4>

        Every 2 seconds someone needs blood. Your blood helps more than one life at a time. Accident victims, premature babies, patients undergoing major surgeries require whole blood, where your blood after testing is used directly. Patients suffering from trauma, anemia, and other surgeries require only red blood cells, which is separated from your blood. The procedure of splitting blood components is called Cytapheresis. Similarly blood platelets are used for cancer patients undergoing chemotherapy or for those undergoing treatment for dengue fever etc. Fresh frozen plasma is used for patients having massive transfusions, plasma is used for burns and cryoprecipitate is used for hemophilia.
        <br>

        <h4>When is blood needed?</h4>

        Blood is needed at regular intervals and at all times as it has only finite time of storage. Red blood cells can be stored for about 42 days, fresh frozen plasma and cryoprecipitate for 365 days and blood platelets for 5 days.
        <br>

        <h4>Who can donate blood?
        </h4>
        <br>
        Anyone above 18 years weighing more than 50 kgs (110 lbs) can donate blood
            </div>
      <div class="panel-footer"></div>
    </div>
  </div>
<div class="col-sm-3 col-md-3"></div>
                          
                 




        </div>
        </section>

