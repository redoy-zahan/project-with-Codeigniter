<?php 

$array1 = array();
$array2 = array();
$array3 = array();
$array4 = array();

foreach ($chart as $key => $value) {
	array_push($array1, $value);
	}

/*foreach ($array1 as $key => $value) {
	array_push($array2, $value);
}*/

array_push($array2, $array1);
array_push($array3, $array2);


/*echo "<pre>";
print_r($array3);
echo "</pre>";*/



// foreach ($array4 as $key => $value) {
// 	$valu = array_values($array4);
// 	print_r($valu);
// }
