	<footer class="footer-fixed">
		
	</footer>
	</div>
		<!-- END MAIN -->
	</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script type="text/javascript">
		console.log(myUrl);
	</script>

	<script src="<?php echo base_url('assets/js/jquery/jquery-2.1.0.min.js');?>"></script>
	 <script src="<?php echo base_url('assets/js/bootstrap/bootstrap.min.js'); ?>"></script> 

	<script src="<?php echo base_url('assets/js/plugins/jquery-slimscroll/jquery.slimscroll.min.js'); ?>"></script>

	<script src="<?php echo base_url('assets/js/plugins/jquery-easypiechart/jquery.easypiechart.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/chartist/chartist.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/klorofil.min.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap-datepicker.js"></script>

 	 <script type="text/javascript" src="<?php echo base_url();?>assets/js/myjs.js"></script> 

 	 <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.unobtrusive-ajax.js"></script>

 	