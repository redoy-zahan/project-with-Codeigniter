<script type="text/javascript">
	 <?php echo "var myUrl ='".base_url()."';"; ?>
</script>

<div class="main">
<!-- NAVBAR -->
<nav class="navbar navbar-default">
<div class="container-fluid">
<div class="navbar-btn">
</div>

<div id="navbar-menu" class="navbar-collapse collapse">

	<ul class="nav navbar-nav navbar-left">
	
	<li class="full-left" ><h3>Admin Panel</h3></li>
		</ul>
	</li>
</ul>

<ul class="nav navbar-nav navbar-right">
	<?php   
	$uname = $this->session->userdata('userName');
	$name = $this->session->userdata('name'); 

	?>
	
	<li class="dropdown">
	<a href="#" class="dropdown-toggle" data-toggle="dropdown">
	<span><?php echo $name; ?></span> <i class="icon-submenu lnr lnr-chevron-down"></i></a>
		<ul class="dropdown-menu">
		<!-- <li><a href="#"><i class="lnr lnr-user"></i> <span>My Profile</span></a></li> -->
		<!-- <li><a href="#"><i class="lnr lnr-cog"></i> <span>Settings</span></a></li> -->
		<li><a href="<?php echo base_url('Auth_Controller/logout');
		?>"><i class="lnr lnr-exit"></i> <span>Logout</span></a></li>
		</ul>
	</li>
</ul>
</div>
</div>
</nav>