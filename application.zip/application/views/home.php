<div style="height:500px; width:70%; border:2px solid #000; float:left;"> Middle Area</div>
