<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>MCQ Exam System</title>

    <!-- Bootstrap Core CSS -->
<link href="<?php echo base_url();?>assests/css/bootstrap.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <!-- Custom Fonts -->
</head>
<body>
<style type="text/css">
    .config{
    margin-top: 15px;
}
</style>

<?php if (isset($success)):?>
<div class="alert alert-success alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<h4><i class="icon fa fa-check"></i> Success Alert!</h4>
	<?php echo $success; ?>
</div>
<?php endif; ?>

<?php if(isset($info)): ?>
<div class="alert alert-info alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<h4><i class="icon fa fa-info"></i> Info Alert!</h4>
	<?php echo $info; ?>
</div>
<?php endif; ?>

<?php if(isset($warning)): ?>
<div class="alert alert-warning alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<h4><i class="icon fa fa-warning"></i> Warning Alert!</h4>
	<?php echo $warning ?>
</div>
<?php endif; ?>

<?php if(isset($error)): ?>
<div class="alert alert-danger alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<h4><i class="icon fa fa-ban"></i> Error Alert!</h4>
	<?php echo $error; ?>
</div>
<?php endif; ?>

  
</body>
</html>